# FTK OS - Quick Start Guide

## Prerequisites

```bash
# Ubuntu/Debian
sudo apt update && sudo apt install -y \
  build-essential gcc make nasm qemu-system-x86 ovmf \
  mtools sgdisk python3

# Arch
sudo pacman -S --needed base-devel gcc make nasm qemu-system-x86 ovmf \
  mtools gptfdisk python3

# Fedora
sudo dnf install -y gcc make nasm qemu-system-x86 edk2-ovmf \
  mtools sgdisk python3
```

## Build & Run (3 Commands)

```bash
# 1.the project
cd /path/to/ftkos_gui

# 2. Build everything (kernel, bootloader, userspace, disk image)
make all

# 3. Run in QEMU with GUI display
make run
```

That's it. The OS will:
1. Boot via UEFI (OVMF)
2. Initialize kernel (memory, scheduler, drivers)
3. Mount FAT32 + ramfs
4. Launch window manager with Calculator, Calendar, Terminal

## Alternative Run Commands

```bash
# Run with GTK display (better on some systems)
make run-gtk

# Run without KVM (slower, works everywhere)
make run-nokvm

# Run headless (serial only, for CI/automation)
make run-headless
```

## Keyboard Controls in the Desktop

| Key | Action |
|-----|--------|
| `F1` | Open Calculator |
| `F2` | Open Calendar |
| `F3` | Open Terminal |
| `Alt + Arrow Keys` | Move software mouse cursor |
| `Enter` | Click at cursor position |
| `Ctrl + Tab` | Cycle window focus |
| `Ctrl + W` | Close focused window |
| `Ctrl + C` (in Calculator) | Copy display to clipboard |
| `Ctrl + V` (in Terminal) | Paste from clipboard |

## Terminal Commands (inside Terminal app)

```bash
# Basic commands
ls
cat hello.txt
echo hello
ps
clear

# Run programs
spawn /bin/ls
spawn /bin/cat hello.txt

# Shell built-ins
help
exit
```

## Verify It's Working

After `make run`, you should see:
1. QEMU window opens with FTK OS desktop
2. Gradient background (dark blue → purple)
3. Taskbar at bottom with "FTK OS" logo and clock
4. Two windows auto-open: Calculator (top-left) and Calendar (top-right)
4. Press `F3` → Terminal window opens with real shell
5. Type `ls` in terminal → shows `/bin` contents

## Troubleshooting

**OVMF not found:**
```bash
# Find your OVMF path
find /usr -name "OVMF*.fd" 2>/dev/null

# Then run with explicit path
OVMF_CODE=/usr/share/OVMF/OVMF_CODE.fd make run
```

**No KVM (running in VM/CI):**
```bash
make run-nokvm
```

**Build fails:**
```bash
make clean && make all
```

**Black screen / no display:**
```bash
# Try different display backend
SDL_VIDEODRIVER=x11 make run
# or
GDK_BACKEND=x11 make run
```

## Project Structure

```
ftkos_gui/
├── kernel/           # Kernel source
│   ├── arch/x86_64/  # x86_64 specific
│   ├── mm/           # Memory management
│   ├── sched/        # Scheduler
│   ├── syscall/      # System calls
│   └── drivers/      # Device drivers
├── boot/efi/         # UEFI bootloader
├── user/             # Userspace programs
│   ├── lib/gui.*     # GUI library
│   └── src/          # init, fsh, wm, etc.
└── tests/            # Integration/unit tests
```

## Run Tests

```bash
# All tests (unit + integration + regression)
make test

# Just integration tests
make -C tests integration

# Just regression tests
make -C tests regression
```

## Expected Serial Output (on success)

```
[ OK ] Memory initialized
[ OK ] Paging enabled
[PER-CPU] CPU 0 (APIC 0) initialized (BSP)
[INFO] Kernel booted successfully (Graphics Enabled)
[INIT] User-mode init task created (PID: 1)
[SCHED] Multi-tasking enabled. Switching to first task...
[SCHED] Switching to task PID 1 (init)
INI
[EXEC] PID 1 executing '/bin/wm'
wm: started
```