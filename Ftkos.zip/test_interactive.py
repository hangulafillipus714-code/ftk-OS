#!/usr/bin/env python3
"""Interactive FTK OS test — wait for prompt, send commands, check output."""

import socket, time, sys, subprocess, re

QEMU_CMD = [
    'qemu-system-x86_64', '-machine', 'q35',
    '-bios', '/usr/share/ovmf/OVMF.fd',
    '-drive', f'format=raw,file=build/ftk_uefi.img',
    '-net', 'none',
    '-serial', 'tcp::4568,server=on,wait=off',
    '-m', '2G', '-no-reboot', '-display', 'none',
]

proc = subprocess.Popen(QEMU_CMD, stderr=subprocess.DEVNULL, stdout=subprocess.DEVNULL)

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
for attempt in range(30):
    try:
        s.settimeout(1); s.connect(('127.0.0.1', 4568)); break
    except:
        time.sleep(1)
else:
    proc.kill()
    print("[!] Connection failed"); sys.exit(1)

s.settimeout(0.5)

all_output = b''
def wait_for(pattern, timeout=20):
    """Wait until pattern appears in serial output."""
    global all_output
    t0 = time.time()
    while time.time() - t0 < timeout:
        try:
            d = s.recv(65536)
            if d: all_output += d
        except socket.timeout:
            pass
        if pattern.encode() in all_output:
            return True
        time.sleep(0.1)
    return False

def send(cmd):
    s.sendall((cmd + '\n').encode())

def drain():
    global all_output
    data = b''
    t0 = time.time()
    while time.time() - t0 < 2:
        try:
            d = s.recv(65536)
            if d: data += d; all_output += d
        except socket.timeout:
            break
    return data.decode('utf-8', errors='replace')

print("[*] Booting OS...")
if not wait_for("ftk>", 30):
    print("[!] Shell prompt not found")
    print(f"    Output so far: {all_output[-500:].decode('utf-8', errors='replace')}")
    proc.kill()
    sys.exit(1)
print("[*] Shell is ready")
drain()  # Drain prompt

tests_passed = 0
tests_total = 0

# Test 1: echo via spawn
tests_total += 1
send("echo hello world")
time.sleep(1)
out = drain()
if "hello world" in out:
    print(f"  PASS echo 'hello world'")
    tests_passed += 1
else:
    print(f"  FAIL echo: {repr(out[:300])}")

# Test 2: ps
tests_total += 1
send("ps")
time.sleep(1)
out = drain()
if "PID" in out:
    print(f"  PASS ps")
    tests_passed += 1
else:
    print(f"  FAIL ps: {repr(out[:300])}")

# Test 3: ls /
tests_total += 1
send("ls /")
time.sleep(1)
out = drain()
if "bin" in out or "EFI" in out or "hello.txt" in out:
    print(f"  PASS ls /")
    tests_passed += 1
else:
    print(f"  FAIL ls /: {repr(out[:300])}")

# Test 4: spawn /bin/echo directly
tests_total += 1
send("spawn /bin/echo spawn_test")
time.sleep(1)
out = drain()
if "spawn_test" in out:
    print(f"  PASS spawn /bin/echo")
    tests_passed += 1
else:
    print(f"  FAIL spawn /bin/echo: {repr(out[:300])}")

# Test 5: cat /hello.txt
tests_total += 1
send("cat /hello.txt")
time.sleep(1)
out = drain()
if "Hello from FTK" in out:
    print(f"  PASS cat /hello.txt")
    tests_passed += 1
else:
    print(f"  FAIL cat: {repr(out[:300])}")

# Test 6: pipe (echo hello | cat)
tests_total += 1
send("echo pipe_test | cat")
time.sleep(2)
out = drain()
if "pipe_test" in out:
    print(f"  PASS pipe 'echo pipe_test | cat'")
    tests_passed += 1
else:
    print(f"  FAIL pipe: {repr(out[:300])}")

print(f"\n=== {tests_passed}/{tests_total} passed ===")

proc.terminate()
try: proc.wait(5)
except: proc.kill()
s.close()
sys.exit(0 if tests_passed == tests_total else 1)
