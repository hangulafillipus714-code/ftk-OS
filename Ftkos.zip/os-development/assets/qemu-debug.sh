#!/bin/bash
# Template QEMU launch script for OS development
# Adjust paths, disk image, and Limine/ISO as needed.

KERNEL=${1:-build/kernel.elf}
DISK=${2:-disk.img}

qemu-system-x86_64 \
  -machine q35 \
  -cpu max \
  -m 512M \
  -smp 1 \
  -serial stdio \
  -s -S \
  -no-reboot \
  -d int,cpu_reset,guest_errors \
  -drive file="$DISK",format=raw,if=none,id=hd \
  -device ahci,id=ahci \
  -device ide-hd,drive=hd,bus=ahci.0 \
  -kernel "$KERNEL" \
  "$@"
