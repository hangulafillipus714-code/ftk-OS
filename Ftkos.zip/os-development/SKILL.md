---
name: os-development
description: Guide agents through end-to-end hobby and from-scratch operating system development on x86-64 (primary) and other arches. Covers recommended implementation order, boot, memory management, interrupts, drivers, processes, filesystems, userland, debugging with QEMU+GDB, common pitfalls, and turning a kernel into a usable OS. Trigger on OS project work, kernel bugs, page faults after context switch, AHCI/FAT issues, scheduler problems, or requests to build a complete useful OS.
---

# OS Development Skill

## Core Mission

Help the agent produce a **useful, complete, bootable operating system** that can run real user programs, not just a "hello world" kernel. Prioritize correctness, debuggability, and incremental progress over features.

Always prefer modern practices: Limine (or equivalent) bootloader, higher-half 64-bit kernel, proper page tables shared for kernel, robust serial logging, QEMU + GDB workflow.

## Recommended Implementation Order (Dependency-Driven)

Follow this order strictly unless there is a strong reason otherwise. Each stage must be stable and debuggable before moving on.

### Phase 0 – Foundations (do first)
1. Cross-compiler toolchain (x86_64-elf-gcc or equivalent). Never use the host compiler for the kernel.
2. Version control (git) + reproducible build system (Make/CMake + scripts).
3. Serial console output (COM1 / UART) as primary debug channel. Framebuffer is secondary.
4. Panic / halt with clear message + register dump.
5. QEMU launch scripts with `-serial stdio -s -S` support for GDB.

### Phase 1 – Boot & Early Kernel
1. Use **Limine** (preferred) or Multiboot2 + GRUB. Avoid writing your own bootloader initially.
2. Higher-half kernel (recommended base `0xFFFFFFFF80000000` or similar).
3. Early identity mapping + higher-half mapping so the kernel can run after enabling paging.
4. GDT (null, kernel code/data, user code/data, TSS).
5. IDT with exception handlers (especially #PF, #GP, #DF, #NP). Double-fault must be safe.
6. Basic `kprintf` / logging that works before and after paging.

### Phase 2 – Memory Management (critical path)
1. Physical memory manager (PMM) – bitmap or buddy from Limine memmap.
2. Virtual memory manager (VMM) – page table manipulation, map/unmap, higher-half physical window.
3. **Kernel must be mapped into every process address space** (copy higher-half PML4 entries or share).
4. Kernel heap (kmalloc/kfree) – start simple (bump or freelist), later slab.
5. Stack allocation for kernel threads and later user processes.

**Common killer bug**: Switching CR3 to a process page table that does not contain the kernel → instant cascade of page faults with `rip == cr2` in kernel text. Fix by always installing kernel mappings.

### Phase 3 – Interrupts & Hardware Basics
1. Disable legacy PIC, set up Local APIC + I/O APIC (from MADT).
2. Timer (PIT or APIC timer) for scheduling ticks.
3. Keyboard (PS/2 or USB later).
4. Proper interrupt stacking, EOI, and IRQ routing.

### Phase 4 – Processes & Scheduling
1. Task / process structure (kernel stack, user stack, CR3, registers, PID, state).
2. Context switch (save/restore, TSS rsp0 update, CR3 load).
3. Simple round-robin or priority scheduler.
4. Syscall interface (syscall/sysret or int 0x80) with proper user/kernel stack switch.
5. Load and run first user ELF (`init`).

**Critical**: On every context switch update TSS.rsp0 **before** loading new CR3 or returning to user mode. Kernel stack must never be null.

### Phase 5 – Storage & Filesystems
1. AHCI / SATA or virtio-blk driver.
2. VFS layer (mount points, open/read/write/close, dentries/inodes).
3. FAT32 (or ext2) as first filesystem – enough to load more programs.
4. Initramfs or early disk image for `/EFI/FTK/init.elf` style loading.

### Phase 6 – Userland & Usability
1. Minimal libc (or port musl parts).
2. Init process that starts a shell.
3. Basic shell + utilities (ls, cat, echo, etc.).
4. Proper process lifecycle (fork/exec/wait/exit if desired).
5. Framebuffer console or graphical output if wanted.

### Phase 7 – Completeness & Polish
- SMP (bring up APs).
- Networking (virtio-net).
- Better memory (demand paging, swap later).
- Security (SMEP/SMAP, W^X, user/kernel separation).
- Self-hosting toolchain (long-term goal).

## Debugging Workflow (Mandatory)

1. **Always** run under QEMU with serial redirected and GDB stub:
   ```
   qemu-system-x86_64 -s -S -serial stdio -m 512M ... -kernel kernel.elf
   ```
2. Attach GDB early: `gdb kernel.elf` → `target remote :1234`.
3. Use hardware breakpoints (`hbreak`) for early code.
4. On any page fault print full state: CR2, error code, RIP, RSP, CR3, current task pointer, rsp0.
5. Never let the page-fault handler itself fault (map handler code + stack permanently).
6. Add `DBGALLOC`, stack canaries, and poison values aggressively during development.
7. Keep a "known good" git tag at every stable milestone.

## Common Pitfalls & Fixes

- **Page fault storm after first context switch**: Kernel not mapped in process page tables. Copy higher-half entries from kernel PML4.
- **Triple fault / reboot loop**: Missing or broken IDT, bad stack, or unhandled exception in early boot.
- **rsp0 / TSS problems**: Kernel stack pointer becomes 0 → fault on interrupt/syscall.
- **Format string bugs** (`0x0x...`): Wrong printf specifier or double "0x".
- **AHCI / disk**: Ensure ABAR is mapped, ports started correctly, command lists allocated in accessible memory.
- **ELF loading**: Correctly handle PT_LOAD, permissions, BSS zeroing, entry point.
- **Higher-half jump**: After enabling paging, far jump or `mov` to higher-half RIP.

## Architecture Recommendations

- Primary target: **x86-64 long mode**, higher-half, Limine protocol.
- Keep architecture-specific code isolated (`arch/x86_64/`).
- Prefer monolithic kernel for first useful OS (microkernels are harder).
- Design clean interfaces early (VFS, device, memory) even if implementations are simple.

## Resources to Consult (in order)

- OSDev Wiki: Getting Started, Bare Bones (Limine), Higher Half Kernel, What Order Should I Make Things In, Going Further on x86, Meaty Skeleton.
- Intel/AMD manuals for paging, interrupts, APIC.
- Limine protocol documentation.
- Existing clean hobby OSes for reference patterns (not to copy blindly): xv6, Tilck, SerenityOS early stages, Redox (Rust).

## Agent Behavior Rules

- When the user shows a crash log (especially `[RAWPF]` or page-fault cascade), immediately diagnose memory/address-space issues first.
- Always ask for or request the relevant source (page-table creation, context switch, TSS setup, ELF loader) when debugging.
- Prefer incremental, testable changes. After every major subsystem, produce a bootable binary that demonstrates the new capability.
- Document design decisions in comments and a simple `DESIGN.md`.
- Aim for a system that can eventually run real programs (shell, simple utilities, later more ambitious software).

## Progressive References

Detailed checklists and patterns live in:
- `references/implementation-order.md`
- `references/debugging-playbook.md`
- `references/memory-and-paging.md`
- `references/common-bugs.md`

Use them when deeper guidance is needed.
