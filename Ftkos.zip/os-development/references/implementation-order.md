# Detailed Implementation Order & Checklists

## Phase 0 – Tooling & Environment Checklist
- [ ] Cross compiler installed and verified (`x86_64-elf-gcc --version`)
- [ ] Binutils for the target
- [ ] NASM or GAS
- [ ] QEMU with KVM if available
- [ ] Git repository initialized, `.gitignore` for build artifacts
- [ ] Makefile / CMake that produces a clean ISO or direct kernel ELF
- [ ] Script that launches QEMU with consistent flags (`-serial stdio -no-reboot -d int,cpu_reset` for early debugging)

## Phase 1 – Boot Success Criteria
- Kernel prints a clear banner via serial **before** and **after** enabling paging
- GDT loaded, long mode active, higher-half RIP
- All exceptions have handlers that dump state and halt cleanly
- Limine requests (memmap, HHDM, framebuffer, RSDP) parsed correctly

## Phase 2 – Memory Success Criteria
- PMM can allocate and free pages without corruption
- VMM can map arbitrary physical frames to virtual addresses
- Kernel higher-half is present in the initial page tables
- When creating a new process address space, the higher-half PML4 slots are copied/shared from the kernel
- kmalloc works for small and page-sized allocations
- Kernel stacks are allocated from a known-good region

### Critical Code Pattern – Installing Kernel into Process
```c
// After allocating process_pml4
for (int i = 256; i < 512; i++) {          // adjust to your higher-half start
    process_pml4[i] = kernel_pml4[i];
}
// Or share a single higher-half PDPT
```

## Phase 3 – Interrupts Success Criteria
- No spurious interrupts
- Timer fires at expected rate
- Keyboard produces scancodes
- Nested interrupts / exceptions do not corrupt stacks
- EOI is sent correctly for both PIC (if used) and APIC

## Phase 4 – Process Success Criteria
- Idle task runs
- First user task (`init`) is created with correct CR3, user stack, kernel stack, and entry point
- Context switch updates:
  - Current task pointer (per-CPU)
  - TSS.rsp0
  - CR3
  - All general-purpose registers + RFLAGS + segments if needed
- Syscall path correctly switches stacks and returns to user mode
- Page faults in user mode are distinguishable from kernel faults

## Phase 5 – Storage Success Criteria
- AHCI identifies the drive and can read sectors
- VFS can mount a FAT32 volume
- `open` / `read` of `/EFI/.../init.elf` or equivalent succeeds
- File descriptors are tracked per process

## Phase 6 – Userland Success Criteria
- `init` runs, prints to console (via syscall), and starts a shell
- Shell can list files, run simple programs
- Programs exit cleanly and resources are reclaimed
- At least a minimal set of utilities exists

## Milestone Tags
Tag git commits as:
- `boot-ok`
- `paging-ok`
- `pmm-vmm-ok`
- `interrupts-ok`
- `first-process`
- `disk-ok`
- `shell-ok`
- `useful-os-v0.1`
