# Debugging Playbook for Hobby Kernels

## Essential QEMU + GDB Setup

```bash
# Launch (example)
qemu-system-x86_64 \
  -machine q35 \
  -cpu max \
  -m 512M \
  -smp 1 \
  -serial stdio \
  -s -S \
  -no-reboot \
  -d int,cpu_reset,guest_errors \
  -drive file=disk.img,format=raw,if=none,id=disk \
  -device ahci,id=ahci \
  -device ide-hd,drive=disk,bus=ahci.0 \
  -kernel kernel.elf   # or use Limine ISO

# In another terminal
gdb kernel.elf
(gdb) target remote :1234
(gdb) hbreak kernel_main          # or _start, or specific function
(gdb) continue
```

Useful GDB commands:
- `info registers` / `info reg cr2 cr3`
- `x/20i $rip`
- `x/32gx $rsp`
- `monitor info mem` / `monitor info tlb` (QEMU monitor)
- Hardware breakpoints preferred early (`hbreak`)

## Page Fault Analysis Checklist

When you see `[RAWPF]` or a page-fault cascade:

1. Record:
   - CR2 (faulting address)
   - Error code bits (P/W/U/RSVD/I/D)
   - RIP
   - RSP / kernel stack
   - CR3
   - Current task pointer and its rsp0
2. Ask:
   - Is the address in kernel space or user space?
   - Is the page table for that CR3 supposed to map it?
   - Did we just switch CR3?
   - Is the faulting instruction itself not mapped? (classic kernel-not-in-process-tables)
3. Common signatures:
   - `rip == cr2` and high address → kernel text missing from current page tables
   - `cr2` near 0 or very high with err=0 → null deref or unmapped structure
   - Recursive faults → PF handler itself is not mapped or uses bad stack

## Serial Logging Best Practices

- Make `kprintf` / `serial_write` work as early as possible (even before full paging).
- Prefix every major subsystem init with clear tags: `[PMM]`, `[VMM]`, `[SCHED]`, `[AHCI]`, etc.
- On panic, dump:
  - All general registers
  - CR0/CR2/CR3/CR4
  - Current task
  - Stack backtrace if possible
- Never call complex functions (malloc, printf formatters that allocate) from early exception paths.

## Common Debug Patterns

- **Poison values**: Fill free pages / stacks with 0xDEADBEEF or 0xCAFEBABE.
- **Canaries**: Put known values at stack ends and check them.
- **Allocation tracking**: Log every phys/virt alloc with caller address (as seen in the user's log).
- **Single-step critical paths**: Context switch, syscall entry, page-table walk.
- **Known-good baseline**: Always keep a git tag that boots to a stable point so you can bisect.

## When the System Triple-Faults / Resets

1. Enable `-d int,cpu_reset` in QEMU.
2. Look for the last exception before reset.
3. Usually missing IDT entry, bad stack on exception, or page fault inside the double-fault handler.
4. Fix the double-fault handler first (it must use a known-good stack and never fault).

## Tools Beyond GDB

- QEMU monitor (`info registers`, `info mem`, `xp /fmt addr`)
- Bochs for more detailed logging if needed
- Serial capture to a file for post-mortem
- Simple kernel debugger (optional later): dump memory, list tasks, etc.
