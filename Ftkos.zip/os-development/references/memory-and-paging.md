# Memory Management & Paging Deep Dive

## Higher-Half Layout Recommendation (x86-64)

Typical modern layout:

- User space: `0x0000000000000000` – `0x00007FFFFFFFFFFF` (canonical)
- Kernel:     `0xFFFFFFFF80000000` – `0xFFFFFFFFFFFFFFFF` (or start at `0xFFFF800000000000` for HHDM)

Limine provides a Higher Half Direct Map (HHDM) that maps all (or a large window of) physical memory at a fixed offset. Use it.

## Mandatory Invariants

1. **Kernel is always mapped** in every address space at the same virtual addresses.
2. Kernel pages are supervisor-only (U=0).
3. User pages are never executable as kernel or vice-versa without explicit intent (W^X).
4. The page-fault handler, IDT, GDT, TSS, and current kernel stack are always accessible no matter which CR3 is loaded.
5. Physical page allocator never hands out pages that are still mapped somewhere critical.

## Creating a Process Address Space

```text
1. Allocate a new PML4 (page-aligned, zeroed or carefully initialized).
2. Copy or share all higher-half PML4 entries from the kernel's PML4.
3. Map the user binary (ELF PT_LOAD segments) into low addresses with correct permissions.
4. Allocate and map a user stack (grows down).
5. Allocate a kernel stack for the task (used on interrupts/syscalls).
6. Set up the initial register state (RIP = entry, RSP = user stack top, segments, RFLAGS).
7. Store the physical address of the new PML4 in the task structure.
```

## Context Switch Memory Steps (order matters)

```text
1. Save old task registers + state.
2. Update per-CPU current task pointer.
3. Update TSS.rsp0 = new_task->kernel_stack_top.
4. Load new CR3 = new_task->pml4_phys.   // TLB flush implied on x86 without PCID
5. Restore new task registers.
6. Return to user mode (or continue in kernel if kernel thread).
```

Doing CR3 load before updating rsp0 is a frequent source of faults.

## Page Fault Error Code Quick Reference

| Bit | Meaning                          |
|-----|----------------------------------|
| 0   | Present (0 = not present)        |
| 1   | Write (1 = write access)         |
| 2   | User (1 = user mode)             |
| 3   | Reserved bit set                 |
| 4   | Instruction fetch (NX violation) |
| 5   | Protection key                   |

`err == 0x10` → instruction fetch of a non-present page (very common when kernel text is missing).

## Testing Memory Subsystem

- Allocate and free thousands of pages in a loop; check for leaks / corruption.
- Map a page, write a pattern, unmap, remap elsewhere, verify.
- Create many processes and force context switches; ensure no cross-contamination.
- Deliberately access unmapped addresses and verify clean fault handling.
