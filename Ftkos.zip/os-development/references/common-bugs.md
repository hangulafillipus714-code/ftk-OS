# Common Bugs & How to Recognize Them

## 1. Kernel Not Mapped in Process Page Tables
**Symptoms**: Immediately after first context switch to user task → cascade of `[RAWPF]` with `rip == cr2` pointing into kernel text (`0xffffffff82......`), `err=0x10`, CR3 = process PML4.
**Fix**: When creating process PML4, copy higher-half entries from kernel PML4 (or share a higher-half PDPT).

## 2. TSS / rsp0 Not Updated
**Symptoms**: Faults on first interrupt or syscall after switch; `rsp0=` empty or zero in logs; kernel stack pointer becomes 0.
**Fix**: In context switch, set `tss.rsp0 = task->kernel_stack_top` **before** loading new CR3 or iret/sysret.

## 3. Page Fault Handler Itself Faults
**Symptoms**: Recursive RAWPF, triple fault, or reboot. Stack grows downward until crash.
**Fix**: Ensure PF handler code, its data, and a dedicated emergency stack are permanently mapped in every address space. Keep the handler extremely simple.

## 4. Bad Early Paging / Higher-Half Jump
**Symptoms**: Triple fault right after enabling paging, or code continues executing at wrong address.
**Fix**: Identity-map the low memory that contains the enabling code, jump to higher-half virtual address, then remove identity map if desired.

## 5. Format / Logging Bugs
**Symptoms**: `0x0xFFFFFFFF...` or garbage early output (`LMNLMN...`, random characters).
**Fix**: Correct printf format strings (`%p` vs `0x%lx`). Initialize serial early and flush.

## 6. AHCI / Disk Mapping
**Symptoms**: CAP/GHC/PI readable but commands hang, or page fault on ABAR access.
**Fix**: Map the ABAR (BAR5) pages into kernel virtual address space before touching registers. Allocate command lists / FIS in DMA-able physical memory that is also mapped.

## 7. ELF Loader Mistakes
**Symptoms**: Init task created but immediately faults, wrong entry point, or missing BSS.
**Fix**: Process every PT_LOAD, respect p_flags for permissions, zero BSS (p_memsz > p_filesz), set correct RIP and user RSP.

## 8. Interrupt Stack / Privilege Transition
**Symptoms**: Faults only when interrupts are enabled or on first timer tick.
**Fix**: Correct IST or rsp0, proper segment selectors on iret, interrupt gates vs trap gates.

## 9. Allocator Corruption
**Symptoms**: Random later crashes, especially after many allocations.
**Fix**: Add redzones, poison free memory, track allocation sites, run under GDB with watchpoints on critical structures.

## 10. Assuming Host Compiler Behavior
**Symptoms**: Kernel works on one machine / QEMU version but not another, or subtle ABI issues.
**Fix**: Always use a proper freestanding cross-compiler with `-ffreestanding -fno-stack-protector -mno-red-zone` (x86-64) etc.

## Debugging Priority Order for Crashes

1. Is the page-fault handler safe?
2. Are kernel mappings present in the current CR3?
3. Is the kernel stack / rsp0 valid?
4. Is the faulting address supposed to be mapped?
5. Did we just change CR3 or privilege level?
6. Check serial log for the last successful message.
