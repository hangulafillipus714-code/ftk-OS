# FTK OS — GUI Edition

A freestanding x86-64 UEFI operating system with a graphical desktop
environment, written entirely in C11 and x86-64 assembly with **zero
external dependencies** (no libc, no POSIX, no runtime support library).

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────┐
│  UEFI Firmware (Q35 / OVMF)                             │
├─────────────────────────────────────────────────────────┤
│  boot/efi/stub.c   — EFI stub, sets up BootInfo,        │
│                       GOP framebuffer, memory map        │
├─────────────────────────────────────────────────────────┤
│  kernel/                                                 │
│  ├── init/main.c          Kernel entry point            │
│  ├── mm/{pmm,vmm,heap}.c  Physical + virtual memory     │
│  ├── sched/scheduler.c    Round-robin preemptive sched  │
│  ├── syscall/syscall.c    29-entry syscall table        │
│  ├── drivers/             ACPI, APIC, AHCI, keyboard,   │
│  │                        PCI, serial, framebuffer       │
│  ├── fs/                  VFS + FAT32 + ramfs            │
│  └── sync/                mutex, semaphore, rwlock       │
├─────────────────────────────────────────────────────────┤
│  user/                                                   │
│  ├── lib/gui.{h,c}        Framebuffer GUI library        │
│  ├── src/wm.c             Desktop window manager         │
│  ├── src/fsh.c            Text-mode shell (fallback)     │
│  └── src/{ls,cat,echo,ps,clear}.c  CLI utilities        │
└─────────────────────────────────────────────────────────┘
```

---

## Building

### Prerequisites

```bash
# Debian / Ubuntu
sudo apt install \
    gcc nasm binutils \
    mtools gdisk dosfstools \
    qemu-system-x86 ovmf
```

### Compile

```bash
make          # builds kernel, bootloader, GUI, disk image
make clean    # wipe all build artifacts
make test     # unit + integration + regression test suite
```

The top-level `make` produces `build/ftk_uefi.img` — a 64 MB GPT disk
image with a single EFI System Partition containing:

```
/EFI/BOOT/BOOTX64.EFI     ← UEFI bootloader stub
/EFI/FTK/ftk_kernel.elf   ← kernel
/EFI/FTK/init.elf         ← PID-1 init (launches /bin/wm)
/bin/wm                    ← GUI window manager
/bin/fsh                   ← text shell (fallback)
/bin/{ls,cat,echo,ps,clear}
```

### Run in QEMU

```bash
qemu-system-x86_64 \
  -machine q35 \
  -cpu host -enable-kvm \
  -m 256M \
  -drive if=pflash,format=raw,readonly=on,file=/usr/share/OVMF/OVMF_CODE.fd \
  -drive if=pflash,format=raw,file=OVMF_VARS.fd \
  -drive format=raw,file=build/ftk_uefi.img \
  -serial stdio \
  -vga std \
  -display sdl
```

Remove `-enable-kvm` if running without hardware virtualisation.

---

## Syscall ABI

Entry via `SYSCALL` instruction. Number in `RAX`; arguments in
`RDI`, `RSI`, `RDX`, `R10`, `R8`, `R9` (System V AMD64 order, with
`R10` substituting `RCX` which SYSCALL clobbers). Return value in `RAX`;
negative values are errno codes.

| Nr | Name         | Signature                                      |
|----|--------------|------------------------------------------------|
|  0 | SYS_EXIT     | `exit(int status)`                             |
|  1 | SYS_WRITE    | `write(int fd, void *buf, size_t n)`           |
|  2 | SYS_READ     | `read(int fd, void *buf, size_t n)`            |
|  3 | SYS_GETPID   | `getpid() → pid_t`                             |
|  4 | SYS_SLEEP    | `sleep(u64 ticks)` — 100 Hz PIT               |
|  5 | SYS_YIELD    | `yield()`                                      |
|  6 | SYS_BRK      | `brk(void *addr)`                              |
|  7 | SYS_EXEC     | `exec(const char *path)`                       |
|  8 | SYS_READFILE | `readfile(path, buf, n)`                       |
|  9 | SYS_LISTDIR  | `listdir(path, buf, n)`                        |
| 10 | SYS_OPEN     | `open(path, flags) → fd`                       |
| 11 | SYS_CLOSE    | `close(fd)`                                    |
| 12 | SYS_SPAWN    | `spawn(path, argv[]) → pid`                    |
| 13 | SYS_PS       | `ps(pid, ps_info_t *buf, int count)`           |
| 14 | SYS_WAITPID  | `waitpid(pid, int *status) → pid`             |
| 15 | SYS_GETDENTS | `getdents(fd, ftk_dirent_t *buf, int count)`   |
| 16 | SYS_PIPE     | `pipe(int pipefd[2])`                          |
| 17 | SYS_DUP2     | `dup2(oldfd, newfd)`                           |
| 18 | SYS_DEBUG    | `debug(char c)` — kernel serial echo           |
| 19 | SYS_KILL     | `kill(pid)`                                    |
| 20 | SYS_FB_INFO  | `fb_info(ftk_fb_info_t *out)`                  |
| 21 | SYS_FB_MAP   | `fb_map() → user vaddr`                        |
| 22 | SYS_FB_FLUSH | `fb_flush(x,y,w,h)` — future double-buffer     |
| 23 | SYS_GETTICKS | `getticks() → u64` ticks at 100 Hz            |
| 24 | SYS_GETKEY   | `getkey(ftk_key_event_t *ev) → 1/0`           |
| 25 | SYS_MMAP     | `mmap(NULL,len,prot,flags,-1,0) → vaddr`       |
| 26 | SYS_MUNMAP   | `munmap(vaddr, len)` (stub in v0.1)            |
| 27 | SYS_SETCURSOR| `setcursor(x, y)`                              |
| 28 | SYS_GETTIME  | `gettime(ftk_time_t *out)` — reads CMOS RTC   |

### Key event structure (`SYS_GETKEY`)

```c
typedef struct {
    int type;       // FTK_KEY_PRESS (1) or FTK_KEY_RELEASE (0)
    int keycode;    // ASCII for printable; FTK_KEY_* for specials
    int modifiers;  // FTK_MOD_SHIFT | FTK_MOD_CTRL | FTK_MOD_ALT
} ftk_key_event_t;
```

Special key codes: `FTK_KEY_UP/DOWN/LEFT/RIGHT`, `FTK_KEY_F1`–`F5/F10`,
`FTK_KEY_HOME`, `FTK_KEY_END`, `FTK_KEY_PGUP`, `FTK_KEY_PGDN`,
`FTK_KEY_DEL`, `FTK_KEY_ESC`, `FTK_KEY_ENTER`, `FTK_KEY_BKSP`.

---

## GUI System

### Framebuffer access

The kernel maps the linear framebuffer at `0x00007F0000000000` in user
space via `SYS_FB_MAP`. The mapping is a direct alias of the GOP
framebuffer physical pages — every write immediately appears on screen
(no page-flip or blit required in v0.1). Format is 32-bit little-endian
`0x00RRGGBB`.

```c
ftk_fb_info_t info;
sys_fb_info(&info);          // width, height, pitch, bpp
u32 *fb = (u32*)sys_fb_map();
fb[y * (info.pitch/4) + x] = 0xFF6B35;  // orange pixel
```

### GUI library (`user/lib/gui.h`)

Link against `user/lib/gui.o`. All functions are freestanding.

| Function | Description |
|----------|-------------|
| `gui_init()` | Map framebuffer, populate globals |
| `gui_clear(col)` | Fill entire screen |
| `gui_fill_rect(x,y,w,h,col)` | Filled rectangle |
| `gui_draw_rect(x,y,w,h,col)` | Hollow rectangle |
| `gui_draw_line(x0,y0,x1,y1,col)` | Bresenham line |
| `gui_draw_circle(cx,cy,r,col)` | Midpoint circle |
| `gui_fill_circle(cx,cy,r,col)` | Filled circle |
| `gui_draw_str(x,y,s,fg,bg)` | 8×16 bitmap text |
| `gui_draw_str_transp(x,y,s,fg)` | Text, transparent bg |
| `gui_draw_button(x,y,w,h,label,pressed)` | 3-D button widget |
| `gui_draw_window(x,y,w,h,title,focused)` | Window chrome |
| `gui_draw_panel(x,y,w,h,bg,border)` | Flat panel |
| `gui_draw_progress(x,y,w,h,pct,fg,bg)` | Progress bar |
| `gui_draw_input(x,y,w,text,cur,focused)` | Text input field |
| `gui_draw_scrollbar(x,y,h,pos,max)` | Scroll bar |
| `gui_draw_taskbar(app_name)` | Bottom taskbar |
| `gui_poll_key(ev)` | Non-blocking key event |
| `gui_ticks()` | 100 Hz tick counter |
| `gui_sleep_ticks(n)` | Sleep n ticks |
| `gui_gettime(t)` | Wall clock (CMOS RTC) |

---

## Window Manager (`/bin/wm`)

The WM is a single user-mode process that:

1. Maps the framebuffer via `SYS_FB_MAP`
2. Renders a gradient desktop background
3. Manages up to 8 windows (z-ordered array)
4. Routes keyboard events to the focused window

### Built-in Applications

| App | Launch | Description |
|-----|--------|-------------|
| **Calculator** | `F1` or menu | Integer arithmetic (+−×÷%), backspace, ±, % |
| **Calendar** | `F2` or menu | Month/year view, RTC-accurate today highlight |
| **Terminal** | `F3` or menu | Built-in command interpreter (no child process) |

### Keyboard Controls

| Key | Action |
|-----|--------|
| `F1` / `F2` / `F3` | Open Calculator / Calendar / Terminal |
| Arrow keys | Move focused window (8 px steps) |
| `Alt` + Arrows | Move software mouse cursor |
| `Enter` | Simulate mouse click at cursor position |
| `Ctrl+Tab` | Cycle focus through open windows |
| `Ctrl+W` | Close focused window |
| `Ctrl+C` | Copy Calculator display to clipboard |
| `Ctrl+V` | Paste clipboard into Terminal input |
| `Enter` (in taskbar logo) | Toggle application menu |

### Calculator Keys

| Key | Action |
|-----|--------|
| `0-9` `.` | Enter digits |
| `+ - * /` | Binary operators |
| `Enter` / `=` | Evaluate |
| `Backspace`/`Del` | Delete last digit |
| `C` | Clear / reset |
| `%` | Percent of accumulator |

### Calendar Keys

| Key | Action |
|-----|--------|
| `←` or `[` | Previous month |
| `→` or `]` | Next month |
| `T` | Jump to today's month |

### Terminal Built-in Commands

| Command | Description |
|---------|-------------|
| `help` | List commands |
| `clear` | Clear screen buffer |
| `echo <text>` | Print text |
| `date` | Show current date/time from CMOS RTC |
| `uptime` | Show system uptime (ticks → h/m/s) |
| `about` | OS version info |

---

## Text Shell (`/bin/fsh`)

Launched if `/bin/wm` is unavailable or when booting without a framebuffer.

| Feature | Detail |
|---------|--------|
| Line editing | Insert, delete, cursor movement |
| History | Up/Down arrow, 32-entry ring buffer |
| Pipe | `cmd1 \| cmd2` |
| Redirection | `cmd > file`, `cmd < file` |
| Background | `cmd &` |
| PATH search | `/bin/` |
| Builtins | `cd`, `exit`, `echo`, `clear`, `history` |

---

## Memory Layout

| Range | Usage |
|-------|-------|
| `0x0000_0000_0000_0000 – 0x0000_7FFF_FFFF_FFFF` | User space |
| `0x0000_2000_0000` | User ELF load base |
| `0x0000_7F00_0000_0000` | FB mapping (`SYS_FB_MAP`) |
| `0xFFFF_8000_0000_0000 +` | Kernel HHDM (phys identity) |
| `0xFFFF_FFFF_8000_0000 +` | Kernel image (`KERNEL_VIRT_BASE`) |

---

## Writing a GUI Application

```c
#include "gui.h"   // from user/lib/

void _start(void)
{
    if (gui_init() != 0) _sc(SYS_EXIT, -1, 0, 0);

    gui_clear(COL_DESKTOP);
    gui_draw_window(100, 80, 300, 200, "My App", 1);
    gui_draw_str(110, 110, "Hello, FTK World!", COL_TEXT, COL_WIN_BODY);
    gui_draw_taskbar("My App");

    for (;;) {
        ftk_key_event_t ev;
        if (gui_poll_key(&ev) && ev.type == FTK_KEY_PRESS) {
            if (ev.keycode == FTK_KEY_ESC) break;
        }
        gui_sleep_ticks(2);   // ~20 ms
    }

    _sc(SYS_EXIT, 0, 0, 0);
}
```

Link:
```bash
gcc -std=c11 -ffreestanding -nostdlib -nostdinc \
    -mno-red-zone -mcmodel=small -mno-sse -O2 \
    -Iuser/lib -c myapp.c -o myapp.o
ld -T user/init.ld myapp.o user/lib/gui.o -o user/myapp.elf
```

---

## Design Decisions & Trade-offs

| Decision | Rationale |
|----------|-----------|
| Single-process WM | No IPC, no shared memory, minimal complexity |
| Direct FB write (no double-buffer) | Simpler in v0.1; tear acceptable at 30 Hz |
| In-process apps (Calc, Cal, Term) | Eliminates need for IPC, message passing |
| CMOS RTC for wall clock | Avoids NTP/TSC calibration; accurate within ±1 s |
| Integer-only calculator | No FPU (kernel ABI requires `-mno-sse`); sufficient for demo |
| Arrow-key simulated mouse | No PS/2 mouse driver; Tab+Enter achieves click |
| `SYS_MUNMAP` stub | Physical page reclamation deferred; processes are short-lived |

---

## Known Limitations (v0.1)

- No physical mouse driver (PS/2 mouse IRQ12 not implemented)
- No network stack
- No audio
- No double-buffering (visible tearing at high redraw rate)
- `SYS_MUNMAP` is a no-op (pages not reclaimed)
- Calculator is integer-only (no floating point)
- Terminal has no actual child-process I/O (built-in interpreter only)
- 8-colour palette only (32-bit ARGB physically, but palette kept small for readability)

---

## Test Suite

```bash
make test
```

Runs in four stages:
1. **Unit tests** — kernel compiled with `-DFTK_TEST_MODE`, covers PMM, VMM, heap, scheduler, syscall dispatch, string, sync primitives, CPU exceptions, context switching, SMP preparation.
2. **Integration tests** — QEMU + PyExpect: boot, scheduler, memory, panic, serial, syscall, AHCI.
3. **Regression tests** — boot, graphics init, shell parse/exec.
4. **Stress tests** — task spawn/kill, heap, interrupt nesting.

---

## Source Tree

```
ftkos/
├── Makefile                 Top-level build
├── README.md                This file
├── boot/efi/stub.c          UEFI bootloader
├── kernel/
│   ├── arch/x86_64/         GDT, IDT, APIC, paging, SMP trampoline
│   ├── drivers/
│   │   ├── acpi/acpi.c      ACPI/MADT parsing
│   │   ├── apic/apic.c      LAPIC + IOAPIC
│   │   ├── char/keyboard.c  PS/2 keyboard (full US layout, GUI events)
│   │   ├── char/serial.c    16550 UART
│   │   ├── storage/ahci.c   SATA/AHCI DMA
│   │   ├── pci/pci.c        PCI bus enumeration
│   │   ├── timer/pit.c      8254 PIT at 100 Hz
│   │   └── video/framebuffer.c  Linear framebuffer, 8×16 font
│   ├── fs/fs/{fat32,vfs,ramfs}.c
│   ├── include/ftk/abi/
│   │   ├── syscall.h        Complete syscall ABI (numbers, structs, errors)
│   │   └── types.h          u8/u16/u32/u64, phys_addr_t, …
│   ├── init/main.c          kernel_main()
│   ├── mm/{pmm,vmm,heap,uaccess}.c
│   ├── sched/{scheduler,task,process,waitqueue}.c
│   ├── sync/{mutex,semaphore,rwlock}.c
│   └── syscall/syscall.c    All 29 syscall handlers
├── user/
│   ├── lib/
│   │   ├── gui.h            GUI API header
│   │   └── gui.c            Drawing, widgets, string utils
│   └── src/
│       ├── init.c           PID-1 (exec wm, fallback fsh)
│       ├── wm.c             Desktop WM + Calculator + Calendar + Terminal
│       ├── fsh.c            Interactive text shell
│       ├── ls.c cat.c echo.c ps.c clear.c
│       └── torture_{spawn,child,vfs}.c  Stress tests
└── tests/
    ├── unit/               Kernel unit test files
    ├── integration/        QEMU/Python integration tests
    ├── regression/         Boot + graphics + shell regression
    └── stress/             Task / heap / interrupt stress tests
```
