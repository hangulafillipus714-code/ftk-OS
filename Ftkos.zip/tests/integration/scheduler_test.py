#!/usr/bin/env python3
"""
Scheduler Integration Test

Verifies that the scheduler starts and init process runs.
Looks for scheduler-related messages in the serial output.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "qemu"))
from run import run_qemu
from expect import check_expected, print_summary


def test_scheduler_init(output):
    expected = [
        "User-mode init task created",
        "Multi-tasking enabled",
        "Switching to first task",
        "Switching to task PID 1",
    ]
    return check_expected(output, expected, name="sched: initialization")


def test_init_process_runs(output):
    expected = [
        "Switching to first task",
        "Switching to task PID 1",
    ]
    return check_expected(output, expected, name="sched: init process runs")


def test_no_scheduler_panic(output):
    import expect as e
    excluded = [
        "KERNEL PANIC",
    ]
    return e.check_excluded(output, excluded, name="sched: no panic")


def main():
    output = run_qemu(timeout=30)

    results = [
        test_scheduler_init(output),
        test_init_process_runs(output),
        test_no_scheduler_panic(output),
    ]

    if not print_summary(results, name="SCHEDULER INTEGRATION TESTS"):
        sys.exit(1)


if __name__ == "__main__":
    main()
