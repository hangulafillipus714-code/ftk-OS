#!/usr/bin/env python3
"""
Serial Integration Test

Verifies that serial output works correctly.
Checks that output is not empty and contains expected boot markers.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "qemu"))
from run import run_qemu
from expect import print_summary


def test_serial_non_empty(output):
    if len(output) > 100:
        print(f"[PASS] serial: output is {len(output)} chars (non-empty)")
        return True
    else:
        print(f"[FAIL] serial: output too short ({len(output)} chars)")
        return False


def test_serial_has_boot_markers(output):
    markers = ["Memory initialized", "Paging enabled", "Kernel booted"]
    missing = [m for m in markers if m not in output]
    if missing:
        print(f"[FAIL] serial: missing markers: {missing}")
        return False
    print(f"[PASS] serial: all boot markers present")
    return True


def test_serial_no_garbage(output):
    """Check for binary garbage in serial output (non-printable chars excluding \n, \r, \t)."""
    garbage_count = 0
    for c in output:
        if ord(c) < 32 and c not in ('\n', '\r', '\t'):
            garbage_count += 1
    
    if garbage_count > 10:
        print(f"[WARN] serial: {garbage_count} non-printable chars found")
        return True
    print(f"[PASS] serial: clean output")
    return True


def main():
    output = run_qemu(timeout=20)

    results = [
        test_serial_non_empty(output),
        test_serial_has_boot_markers(output),
        test_serial_no_garbage(output),
    ]

    if not print_summary(results, name="SERIAL INTEGRATION TESTS"):
        sys.exit(1)


if __name__ == "__main__":
    main()
