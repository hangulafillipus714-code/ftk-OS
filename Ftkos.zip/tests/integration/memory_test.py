#!/usr/bin/env python3
"""
Memory Integration Test

Verifies that memory initialization completes successfully.
Checks for PMM and VMM messages.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "qemu"))
from run import run_qemu
from expect import check_expected, check_excluded, print_summary


def test_memory_init(output):
    expected = [
        "Memory initialized",
        "Paging enabled",
    ]
    return check_expected(output, expected, name="mem: initialization")


def test_no_memory_panic(output):
    return check_excluded(output, ["KERNEL PANIC"], name="mem: no panic")


def main():
    output = run_qemu(timeout=20)

    results = [
        test_memory_init(output),
        test_no_memory_panic(output),
    ]

    if not print_summary(results, name="MEMORY INTEGRATION TESTS"):
        sys.exit(1)


if __name__ == "__main__":
    main()
