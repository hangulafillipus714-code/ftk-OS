#!/usr/bin/env python3
"""
Panic Integration Test

Verifies that kernel panic behaves correctly.
The normal boot should NOT trigger a panic.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "qemu"))
from run import run_qemu
from expect import check_excluded, print_summary


def test_no_unexpected_panic(output):
    return check_excluded(
        output,
        ["KERNEL PANIC"],
        name="panic: no unexpected panic during boot"
    )


def test_boot_completes(output):
    expected_markers = [
        "User-mode init task created",
    ]
    from expect import check_expected
    return check_expected(output, expected_markers, name="panic: boot completes")


def main():
    output = run_qemu(timeout=30)

    results = [
        test_no_unexpected_panic(output),
        test_boot_completes(output),
    ]

    if not print_summary(results, name="PANIC INTEGRATION TESTS"):
        sys.exit(1)


if __name__ == "__main__":
    main()
