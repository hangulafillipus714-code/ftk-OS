#!/usr/bin/env python3
"""
tests/integration/syscall_test.py
----------------------------------
Integration test: verifies that the FTK OS syscall subsystem initialises
correctly during a normal boot, via patterns emitted on the serial console.

Run via:  make -C tests integration
          (which calls this script through tests/qemu/run.py)
"""

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'qemu'))
from expect import check_expected, check_excluded, print_summary
from run import run_qemu

INIT_PATTERNS = [
    "[SYSCALL] Initialized:",
    "LSTAR=0xFFFF",
    "syscalls registered",
]

ABSENT_PATTERNS = [
    "SYSCALL PANIC",
    "SYSCALL FAULT",
    "[PANIC]",
    "triple fault",
]


def test_syscall_init(output: str) -> bool:
    """Syscall subsystem reports successful initialisation."""
    return check_expected(output, INIT_PATTERNS, "syscall: initialization")


def test_syscall_no_fault(output: str) -> bool:
    """No panic or fault emitted during or after syscall_init()."""
    return check_excluded(output, ABSENT_PATTERNS, "syscall: no fault on init")


def test_lstar_in_kernel(output: str) -> bool:
    """LSTAR address is visibly in the higher-half (starts with 0xffff...)."""
    marker = "LSTAR=0xffff"
    if marker.lower() in output.lower():
        print("[PASS] syscall: LSTAR in higher-half kernel")
        return True
    else:
        print(f"[FAIL] syscall: LSTAR not in higher-half (looking for '{marker}')")
        return False


def test_syscall_count(output: str) -> bool:
    """Correct number of syscalls registered (SYSCALL_COUNT >= 19)."""
    for line in output.splitlines():
        if "syscalls registered" in line:
            print(f"[PASS] syscall: {line.strip()}")
            return True
    print(f"[FAIL] syscall: no 'syscalls registered' in output")
    return False


def main():
    image = os.environ.get("FTK_IMAGE", os.path.join(os.path.dirname(__file__), '..', '..', 'build', 'ftk_uefi.img'))
    timeout = int(os.environ.get("FTK_TIMEOUT", "60"))

    print("=" * 40)
    print("  SYSCALL INTEGRATION TESTS")
    print("=" * 40)

    output = run_qemu(image=image, timeout=timeout)

    results = [
        test_syscall_init(output),
        test_syscall_no_fault(output),
        test_lstar_in_kernel(output),
        test_syscall_count(output),
    ]

    if not print_summary(results, name="SYSCALL INTEGRATION TESTS"):
        sys.exit(1)


if __name__ == "__main__":
    main()