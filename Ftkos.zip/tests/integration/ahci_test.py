#!/usr/bin/env python3
"""
AHCI Boot-to-User-Mode Integration Test

Verifies the full boot-to-user-mode chain:
  1. AHCI controller found and initialized
  2. FAT32 volume mounted
  3. init.elf loaded from disk
  4. ELF parsing succeeds, user-mode task created
  5. Scheduler switches to the init task

Run standalone:
  python3 tests/integration/ahci_test.py

Or as part of the test suite:
  make test
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "qemu"))
from run import run_qemu
from expect import check_expected, check_excluded, print_summary


def test_ahci_init(output):
    expected = [
        "AHCI SATA:",
        "CAP=0x",
        "Port 0:",
        "Firmware CLB=",
        "Using CLB=",
    ]
    return check_expected(output, expected, name="ahci: controller initialized")


def test_fat32_mount(output):
    expected = [
        "Volume mounted.",
        "Root cluster:",
    ]
    return check_expected(output, expected, name="ahci: FAT32 volume mounted")


def test_init_elf_loaded(output):
    expected = [
        "Loading init.elf:",
        "ELF loaded: entry=",
    ]
    return check_expected(output, expected, name="ahci: init.elf loaded")


def test_user_mode_task(output):
    expected = [
        "User-mode init task created",
        "Switching to first task",
        "Switching to task PID 1",
    ]
    return check_expected(output, expected, name="ahci: user-mode task created")


def test_no_errors(output):
    excluded = [
        "KERNEL PANIC",
        "Triple Fault",
        "Fatal",
        "Disk read failed",
        "Failed to open",
        "not found; falling back",
    ]
    return check_excluded(output, excluded, name="ahci: no errors or fallbacks")


def test_user_syscall_ring3_ring0(output):
    """Verify Ring-3→Ring-0→Ring-3 round trip via the init.elf syscall (WM)."""
    expected = [
        "wm: started",
    ]
    return check_expected(output, expected, name="ahci: user-mode syscall round-trip")


def test_fat_cache_hits(output):
    """Check FAT sector cache reduces redundant reads (LBA 2089 should appear
    only once or twice, not ~10 times)."""
    lines = output.splitlines()
    count = sum(1 for line in lines if "lba=2089" in line)
    if count > 0:
        print(f"[INFO] ahci: FAT sector (LBA 2089) read {count} time(s)")
    # Not a pass/fail test — just informational
    return True


def main():
    # Run with a longer timeout for full boot to user mode
    output = run_qemu(timeout=30)

    results = [
        test_ahci_init(output),
        test_fat32_mount(output),
        test_init_elf_loaded(output),
        test_user_mode_task(output),
        test_no_errors(output),
        test_user_syscall_ring3_ring0(output),
        test_fat_cache_hits(output),
    ]

    if not print_summary(results, name="AHCI BOOT-TO-USER TESTS"):
        sys.exit(1)


if __name__ == "__main__":
    main()
