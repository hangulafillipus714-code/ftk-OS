#!/usr/bin/env python3
"""
Boot Integration Test

Verifies that the kernel boots successfully through all stages:
  Power On -> UEFI -> Kernel Entry -> Paging -> Scheduler -> Init

Expected output markers (in order):
  [PAGING INIT]
  [PAGING OK]
  Kernel booted
  Scheduler enabled
  Init process started
  
Measures boot time from first output to "Kernel booted" message.
"""

import sys
import time
from pathlib import Path

# Add parent of tests dir to path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "qemu"))
from run import run_qemu
from expect import check_expected, check_excluded, print_summary


def test_boot_sequence(output):
    expected = [
        "Memory initialized",
        "Paging enabled",
        "Kernel booted",
        "ELF loaded: entry=",
        "User-mode init task created",
        "Starting scheduler",
    ]
    return check_expected(output, expected, name="boot: full boot sequence")


def test_no_early_panic(output):
    excluded = [
        "KERNEL PANIC",
        "Triple Fault",
        "Fatal",
    ]
    return check_excluded(output, excluded, name="boot: no early panic")


def test_boot_time(output):
    """Measure boot time from first output to 'Kernel booted'."""
    lines = output.splitlines()
    boot_start = None
    boot_end = None
    for i, line in enumerate(lines):
        if "Memory initialized" in line:
            boot_start = i
        if "Kernel booted" in line:
            boot_end = i
            break

    if boot_start is not None and boot_end is not None:
        elapsed = (boot_end - boot_start) * 0.001  # rough estimate
        print(f"[INFO] boot: ~{elapsed:.3f}s between boot markers")
        return True
    else:
        print("[WARN] boot: could not measure boot time (markers missing)")
        return True


def main():
    output = run_qemu(timeout=30)

    results = [
        test_boot_sequence(output),
        test_no_early_panic(output),
        test_boot_time(output),
    ]

    if not print_summary(results, name="BOOT INTEGRATION TESTS"):
        sys.exit(1)


if __name__ == "__main__":
    main()
