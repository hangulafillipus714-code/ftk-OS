#!/usr/bin/env python3
"""
Shell Serial Output Regression Test

Verifies that the init shell's serial output is complete and
not truncated. Every shell-related bug that has been fixed
(serial truncation, print corruption, broken prompt) gets a test here.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "qemu"))
from run import run_qemu
from expect import check_expected, check_excluded, print_summary


def test_shell_prompt_full(output):
    """Both 'INI' and 'wm: started' must appear (WM runs instead of shell)."""
    return check_expected(
        output,
        ["INI", "wm: started"],
        name="wm: prompt not truncated (regression: #serial-truncation)"
    )


def test_full_boot_chain_serial(output):
    """All boot messages must be present in the serial output."""
    markers = [
        "AHCI SATA:",
        "Volume mounted.",
        "Loading init.elf:",
        "User-mode init task created",
        "Switching to first task",
        "Switching to task PID 1",
        "wm: started",
    ]
    return check_expected(output, markers, name="wm: full boot chain serial output")


def test_no_serial_errors(output):
    excluded = [
        "KERNEL PANIC",
        "Double Fault",
        "Triple Fault",
        "Fatal",
    ]
    return check_excluded(output, excluded, name="shell: no fatal errors")


def test_boot_message_order(output):
    """Boot messages must appear in chronological order."""
    lines = output.splitlines()
    expected_order = [
        "Volume mounted.",
        "Loading init.elf:",
        "User-mode init task created",
        "Switching to first task",
        "Switching to task PID 1",
    ]
    indices = []
    for marker in expected_order:
        found = False
        for i, l in enumerate(lines):
            if marker in l:
                indices.append(i)
                found = True
                break
        if not found:
            print(f"[FAIL] wm: marker '{marker}' not found (order check)")
            return False

    if indices == sorted(indices):
        print("[PASS] wm: boot messages in order")
        return True
    else:
        print("[FAIL] wm: boot messages out of order")
        return False


def main():
    output = run_qemu(timeout=30)

    results = [
        test_shell_prompt_full(output),
        test_full_boot_chain_serial(output),
        test_no_serial_errors(output),
        test_boot_message_order(output),
    ]

    if not print_summary(results, name="SHELL REGRESSION TESTS"):
        sys.exit(1)


if __name__ == "__main__":
    main()
