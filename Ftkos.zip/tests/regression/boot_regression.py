#!/usr/bin/env python3
"""
Boot Regression Test Suite

Every boot-related bug that has been fixed gets a test here.
These tests ensure that previously fixed bugs never reappear.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "qemu"))
from run import run_qemu
from expect import check_expected, check_excluded, print_summary


# Regression: Boot must not hang before "Kernel booted"
def test_regression_boot_hang(output):
    return check_expected(
        output,
        ["Kernel booted"],
        name="regression: boot does not hang (issue #1)"
    )


# Regression: Paging must initialize before kernel continues
def test_regression_paging_order(output):
    lines = output.splitlines()
    paging_init_idx = -1
    kernel_booted_idx = -1
    for i, l in enumerate(lines):
        if "Paging enabled" in l:
            paging_init_idx = i
        if "Kernel booted" in l:
            kernel_booted_idx = i

    if paging_init_idx >= 0 and kernel_booted_idx >= 0 and paging_init_idx < kernel_booted_idx:
        print(f"[PASS] regression: paging init precedes kernel boot (issue #2)")
        return True
    else:
        print(f"[FAIL] regression: paging init does not precede kernel boot (issue #2)")
        return False


# Regression: No unexplained double faults during boot
def test_regression_no_double_fault(output):
    return check_excluded(
        output,
        ["Double Fault"],
        name="regression: no double fault during boot (issue #3)"
    )


# Regression: Serial output is not truncated
def test_regression_serial_not_truncated(output):
    if "Kernel booted successfully" in output:
        print(f"[PASS] regression: serial output complete (issue #4)")
        return True
    print(f"[FAIL] regression: serial output truncated (issue #4)")
    return False


def main():
    output = run_qemu(timeout=20)

    results = [
        test_regression_boot_hang(output),
        test_regression_paging_order(output),
        test_regression_no_double_fault(output),
        test_regression_serial_not_truncated(output),
    ]

    if not print_summary(results, name="BOOT REGRESSION TESTS"):
        sys.exit(1)


if __name__ == "__main__":
    main()
