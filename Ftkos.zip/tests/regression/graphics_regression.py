#!/usr/bin/env python3
"""
Graphics Regression Test Suite

Verifies that the framebuffer/graphics output behaves correctly.
Since we can't capture framebuffer from serial, we check for
graphics-related serial log messages.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "qemu"))
from run import run_qemu
from expect import check_expected, print_summary


def test_framebuffer_initialized(output):
    return check_expected(
        output,
        ["Graphics Enabled"],
        name="graphics: framebuffer initialized"
    )


def test_framebuffer_ok_message(output):
    """Check that boot messages about framebuffer init appear."""
    markers = ["Memory initialized", "Paging enabled"]
    return check_expected(output, markers, name="graphics: boot messages shown")


def main():
    output = run_qemu(timeout=20)

    results = [
        test_framebuffer_initialized(output),
        test_framebuffer_ok_message(output),
    ]

    if not print_summary(results, name="GRAPHICS REGRESSION TESTS"):
        sys.exit(1)


if __name__ == "__main__":
    main()
