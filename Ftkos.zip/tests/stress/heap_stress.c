#include <ftk/test.h>
#include <ftk/memory.h>
#include <ftk/string.h>

#define HEAP_OPS 100000

static void test_heap_stress_alloc_free(void) {
    TEST_START("STRESS: heap alloc/free 100K operations");
    int ok = 1;
    for (int i = 0; i < HEAP_OPS; i++) {
        size_t sz = 1 + (i % 4096);
        void *p = kmalloc(sz);
        if (!p) {
            if (i < 10) {
                ok = 0;
                break;
            }
            continue;
        }
        memset(p, (u8)(i & 0xFF), sz);
        kfree(p);
    }
    TEST_ASSERT(ok, "100K operations completed");
    kprintf("  %d alloc/free cycles\n", HEAP_OPS);
    TEST_END();
}

static void test_heap_stress_random_free(void) {
    TEST_START("STRESS: random order alloc/free with varied sizes");
    void *ptrs[256];
    size_t sizes[256];
    int ok = 1;

    int total_allocs = 0;
    for (int round = 0; round < 30 && ok; round++) {
        int count = 0;
        for (int i = 0; i < 64; i++) {
            sizes[i] = (i % 2 == 0) ? 256 : (i % 3 == 0) ? 1024 :
                       (i % 5 == 0) ? 4096 : 64;
            ptrs[i] = kmalloc(sizes[i]);
            if (!ptrs[i]) {
                sizes[i] = 16;
                ptrs[i] = kmalloc(16);
            }
            if (!ptrs[i]) break;
            memset(ptrs[i], (u8)((i + round) & 0xFF), sizes[i]);
            count++;
            total_allocs++;
        }
        for (int i = count - 1; i >= 0; i--) {
            u8 *buf = (u8 *)ptrs[i];
            for (size_t j = 0; j < sizes[i] && j < 8; j++) {
                if (buf[j] != (u8)((i + round) & 0xFF)) { ok = 0; break; }
            }
            if (!ok) break;
            kfree(ptrs[i]);
        }
    }
    kprintf("  total allocs: %d\n", total_allocs);
    TEST_ASSERT(total_allocs > 0, "at least some allocations succeeded");
    TEST_ASSERT(ok, "random alloc/free with varied sizes");
    TEST_END();
}

void test_heap_stress_register(void) {
    test_register("stress: heap 100K alloc/free", test_heap_stress_alloc_free);
    test_register("stress: heap random size alloc/free", test_heap_stress_random_free);
}
