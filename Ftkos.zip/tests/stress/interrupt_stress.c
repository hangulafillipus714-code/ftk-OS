#include <ftk/test.h>
#include <ftk/arch/x86_64/isr.h>
#include <drivers/timer/pit.h>

static void test_timer_interrupt_stress(void) {
    TEST_START("STRESS: PIT generates 1000 timer interrupts");

    system_ticks = 0;
    pit_init(100);
    __asm__ volatile("sti");
    while (system_ticks < 1000) {
        __asm__ volatile("pause");
    }
    __asm__ volatile("cli");

    kprintf("  system_ticks: %llu\n", (u64)system_ticks);
    TEST_ASSERT(system_ticks >= 1000, "expected >=1000 timer ticks from PIT");
    TEST_END();
}

void test_interrupt_stress_register(void) {
    test_register("stress: PIT timer 1000 ticks", test_timer_interrupt_stress);
}
