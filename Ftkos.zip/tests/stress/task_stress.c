#include <ftk/test.h>
#include <ftk/scheduler.h>
#include <ftk/memory.h>

static volatile int stress_counters[500];

static void stress_task(void) {
    int id = -1;
    for (int i = 0; i < 500; i++) {
        if (stress_counters[i] == -1) {
            stress_counters[i] = 0;
            id = i;
            break;
        }
    }
    if (id < 0) return;
    for (int i = 0; i < 1000; i++) {
        stress_counters[id]++;
    }
}

static void test_create_500_tasks(void) {
    TEST_START("STRESS: create 500 tasks (no crash)");
    /* Check available memory first */
    extern size_t pmm_get_free_page_count(void);
    size_t pages = pmm_get_free_page_count();
    kprintf("  free pages: %u\n", (unsigned int)pages);
    int max_tasks = (pages > 100) ? 500 : (pages > 10) ? 50 : 10;
    int count = 0;
    for (int i = 0; i < max_tasks; i++) {
        Task *t = create_task("stress", stress_task);
        if (!t) break;
        count++;
    }
    kprintf("  created %d tasks\n", count);
    TEST_ASSERT(count > 0, "at least some tasks created");
    TEST_END();
}

void test_task_stress_register(void) {
    test_register("stress: create 500 tasks", test_create_500_tasks);
}
