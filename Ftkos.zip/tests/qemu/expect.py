#!/usr/bin/env python3
"""
FTK OS Expected Output Checker

Checks captured serial output against expected patterns.
Used by integration and regression tests.
"""

import re
import sys


def check_expected(output: str, expected: list, name: str = "test") -> bool:
    """
    Verify that all expected patterns appear in the output in order.
    
    Args:
        output: Full serial output string.
        expected: List of strings or (pattern, description) tuples.
                  Patterns are treated as regex if they start/end with /.
        name: Test name for reporting.
    
    Returns:
        True if all patterns match, False otherwise.
    """
    lines = output.splitlines()
    all_found = True
    missing = []

    for item in expected:
        if isinstance(item, tuple):
            pattern, desc = item
        else:
            pattern = item
            desc = item

        is_regex = pattern.startswith("/") and pattern.endswith("/")
        found = False

        for line in lines:
            if is_regex:
                if re.search(pattern[1:-1], line):
                    found = True
                    break
            else:
                if pattern in line:
                    found = True
                    break

        if not found:
            all_found = False
            missing.append(desc)

    if all_found:
        print(f"[PASS] {name}: All expected patterns found")
        return True
    else:
        print(f"[FAIL] {name}: Missing patterns: {', '.join(missing)}")
        return False


def check_excluded(output: str, excluded: list, name: str = "test") -> bool:
    """
    Verify that certain patterns do NOT appear in output.
    
    Returns:
        True if none of the excluded patterns appear.
    """
    lines = output.splitlines()
    found_unexpected = []

    for pattern in excluded:
        for line in lines:
            if pattern in line:
                found_unexpected.append(pattern)
                break

    if found_unexpected:
        print(f"[FAIL] {name}: Unexpected patterns found: {', '.join(found_unexpected)}")
        return False
    
    print(f"[PASS] {name}: No unexpected patterns")
    return True


def print_summary(results: list, name: str = "TEST SUITE"):
    """Print a summary of all test results."""
    passed = sum(1 for r in results if r)
    total = len(results)
    print(f"\n{'=' * 40}")
    print(f"  {name}")
    print(f"  {passed}/{total} passed")
    if passed == total:
        print(f"  ALL TESTS PASSED")
    else:
        print(f"  {total - passed} TEST(S) FAILED")
    print(f"{'=' * 40}")
    return passed == total
