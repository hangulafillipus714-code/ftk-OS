#!/usr/bin/env python3
"""
FTK OS QEMU Test Harness

Launches QEMU with the FTK OS, captures serial output,
enforces a timeout, and returns the log.
"""

import subprocess
import sys
import os
import signal
import time
import tempfile
from pathlib import Path

FTK_DIR = Path(__file__).resolve().parent.parent.parent
BUILD_DIR = FTK_DIR / "build"
OVMF_PATH = "/usr/share/ovmf/OVMF.fd"


def run_qemu(timeout: int = 30, extra_args: list = None,
             image: str = None) -> str:
    """
    Launch QEMU and capture serial output.
    
    Uses a temporary file for serial output to avoid buffering issues
    with pipe-based stdout capture.
    
    Args:
        timeout: Maximum seconds to wait before killing QEMU.
        extra_args: Additional QEMU arguments.
        image: Path to disk image (default: build/ftk_uefi.img).
    
    Returns:
        Full serial output as a string.
    
    Raises:
        FileNotFoundError: If disk image or OVMF is missing.
        TimeoutError: If QEMU doesn't exit within timeout.
        RuntimeError: If QEMU crashes or returns non-zero.
    """
    qemu_img = Path(image) if image else BUILD_DIR / "ftk_uefi.img"
    if not qemu_img.exists():
        raise FileNotFoundError(f"Disk image not found: {qemu_img}")
    if not os.path.exists(OVMF_PATH):
        raise FileNotFoundError(f"OVMF firmware not found: {OVMF_PATH}")

    serial_file = tempfile.NamedTemporaryFile(prefix="ftk_serial_", mode="w+", delete=False)
    serial_path = serial_file.name
    serial_file.close()

    cmd = [
        "qemu-system-x86_64",
        "-machine", "q35",
        "-cpu", "max",
        "-smp", "4",
        "-bios", OVMF_PATH,
        "-drive", f"format=raw,file={qemu_img}",
        "-net", "none",
        "-serial", f"file:{serial_path}",
        "-m", "2G",
        "-no-reboot",
        "-display", "none",
        "-d", "guest_errors",
    ]
    if extra_args:
        cmd.extend(extra_args)

    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except FileNotFoundError:
        os.unlink(serial_path)
        raise RuntimeError("qemu-system-x86_64 not found. Install qemu-system-x86.")

    try:
        proc.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        proc.send_signal(signal.SIGTERM)
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()

    with open(serial_path, "r") as f:
        output = f.read()

    try:
        os.unlink(serial_path)
    except OSError:
        pass

    if not output:
        raise TimeoutError(
            f"QEMU produced no serial output within {timeout}s. "
            f"Check that the disk image boots correctly."
        )

    return output


def main():
    timeout = 30
    image = None
    extra_args = []
    
    argv = sys.argv[1:]
    i = 0
    while i < len(argv):
        if argv[i] == "--image" and i + 1 < len(argv):
            image = argv[i + 1]
            i += 2
        elif argv[i] == "--timeout" and i + 1 < len(argv):
            timeout = int(argv[i + 1])
            i += 2
        elif argv[i].startswith("--"):
            i += 1
        else:
            try:
                timeout = int(argv[i])
                i += 1
            except ValueError:
                extra_args.append(argv[i])
                i += 1
    
    try:
        output = run_qemu(timeout=timeout, extra_args=extra_args, image=image)
        print(output, end="")
    except (FileNotFoundError, TimeoutError, RuntimeError) as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
