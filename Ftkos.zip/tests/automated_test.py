#!/usr/bin/env python3
"""Test echo x5 (no VFS) then ls x1."""

import socket, time, sys, subprocess

proc = subprocess.Popen([
    'qemu-system-x86_64', '-machine', 'q35',
    '-bios', '/usr/share/ovmf/OVMF.fd',
    '-drive', 'format=raw,file=build/ftk_uefi.img',
    '-net', 'none',
    '-serial', 'tcp::4567,server=on,wait=off',
    '-m', '2G', '-no-reboot', '-display', 'none',
    '-debugcon', 'file:/tmp/trace.log',
    '-global', 'isa-debugcon.iobase=0x500'
], stderr=subprocess.DEVNULL, stdout=subprocess.DEVNULL)

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
for attempt in range(20):
    try:
        s.settimeout(1); s.connect(('127.0.0.1', 4567)); break
    except: time.sleep(1)
else: print("[!] Connection failed"); sys.exit(1)
s.settimeout(1)

def recv_all(deadline=20):
    data = b''
    t0 = time.time()
    while time.time() - t0 < deadline:
        try:
            d = s.recv(65536)
            if not d: break
            data += d
        except socket.timeout: continue
    return data

print("[*] Booting...", flush=True)
time.sleep(20)
print("[*] Draining boot output...", flush=True)
recv_all(15)

# Test echo (no disk)
for i in range(5):
    # Drain any leftover
    time.sleep(1)
    recv_all(2)
    # Send command
    s.sendall(b'echo hello\n')
    time.sleep(5)
    out = recv_all(8)
    has = b'hello' in out
    print(f'echo #{i+1}: {len(out)} bytes, hello={has}', flush=True)
    if not has and out:
        print(f'  raw: {out[:200]}', flush=True)

# Test ls (disk)
s.send(b'ls\r')
time.sleep(10)
out = recv_all(10)
print(f'ls: {len(out)} bytes', flush=True)
if out:
    print(out.decode(errors='replace')[-500:], flush=True)

s.close(); proc.kill(); proc.wait()

# Print trace markers
import os
try:
    with open('/tmp/trace.log') as f:
        trace = f.read()
    print(f'\n--- Trace markers ({len(trace)} chars) ---')
    # Print unique markers in order
    markers = ''.join(c for c in trace if c.isalpha() and c.isupper())
    print(f'Markers: {markers}')
except: pass
