#!/usr/bin/env python3
"""
Generate test_suite.c from test source files.

Scans test source files for functions matching
    void test_<name>_register(void)
and generates a test_suite_init() that calls all of them.
"""

import re
import sys
from pathlib import Path


def find_register_funcs(src_files):
    """Find all test registration functions in source files."""
    pattern = re.compile(r'void\s+(test_\w+_register)\s*\(\s*void\s*\)')
    results = {}
    
    for src in src_files:
        content = Path(src).read_text()
        matches = pattern.findall(content)
        if matches:
            results[src] = matches
    
    return results


def gen_suite(register_map, output_path):
    """Generate the test_suite_init function."""
    lines = []
    lines.append('#include <ftk/test.h>')
    lines.append('')
    
    # Collect all func names
    all_funcs = []
    for src, funcs in register_map.items():
        for f in funcs:
            lines.append(f'extern void {f}(void);')
            all_funcs.append(f)
    
    lines.append('')
    lines.append('void test_suite_init(void) {')
    for f in all_funcs:
        lines.append(f'    {f}();')
    lines.append('}')
    lines.append('')
    
    Path(output_path).write_text('\n'.join(lines))
    print(f"[GEN] {output_path}: {len(all_funcs)} registration(s)")


def main():
    if len(sys.argv) < 3:
        print("Usage: gen_suite.py <output> <src1> [src2 ...]")
        sys.exit(1)
    
    output = sys.argv[1]
    srcs = sys.argv[2:]
    
    register_map = find_register_funcs(srcs)
    gen_suite(register_map, output)


if __name__ == '__main__':
    main()
