#include <ftk/test.h>
#include <ftk/string.h>

static void test_strlen_basic(void) {
    TEST_START("strlen returns correct length");
    TEST_ASSERT(strlen("") == 0, "empty string");
    TEST_ASSERT(strlen("a") == 1, "single char");
    TEST_ASSERT(strlen("hello") == 5, "hello");
    TEST_ASSERT(strlen("hello world") == 11, "two words");
    TEST_ASSERT(strlen("abcdefghijklmnopqrstuvwxyz") == 26, "alphabet");
    TEST_END();
}

static void test_strcmp_basic(void) {
    TEST_START("strcmp compares correctly");
    TEST_ASSERT(strcmp("", "") == 0, "empty strings");
    TEST_ASSERT(strcmp("a", "a") == 0, "same char");
    TEST_ASSERT(strcmp("hello", "hello") == 0, "same string");
    TEST_ASSERT(strcmp("abc", "abd") < 0, "less than");
    TEST_ASSERT(strcmp("abd", "abc") > 0, "greater than");
    TEST_ASSERT(strcmp("short", "longer") != 0, "different lengths");
    TEST_END();
}

static void test_strncmp_basic(void) {
    TEST_START("strncmp compares with limit");
    TEST_ASSERT(strncmp("abc", "abc", 3) == 0, "exact n");
    TEST_ASSERT(strncmp("abc", "abd", 2) == 0, "partial match");
    TEST_ASSERT(strncmp("abc", "abd", 3) < 0, "diff at n");
    TEST_ASSERT(strncmp("ab", "abc", 2) == 0, "shorter string");
    TEST_ASSERT(strncmp("abc", "abc", 0) == 0, "zero length");
    TEST_END();
}

static void test_memcpy_basic(void) {
    char dst[32];
    const char *src = "hello world";
    TEST_START("memcpy copies correctly");
    memset(dst, 0, sizeof(dst));
    memcpy(dst, src, 12);
    TEST_ASSERT(strcmp(dst, "hello world") == 0, "basic copy");
    TEST_ASSERT(dst[10] == 'd', "last char 'd' at index 10");
    TEST_ASSERT(dst[11] == '\0', "null terminator at index 11");
    TEST_END();
}

static void test_memcpy_overlap(void) {
    char buf[32];
    TEST_START("memcpy handles non-overlapping regions");
    memset(buf, 'A', 16);
    memset(buf + 16, 'B', 16);
    memcpy(buf + 8, buf + 16, 8);
    TEST_ASSERT(buf[7] == 'A', "before copy untouched");
    TEST_ASSERT(buf[8] == 'B', "copy dst correct");
    TEST_END();
}

static void test_memset_basic(void) {
    char buf[32];
    TEST_START("memset sets memory correctly");
    memset(buf, 0xAA, sizeof(buf));
    for (int i = 0; i < 32; i++) {
        TEST_ASSERT((u8)buf[i] == 0xAA, "byte pattern");
    }
    memset(buf, 0, sizeof(buf));
    TEST_ASSERT(buf[0] == 0, "first byte zero");
    TEST_ASSERT(buf[31] == 0, "last byte zero");
    TEST_END();
}

static void test_strcpy_basic(void) {
    char dst[32];
    TEST_START("strcpy copies string");
    memset(dst, 0, sizeof(dst));
    strcpy(dst, "hello");
    TEST_ASSERT(strcmp(dst, "hello") == 0, "basic copy");
    TEST_ASSERT(strlen(dst) == 5, "correct length");
    TEST_END();
}

static void test_strncpy_basic(void) {
    char dst[16];
    TEST_START("strncpy copies with limit");
    memset(dst, 0xAA, sizeof(dst));
    strncpy(dst, "hello", 3);
    TEST_ASSERT(strncmp(dst, "hel", 3) == 0, "partial copy");
    dst[15] = 0;
    TEST_END();
}

static void test_strchr_basic(void) {
    TEST_START("strchr finds character");
    const char *s = "hello world";
    TEST_ASSERT(strchr(s, 'h') == s, "first char");
    TEST_ASSERT(strchr(s, 'w') == s + 6, "middle char");
    TEST_ASSERT(strchr(s, 'z') == NULL, "not found");
    TEST_END();
}

void test_string_register(void) {
    test_register("string: strlen", test_strlen_basic);
    test_register("string: strcmp", test_strcmp_basic);
    test_register("string: strncmp", test_strncmp_basic);
    test_register("string: memcpy", test_memcpy_basic);
    test_register("string: memcpy non-overlap", test_memcpy_overlap);
    test_register("string: memset", test_memset_basic);
    test_register("string: strcpy", test_strcpy_basic);
    test_register("string: strncpy", test_strncpy_basic);
    test_register("string: strchr", test_strchr_basic);
}
