#include <ftk/test.h>
#include <ftk/arch/x86_64/idt.h>
#include <ftk/arch/x86_64/isr.h>
#include <ftk/io.h>
#include <ftk/string.h>

extern struct idt_entry idt[256];
extern struct idt_ptr idtp;
extern isr_handler_t interrupt_handlers[256];

static void test_idt_loaded(void) {
    TEST_START("IDT: loaded and valid");
    u64 base = idtp.base;
    u16 limit = idtp.limit;
    
    kprintf("  IDT base: 0x%llx, limit: %u\n", base, limit);
    TEST_ASSERT(base != 0, "IDT base is non-zero");
    TEST_ASSERT(limit == sizeof(struct idt_entry) * 256 - 1, "IDT limit is correct");
    TEST_END();
}

static void test_idt_entries_valid(void) {
    TEST_START("IDT: all 256 entries initialized");
    int valid = 0;
    for (int i = 0; i < 256; i++) {
        if (idt[i].flags != 0) valid++;
    }
    kprintf("  Valid entries: %d/256\n", valid);
    TEST_ASSERT(valid == 256, "all 256 IDT entries are initialized");
    TEST_END();
}

static void test_exception_gates_present(void) {
    TEST_START("IDT: CPU exception gates (0-31) present");
    for (int i = 0; i < 32; i++) {
        TEST_ASSERT(idt[i].flags & 0x80, "exception vector present");
        TEST_ASSERT(idt[i].selector == 0x08, "exception uses kernel CS");
    }
    TEST_END();
}

static void test_irq_gates_present(void) {
    TEST_START("IDT: IRQ gates (32-47) present");
    for (int i = 32; i < 48; i++) {
        TEST_ASSERT(idt[i].flags & 0x80, "IRQ vector present");
        TEST_ASSERT(idt[i].selector == 0x08, "IRQ uses kernel CS");
    }
    TEST_END();
}

static void test_pic_remapped(void) {
    TEST_START("PIC: master/slave remapped to 0x20/0x28");
    u8 master_mask = inb(0x21);
    u8 slave_mask = inb(0xA1);
    kprintf("  PIC master mask: 0x%02x, slave mask: 0x%02x\n", master_mask, slave_mask);
    TEST_ASSERT(master_mask != 0x00, "master PIC not at default vector");
    TEST_ASSERT(slave_mask != 0x00, "slave PIC not at default vector");
    TEST_END();
}

static void test_interrupt_flag(void) {
    TEST_START("CPU: interrupt flag (IF) manipulation");
    u64 rflags_before, rflags_after;
    
    __asm__ volatile("sti");
    __asm__ volatile("pushfq; pop %0" : "=r" (rflags_before));
    __asm__ volatile("cli");
    __asm__ volatile("pushfq; pop %0" : "=r" (rflags_after));
    
    kprintf("  RFLAGS before: 0x%llx, after cli: 0x%llx\n", rflags_before, rflags_after);
    TEST_ASSERT((rflags_before & (1ULL << 9)) != 0, "IF was set before cli");
    TEST_ASSERT((rflags_after & (1ULL << 9)) == 0, "IF is clear after cli");
    
    __asm__ volatile("sti");
    __asm__ volatile("pushfq; pop %0" : "=r" (rflags_after));
    TEST_ASSERT((rflags_after & (1ULL << 9)) != 0, "IF is set after sti");
    TEST_END();
}

/* Interrupt nesting test state */
static volatile int nesting_level = 0;
static volatile int max_nesting = 0;
static volatile u64 nesting_rip[16];
static volatile u64 nesting_rsp[16];
static volatile int nesting_vector[16];
static volatile int nesting_rounds = 0;

static void nested_outer_handler(Registers *regs) {
    nesting_level++;
    if (nesting_level > max_nesting) max_nesting = nesting_level;
    nesting_rip[nesting_level - 1] = regs->rip;
    nesting_rsp[nesting_level - 1] = regs->rsp;
    nesting_vector[nesting_level - 1] = regs->int_no;
    
    if (nesting_level == 1) {
        __asm__ volatile("int $0x22");  /* Nested: trigger vector 34 */
    }
    
    nesting_level--;
    if (nesting_level == 0) nesting_rounds++;
}

static void nested_inner_handler(Registers *regs) {
    nesting_level++;
    if (nesting_level > max_nesting) max_nesting = nesting_level;
    nesting_rip[nesting_level - 1] = regs->rip;
    nesting_rsp[nesting_level - 1] = regs->rsp;
    nesting_vector[nesting_level - 1] = regs->int_no;
    
    nesting_level--;
}

static void test_interrupt_nesting(void) {
    TEST_START("INTERRUPT NESTING: INT 0x21 triggers INT 0x22 inside ISR");
    
    nesting_level = 0;
    max_nesting = 0;
    nesting_rounds = 0;
    memset((void*)nesting_rip, 0, sizeof(nesting_rip));
    memset((void*)nesting_rsp, 0, sizeof(nesting_rsp));
    memset((void*)nesting_vector, 0, sizeof(nesting_vector));
    
    isr_register_handler(0x21, nested_outer_handler);  /* vector 33 */
    isr_register_handler(0x22, nested_inner_handler);  /* vector 34 */
    
    /* Trigger nesting 3 times */
    for (int i = 0; i < 3; i++) {
        __asm__ volatile("int $0x21");
    }
    
    isr_register_handler(0x21, NULL);
    isr_register_handler(0x22, NULL);
    
    kprintf("  Max nesting level reached: %d\n", max_nesting);
    kprintf("  Nesting rounds: %d\n", nesting_rounds);
    for (int i = 0; i < max_nesting; i++) {
        kprintf("  Level %d: Vector=%d, RIP=0x%llx, RSP=0x%llx\n",
                i + 1, nesting_vector[i], nesting_rip[i], nesting_rsp[i]);
    }
    
    TEST_ASSERT(max_nesting >= 2, "reached nesting level 2");
    TEST_ASSERT(nesting_vector[0] == 0x21, "outer interrupt was vector 0x21");
    TEST_ASSERT(nesting_vector[1] == 0x22, "nested interrupt was vector 0x22");
    TEST_ASSERT(nesting_rip[0] != 0 && nesting_rip[1] != 0, "RIP captured for both levels");
    TEST_ASSERT(nesting_rsp[0] != nesting_rsp[1], "different stack pointers at each level");
    TEST_END();
}

void test_idt_pic_register(void) {
    test_register("idt: loaded", test_idt_loaded);
    test_register("idt: entries initialized", test_idt_entries_valid);
    test_register("idt: exception gates", test_exception_gates_present);
    test_register("idt: irq gates", test_irq_gates_present);
    test_register("pic: remapped", test_pic_remapped);
    test_register("cpu: interrupt flag", test_interrupt_flag);
    test_register("interrupt: nesting", test_interrupt_nesting);
}