#include <ftk/test.h>
#include <ftk/arch/x86_64/isr.h>
#include <ftk/io.h>
#include <ftk/scheduler.h>

static void dummy_entry(void) { while (1) __asm__ volatile("pause"); }

static void test_task_creation(void) {
    TEST_START("SCHEDULER: task creation (A/B/C)");
    
    Task *task_a = create_task("TaskA", dummy_entry);
    Task *task_b = create_task("TaskB", dummy_entry);
    Task *task_c = create_task("TaskC", dummy_entry);
    
    TEST_ASSERT(task_a != NULL, "Task A created");
    TEST_ASSERT(task_b != NULL, "Task B created");
    TEST_ASSERT(task_c != NULL, "Task C created");
    
    kprintf("  Created tasks: A(PID=%d) B(PID=%d) C(PID=%d)\n", 
            task_a->pid, task_b->pid, task_c->pid);
    TEST_END();
}

void test_interrupt_nesting_register(void) {
    test_register("scheduler: task creation", test_task_creation);
}

void test_scheduler_context_switch_register(void) {
}
