#include <ftk/test.h>
#include <ftk/scheduler.h>
#include <ftk/memory.h>
#include <ftk/string.h>

static volatile int task_a_ran = 0;

static void dummy_task_a(void) {
    task_a_ran = 1;
}

static void test_create_task_basic(void) {
    TEST_START("create_task returns valid task");
    Task *t = create_task("test_dummy", dummy_task_a);
    TEST_ASSERT(t != NULL, "task created");
    TEST_ASSERT(t->pid > 0, "non-zero PID");
    TEST_ASSERT(strncmp(t->name, "test_dummy", 10) == 0, "name set");
    TEST_ASSERT(t->state == TASK_READY, "initial state READY");
    TEST_END();
}

static void test_create_task_null_entry(void) {
    TEST_START("create_task with NULL entry returns NULL");
    Task *t = create_task("null", NULL);
    TEST_ASSERT(t == NULL, "NULL entry returns NULL");
    TEST_END();
}

static void test_multiple_tasks(void) {
    TEST_START("create 20 tasks");
    Task *tasks[20];
    int ok = 1;
    for (int i = 0; i < 20; i++) {
        tasks[i] = create_task("batch", dummy_task_a);
        if (!tasks[i]) {
            kprintf("  failed at task %d\n", i);
            ok = 0; break;
        }
    }
    TEST_ASSERT(ok, "all 20 tasks created");
    TEST_END();
}

static void test_task_name_max_length(void) {
    TEST_START("task name truncated to 31 chars");
    Task *t = create_task("this_is_a_very_long_task_name_that_exceeds_limit", dummy_task_a);
    if (t) {
        TEST_ASSERT(strlen(t->name) < 32, "name length < 32");
        TEST_ASSERT(strlen(t->name) == 31, "name truncated to 31 chars");
    } else {
        kprintf("  (task not created - insufficient memory)\n");
    }
    TEST_END();
}

static void test_scheduler_teardown(void) {
    TEST_START("sched: teardown state for subsequent tests");
    extern Task *task_list;
    extern Task *current_task;
    extern u32 next_pid;
    
    task_list = NULL;
    current_task = NULL;
    next_pid = 1;
    TEST_END();
}

void test_scheduler_register(void) {
    test_register("sched: create task", test_create_task_basic);
    test_register("sched: create task NULL entry", test_create_task_null_entry);
    test_register("sched: create 100 tasks", test_multiple_tasks);
    test_register("sched: task name truncation", test_task_name_max_length);
    test_register("sched: teardown state", test_scheduler_teardown);
}
