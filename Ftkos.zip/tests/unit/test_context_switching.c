#include <ftk/test.h>
#include <ftk/scheduler.h>
#include <ftk/memory.h>
#include <ftk/string.h>
#include <ftk/printk.h>
#include <ftk/pmm.h>
#include <ftk/memory_layout.h>

extern Task *current_task;
extern Task *task_list;
extern void task_switch(TaskContext *prev, TaskContext *next);

/* Task contexts for cooperative switching */
static TaskContext task_ctx[3];
static TaskContext test_ctx;
static volatile int task_counts[3];
static int yield_target = -1;

/* Task functions yield back to test */
static void task_func(void) {
    while (1) {
        task_counts[yield_target]++;
        task_switch(&task_ctx[yield_target], &test_ctx);
    }
}

static void test_context_switching(void) {
    TEST_START("CONTEXT SWITCHING: round-robin A/B/C");
    
    for (int i = 0; i < 3; i++) task_counts[i] = 0;

    /* Build task stacks manually.
     * Stack layout expected by task_switch (from HIGH to LOW):
     *   [return address] ← popped by 'ret'
     *   [RFLAGS]         ← popped by popfq
     *   RBX, RBP, R12, R13, R14, R15 ← popped in that order
     * We push in reverse: R15 first, through to return address last.
     */
    for (int i = 0; i < 3; i++) {
        phys_addr_t stack_phys = pmm_alloc_pages(4);
        TEST_ASSERT(stack_phys != 0, "stack page allocated");
        virt_addr_t stack_virt = PHYS_TO_VIRT(stack_phys);
        u64 *sp = (u64 *)(stack_virt + 4 * 4096);
        *(--sp) = (u64)task_func;   /* return address for 'ret' */
        *(--sp) = 0x202;            /* RFLAGS (IF=1) */
        *(--sp) = 0;                /* RBX */
        *(--sp) = 0;                /* RBP */
        *(--sp) = 0;                /* R12 */
        *(--sp) = 0;                /* R13 */
        *(--sp) = 0;                /* R14 */
        *(--sp) = 0;                /* R15 */
        task_ctx[i].rsp = (u64)sp;
    }

    /* Cooperative round-robin switching */
    char output[33];
    int op = 0;

    for (int round = 0; round < 8; round++) {
        for (int t = 0; t < 3; t++) {
            yield_target = t;
            task_switch(&test_ctx, &task_ctx[t]);
            if (op < 32) output[op++] = 'A' + t;
        }
    }
    output[op] = 0;

    kprintf("  Output: %s\n", output);
    kprintf("  Task A: %d, B: %d, C: %d\n", task_counts[0], task_counts[1], task_counts[2]);

    TEST_ASSERT(task_counts[0] == 8, "Task A ran 8 times");
    TEST_ASSERT(task_counts[1] == 8, "Task B ran 8 times");
    TEST_ASSERT(task_counts[2] == 8, "Task C ran 8 times");

    for (int i = 0; i < op; i++) {
        char expected = "ABC"[i % 3];
        if (output[i] != expected) {
            kprintf("  Pattern mismatch at pos %d: got '%c', expected '%c'\n", i, output[i], expected);
            TEST_END();
            return;
        }
    }
    TEST_ASSERT(1, "ABCABC... pattern maintained");

    TEST_END();
}

static void test_task_state_transitions(void) {
    TEST_START("CONTEXT SWITCHING: task state transitions");
    
    Task *t = create_task("StateTest", task_func);
    TEST_ASSERT(t != NULL, "task created");
    
    TEST_ASSERT(t->state == TASK_READY, "initial state READY");
    
    t->state = TASK_RUNNING;
    TEST_ASSERT(t->state == TASK_RUNNING, "state RUNNING");
    
    t->state = TASK_BLOCKED;
    TEST_ASSERT(t->state == TASK_BLOCKED, "state BLOCKED");
    
    t->state = TASK_READY;
    TEST_ASSERT(t->state == TASK_READY, "state back to READY");
    
    TEST_END();
}

static void test_task_stack_isolation(void) {
    TEST_START("CONTEXT SWITCHING: task stack isolation");
    
    Task *t1 = create_task("Stack1", task_func);
    Task *t2 = create_task("Stack2", task_func);
    
    TEST_ASSERT(t1 != NULL && t2 != NULL, "both tasks created");
    TEST_ASSERT(t1->context.rsp != t2->context.rsp, "different stack pointers");
    
    TEST_END();
}

static void test_scheduler_round_robin(void) {
    TEST_START("CONTEXT SWITCHING: scheduler round-robin order");
    
    /* Clear state left over from main.c or previous tests */
    extern Task *current_task;
    extern Task *task_list;
    current_task = NULL;
    task_list = NULL;

    /* Initialize scheduler to create idle task + task list */
    scheduler_init();
    
    Task *t1 = create_task("RR1", task_func);
    Task *t2 = create_task("RR2", task_func);
    Task *t3 = create_task("RR3", task_func);
    
    TEST_ASSERT(t1 && t2 && t3, "three tasks created");
    
    /* Verify circular list: idle -> t1 -> t2 -> t3 -> idle */
    TEST_ASSERT(task_list != NULL, "task_list exists (idle)");
    TEST_ASSERT(task_list->next == t1, "idle->next is first new task");
    TEST_ASSERT(t1->next == t2, "t1->next is t2");
    TEST_ASSERT(t2->next == t3, "t2->next is t3");
    TEST_ASSERT(t3->next == task_list, "t3->next wraps to idle");
    TEST_ASSERT(t3->prev == t2, "t3->prev is t2");
    TEST_ASSERT(t2->prev == t1, "t2->prev is t1");
    TEST_ASSERT(t1->prev == task_list, "t1->prev is idle");
    
    TEST_ASSERT(t1->pid != t2->pid && t2->pid != t3->pid && t1->pid != t3->pid, "unique PIDs");
    
    /* Reset scheduler state so subsequent tests don't accidentally switch into leftover tasks */
    current_task = NULL;
    task_list = NULL;
    extern u32 next_pid;
    next_pid = 1;
    
    TEST_END();
}

void test_context_switching_register(void) {
    test_register("ctx: round-robin ABC", test_context_switching);
    test_register("ctx: task state transitions", test_task_state_transitions);
    test_register("ctx: task stack isolation", test_task_stack_isolation);
    test_register("ctx: scheduler round-robin order", test_scheduler_round_robin);
}