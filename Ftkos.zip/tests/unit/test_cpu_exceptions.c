#include <ftk/test.h>
#include <ftk/arch/x86_64/isr.h>
#include <ftk/printk.h>
#include <ftk/memory.h>

static volatile int exception_caught = 0;
static volatile u64 exception_vector = 0;

/* #DE handler: int $0 (software int, RIP already past) */
static void handler_de(Registers *regs) {
    exception_caught = 1;
    exception_vector = regs->int_no;
}

/* #BP handler: int3 (trap, RIP already past) */
static void handler_bp(Registers *regs) {
    exception_caught = 1;
    exception_vector = regs->int_no;
}

/* #UD handler: ud2 (2 bytes: 0F 0B) */
static void handler_ud(Registers *regs) {
    exception_caught = 1;
    exception_vector = regs->int_no;
    regs->rip += 2;
}

/* #GP handler: ltr %w0 (3 bytes: 0F 00 D8) */
static void handler_gp(Registers *regs) {
    exception_caught = 1;
    exception_vector = regs->int_no;
    regs->rip += 3;
}



static void test_divide_by_zero(void) {
    TEST_START("EXCEPTION: divide by zero (#DE, vector 0)");
    exception_caught = 0;
    isr_register_handler(0, handler_de);
    __asm__ volatile("int $0");
    TEST_ASSERT(exception_caught, "exception was caught");
    TEST_ASSERT(exception_vector == 0, "correct vector (0)");
    TEST_END();
}

static void test_invalid_opcode(void) {
    TEST_START("EXCEPTION: invalid opcode (#UD, vector 6)");
    exception_caught = 0;
    isr_register_handler(6, handler_ud);
    __asm__ volatile("ud2");
    TEST_ASSERT(exception_caught, "exception was caught");
    TEST_ASSERT(exception_vector == 6, "correct vector (6)");
    TEST_END();
}

static void test_general_protection_fault(void) {
    TEST_START("EXCEPTION: general protection fault (#GP, vector 13)");
    exception_caught = 0;
    isr_register_handler(13, handler_gp);
    /* Load a task register selector beyond GDT limit to trigger #GP */
    __asm__ volatile("ltr %w0" : : "r" ((u16)0x0040));
    TEST_ASSERT(exception_caught, "exception was caught");
    TEST_ASSERT(exception_vector == 13, "correct vector (13)");
    TEST_END();
}

static void test_page_fault(void) {
    TEST_START("EXCEPTION: page fault (#PF, vector 14)");
    kprintf("  [SKIPPED] Unreliable return from #PF in test harness\n");
    TEST_END();
}

static void test_breakpoint(void) {
    TEST_START("EXCEPTION: breakpoint (#BP, vector 3)");
    exception_caught = 0;
    isr_register_handler(3, handler_bp);
    __asm__ volatile("int3");
    TEST_ASSERT(exception_caught, "exception was caught");
    TEST_ASSERT(exception_vector == 3, "correct vector (3)");
    TEST_END();
}

static void test_overflow(void) {
    TEST_START("EXCEPTION: overflow (#OF, vector 4)");
    kprintf("  [SKIPPED] INTO not supported in 64-bit mode\n");
    isr_register_handler(4, NULL);
    TEST_END();
}

static void test_bound_range_exceeded(void) {
    TEST_START("EXCEPTION: bound range exceeded (#BR, vector 5)");
    kprintf("  [SKIPPED] BOUND not supported in 64-bit mode\n");
    isr_register_handler(5, NULL);
    TEST_END();
}

static void test_device_not_available(void) {
    TEST_START("EXCEPTION: device not available (#NM, vector 7) - skip (needs CR0.TS set)");
    kprintf("  [SKIPPED] Requires CR0.TS bit to be set\n");
    isr_register_handler(7, NULL);
    TEST_END();
}

static void test_double_fault(void) {
    TEST_START("EXCEPTION: double fault (#DF, vector 8) - skip (would hang)");
    kprintf("  [SKIPPED] Double fault test skipped - requires dedicated IST stack\n");
    TEST_END();
}

static void test_invalid_tss(void) {
    TEST_START("EXCEPTION: invalid TSS (#TS, vector 10) - skip");
    kprintf("  [SKIPPED] Requires TSS manipulation\n");
    TEST_END();
}

static void test_segment_not_present(void) {
    TEST_START("EXCEPTION: segment not present (#NP, vector 11) - skip");
    kprintf("  [SKIPPED] Requires segment manipulation\n");
    TEST_END();
}

static void test_stack_segment_fault(void) {
    TEST_START("EXCEPTION: stack fault (#SS, vector 12) - skip");
    kprintf("  [SKIPPED] Requires stack segment manipulation\n");
    TEST_END();
}

static void test_x87_fpu_fault(void) {
    TEST_START("EXCEPTION: x87 FPU fault (#MF, vector 16) - skip");
    kprintf("  [SKIPPED] Requires FPU exception\n");
    TEST_END();
}

static void test_alignment_check(void) {
    TEST_START("EXCEPTION: alignment check (#AC, vector 17) - skip");
    kprintf("  [SKIPPED] Requires AC flag and unaligned access\n");
    TEST_END();
}

static void test_machine_check(void) {
    TEST_START("EXCEPTION: machine check (#MC, vector 18) - skip");
    kprintf("  [SKIPPED] Hardware-specific\n");
    TEST_END();
}

static void test_simd_fpu_fault(void) {
    TEST_START("EXCEPTION: SIMD FPU fault (#XM, vector 19) - skip");
    kprintf("  [SKIPPED] Requires SIMD FPU exception\n");
    TEST_END();
}

static void test_virtualization_exception(void) {
    TEST_START("EXCEPTION: virtualization (#VE, vector 20) - skip");
    kprintf("  [SKIPPED] Requires VMX\n");
    TEST_END();
}

static void test_security_exception(void) {
    TEST_START("EXCEPTION: security (#SX, vector 30) - skip");
    kprintf("  [SKIPPED] Requires SMM/SMX\n");
    TEST_END();
}

void test_cpu_exceptions_register(void) {
    test_register("exception: divide by zero", test_divide_by_zero);
    test_register("exception: invalid opcode", test_invalid_opcode);
    test_register("exception: general protection fault", test_general_protection_fault);
    test_register("exception: page fault", test_page_fault);
    test_register("exception: breakpoint", test_breakpoint);
    test_register("exception: overflow", test_overflow);
    test_register("exception: bound range exceeded", test_bound_range_exceeded);
    test_register("exception: device not available", test_device_not_available);
    test_register("exception: double fault", test_double_fault);
    test_register("exception: invalid tss", test_invalid_tss);
    test_register("exception: segment not present", test_segment_not_present);
    test_register("exception: stack fault", test_stack_segment_fault);
    test_register("exception: x87 fpu fault", test_x87_fpu_fault);
    test_register("exception: alignment check", test_alignment_check);
    test_register("exception: machine check", test_machine_check);
    test_register("exception: simd fpu fault", test_simd_fpu_fault);
    test_register("exception: virtualization", test_virtualization_exception);
    test_register("exception: security", test_security_exception);
}
