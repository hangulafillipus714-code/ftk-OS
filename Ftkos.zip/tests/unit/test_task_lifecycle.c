#include <ftk/test.h>
#include <ftk/scheduler.h>
#include <ftk/memory.h>
#include <ftk/string.h>
#include <ftk/waitqueue.h>

/* ── Helpers ──────────────────────────────────────────── */

static void dummy_entry(void) { }

/* ── task_destroy ─────────────────────────────────────── */

static void test_task_destroy_basic(void) {
    TEST_START("task_destroy frees a kernel task");
    Task *t = create_task("victim", dummy_entry);
    TEST_ASSERT(t != NULL, "task created");
    u32 pid = t->pid;
    task_destroy(t);
    /* If we reach here without triple-fault, the destroy worked.
     * We can't dereference t anymore — it's freed. */
    TEST_ASSERT(pid > 0, "task had valid PID before destroy");
    TEST_END();
}

static void test_task_destroy_null(void) {
    TEST_START("task_destroy(NULL) does not crash");
    task_destroy(NULL);
    /* reaching here = pass */
    TEST_END();
}

static void test_task_destroy_idle(void) {
    TEST_START("task_destroy of PID 0 is a no-op");
    Task fake;
    memset(&fake, 0, sizeof(fake));
    fake.pid = 0;
    task_destroy(&fake);
    /* reaching here = pass */
    TEST_END();
}

/* ── scheduler_collect_zombie ─────────────────────────── */

static void test_zombie_collect_basic(void) {
    TEST_START("scheduler_collect_zombie collects matching zombie");

    extern Task *task_list;
    extern Task *current_task;

    /* Set up minimal scheduler state */
    if (!current_task) {
        Task *idle = kmalloc(sizeof(Task));
        TEST_ASSERT(idle != NULL, "alloc idle");
        memset(idle, 0, sizeof(Task));
        strncpy(idle->name, "idle", 31);
        idle->pid = 0;
        idle->state = TASK_RUNNING;
        current_task = idle;
    }
    current_task->pid = 99;
    current_task->parent_pid = 0;

    /* Create a child task and manually set it to zombie */
    Task *child = kmalloc(sizeof(Task));
    TEST_ASSERT(child != NULL, "alloc child");
    memset(child, 0, sizeof(Task));
    child->pid = 100;
    child->parent_pid = 99;
    child->state = TASK_ZOMBIE;
    child->exit_status = 42;
    child->kernel_stack_phys = 0;
    child->address_space = NULL;

    /* Insert into circular list */
    if (task_list) {
        child->next = task_list->next;
        child->prev = task_list;
        task_list->next->prev = child;
        task_list->next = child;
    } else {
        task_list = child;
        child->next = child;
        child->prev = child;
    }

    /* Collect zombie */
    Task *zombie = scheduler_collect_zombie(100);
    TEST_ASSERT(zombie != NULL, "zombie collected");
    TEST_ASSERT_EQ(zombie->pid, 100, "correct PID");
    TEST_ASSERT_EQ(zombie->exit_status, 42, "exit status preserved");
    kfree(zombie);

    /* Verify no zombie remains */
    Task *again = scheduler_collect_zombie(100);
    TEST_ASSERT(again == NULL, "no zombie after collection");

    /* Restore child's allocation so we can clean up */
    /* (already freed via kfree above) */
    TEST_END();
}

static void test_zombie_collect_wrong_pid(void) {
    TEST_START("scheduler_collect_zombie returns NULL for unknown PID");

    extern Task *task_list;
    Task *zombie = scheduler_collect_zombie(999999);
    TEST_ASSERT(zombie == NULL, "no zombie for unknown PID");

    zombie = scheduler_collect_zombie(-1);
    /* may or may not find something depending on state — just no crash */
    TEST_END();
}

static void test_zombie_collect_not_zombie(void) {
    TEST_START("scheduler_collect_zombie skips non-zombie children");

    extern Task *task_list;
    extern Task *current_task;

    /* Create a RUNNING child (should not be collected) */
    Task *child = kmalloc(sizeof(Task));
    TEST_ASSERT(child != NULL, "alloc child");
    memset(child, 0, sizeof(Task));
    child->pid = 200;
    child->parent_pid = current_task ? current_task->pid : 99;
    child->state = TASK_RUNNING;

    if (task_list) {
        child->next = task_list->next;
        child->prev = task_list;
        task_list->next->prev = child;
        task_list->next = child;
    } else {
        task_list = child;
        child->next = child;
        child->prev = child;
    }

    Task *zombie = scheduler_collect_zombie(200);
    TEST_ASSERT(zombie == NULL, "running child not collected");

    /* Manually remove from list and free */
    if (task_list == child) {
        task_list = (child->next == child) ? NULL : child->next;
    }
    child->prev->next = child->next;
    child->next->prev = child->prev;
    kfree(child);

    TEST_END();
}

/* ── scheduler_has_child ───────────────────────────────── */

static void test_has_child_found(void) {
    TEST_START("scheduler_has_child finds matching child PID");

    extern Task *task_list;
    extern Task *current_task;

    if (!current_task) {
        Task *idle = kmalloc(sizeof(Task));
        memset(idle, 0, sizeof(Task));
        idle->pid = 99;
        idle->state = TASK_RUNNING;
        current_task = idle;
    }
    current_task->pid = 99;

    Task *child = kmalloc(sizeof(Task));
    memset(child, 0, sizeof(Task));
    child->pid = 101;
    child->parent_pid = 99;
    child->state = TASK_READY;

    if (task_list) {
        child->next = task_list->next;
        child->prev = task_list;
        task_list->next->prev = child;
        task_list->next = child;
    } else {
        task_list = child;
        child->next = child;
        child->prev = child;
    }

    int found = scheduler_has_child(101);
    TEST_ASSERT(found, "child 101 found");

    /* Cleanup */
    if (task_list == child) {
        task_list = (child->next == child) ? NULL : child->next;
    }
    child->prev->next = child->next;
    child->next->prev = child->prev;
    kfree(child);

    TEST_END();
}

static void test_has_child_not_found(void) {
    TEST_START("scheduler_has_child returns 0 for unknown PID");
    int found = scheduler_has_child(999999);
    TEST_ASSERT(!found, "unknown PID not found");
    TEST_END();
}

/* ── waitqueue ─────────────────────────────────────────── */

static void test_waitqueue_init_empty(void) {
    TEST_START("init_waitqueue_head initializes empty queue");
    wait_queue_head_t wq;
    init_waitqueue_head(&wq);
    TEST_ASSERT(wq.head == NULL, "head NULL");
    TEST_ASSERT(wq.tail == NULL, "tail NULL");
    TEST_END();
}

static void test_waitqueue_is_empty(void) {
    TEST_START("waitqueue_is_empty returns 1 for empty queue");
    wait_queue_head_t wq;
    init_waitqueue_head(&wq);
    TEST_ASSERT(waitqueue_is_empty(&wq), "empty queue");
    TEST_END();
}

/* ── Registration ──────────────────────────────────────── */

void test_task_lifecycle_register(void) {
    test_register("task: destroy basic",        test_task_destroy_basic);
    test_register("task: destroy NULL",          test_task_destroy_null);
    test_register("task: destroy idle",          test_task_destroy_idle);
    test_register("task: zombie collect basic",  test_zombie_collect_basic);
    test_register("task: zombie wrong PID",      test_zombie_collect_wrong_pid);
    test_register("task: zombie not zombie",     test_zombie_collect_not_zombie);
    test_register("task: has child found",       test_has_child_found);
    test_register("task: has child not found",   test_has_child_not_found);
    test_register("task: waitqueue init",        test_waitqueue_init_empty);
    test_register("task: waitqueue empty",       test_waitqueue_is_empty);
}
