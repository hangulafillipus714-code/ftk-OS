#include <ftk/test.h>
#include <ftk/abi/types.h>
#include <ftk/arch/x86_64/cpu.h>
#include <ftk/string.h>
#include <ftk/panic.h>
#include <ftk/stdbool.h>

/* ============================================================
 * SMP Preparation Tests
 * ============================================================ */

/* Spinlock implementation */
typedef struct spinlock {
    volatile u32 locked;
} spinlock_t;

#define SPINLOCK_INIT { 0 }

static inline void spinlock_acquire(spinlock_t *lock) {
    while (__sync_lock_test_and_set(&lock->locked, 1)) {
        while (lock->locked) {
            __asm__ volatile("pause");
        }
    }
}

static inline void spinlock_release(spinlock_t *lock) {
    __sync_lock_release(&lock->locked);
}

static inline int spinlock_try_acquire(spinlock_t *lock) {
    return !__sync_lock_test_and_set(&lock->locked, 1);
}

/* Atomic operations test */
static volatile u32 atomic_counter = 0;
static volatile u64 atomic64_counter = 0;
static volatile u32 atomic_bitmask = 0;

static void test_atomic_increment(void) {
    TEST_START("ATOMIC: __sync_fetch_and_add increment");
    atomic_counter = 0;
    for (int i = 0; i < 10000; i++) {
        __sync_fetch_and_add(&atomic_counter, 1);
    }
    TEST_ASSERT_EQ(atomic_counter, 10000, "atomic increment 10000 times");
    TEST_END();
}

static void test_atomic_decrement(void) {
    TEST_START("ATOMIC: __sync_fetch_and_sub decrement");
    atomic_counter = 10000;
    for (int i = 0; i < 10000; i++) {
        __sync_fetch_and_sub(&atomic_counter, 1);
    }
    TEST_ASSERT_EQ(atomic_counter, 0, "atomic decrement to zero");
    TEST_END();
}

static void test_atomic_compare_and_swap(void) {
    TEST_START("ATOMIC: __sync_bool_compare_and_swap");
    atomic_counter = 42;
    bool ok = __sync_bool_compare_and_swap(&atomic_counter, 42, 99);
    TEST_ASSERT(ok, "CAS succeeded when expected");
    TEST_ASSERT_EQ(atomic_counter, 99, "value changed to 99");
    
    ok = __sync_bool_compare_and_swap(&atomic_counter, 42, 100);
    TEST_ASSERT(!ok, "CAS failed when expected");
    TEST_ASSERT_EQ(atomic_counter, 99, "value unchanged after failed CAS");
    TEST_END();
}

static void test_atomic_64bit(void) {
    TEST_START("ATOMIC: 64-bit operations");
    atomic64_counter = 0;
    for (int i = 0; i < 5000; i++) {
        __sync_fetch_and_add(&atomic64_counter, 2);
    }
    TEST_ASSERT_EQ(atomic64_counter, 10000, "64-bit atomic add");
    
    __sync_fetch_and_sub(&atomic64_counter, 5000);
    TEST_ASSERT_EQ(atomic64_counter, 5000, "64-bit atomic sub");
    TEST_END();
}

static void test_atomic_bitwise(void) {
    TEST_START("ATOMIC: bitwise operations");
    atomic_bitmask = 0;
    
    /* Test OR */
    __sync_fetch_and_or(&atomic_bitmask, 0x0F);
    TEST_ASSERT_EQ(atomic_bitmask, 0x0F, "atomic OR");
    
    /* Test AND */
    __sync_fetch_and_and(&atomic_bitmask, 0x03);
    TEST_ASSERT_EQ(atomic_bitmask, 0x03, "atomic AND");
    
    /* Test XOR */
    __sync_fetch_and_xor(&atomic_bitmask, 0x01);
    TEST_ASSERT_EQ(atomic_bitmask, 0x02, "atomic XOR");
    
    /* Test NAND (via AND with complement) */
    __sync_fetch_and_and(&atomic_bitmask, ~0x02);
    TEST_ASSERT_EQ(atomic_bitmask, 0x00, "atomic NAND (AND with ~)");
    TEST_END();
}

/* Spinlock tests */
static spinlock_t test_lock = SPINLOCK_INIT;
static volatile int spinlock_critical_section_count = 0;
static volatile int spinlock_contention = 0;

static void test_spinlock_basic(void) {
    TEST_START("SPINLOCK: basic acquire/release");
    spinlock_acquire(&test_lock);
    spinlock_critical_section_count++;
    spinlock_release(&test_lock);
    TEST_ASSERT_EQ(spinlock_critical_section_count, 1, "critical section entered once");
    TEST_END();
}

static void test_spinlock_contention(void) {
    TEST_START("SPINLOCK: contention handling");
    spinlock_critical_section_count = 0;
    spinlock_contention = 0;
    
    spinlock_acquire(&test_lock);
    /* Simulate contention by trying to acquire again */
    if (!spinlock_try_acquire(&test_lock)) {
        spinlock_contention++;
    }
    spinlock_release(&test_lock);
    
    TEST_ASSERT_EQ(spinlock_contention, 1, "detected contention");
    TEST_END();
}

static void test_spinlock_try_acquire(void) {
    TEST_START("SPINLOCK: try_acquire");
    spinlock_t lock = SPINLOCK_INIT;
    
    int got = spinlock_try_acquire(&lock);
    TEST_ASSERT(got, "first try_acquire succeeds");
    
    got = spinlock_try_acquire(&lock);
    TEST_ASSERT(!got, "second try_acquire fails (already held)");
    
    spinlock_release(&lock);
    
    got = spinlock_try_acquire(&lock);
    TEST_ASSERT(got, "try_acquire succeeds after release");
    spinlock_release(&lock);
    TEST_END();
}

/* Interrupt enable/disable tests */
static void test_interrupt_disable_enable(void) {
    TEST_START("INTERRUPT: cli/sti");
    
    __asm__ volatile("sti");
    u64 rflags1;
    __asm__ volatile("pushfq; pop %0" : "=r" (rflags1));
    TEST_ASSERT(rflags1 & (1ULL << 9), "IF set after sti");
    
    __asm__ volatile("cli");
    u64 rflags2;
    __asm__ volatile("pushfq; pop %0" : "=r" (rflags2));
    TEST_ASSERT(!(rflags2 & (1ULL << 9)), "IF clear after cli");
    
    __asm__ volatile("sti");
    u64 rflags3;
    __asm__ volatile("pushfq; pop %0" : "=r" (rflags3));
    TEST_ASSERT(rflags3 & (1ULL << 9), "IF set after sti again");
    TEST_END();
}

static void test_interrupt_save_restore(void) {
    TEST_START("INTERRUPT: save/restore RFLAGS (cli + pushfq/popfq)");
    
    __asm__ volatile("sti");
    
    u64 saved_rflags;
    __asm__ volatile(
        "pushfq\n\t"
        "cli\n\t"
        "pop %0"
        : "=r" (saved_rflags)
        :
        : "memory", "cc"
    );
    
    TEST_ASSERT(saved_rflags & (1ULL << 9), "saved RFLAGS has IF=1");
    
    /* Restore */
    __asm__ volatile(
        "push %0\n\t"
        "popfq"
        :
        : "r" (saved_rflags)
        : "memory", "cc"
    );
    
    u64 current_rflags;
    __asm__ volatile("pushfq; pop %0" : "=r" (current_rflags));
    TEST_ASSERT(current_rflags & (1ULL << 9), "IF restored to 1");
    TEST_END();
}

/* Per-CPU data tests */
#define MAX_CPUS 8

typedef struct per_cpu_data {
    u32 cpu_id;
    u64 scheduler_ticks;
    void *current_task;
    spinlock_t lock;
    u64 irq_count[16];
} per_cpu_data_t;

static per_cpu_data_t per_cpu[MAX_CPUS] __attribute__((aligned(64)));

static void per_cpu_init(u32 cpu_id) {
    per_cpu[cpu_id].cpu_id = cpu_id;
    per_cpu[cpu_id].scheduler_ticks = 0;
    per_cpu[cpu_id].current_task = NULL;
    per_cpu[cpu_id].lock = (spinlock_t)SPINLOCK_INIT;
    memset(per_cpu[cpu_id].irq_count, 0, sizeof(per_cpu[cpu_id].irq_count));
}

static void test_per_cpu_initialization(void) {
    TEST_START("PER-CPU: initialization");
    per_cpu_init(0);
    TEST_ASSERT_EQ(per_cpu[0].cpu_id, 0, "CPU 0 ID set");
    TEST_ASSERT_EQ(per_cpu[0].scheduler_ticks, 0, "ticks zero");
    TEST_ASSERT(per_cpu[0].current_task == NULL, "no current task");
    TEST_END();
}

static void test_per_cpu_isolation(void) {
    TEST_START("PER-CPU: data isolation between CPUs");
    per_cpu_init(0);
    per_cpu_init(1);
    
    per_cpu[0].scheduler_ticks = 100;
    per_cpu[1].scheduler_ticks = 200;
    
    TEST_ASSERT_EQ(per_cpu[0].scheduler_ticks, 100, "CPU 0 ticks");
    TEST_ASSERT_EQ(per_cpu[1].scheduler_ticks, 200, "CPU 1 ticks");
    TEST_ASSERT(per_cpu[0].scheduler_ticks != per_cpu[1].scheduler_ticks, "isolated data");
    TEST_END();
}

static void test_per_cpu_irq_accounting(void) {
    TEST_START("PER-CPU: IRQ accounting");
    per_cpu_init(0);
    
    per_cpu[0].irq_count[0]++;  /* Timer */
    per_cpu[0].irq_count[1]++;  /* Keyboard */
    per_cpu[0].irq_count[0]++;  /* Timer again */
    
    TEST_ASSERT_EQ(per_cpu[0].irq_count[0], 2, "timer IRQ count");
    TEST_ASSERT_EQ(per_cpu[0].irq_count[1], 1, "keyboard IRQ count");
    TEST_END();
}

static void test_per_cpu_spinlock(void) {
    TEST_START("PER-CPU: spinlock in per-CPU data");
    per_cpu_init(0);
    
    spinlock_acquire(&per_cpu[0].lock);
    per_cpu[0].scheduler_ticks = 42;
    spinlock_release(&per_cpu[0].lock);
    
    TEST_ASSERT_EQ(per_cpu[0].scheduler_ticks, 42, "modified under lock");
    TEST_END();
}

/* Memory barrier tests */
static volatile u32 mb_var1 = 0, mb_var2 = 0;

static void test_memory_barrier(void) {
    TEST_START("MEMORY BARRIER: compiler and CPU barriers");
    
    mb_var1 = 1;
    __asm__ volatile("mfence" ::: "memory");  /* Full memory barrier */
    mb_var2 = 2;
    
    TEST_ASSERT_EQ(mb_var1, 1, "var1 set before barrier");
    TEST_ASSERT_EQ(mb_var2, 2, "var2 set after barrier");
    TEST_END();
}

static void test_compiler_barrier(void) {
    TEST_START("COMPILER BARRIER: prevent reordering");
    
    u32 a = 1;
    __asm__ volatile("" ::: "memory");  /* Compiler barrier */
    u32 b = 2;
    
    TEST_ASSERT_EQ(a, 1, "a unchanged");
    TEST_ASSERT_EQ(b, 2, "b set");
    TEST_END();
}

/* CPU feature detection for SMP */
static void test_cpu_feature_smp(void) {
    TEST_START("CPU: SMP-relevant features");
    
    u32 eax, ebx, ecx, edx;
    cpu_cpuid(1, 0, &eax, &ebx, &ecx, &edx);
    
    kprintf("  CPUID.1.ECX: 0x%08x\n", ecx);
    kprintf("  CPUID.1.EDX: 0x%08x\n", edx);
    
    bool htt = (edx >> 28) & 1;       /* Hyper-threading */
    bool apic = (edx >> 9) & 1;       /* Local APIC */
    bool cmpxchg8b = (edx >> 8) & 1;  /* CMPXCHG8B */
    bool hlt = (edx >> 4) & 1;        /* HLT instruction */
    
    kprintf("  HTT: %d, APIC: %d, CMPXCHG8B: %d, HLT: %d\n", htt, apic, cmpxchg8b, hlt);
    
    /* Check CPUID leaf 0xB for x2APIC/Logical Processor info */
    cpu_cpuid(0xB, 0, &eax, &ebx, &ecx, &edx);
    if (eax >= 0xB) {
        kprintf("  Extended topology leaf available\n");
    }
    
    TEST_ASSERT(apic, "Local APIC present (required for SMP)");
    TEST_END();
}

/* TSS and IST for interrupt handling */
static void test_tss_ist(void) {
    TEST_START("TSS: Task State Segment for IST");
    
    /* Verify TSS is set up (done in gdt.c) */
    u16 tr;
    __asm__ volatile("str %0" : "=r" (tr));
    kprintf("  TR (Task Register): 0x%04x\n", tr);
    
    TEST_ASSERT(tr != 0, "TSS loaded in TR");
    TEST_END();
}

void test_smp_preparation_register(void) {
    test_register("smp: atomic increment", test_atomic_increment);
    test_register("smp: atomic decrement", test_atomic_decrement);
    test_register("smp: atomic CAS", test_atomic_compare_and_swap);
    test_register("smp: atomic 64-bit", test_atomic_64bit);
    test_register("smp: atomic bitwise", test_atomic_bitwise);
    test_register("smp: spinlock basic", test_spinlock_basic);
    test_register("smp: spinlock contention", test_spinlock_contention);
    test_register("smp: spinlock try_acquire", test_spinlock_try_acquire);
    test_register("smp: interrupt cli/sti", test_interrupt_disable_enable);
    test_register("smp: interrupt save/restore", test_interrupt_save_restore);
    test_register("smp: per-cpu init", test_per_cpu_initialization);
    test_register("smp: per-cpu isolation", test_per_cpu_isolation);
    test_register("smp: per-cpu IRQ accounting", test_per_cpu_irq_accounting);
    test_register("smp: per-cpu spinlock", test_per_cpu_spinlock);
    test_register("smp: memory barrier", test_memory_barrier);
    test_register("smp: compiler barrier", test_compiler_barrier);
    test_register("smp: CPU features", test_cpu_feature_smp);
    test_register("smp: TSS/IST", test_tss_ist);
}