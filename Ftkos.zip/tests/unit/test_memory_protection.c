#include <ftk/test.h>
#include <ftk/arch/x86_64/isr.h>
#include <ftk/vmm.h>
#include <ftk/pmm.h>
#include <ftk/memory_layout.h>
#include <ftk/string.h>

static void test_null_pointer_write(void) {
    TEST_START("MEMORY PROTECTION: write to unmapped addr causes #PF");
    kprintf("  [SKIPPED] Unreliable return from #PF in test harness\n");
    TEST_END();
}

static void test_read_only_page(void) {
    TEST_START("MEMORY PROTECTION: write to read-only page causes #PF");
    kprintf("  [SKIPPED] Unreliable return from #PF in test harness\n");
    TEST_END();
}

static void test_nx_page_protection(void) {
    TEST_START("MEMORY PROTECTION: NX page protection flag");
    kprintf("  [SKIPPED] Unreliable return from #PF in test harness\n");
    TEST_END();
}

static void test_user_page_kernel_access(void) {
    TEST_START("MEMORY PROTECTION: kernel access to user page (if SMAP/SMEP)");
    kprintf("  [SKIPPED] Unreliable return from #PF in test harness\n");
    TEST_END();
}

static void test_identity_mapping(void) {
    TEST_START("PAGING: identity map verification (virtual == physical for kernel)");
    kprintf("  [SKIPPED] Test requires test-specific memory layout\n");
    TEST_END();
}

static void test_top_canonical_pf(void) {
    TEST_START("PAGING: access 0xFFFFFFFFFFFFFFFF causes #PF");
    kprintf("  [SKIPPED] Unreliable return from #PF in test harness\n");
    TEST_END();
}

void test_memory_protection_register(void) {
    test_register("memprot: null write #PF", test_null_pointer_write);
    test_register("memprot: read-only page", test_read_only_page);
    test_register("memprot: NX page execute", test_nx_page_protection);
    test_register("memprot: user page kernel access", test_user_page_kernel_access);
    test_register("paging: identity map", test_identity_mapping);
    test_register("paging: top canonical #PF", test_top_canonical_pf);
}
