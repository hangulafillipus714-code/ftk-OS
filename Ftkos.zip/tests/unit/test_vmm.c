#include <ftk/test.h>
#include <ftk/vmm.h>
#include <ftk/pmm.h>
#include <ftk/memory_layout.h>
#include <ftk/string.h>

/* Page table mappings consume extra pages for PDPT/PD/PT tables.
   Skip VMM tests if free pages are critically low. */
static int vmm_has_enough_pages(void) {
    size_t free = pmm_get_free_page_count();
    if (free < 16) {
        kprintf("  (skipping: only %d free pages)\n", (int)free);
        return 0;
    }
    return 1;
}



static void test_vmm_map_unmap(void) {
    TEST_START("VMM: map and unmap a page");
    if (!vmm_has_enough_pages()) { TEST_END(); return; }
    phys_addr_t phys = pmm_alloc_page();
    TEST_ASSERT(phys != 0, "physical page allocated");
    /* Use address far away from kernel's boot-mapped range */
    virt_addr_t virt = 0xFFFFFF0000000000ULL;
    int ret = vmm_map_page(&kernel_space, virt, phys, PTE_KERNEL_FLAGS);
    TEST_ASSERT(ret == 0, "map succeeded");
    phys_addr_t mapped = vmm_virt_to_phys(virt);
    TEST_ASSERT(mapped == phys, "virt_to_phys matches");
    ret = vmm_unmap_page(&kernel_space, virt);
    TEST_ASSERT(ret == 0, "unmap succeeded");
    mapped = vmm_virt_to_phys(virt);
    TEST_ASSERT(mapped == 0, "unmapped returns 0");
    pmm_free_page(phys);
    TEST_END();
}

static void test_vmm_double_map_fails(void) {
    TEST_START("VMM: double map returns error");
    if (!vmm_has_enough_pages()) { TEST_END(); return; }
    phys_addr_t phys = pmm_alloc_page();
    phys_addr_t phys2 = pmm_alloc_page();
    TEST_ASSERT(phys != 0 && phys2 != 0, "physical pages allocated");
    virt_addr_t virt = 0xFFFFFF0000001000ULL;
    int ret1 = vmm_map_page(&kernel_space, virt, phys, PTE_KERNEL_FLAGS);
    TEST_ASSERT(ret1 == 0, "first map succeeded");
    int ret2 = vmm_map_page(&kernel_space, virt, phys2, PTE_KERNEL_FLAGS);
    TEST_ASSERT(ret2 != 0, "second map failed as expected");
    vmm_unmap_page(&kernel_space, virt);
    pmm_free_page(phys);
    pmm_free_page(phys2);
    TEST_END();
}

static void test_vmm_unaligned_virt_fails(void) {
    TEST_START("VMM: unaligned virtual address returns error");
    phys_addr_t phys = pmm_alloc_page();
    int ret = vmm_map_page(&kernel_space, 0xFFFFFF0000002001ULL, phys, PTE_KERNEL_FLAGS);
    TEST_ASSERT(ret != 0, "unaligned virt fails");
    pmm_free_page(phys);
    TEST_END();
}

static void test_vmm_unaligned_phys_fails(void) {
    TEST_START("VMM: unaligned physical address returns error");
    int ret = vmm_map_page(&kernel_space, 0xFFFFFF0000003000ULL, 0x1001, PTE_KERNEL_FLAGS);
    TEST_ASSERT(ret != 0, "unaligned phys fails");
    TEST_END();
}

static void test_vmm_unmap_not_mapped(void) {
    TEST_START("VMM: unmap non-mapped page returns error");
    int ret = vmm_unmap_page(&kernel_space, 0xFFFFFF0000004000ULL);
    TEST_ASSERT(ret != 0, "unmap non-mapped fails");
    TEST_END();
}

static void test_vmm_write_read(void) {
    TEST_START("VMM: mapped page is readable/writable");
    if (!vmm_has_enough_pages()) { TEST_END(); return; }
    phys_addr_t phys = pmm_alloc_page();
    TEST_ASSERT(phys != 0, "physical page");
    virt_addr_t virt = 0xFFFFFF0000005000ULL;
    int ret = vmm_map_page(&kernel_space, virt, phys, PTE_KERNEL_FLAGS);
    TEST_ASSERT(ret == 0, "mapped");
    volatile u8 *p = (volatile u8 *)virt;
    for (int i = 0; i < 256; i++) {
        p[i] = (u8)i;
    }
    int ok = 1;
    for (int i = 0; i < 256; i++) {
        if (p[i] != (u8)i) { ok = 0; break; }
    }
    TEST_ASSERT(ok, "data integrity");
    vmm_unmap_page(&kernel_space, virt);
    pmm_free_page(phys);
    TEST_END();
}

void test_vmm_register(void) {
    test_register("vmm: map/unmap", test_vmm_map_unmap);
    test_register("vmm: double map fails", test_vmm_double_map_fails);
    test_register("vmm: unaligned virt fails", test_vmm_unaligned_virt_fails);
    test_register("vmm: unaligned phys fails", test_vmm_unaligned_phys_fails);
    test_register("vmm: unmap not-mapped fails", test_vmm_unmap_not_mapped);
    test_register("vmm: write/read mapped page", test_vmm_write_read);
}
