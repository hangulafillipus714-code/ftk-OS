#include <ftk/test.h>
#include <ftk/memory.h>
#include <ftk/string.h>

#define ALLOC_COUNT 64

static void test_kmalloc_basic(void) {
    TEST_START("kmalloc allocates non-NULL");
    void *p = kmalloc(64);
    TEST_ASSERT(p != NULL, "kmalloc(64) != NULL");
    if (p) kfree(p);
    TEST_END();
}

static void test_kmalloc_zero(void) {
    TEST_START("kmalloc(0) may return NULL or valid small block");
    void *p = kmalloc(0);
    if (p) kfree(p);
    kprintf("  (kmalloc(0) returned %p)\n", (void*)(u64)p);
    TEST_END();
}

static void test_kmalloc_write_read(void) {
    TEST_START("kmalloc region is writable and retains data");
    void *p = kmalloc(128);
    TEST_ASSERT(p != NULL, "allocation");
    memset(p, 0x5A, 128);
    u8 *buf = (u8 *)p;
    int ok = 1;
    for (int i = 0; i < 128; i++) {
        if (buf[i] != 0x5A) { ok = 0; break; }
    }
    TEST_ASSERT(ok, "data integrity after write");
    kfree(p);
    TEST_END();
}

static void test_kmalloc_many(void) {
    TEST_START("kmalloc/kfree 100000 times - no leaks or corruption");
    void *ptrs[64];
    int ok = 1;
    for (int iter = 0; iter < 1563; iter++) {
        for (int i = 0; i < 64; i++) {
            ptrs[i] = kmalloc(16 + (i % 48));
            if (!ptrs[i]) { ok = 0; break; }
            memset(ptrs[i], (u8)(i + iter), 16 + (i % 48));
        }
        if (!ok) break;
        for (int i = 0; i < 64; i++) {
            u8 *buf = (u8 *)ptrs[i];
            size_t sz = 16 + (i % 48);
            for (size_t j = 0; j < sz; j++) {
                if (buf[j] != (u8)(i + iter)) { ok = 0; break; }
            }
            if (!ok) break;
            kfree(ptrs[i]);
        }
        if (!ok) break;
    }
    TEST_ASSERT(ok, "all allocs/frees succeeded with data integrity");
    TEST_END();
}

static void test_kmalloc_large(void) {
    TEST_START("kmalloc large block (64KB)");
    void *p = kmalloc(65536);
    TEST_ASSERT(p != NULL, "64KB allocation");
    if (p) {
        memset(p, 0xFF, 65536);
        kfree(p);
    }
    TEST_END();
}

static void test_kmalloc_varied_sizes(void) {
    TEST_START("kmalloc varied sizes: 1KB, 16KB, 32KB, 512B, 64B");
    void *sizes[5];
    sizes[0] = kmalloc(1024);
    sizes[1] = kmalloc(16384);
    sizes[2] = kmalloc(32768);
    sizes[3] = kmalloc(512);
    sizes[4] = kmalloc(64);
    int ok = 1;
    for (int i = 0; i < 5; i++) {
        if (!sizes[i]) { ok = 0; kprintf("  size %d failed\n", i); }
    }
    TEST_ASSERT(ok, "all sizes allocated");
    for (int i = 0; i < 5; i++) {
        if (sizes[i]) kfree(sizes[i]);
    }
    TEST_END();
}

static void test_kfree_null(void) {
    TEST_START("kfree(NULL) is safe");
    kfree(NULL);
    kprintf("  (no crash)\n");
    TEST_END();
}

static void test_kmalloc_aligned(void) {
    TEST_START("kmalloc returns aligned pointers");
    void *p = kmalloc(8);
    TEST_ASSERT(p != NULL, "allocation");
    TEST_ASSERT(((u64)p & 7) == 0, "8-byte aligned");
    if (p) kfree(p);
    TEST_END();
}

/* Heap corruption detection tests */
static void test_heap_overflow_detection(void) {
    TEST_START("HEAP CORRUPTION: detect buffer overflow (write past allocation)");
    kprintf("  [SKIPPED] Test intentionally causes kernel panic\n");
    TEST_END();
}

static void test_heap_underflow_detection(void) {
    TEST_START("HEAP CORRUPTION: detect buffer underflow (write before allocation)");
    kprintf("  [SKIPPED] Test intentionally causes kernel panic\n");
    TEST_END();
}

static void test_heap_double_free_detection(void) {
    TEST_START("HEAP CORRUPTION: detect double free");
    kprintf("  [SKIPPED] Test intentionally causes kernel panic\n");
    TEST_END();
}

static void test_heap_use_after_free_detection(void) {
    TEST_START("HEAP CORRUPTION: detect use after free");
    kprintf("  [SKIPPED] Test intentionally causes kernel panic\n");
    TEST_END();
}

static void test_heap_integrity_check(void) {
    TEST_START("HEAP INTEGRITY: verify heap structure consistency");
    void *p1 = kmalloc(128);
    void *p2 = kmalloc(256);
    void *p3 = kmalloc(512);
    
    TEST_ASSERT(p1 && p2 && p3, "allocations");
    
    /* Fill with patterns */
    memset(p1, 0x11, 128);
    memset(p2, 0x22, 256);
    memset(p3, 0x33, 512);
    
    /* Verify integrity by re-reading */
    u8 *b1 = (u8 *)p1;
    u8 *b2 = (u8 *)p2;
    u8 *b3 = (u8 *)p3;
    int ok = 1;
    for (int i = 0; i < 128; i++) if (b1[i] != 0x11) ok = 0;
    for (int i = 0; i < 256; i++) if (b2[i] != 0x22) ok = 0;
    for (int i = 0; i < 512; i++) if (b3[i] != 0x33) ok = 0;
    
    TEST_ASSERT(ok, "data integrity after multiple allocations");
    
    kfree(p1);
    kfree(p2);
    kfree(p3);
    TEST_END();
}

void test_heap_register(void) {
    test_register("heap: kmalloc basic", test_kmalloc_basic);
    test_register("heap: kmalloc zero", test_kmalloc_zero);
    test_register("heap: write/read integrity", test_kmalloc_write_read);
    test_register("heap: 100K alloc/free cycle", test_kmalloc_many);
    test_register("heap: large 64KB block", test_kmalloc_large);
    test_register("heap: varied sizes", test_kmalloc_varied_sizes);
    test_register("heap: kfree NULL safe", test_kfree_null);
    test_register("heap: alignment", test_kmalloc_aligned);
    test_register("heap: overflow detection", test_heap_overflow_detection);
    test_register("heap: underflow detection", test_heap_underflow_detection);
    test_register("heap: double free detection", test_heap_double_free_detection);
    test_register("heap: use after free detection", test_heap_use_after_free_detection);
    test_register("heap: integrity check", test_heap_integrity_check);
}
