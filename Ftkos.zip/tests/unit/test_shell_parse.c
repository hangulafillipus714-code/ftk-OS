#include <ftk/test.h>
#include <ftk/string.h>

/*
 * Test string-parsing helpers that mirror the shell's tokenizer
 * (blueprint Phase C).  We can't call the kernel_shell.c static
 * functions directly, so we duplicate the logic as a test helper.
 */

/* Strip trailing newline/cr (blueprint C1) */
static void chomp(char *line) {
    size_t len = strlen(line);
    if (len > 0 && (line[len-1] == '\n' || line[len-1] == '\r'))
        line[--len] = '\0';
}

/* Tokenize line into argv[], return argc (blueprint C1) */
static int tokenize(char *line, char **argv, int max) {
    chomp(line);
    int argc = 0;
    char *tok = line;
    while (*tok) {
        while (*tok == ' ' || *tok == '\t') tok++;
        if (!*tok) break;
        argv[argc++] = tok;
        /* Advance past this token and NUL-terminate */
        while (*tok && *tok != ' ' && *tok != '\t') tok++;
        if (*tok) *tok++ = '\0';
        if (argc >= max) break;
    }
    if (argc < max)
        argv[argc] = NULL;
    return argc;
}

/* ── chomp ────────────────────────────────────────────── */

static void test_chomp_trailing_newline(void) {
    TEST_START("chomp strips trailing \\n");
    char line[] = "hello\n";
    chomp(line);
    TEST_ASSERT(strlen(line) == 5, "len=5 after chomp");
    TEST_ASSERT(line[5] == '\0', "null terminated");
    TEST_ASSERT(line[4] == 'o', "last char is 'o'");
    TEST_END();
}

static void test_chomp_trailing_cr(void) {
    TEST_START("chomp strips trailing \\r");
    char line[] = "hello\r";
    chomp(line);
    TEST_ASSERT(strlen(line) == 5, "len=5 after chomp");
    TEST_END();
}

static void test_chomp_no_newline(void) {
    TEST_START("chomp no-op on line without newline");
    char line[] = "hello";
    chomp(line);
    TEST_ASSERT(strcmp(line, "hello") == 0, "unchanged");
    TEST_END();
}

static void test_chomp_empty(void) {
    TEST_START("chomp no-op on empty string");
    char line[] = "";
    chomp(line);
    TEST_ASSERT(strlen(line) == 0, "len=0");
    TEST_END();
}

/* ── tokenize ─────────────────────────────────────────── */

static void test_tokenize_basic(void) {
    TEST_START("tokenize: three words");
    char line[] = "ls -l /tmp";
    char *argv[8];
    memset(argv, 0, sizeof(argv));
    int argc = tokenize(line, argv, 8);
    TEST_ASSERT_EQ(argc, 3, "argc=3");
    TEST_ASSERT(argv[0] != NULL, "argv[0] non-NULL");
    TEST_ASSERT(argv[1] != NULL, "argv[1] non-NULL");
    TEST_ASSERT(argv[2] != NULL, "argv[2] non-NULL");
    TEST_ASSERT(argv[3] == NULL, "argv[3] NULL sentinel");
    if (argc >= 3 && argv[0] && argv[1] && argv[2]) {
        TEST_ASSERT(strcmp(argv[0], "ls") == 0, "argv[0]='ls'");
        TEST_ASSERT(strcmp(argv[1], "-l") == 0, "argv[1]='-l'");
        TEST_ASSERT(strcmp(argv[2], "/tmp") == 0, "argv[2]='/tmp'");
    }
    TEST_END();
}

static void test_tokenize_trailing_newline(void) {
    TEST_START("tokenize strips trailing \\n automatically");
    char line[] = "echo hello\n";
    char *argv[8];
    memset(argv, 0, sizeof(argv));
    int argc = tokenize(line, argv, 8);
    TEST_ASSERT_EQ(argc, 2, "argc=2");
    if (argc >= 2) {
        TEST_ASSERT(strcmp(argv[0], "echo") == 0, "argv[0]='echo'");
        TEST_ASSERT(strcmp(argv[1], "hello") == 0, "argv[1]='hello'");
    }
    TEST_END();
}

static void test_tokenize_multiple_spaces(void) {
    TEST_START("tokenize handles multiple spaces");
    char line[] = "cat   -n    file.txt";
    char *argv[8];
    memset(argv, 0, sizeof(argv));
    int argc = tokenize(line, argv, 8);
    TEST_ASSERT_EQ(argc, 3, "argc=3");
    if (argc >= 3) {
        TEST_ASSERT(strcmp(argv[0], "cat") == 0, "argv[0]='cat'");
        TEST_ASSERT(strcmp(argv[1], "-n") == 0, "argv[1]='-n'");
        TEST_ASSERT(strcmp(argv[2], "file.txt") == 0, "argv[2]='file.txt'");
    }
    TEST_END();
}

static void test_tokenize_tabs(void) {
    TEST_START("tokenize handles tabs");
    char line[] = "echo\tfoo\t\tbar";
    char *argv[8];
    memset(argv, 0, sizeof(argv));
    int argc = tokenize(line, argv, 8);
    TEST_ASSERT_EQ(argc, 3, "argc=3");
    if (argc >= 3) {
        TEST_ASSERT(strcmp(argv[0], "echo") == 0, "argv[0]='echo'");
        TEST_ASSERT(strcmp(argv[1], "foo") == 0, "argv[1]='foo'");
        TEST_ASSERT(strcmp(argv[2], "bar") == 0, "argv[2]='bar'");
    }
    TEST_END();
}

static void test_tokenize_empty(void) {
    TEST_START("tokenize empty string returns argc=0");
    char line[] = "";
    char *argv[8];
    memset(argv, 0, sizeof(argv));
    int argc = tokenize(line, argv, 8);
    TEST_ASSERT_EQ(argc, 0, "argc=0");
    TEST_ASSERT(argv[0] == NULL, "argv[0] NULL");
    TEST_END();
}

static void test_tokenize_only_spaces(void) {
    TEST_START("tokenize spaces-only returns argc=0");
    char line[] = "   \t   \t  ";
    char *argv[8];
    memset(argv, 0, sizeof(argv));
    int argc = tokenize(line, argv, 8);
    TEST_ASSERT_EQ(argc, 0, "argc=0");
    TEST_END();
}

static void test_tokenize_single(void) {
    TEST_START("tokenize single word");
    char line[] = "clear\n";
    char *argv[8];
    memset(argv, 0, sizeof(argv));
    int argc = tokenize(line, argv, 8);
    TEST_ASSERT_EQ(argc, 1, "argc=1");
    if (argc >= 1) {
        TEST_ASSERT(strcmp(argv[0], "clear") == 0, "argv[0]='clear'");
    }
    TEST_ASSERT(argv[1] == NULL, "argv[1] NULL sentinel");
    TEST_END();
}

static void test_tokenize_max_argv(void) {
    TEST_START("tokenize respects max args");
    char line[] = "a b c d e";
    char *argv[3];
    memset(argv, 0, sizeof(argv));
    int argc = tokenize(line, argv, 3);
    TEST_ASSERT_EQ(argc, 3, "argc=3 (not 5)");
    if (argc >= 3) {
        TEST_ASSERT(strcmp(argv[0], "a") == 0, "argv[0]='a'");
        TEST_ASSERT(strcmp(argv[1], "b") == 0, "argv[1]='b'");
        TEST_ASSERT(strcmp(argv[2], "c") == 0, "argv[2]='c'");
    }
    TEST_END();
}

static void test_tokenize_leading_whitespace(void) {
    TEST_START("tokenize ignores leading whitespace");
    char line[] = "  \t  hello world";
    char *argv[8];
    memset(argv, 0, sizeof(argv));
    int argc = tokenize(line, argv, 8);
    TEST_ASSERT_EQ(argc, 2, "argc=2");
    if (argc >= 2) {
        TEST_ASSERT(strcmp(argv[0], "hello") == 0, "argv[0]='hello'");
        TEST_ASSERT(strcmp(argv[1], "world") == 0, "argv[1]='world'");
    }
    TEST_END();
}

/* ── Registration ─────────────────────────────────────── */

void test_shell_parse_register(void) {
    test_register("parse: chomp newline",         test_chomp_trailing_newline);
    test_register("parse: chomp CR",              test_chomp_trailing_cr);
    test_register("parse: chomp no newline",      test_chomp_no_newline);
    test_register("parse: chomp empty",           test_chomp_empty);
    test_register("parse: tokenize 3 words",      test_tokenize_basic);
    test_register("parse: tokenize with \\n",     test_tokenize_trailing_newline);
    test_register("parse: tokenize multi space",  test_tokenize_multiple_spaces);
    test_register("parse: tokenize tabs",         test_tokenize_tabs);
    test_register("parse: tokenize empty",        test_tokenize_empty);
    test_register("parse: tokenize spaces only",  test_tokenize_only_spaces);
    test_register("parse: tokenize single",       test_tokenize_single);
    test_register("parse: tokenize max args",     test_tokenize_max_argv);
    test_register("parse: tokenize leading ws",   test_tokenize_leading_whitespace);
}
