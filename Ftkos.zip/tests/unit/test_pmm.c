#include <ftk/test.h>
#include <ftk/pmm.h>
#include <ftk/string.h>
#include <ftk/memory.h>

static void test_pmm_alloc_free_page(void) {
    TEST_START("PMM: allocate and free single page");
    size_t free_before = pmm_get_free_page_count();
    phys_addr_t page = pmm_alloc_page();
    TEST_ASSERT(page != 0, "alloc_page returned non-zero");
    TEST_ASSERT((page & 0xFFF) == 0, "page is 4K-aligned");
    size_t free_after_alloc = pmm_get_free_page_count();
    TEST_ASSERT(free_after_alloc == free_before - 1, "free count decreased by 1");
    pmm_free_page(page);
    size_t free_after_free = pmm_get_free_page_count();
    TEST_ASSERT(free_after_free == free_before, "free count restored");
    TEST_END();
}

static void test_pmm_alloc_multiple(void) {
    TEST_START("PMM: allocate and free multiple contiguous pages");
    phys_addr_t pages = pmm_alloc_pages(16);
    TEST_ASSERT(pages != 0, "alloc_pages(16) returned non-zero");
    TEST_ASSERT((pages & 0xFFF) == 0, "page-aligned");
    pmm_free_pages(pages, 16);
    TEST_END();
}

static void test_pmm_exhaustion(void) {
    TEST_START("PMM: allocate until NULL (exhaustion)");
    size_t max_alloc = pmm_get_free_page_count();
    size_t total_pages = max_alloc;
    kprintf("  free pages: %u\n", (unsigned int)max_alloc);

    /* Allocate in batches of 64 to avoid tracking array allocation failure */
    int count = 0;
    int batch_count = 0;
    phys_addr_t batch[64];
    while (count < (int)max_alloc + 1) {
        phys_addr_t p = pmm_alloc_page();
        if (!p) break;
        batch[batch_count++] = p;
        count++;
        if (batch_count == 64) {
            for (int i = 0; i < batch_count; i++)
                pmm_free_page(batch[i]);
            batch_count = 0;
        }
    }
    for (int i = 0; i < batch_count; i++)
        pmm_free_page(batch[i]);

    kprintf("  allocated %d pages before NULL\n", count);

    /* Verify we exhausted or nearly exhausted PMM */
    TEST_ASSERT(count > 0, "allocated at least one page");
    TEST_ASSERT((size_t)count >= total_pages - 10 || (size_t)count >= total_pages * 8 / 10,
                "allocated most free pages");

    size_t free_after = pmm_get_free_page_count();
    TEST_ASSERT(free_after >= (size_t)count || free_after + 10 >= (size_t)count,
                "pages freed back");
    TEST_END();
}

static void test_pmm_alloc_zero_pages(void) {
    TEST_START("PMM: alloc_pages(0) returns 0");
    phys_addr_t p = pmm_alloc_pages(0);
    TEST_ASSERT(p == 0, "zero request returns 0");
    TEST_END();
}

static void test_pmm_double_free(void) {
    TEST_START("PMM: double free is safe (no crash)");
    phys_addr_t page = pmm_alloc_page();
    TEST_ASSERT(page != 0, "allocated page");
    pmm_free_page(page);
    size_t free_before = pmm_get_free_page_count();
    pmm_free_page(page);
    size_t free_after = pmm_get_free_page_count();
    kprintf("  free after single free: %u, after double free: %u\n",
            (unsigned int)free_before, (unsigned int)free_after);
    TEST_END();
}

static void test_pmm_invalid_free(void) {
    TEST_START("PMM: free invalid address is safe");
    pmm_free_page(0x12345678);
    pmm_free_page((phys_addr_t)-1);
    pmm_free_pages(0, 10);
    kprintf("  (no crash on invalid frees)\n");
    TEST_END();
}

static void test_pmm_free_counters(void) {
    TEST_START("PMM: free/total counters are sane");
    size_t total = pmm_get_total_page_count();
    size_t free = pmm_get_free_page_count();
    TEST_ASSERT(total > 0, "total > 0");
    TEST_ASSERT(free <= total, "free <= total");
    kprintf("  total: %u, free: %u\n", (unsigned int)total, (unsigned int)free);
    TEST_END();
}

void test_pmm_register(void) {
    test_register("pmm: alloc/free single page", test_pmm_alloc_free_page);
    test_register("pmm: alloc/free multiple pages", test_pmm_alloc_multiple);
    test_register("pmm: exhaustion test", test_pmm_exhaustion);
    test_register("pmm: alloc_pages(0)", test_pmm_alloc_zero_pages);
    test_register("pmm: double free safe", test_pmm_double_free);
    test_register("pmm: invalid free safe", test_pmm_invalid_free);
    test_register("pmm: free/total counters", test_pmm_free_counters);
}
