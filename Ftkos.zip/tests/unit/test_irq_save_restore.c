/*
 * tests/unit/test_irq_save_restore.c — IRQ-save/restore symmetry tests
 *
 * These tests verify the invariant that spinlock_acquire_irqsave /
 * spinlock_release_irqrestore preserve RFLAGS.IF across arbitrary
 * nested acquisition / context-switch sites.  The bug this guards
 * against is documented in report.md: scheduler_yield() historically
 * did 'spinlock_release' (no IRQ restore) + bare 'sti' after
 * task_switch, which dropped the saved rflags and unconditionally
 * enabled IRQs — leaking IRQ-enabled state to callers that expected
 * IRQs to remain disabled (e.g. nested spinlock holders, IRQ handlers
 * that should return with IRQs still off until the matching iretq).
 *
 * Tests are written to run inside the FTK_TEST_MODE kernel harness
 * (single CPU, no actual timer IRQs).
 */

#include <ftk/test.h>
#include <ftk/spinlock.h>
#include <ftk/scheduler.h>
#include <ftk/memory.h>
#include <ftk/string.h>
#include <ftk/abi/types.h>

extern Task *current_task;
extern Task *task_list;

/* ── spinlock IRQ-save/restore symmetry ────────────────────── */

static void test_spinlock_irq_basic(void) {
    TEST_START("spinlock_irqsave: acquire+release preserves IF");
    spinlock_t s = SPINLOCK_INIT;
    u64 rflags_before;
    u64 rflags_after;

    __asm__ volatile("pushfq; pop %0" : "=r"(rflags_before));

    spinlock_acquire_irqsave(&s, &rflags_after);
    /* While held, IF must be 0 */
    u64 rflags_mid;
    __asm__ volatile("pushfq; pop %0" : "=r"(rflags_mid));
    TEST_ASSERT((rflags_mid & 0x200) == 0, "IF cleared under irqsave lock");

    spinlock_release_irqrestore(&s, rflags_after);

    u64 rflags_final;
    __asm__ volatile("pushfq; pop %0" : "=r"(rflags_final));

    /* IF bit (RFLAGS bit 9) must be preserved exactly */
    TEST_ASSERT_EQ((rflags_before & 0x200),
                   (rflags_final & 0x200),
                   "IF preserved across irqsave/irqrestore");
    TEST_END();
}

static void test_spinlock_irq_repeated(void) {
    /* Reproduces the spawn/waitpid pattern that triggered the
     * heisenbug: many acquire/release cycles in a tight loop.
     * If rflags leak, this would eventually leave IF in the
     * wrong state. */
    TEST_START("spinlock_irqsave: 1000 cycles preserve IF");
    spinlock_t s = SPINLOCK_INIT;

    u64 rflags_before;
    __asm__ volatile("pushfq; pop %0" : "=r"(rflags_before));

    for (int i = 0; i < 1000; i++) {
        u64 saved;
        spinlock_acquire_irqsave(&s, &saved);
        spinlock_release_irqrestore(&s, saved);
    }

    u64 rflags_after;
    __asm__ volatile("pushfq; pop %0" : "=r"(rflags_after));

    TEST_ASSERT_EQ((rflags_before & 0x200),
                   (rflags_after & 0x200),
                   "IF preserved across 1000 cycles");
    TEST_END();
}

static void test_spinlock_irq_nested(void) {
    /* Nested irqsave must restore IF only when the outermost
     * release fires — the inner release keeps IRQs disabled
     * because the saved rflags at the inner level has IF=0. */
    TEST_START("spinlock_irqsave: nested acquire/release");
    spinlock_t a = SPINLOCK_INIT;
    spinlock_t b = SPINLOCK_INIT;

    u64 rflags_outer;
    spinlock_acquire_irqsave(&a, &rflags_outer);

    u64 rflags_mid;
    __asm__ volatile("pushfq; pop %0" : "=r"(rflags_mid));
    TEST_ASSERT((rflags_mid & 0x200) == 0, "IF cleared after outer acquire");

    u64 rflags_inner;
    spinlock_acquire_irqsave(&b, &rflags_inner);

    u64 rflags_inner_mid;
    __asm__ volatile("pushfq; pop %0" : "=r"(rflags_inner_mid));
    TEST_ASSERT((rflags_inner_mid & 0x200) == 0, "IF stays 0 after inner acquire");

    spinlock_release_irqrestore(&b, rflags_inner);

    u64 rflags_after_inner;
    __asm__ volatile("pushfq; pop %0" : "=r"(rflags_after_inner));
    TEST_ASSERT((rflags_after_inner & 0x200) == 0,
                "IF still 0 after inner release (outer still held)");

    spinlock_release_irqrestore(&a, rflags_outer);

    u64 rflags_final;
    __asm__ volatile("pushfq; pop %0" : "=r"(rflags_final));
    /* Without an explicit pre-state assumption, just verify IF is set:
     * tests run with IRQs enabled (kernel_main enables them before
     * invoking test_run_all). */
    TEST_ASSERT((rflags_final & 0x200) != 0,
                "IF restored to 1 after outer release");
    TEST_END();
}

/* ── scheduler_yield() preserves IRQ state (no-op path) ───── */

static void test_scheduler_yield_preserves_irq(void) {
    /* When scheduler_pick_next returns the same task (no other
     * runnable task), scheduler_yield() takes the early-return
     * path that does spinlock_release_irqrestore.  Verify IF is
     * preserved across this call.
     *
     * This is the closest in-ring-0 analogue to the spawn/waitpid
     * race: any IRQ-state leak in the early-return path indicates
     * the same bug class as the heisenbug. */
    TEST_START("scheduler_yield: early-return preserves IF");

    if (!current_task) {
        Task *t = kmalloc(sizeof(Task));
        if (!t) {
            kprintf("  (no memory for current_task — skipping)\n");
            TEST_END();
            return;
        }
        memset(t, 0, sizeof(Task));
        t->pid = 0;
        t->state = TASK_RUNNING;
        current_task = t;
        if (!task_list) {
            task_list = t;
            t->next = t;
            t->prev = t;
        }
    }

    u64 rflags_before;
    __asm__ volatile("pushfq; pop %0" : "=r"(rflags_before));

    /* Enable IRQs explicitly so we test the 'restore to IF=1' case. */
    __asm__ volatile("sti");

    scheduler_yield();

    u64 rflags_after;
    __asm__ volatile("pushfq; pop %0" : "=r"(rflags_after));

    TEST_ASSERT_EQ((rflags_before & 0x200) | 0x200,
                   (rflags_after & 0x200) | 0x200,
                   "IF still set after yield (we forced sti before)");
    /* Final IF must be 1 since we sti'd before yield */
    TEST_ASSERT((rflags_after & 0x200) != 0,
                "IF actually 1 after yield");
    TEST_END();
}

static void test_scheduler_yield_preserves_cli(void) {
    /* Same as above but enter with IRQs disabled.  The yield's
     * early-return path must restore IF to 0, not unconditionally
     * enable IRQs.  This is the exact regression of the old
     * 'spinlock_release + sti' bug. */
    TEST_START("scheduler_yield: early-return preserves IF=0");

    if (!current_task) {
        Task *t = kmalloc(sizeof(Task));
        if (!t) {
            kprintf("  (no memory for current_task — skipping)\n");
            TEST_END();
            return;
        }
        memset(t, 0, sizeof(Task));
        t->pid = 0;
        t->state = TASK_RUNNING;
        current_task = t;
        if (!task_list) {
            task_list = t;
            t->next = t;
            t->prev = t;
        }
    }

    __asm__ volatile("cli");
    scheduler_yield();

    u64 rflags_after;
    __asm__ volatile("pushfq; pop %0" : "=r"(rflags_after));

    /* Re-enable IRQs for subsequent tests */
    __asm__ volatile("sti");

    TEST_ASSERT((rflags_after & 0x200) == 0,
                "IF remained 0 after yield (early-return path respected IF=0)");
    TEST_END();
}

/* ── Forged new-task RFLAGS sanity ─────────────────────────── */

static void forged_flags_probe_entry(void) { for(;;) __asm__ volatile("hlt"); }

static void test_new_task_forged_rflags_has_if(void) {
    /* create_task forges a cooperative RFLAGS of 0x202 (IF=1) and
     * an iretq RFLAGS of DEFAULT_RFLAGS (0x202).  A regression
     * here would manifest as lost timer interrupts once a new task
     * gets scheduled, which is exactly the original heisenbug's
     * symptom.  This test pins the invariant. */
    TEST_START("task forged RFLAGS: IF=1 in cooperative + iretq frames");

    extern void ret_from_interrupt(void);

    Task *t = create_task("forged_flags_probe", forged_flags_probe_entry);
    if (!t) {
        kprintf("  (task not created — skipping)\n");
        TEST_END();
        return;
    }

    /* context.rsp points at the cooperative frame.  Layout (low to high):
     *   [0] R15 [1] R14 [2] R13 [3] R12 [4] RBP [5] RBX [6] RFLAGS [7] ret */
    u64 *coop = (u64 *)t->context.rsp;
    u64 coop_rflags = coop[6];
    u64 coop_ret    = coop[7];

    TEST_ASSERT((coop_rflags & 0x200) != 0,
                "cooperative frame RFLAGS.IF=1");
    TEST_ASSERT(coop_ret == (u64)(uintptr_t)ret_from_interrupt,
                "cooperative frame return = ret_from_interrupt");

    /* iretq frame starts at coop[8].  Layout:
     *   [8] R15 [9] R14 [10] R13 [11] R12 [12] R11 [13] R10 [14] R9
     *   [15] R8   [16] RSI [17] RDI [18] RBP [19] RDX [20] RCX
     *   [21] RBX  [22] RAX [23] int_no [24] err_code
     *   [25] RIP  [26] CS   [27] RFLAGS [28] RSP [29] SS
     */
    u64 iretq_rflags = coop[27];
    TEST_ASSERT((iretq_rflags & 0x200) != 0,
                "iretq frame RFLAGS.IF=1");

    task_destroy(t);
    TEST_END();
}

/* ── Registration ──────────────────────────────────────────── */

void test_irq_save_restore_register(void) {
    test_register("irq: spinlock acquire/release preserves IF",
                  test_spinlock_irq_basic);
    test_register("irq: spinlock 1000 cycles preserve IF",
                  test_spinlock_irq_repeated);
    test_register("irq: nested spinlock IRQ state",
                  test_spinlock_irq_nested);
    test_register("irq: scheduler_yield preserves IF=1 (early-return)",
                  test_scheduler_yield_preserves_irq);
    test_register("irq: scheduler_yield preserves IF=0 (early-return)",
                  test_scheduler_yield_preserves_cli);
    test_register("irq: new task forged RFLAGS has IF=1",
                  test_new_task_forged_rflags_has_if);
}
