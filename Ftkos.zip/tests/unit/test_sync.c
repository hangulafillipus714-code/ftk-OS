/*
 * tests/unit/test_sync.c — Unit tests for FTK OS synchronization primitives
 *
 * Tests mutex, semaphore, rwlock, and wait queue operations.
 * All tests run in kernel mode (Ring 0) within the test harness.
 */

#include <ftk/test.h>
#include <ftk/mutex.h>
#include <ftk/semaphore.h>
#include <ftk/rwlock.h>
#include <ftk/waitqueue.h>
#include <ftk/scheduler.h>
#include <ftk/string.h>

/* ── Mutex tests ──────────────────────────────────────────── */

static void test_mutex_init(void) {
    TEST_START("mutex: init");
    mutex_t m = MUTEX_INIT;
    TEST_ASSERT(m.locked == 0, "initial state unlocked");
    TEST_ASSERT(m.waiters == NULL, "no initial waiters");
    TEST_END();
}

static void test_mutex_init_func(void) {
    TEST_START("mutex: init function");
    mutex_t m;
    mutex_init(&m);
    TEST_ASSERT(m.locked == 0, "init sets locked=0");
    TEST_ASSERT(m.waiters == NULL, "init sets waiters=NULL");
    TEST_END();
}

static void test_mutex_lock_unlock(void) {
    TEST_START("mutex: lock/unlock cycle");
    mutex_t m;
    mutex_init(&m);

    mutex_lock(&m);
    TEST_ASSERT(m.locked != 0, "locked after mutex_lock");

    mutex_unlock(&m);
    TEST_ASSERT(m.locked == 0, "unlocked after mutex_unlock");
    TEST_END();
}

static void test_mutex_trylock(void) {
    TEST_START("mutex: trylock");
    mutex_t m;
    mutex_init(&m);

    int got = mutex_trylock(&m);
    TEST_ASSERT(got == 1, "trylock succeeds on unlocked mutex");
    TEST_ASSERT(m.locked != 0, "mutex now locked");

    int got2 = mutex_trylock(&m);
    TEST_ASSERT(got2 == 0, "trylock fails on locked mutex");

    mutex_unlock(&m);
    int got3 = mutex_trylock(&m);
    TEST_ASSERT(got3 == 1, "trylock succeeds after unlock");
    mutex_unlock(&m);
    TEST_END();
}

static void test_mutex_relock_after_unlock(void) {
    TEST_START("mutex: re-lock after unlock");
    mutex_t m;
    mutex_init(&m);

    for (int i = 0; i < 10; i++) {
        mutex_lock(&m);
        TEST_ASSERT(m.locked != 0, "locked in iteration");
        mutex_unlock(&m);
        TEST_ASSERT(m.locked == 0, "unlocked in iteration");
    }
    TEST_END();
}

/* ── Semaphore tests ──────────────────────────────────────── */

static void test_semaphore_init(void) {
    TEST_START("semaphore: init");
    semaphore_t sem;
    sem_init(&sem, 5);
    TEST_ASSERT(sem.count == 5, "initial count = 5");
    TEST_END();
}

static void test_semaphore_try_wait(void) {
    TEST_START("semaphore: try_wait");
    semaphore_t sem;
    sem_init(&sem, 2);

    int r1 = sem_try_wait(&sem);
    TEST_ASSERT(r1 == 0, "first try_wait succeeds");
    TEST_ASSERT(sem.count == 1, "count decremented to 1");

    int r2 = sem_try_wait(&sem);
    TEST_ASSERT(r2 == 0, "second try_wait succeeds");
    TEST_ASSERT(sem.count == 0, "count decremented to 0");

    int r3 = sem_try_wait(&sem);
    TEST_ASSERT(r3 == -1, "third try_wait fails (would block)");
    TEST_ASSERT(sem.count == 0, "count unchanged at 0");
    TEST_END();
}

static void test_semaphore_signal(void) {
    TEST_START("semaphore: signal");
    semaphore_t sem;
    sem_init(&sem, 0);

    sem_signal(&sem);
    TEST_ASSERT(sem.count == 1, "count incremented to 1");

    sem_signal(&sem);
    TEST_ASSERT(sem.count == 2, "count incremented to 2");

    int r = sem_try_wait(&sem);
    TEST_ASSERT(r == 0, "try_wait succeeds after signal");
    TEST_ASSERT(sem.count == 1, "count back to 1");
    TEST_END();
}

static void test_semaphore_binary(void) {
    TEST_START("semaphore: binary (mutex-like)");
    semaphore_t sem;
    sem_init(&sem, 1);

    int r1 = sem_try_wait(&sem);
    TEST_ASSERT(r1 == 0, "acquire binary semaphore");

    int r2 = sem_try_wait(&sem);
    TEST_ASSERT(r2 == -1, "second acquire fails");

    sem_signal(&sem);
    int r3 = sem_try_wait(&sem);
    TEST_ASSERT(r3 == 0, "re-acquire after release");
    sem_signal(&sem);
    TEST_END();
}

/* ── RWLock tests ─────────────────────────────────────────── */

static void test_rwlock_init(void) {
    TEST_START("rwlock: init");
    rwlock_t l = RWLOCK_INIT;
    TEST_ASSERT(l.readers == 0, "no initial readers");
    TEST_ASSERT(l.writer == 0, "no initial writer");
    TEST_END();
}

static void test_rwlock_read_lock_unlock(void) {
    TEST_START("rwlock: read lock/unlock");
    rwlock_t l = RWLOCK_INIT;

    rwlock_read_lock(&l);
    TEST_ASSERT(l.readers == 1, "one reader after read_lock");

    rwlock_read_unlock(&l);
    TEST_ASSERT(l.readers == 0, "no readers after read_unlock");
    TEST_END();
}

static void test_rwlock_write_lock_unlock(void) {
    TEST_START("rwlock: write lock/unlock");
    rwlock_t l = RWLOCK_INIT;

    rwlock_write_lock(&l);
    TEST_ASSERT(l.writer != 0, "writer flag set after write_lock");

    rwlock_write_unlock(&l);
    TEST_ASSERT(l.writer == 0, "writer flag clear after write_unlock");
    TEST_END();
}

static void test_rwlock_multiple_readers(void) {
    TEST_START("rwlock: multiple concurrent readers");
    rwlock_t l = RWLOCK_INIT;

    rwlock_read_lock(&l);
    rwlock_read_lock(&l);
    rwlock_read_lock(&l);
    TEST_ASSERT(l.readers == 3, "three concurrent readers");

    rwlock_read_unlock(&l);
    TEST_ASSERT(l.readers == 2, "two readers after one unlock");

    rwlock_read_unlock(&l);
    rwlock_read_unlock(&l);
    TEST_ASSERT(l.readers == 0, "no readers after all unlocked");
    TEST_END();
}

static void test_rwlock_write_cycle(void) {
    TEST_START("rwlock: write lock/unlock cycle");
    rwlock_t l = RWLOCK_INIT;

    for (int i = 0; i < 5; i++) {
        rwlock_write_lock(&l);
        TEST_ASSERT(l.writer != 0, "writer locked");
        rwlock_write_unlock(&l);
        TEST_ASSERT(l.writer == 0, "writer unlocked");
    }
    TEST_END();
}

/* ── Wait Queue tests ─────────────────────────────────────── */

static void test_waitqueue_init(void) {
    TEST_START("waitqueue: init");
    wait_queue_head_t wq = WAIT_QUEUE_INIT;
    TEST_ASSERT(wq.head == NULL, "head is NULL");
    TEST_ASSERT(wq.tail == NULL, "tail is NULL");
    TEST_END();
}

static void test_waitqueue_init_func(void) {
    TEST_START("waitqueue: init function");
    wait_queue_head_t wq;
    init_waitqueue_head(&wq);
    TEST_ASSERT(wq.head == NULL, "head is NULL after init");
    TEST_ASSERT(wq.tail == NULL, "tail is NULL after init");
    TEST_END();
}

static void test_waitqueue_is_empty(void) {
    TEST_START("waitqueue: is_empty on fresh queue");
    wait_queue_head_t wq;
    init_waitqueue_head(&wq);
    TEST_ASSERT(waitqueue_is_empty(&wq) == 1, "fresh queue is empty");
    TEST_END();
}

static void test_waitqueue_wake_empty(void) {
    TEST_START("waitqueue: wake_up on empty queue");
    wait_queue_head_t wq;
    init_waitqueue_head(&wq);
    /* Should not crash */
    wake_up(&wq);
    TEST_ASSERT(wq.head == NULL, "still empty after wake_up");
    TEST_END();
}

static void test_waitqueue_wake_all_empty(void) {
    TEST_START("waitqueue: wake_up_all on empty queue");
    wait_queue_head_t wq;
    init_waitqueue_head(&wq);
    wake_up_all(&wq);
    TEST_ASSERT(wq.head == NULL, "still empty after wake_up_all");
    TEST_END();
}

/* ── Registration ────────────────────────────────────────── */

void test_sync_register(void) {
    /* Mutex tests */
    test_register("sync: mutex init macro", test_mutex_init);
    test_register("sync: mutex init func", test_mutex_init_func);
    test_register("sync: mutex lock/unlock", test_mutex_lock_unlock);
    test_register("sync: mutex trylock", test_mutex_trylock);
    test_register("sync: mutex relock cycle", test_mutex_relock_after_unlock);

    /* Semaphore tests */
    test_register("sync: semaphore init", test_semaphore_init);
    test_register("sync: semaphore try_wait", test_semaphore_try_wait);
    test_register("sync: semaphore signal", test_semaphore_signal);
    test_register("sync: semaphore binary", test_semaphore_binary);

    /* RWLock tests */
    test_register("sync: rwlock init", test_rwlock_init);
    test_register("sync: rwlock read lock/unlock", test_rwlock_read_lock_unlock);
    test_register("sync: rwlock write lock/unlock", test_rwlock_write_lock_unlock);
    test_register("sync: rwlock multiple readers", test_rwlock_multiple_readers);
    test_register("sync: rwlock write cycle", test_rwlock_write_cycle);

    /* Wait Queue tests */
    test_register("sync: waitqueue init macro", test_waitqueue_init);
    test_register("sync: waitqueue init func", test_waitqueue_init_func);
    test_register("sync: waitqueue is_empty", test_waitqueue_is_empty);
    test_register("sync: waitqueue wake empty", test_waitqueue_wake_empty);
    test_register("sync: waitqueue wake_all empty", test_waitqueue_wake_all_empty);
}
