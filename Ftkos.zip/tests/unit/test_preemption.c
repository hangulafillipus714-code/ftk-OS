/*
 * tests/unit/test_preemption.c — Unit tests for preemption control
 *
 * Tests preempt_disable()/preempt_enable() nesting and the scheduler's
 * behavior when preemption is suppressed.
 */

#include <ftk/test.h>
#include <ftk/scheduler.h>
#include <ftk/string.h>

/* ── Preemption control tests ────────────────────────────── */

static void test_preempt_disable_enable(void) {
    TEST_START("preempt: disable/enable");
    if (!current_task) scheduler_init();

    TEST_ASSERT(is_preempt_disabled() == 0, "preemption enabled initially");

    preempt_disable();
    TEST_ASSERT(is_preempt_disabled() == 1, "preemption disabled after disable()");

    preempt_enable();
    TEST_ASSERT(is_preempt_disabled() == 0, "preemption enabled after enable()");
    TEST_END();
}

static void test_preempt_nesting(void) {
    TEST_START("preempt: nesting");

    preempt_disable();
    preempt_disable();
    TEST_ASSERT(is_preempt_disabled() == 1, "preemption disabled (nest=2)");
    TEST_ASSERT(current_task->preempt_count == 2, "preempt_count == 2");

    preempt_enable();
    TEST_ASSERT(is_preempt_disabled() == 1, "still disabled (nest=1)");
    TEST_ASSERT(current_task->preempt_count == 1, "preempt_count == 1");

    preempt_enable();
    TEST_ASSERT(is_preempt_disabled() == 0, "fully enabled (nest=0)");
    TEST_ASSERT(current_task->preempt_count == 0, "preempt_count == 0");
    TEST_END();
}

static void test_preempt_deep_nesting(void) {
    TEST_START("preempt: deep nesting (10 levels)");

    for (int i = 0; i < 10; i++) {
        preempt_disable();
    }
    TEST_ASSERT(current_task->preempt_count == 10, "preempt_count == 10");
    TEST_ASSERT(is_preempt_disabled() == 1, "preemption disabled");

    for (int i = 0; i < 10; i++) {
        preempt_enable();
    }
    TEST_ASSERT(current_task->preempt_count == 0, "preempt_count == 0 after unwind");
    TEST_ASSERT(is_preempt_disabled() == 0, "preemption enabled");
    TEST_END();
}

static void test_yield_skips_when_preempt_disabled(void) {
    TEST_START("preempt: yield is no-op when disabled");

    preempt_disable();

    /* scheduler_yield() should be a no-op when preemption is disabled.
     * If it were not, calling yield on the idle task with no other
     * runnable tasks would still work, but we verify the semantics. */
    scheduler_yield();

    /* If we get here, yield returned without switching */
    TEST_ASSERT(is_preempt_disabled() == 1, "preemption still disabled after yield");

    preempt_enable();
    TEST_ASSERT(is_preempt_disabled() == 0, "preemption re-enabled");
    TEST_END();
}

static void test_preempt_initial_value(void) {
    TEST_START("preempt: task initial preempt_count");

    /* Current task should have preempt_count == 0 (set in scheduler_init) */
    if (current_task) {
        TEST_ASSERT(current_task->preempt_count == 0,
                    "current task starts with preempt_count=0");
    }
    TEST_END();
}

/* ── Registration ────────────────────────────────────────── */

void test_preemption_register(void) {
    test_register("preempt: disable/enable", test_preempt_disable_enable);
    test_register("preempt: nesting", test_preempt_nesting);
    test_register("preempt: deep nesting", test_preempt_deep_nesting);
    test_register("preempt: yield no-op", test_yield_skips_when_preempt_disabled);
    test_register("preempt: initial value", test_preempt_initial_value);
}
