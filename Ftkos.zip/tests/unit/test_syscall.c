/*
 * tests/unit/test_syscall.c — FTK OS syscall unit tests
 *
 * All tests run in ring-0 (kernel test mode).  We cannot fire a real
 * SYSCALL instruction from ring-0 (it would fault), so we use two
 * approaches:
 *
 *  A) Direct C calls into the dispatcher (syscall_dispatch) with a
 *     hand-built SyscallFrame — validates handler logic.
 *
 *  B) Ring-0 stub path (syscall_entry_stub_ring0 from syscall_entry.S) —
 *     validates the assembly save/restore frame but without the SWAPGS +
 *     RSP swap that only makes sense in ring-3.
 *
 *  C) MSR verification via RDMSR — validates syscall_init() programming.
 */

#include <ftk/test.h>
#include <ftk/syscall.h>
#include <ftk/abi/syscall.h>
#include <ftk/abi/types.h>
#include <ftk/scheduler.h>
#include <ftk/printk.h>
#include <ftk/memory.h>
#include <ftk/string.h>

/* ── helpers ─────────────────────────────────────────────── */

static inline u64 rdmsr_test(u32 msr)
{
    u32 lo, hi;
    __asm__ volatile("rdmsr" : "=a"(lo), "=d"(hi) : "c"(msr));
    return ((u64)hi << 32) | lo;
}

/*
 * build_frame – zero-fill a SyscallFrame and set the syscall number.
 * Callers fill in argument registers (rdi, rsi, rdx, r10, r8, r9).
 */
static void build_frame(SyscallFrame *f, u64 nr)
{
    u8 *p = (u8*)f;
    for (u64 i = 0; i < sizeof(*f); i++) p[i] = 0;
    f->rax = nr;
}

/* Invoke syscall_dispatch and return rax (the syscall return value). */
static s64 dispatch(SyscallFrame *f)
{
    syscall_dispatch(f);
    return (s64)f->rax;
}

/* ── Group 1: Initialisation / MSR ───────────────────────── */

static void test_syscall_init_flag(void)
{
    TEST_ASSERT(syscall_is_initialized(),
                "syscall_is_initialized() must be true after syscall_init()");
}

static void test_lstar_set(void)
{
    u64 lstar = rdmsr_test(MSR_LSTAR);
    TEST_ASSERT(lstar != 0,
                "IA32_LSTAR must be non-zero after syscall_init()");

    /* Must be in kernel virtual range */
    TEST_ASSERT(lstar >= 0xFFFFFFFF80000000ULL,
                "IA32_LSTAR must point into higher-half kernel");
}

static void test_lstar_matches_query(void)
{
    u64 via_msr = rdmsr_test(MSR_LSTAR);
    u64 via_api = syscall_get_lstar();
    TEST_ASSERT(via_msr == via_api,
                "syscall_get_lstar() must match raw RDMSR(LSTAR)");
}

static void test_star_kernel_cs(void)
{
    u64 star = rdmsr_test(MSR_STAR);
    u16 kcs  = (u16)((star >> 32) & 0xFFFF);
    TEST_ASSERT(kcs == GDT_KERNEL_CODE,
                "STAR[47:32] must equal GDT_KERNEL_CODE (0x08)");
}

static void test_star_user_cs(void)
{
    u64 star  = rdmsr_test(MSR_STAR);
    u16 uhigh = (u16)((star >> 48) & 0xFFFF);
    /*
     * SYSRETQ: CS = [63:48]+16, SS = [63:48]+8.
     * We want CS=GDT_USER_CODE(0x20), SS=GDT_USER_DATA(0x18).
     * So [63:48] = 0x20-0x10 = 0x10.
     */
    TEST_ASSERT(uhigh + 16 == GDT_USER_CODE,
                "STAR[63:48]+16 must equal GDT_USER_CODE (0x20)");
    TEST_ASSERT(uhigh + 8 == GDT_USER_DATA,
                "STAR[63:48]+8 must equal GDT_USER_DATA (0x18)");
}

static void test_fmask_if_cleared(void)
{
    u64 fmask = rdmsr_test(MSR_FMASK);
    TEST_ASSERT(fmask & (1ULL << 9),
                "IA32_FMASK must mask IF (bit 9) on syscall entry");
}

static void test_fmask_df_cleared(void)
{
    u64 fmask = rdmsr_test(MSR_FMASK);
    TEST_ASSERT(fmask & (1ULL << 10),
                "IA32_FMASK must mask DF (bit 10) on syscall entry");
}

static void test_efer_sce(void)
{
    u64 efer = rdmsr_test(MSR_EFER);
    TEST_ASSERT(efer & EFER_SCE,
                "IA32_EFER.SCE (bit 0) must be set after syscall_init()");
}

/* ── Group 2: Dispatch table / unknown numbers ───────────── */

static void test_unknown_syscall_returns_nosys(void)
{
    SyscallFrame f;
    build_frame(&f, 9999);
    s64 ret = dispatch(&f);
    TEST_ASSERT(ret == ESYS_NOSYS,
                "Unknown syscall number must return ESYS_NOSYS");
}

static void test_syscall_count_boundary(void)
{
    /* SYSCALL_COUNT itself is out of range */
    SyscallFrame f;
    build_frame(&f, SYSCALL_COUNT);
    s64 ret = dispatch(&f);
    TEST_ASSERT(ret == ESYS_NOSYS,
                "Syscall number == SYSCALL_COUNT must return ESYS_NOSYS");
}

static void test_max_u64_syscall_returns_nosys(void)
{
    SyscallFrame f;
    build_frame(&f, (u64)-1);
    s64 ret = dispatch(&f);
    TEST_ASSERT(ret == ESYS_NOSYS,
                "Max u64 syscall number must return ESYS_NOSYS");
}

/* ── Group 3: SYS_WRITE ──────────────────────────────────── */

static void test_write_stdout_returns_n(void)
{
    SyscallFrame f;
    build_frame(&f, SYS_WRITE);
    f.rdi = FD_STDOUT;
    f.rsi = (u64)(uintptr_t)"hello";
    f.rdx = 5;
    s64 ret = dispatch(&f);
    TEST_ASSERT(ret == 5, "write(stdout, 'hello', 5) must return 5");
}

static void test_write_stderr_returns_n(void)
{
    SyscallFrame f;
    build_frame(&f, SYS_WRITE);
    f.rdi = FD_STDERR;
    f.rsi = (u64)(uintptr_t)"err";
    f.rdx = 3;
    s64 ret = dispatch(&f);
    TEST_ASSERT(ret == 3, "write(stderr, 'err', 3) must return 3");
}

static void test_write_zero_bytes(void)
{
    SyscallFrame f;
    build_frame(&f, SYS_WRITE);
    f.rdi = FD_STDOUT;
    f.rsi = (u64)(uintptr_t)"x";
    f.rdx = 0;
    s64 ret = dispatch(&f);
    TEST_ASSERT(ret == 0, "write(..., 0) must return 0");
}

static void test_write_bad_fd(void)
{
    SyscallFrame f;
    build_frame(&f, SYS_WRITE);
    f.rdi = 99;   /* no such fd */
    f.rsi = (u64)(uintptr_t)"data";
    f.rdx = 4;
    s64 ret = dispatch(&f);
    TEST_ASSERT(ret == ESYS_BADF, "write(bad_fd) must return ESYS_BADF");
}

static void test_write_null_buf(void)
{
    SyscallFrame f;
    build_frame(&f, SYS_WRITE);
    f.rdi = FD_STDOUT;
    f.rsi = 0;   /* NULL */
    f.rdx = 4;
    s64 ret = dispatch(&f);
    TEST_ASSERT(ret == ESYS_FAULT, "write(NULL buf) must return ESYS_FAULT");
}

static void test_write_stdin_fd(void)
{
    SyscallFrame f;
    build_frame(&f, SYS_WRITE);
    f.rdi = FD_STDIN;  /* can't write to stdin */
    f.rsi = (u64)(uintptr_t)"x";
    f.rdx = 1;
    s64 ret = dispatch(&f);
    TEST_ASSERT(ret == ESYS_BADF,
                "write(FD_STDIN) must return ESYS_BADF");
}

/* ── Group 4: SYS_READ ───────────────────────────────────── */

static void test_read_bad_fd(void)
{
    char buf[4];
    SyscallFrame f;
    build_frame(&f, SYS_READ);
    f.rdi = FD_STDOUT;  /* can't read from stdout */
    f.rsi = (u64)(uintptr_t)buf;
    f.rdx = 1;
    s64 ret = dispatch(&f);
    TEST_ASSERT(ret == ESYS_BADF,
                "read(FD_STDOUT) must return ESYS_BADF");
}

static void test_read_null_buf(void)
{
    SyscallFrame f;
    build_frame(&f, SYS_READ);
    f.rdi = FD_STDIN;
    f.rsi = 0;  /* NULL */
    f.rdx = 1;
    s64 ret = dispatch(&f);
    TEST_ASSERT(ret == ESYS_FAULT,
                "read(NULL buf) must return ESYS_FAULT");
}

static void test_read_zero_bytes(void)
{
    char buf[4];
    SyscallFrame f;
    build_frame(&f, SYS_READ);
    f.rdi = FD_STDIN;
    f.rsi = (u64)(uintptr_t)buf;
    f.rdx = 0;
    s64 ret = dispatch(&f);
    TEST_ASSERT(ret == 0, "read(stdin, buf, 0) must return 0");
}

/* ── Group 5: SYS_GETPID ─────────────────────────────────── */

static void test_getpid_returns_current_pid(void)
{
    SyscallFrame f;
    build_frame(&f, SYS_GETPID);
    s64 ret = dispatch(&f);
    u32 real_pid = scheduler_current_pid();
    TEST_ASSERT((u32)ret == real_pid,
                "getpid() must return scheduler_current_pid()");
}

static void test_getpid_positive(void)
{
    SyscallFrame f;
    build_frame(&f, SYS_GETPID);
    s64 ret = dispatch(&f);
    TEST_ASSERT(ret >= 0, "getpid() must return non-negative value");
}

/* ── Group 6: SYS_YIELD ──────────────────────────────────── */

static void test_yield_returns_ok(void)
{
    SyscallFrame f;
    build_frame(&f, SYS_YIELD);
    s64 ret = dispatch(&f);
    TEST_ASSERT(ret == ESYS_OK, "yield() must return ESYS_OK (0)");
}

/* ── Group 7: SYS_SLEEP ──────────────────────────────────── */

static void test_sleep_zero_returns_ok(void)
{
    SyscallFrame f;
    build_frame(&f, SYS_SLEEP);
    f.rdi = 0;  /* zero ticks – should return immediately */
    s64 ret = dispatch(&f);
    TEST_ASSERT(ret == ESYS_OK,
                "sleep(0) must return immediately with ESYS_OK");
}

/* ── Group 8: SYS_BRK ────────────────────────────────────── */

static void test_brk_kernel_task(void)
{
    SyscallFrame f;
    build_frame(&f, SYS_BRK);
    f.rdi = 0;
    s64 ret = dispatch(&f);
    TEST_ASSERT(ret == ESYS_PERM,
                "brk() from kernel task must return ESYS_PERM");
}

/* ── Group 9: Frame integrity via ring-0 stub ────────────── */

/*
 * Call the ring-0 assembly stub with a known RAX value and verify
 * that the value is round-tripped through the frame correctly.
 * We plant a sentinel write syscall and check return == byte count.
 */
extern void syscall_entry_stub_ring0(void);

static void test_stub_frame_roundtrip(void)
{
    /*
     * Set up registers for SYS_WRITE(stdout, ".", 1) and invoke the
     * ring-0 stub path.  The stub builds a SyscallFrame, dispatches,
     * then returns with RAX = 1 (bytes written).
     */
    s64 ret;
    __asm__ volatile(
        "mov $1, %%rax\n"   /* SYS_WRITE */
        "mov $1, %%rdi\n"   /* FD_STDOUT */
        "lea 1f(%%rip), %%rsi\n"
        "mov $1, %%rdx\n"   /* n=1 */
        "call syscall_entry_stub_ring0\n"
        /* RAX now holds return value */
        "jmp 2f\n"
        "1: .byte '.'\n"
        "2:\n"
        : "=a"(ret)
        :
        : "rdi", "rsi", "rdx", "rcx", "r8", "r9", "r10",
          "r11", "rbx", "rbp", "r12", "r13", "r14", "r15",
          "memory"
    );
    TEST_ASSERT(ret == 1,
                "Ring-0 stub SYS_WRITE must return 1 via frame roundtrip");
}

static void test_stub_unknown_nr_nosys(void)
{
    s64 ret;
    __asm__ volatile(
        "mov $9999, %%rax\n"
        "xor %%rdi, %%rdi\n"
        "xor %%rsi, %%rsi\n"
        "xor %%rdx, %%rdx\n"
        "call syscall_entry_stub_ring0\n"
        : "=a"(ret)
        :
        : "rdi", "rsi", "rdx", "rcx", "r8", "r9", "r10",
          "r11", "rbx", "rbp", "r12", "r13", "r14", "r15",
          "memory"
    );
    TEST_ASSERT(ret == (s64)ESYS_NOSYS,
                "Ring-0 stub: unknown syscall must return ESYS_NOSYS");
}

static void test_stub_getpid(void)
{
    s64 ret;
    u32 real_pid = scheduler_current_pid();
    __asm__ volatile(
        "mov $3, %%rax\n"   /* SYS_GETPID */
        "xor %%rdi, %%rdi\n"
        "call syscall_entry_stub_ring0\n"
        : "=a"(ret)
        :
        : "rdi", "rsi", "rdx", "rcx", "r8", "r9", "r10",
          "r11", "rbx", "rbp", "r12", "r13", "r14", "r15",
          "memory"
    );
    TEST_ASSERT((u32)ret == real_pid,
                "Ring-0 stub SYS_GETPID must match scheduler_current_pid()");
}

/* ── Group 10: Idempotency / re-init safety ──────────────── */

static void test_lstar_stable_after_second_init(void)
{
    u64 before = syscall_get_lstar();
    /* Calling init again must be idempotent */
    syscall_init();
    u64 after = syscall_get_lstar();
    TEST_ASSERT(before == after,
                "LSTAR must not change across repeated syscall_init() calls");
}

/* ── Group 11: spawn / waitpid / exit zombie collection ──── */

static void test_spawn_waitpid_exit_cycle(void)
{
    TEST_START("spawn/waitpid/exit: zombie collection and waitpid_prepare");

    extern Task *current_task;
    extern Task *task_list;

    Task *saved_current = current_task;
    Task *saved_list = task_list;

    /* Create a fake parent context so scheduler_waitpid_prepare doesn't reject us */
    Task *parent = kmalloc(sizeof(Task));
    memset(parent, 0, sizeof(Task));
    parent->pid = 1;
    parent->state = TASK_RUNNING;

    /* Set global pointers so scheduler_waitpid_prepare works */
    current_task = parent;

    /* ── Test 1: collect a zombie ──────────────────────────── */
    {
        Task *child = kmalloc(sizeof(Task));
        memset(child, 0, sizeof(Task));
        child->pid = 2;
        child->parent_pid = 1;
        child->state = TASK_ZOMBIE;
        child->exit_status = 42;
        child->next = child;
        child->prev = child;
        task_list = child;

        Task *zombie = NULL;
        int ret = scheduler_waitpid_prepare(2, &zombie);
        TEST_ASSERT(ret == 1, "waitpid_prepare returns 1 for zombie");
        TEST_ASSERT(zombie != NULL, "zombie pointer is non-NULL");
        TEST_ASSERT(zombie->pid == 2, "zombie PID matches child");
        TEST_ASSERT(zombie->exit_status == 42, "exit status is 42");
        if (zombie) {
            kfree(zombie);
        }
        task_list = NULL;
    }

    /* ── Test 2: no child exists ───────────────────────────── */
    {
        Task *zombie = NULL;
        int ret = scheduler_waitpid_prepare(99, &zombie);
        TEST_ASSERT(ret == -1, "waitpid_prepare returns -1 for non-existent child");
    }

    /* ── Test 3: child is alive → must block (TASK_BLOCKED) ── */
    {
        Task *child = kmalloc(sizeof(Task));
        memset(child, 0, sizeof(Task));
        child->pid = 3;
        child->parent_pid = 1;
        child->state = TASK_READY;
        child->next = child;
        child->prev = child;
        task_list = child;

        /* Reset parent's state to RUNNING */
        parent->state = TASK_RUNNING;

        Task *zombie = NULL;
        int ret = scheduler_waitpid_prepare(3, &zombie);
        TEST_ASSERT(ret == 0, "waitpid_prepare returns 0 for alive child");
        TEST_ASSERT(parent->state == TASK_BLOCKED, "parent is now TASK_BLOCKED");

        kfree(child);
    }

    /* ── Test 4: scheduler_waitpid_prepare with target_pid=-1 ── */
    {
        Task *child_a = kmalloc(sizeof(Task));
        memset(child_a, 0, sizeof(Task));
        child_a->pid = 10;
        child_a->parent_pid = 1;
        child_a->state = TASK_ZOMBIE;
        child_a->exit_status = 7;

        Task *child_b = kmalloc(sizeof(Task));
        memset(child_b, 0, sizeof(Task));
        child_b->pid = 11;
        child_b->parent_pid = 1;
        child_b->state = TASK_READY;

        /* Build circular list: child_a <-> child_b */
        child_a->next = child_b;
        child_a->prev = child_b;
        child_b->next = child_a;
        child_b->prev = child_a;
        task_list = child_a;

        parent->state = TASK_RUNNING;

        Task *zombie = NULL;
        int ret = scheduler_waitpid_prepare(-1, &zombie);
        TEST_ASSERT(ret == 1, "waitpid_prepare(-1) returns 1 (zombie found)");
        TEST_ASSERT(zombie != NULL, "zombie found with target_pid=-1");
        if (zombie) {
            TEST_ASSERT(zombie->pid == 10, "first zombie has PID 10");
            kfree(zombie);
        }

        /* Clean up child_b (still in list) */
        task_list = child_b;
        child_b->next = child_b;
        child_b->prev = child_b;
        kfree(child_b);
        task_list = NULL;
    }

    kfree(parent);
    current_task = saved_current;
    task_list = saved_list;

    TEST_END();
}

/* ── Registration ────────────────────────────────────────── */

void test_syscall_register(void)
{
    /* Group 1: MSR / init */
    test_register("syscall: init flag",           test_syscall_init_flag);
    test_register("syscall: LSTAR non-zero",      test_lstar_set);
    test_register("syscall: LSTAR api matches",   test_lstar_matches_query);
    test_register("syscall: STAR kernel CS",      test_star_kernel_cs);
    test_register("syscall: STAR user CS",        test_star_user_cs);
    test_register("syscall: FMASK IF bit",        test_fmask_if_cleared);
    test_register("syscall: FMASK DF bit",        test_fmask_df_cleared);
    test_register("syscall: EFER SCE bit",        test_efer_sce);

    /* Group 2: dispatch */
    test_register("syscall: unknown returns nosys",    test_unknown_syscall_returns_nosys);
    test_register("syscall: count boundary nosys",     test_syscall_count_boundary);
    test_register("syscall: max u64 nosys",            test_max_u64_syscall_returns_nosys);

    /* Group 3: SYS_WRITE */
    test_register("syscall: write stdout n",      test_write_stdout_returns_n);
    test_register("syscall: write stderr n",      test_write_stderr_returns_n);
    test_register("syscall: write zero bytes",    test_write_zero_bytes);
    test_register("syscall: write bad fd",        test_write_bad_fd);
    test_register("syscall: write null buf",      test_write_null_buf);
    test_register("syscall: write stdin fd",      test_write_stdin_fd);

    /* Group 4: SYS_READ */
    test_register("syscall: read bad fd",         test_read_bad_fd);
    test_register("syscall: read null buf",       test_read_null_buf);
    test_register("syscall: read zero bytes",     test_read_zero_bytes);

    /* Group 5: SYS_GETPID */
    test_register("syscall: getpid matches sched",  test_getpid_returns_current_pid);
    test_register("syscall: getpid positive",       test_getpid_positive);

    /* Group 6: SYS_YIELD */
    test_register("syscall: yield ok",            test_yield_returns_ok);

    /* Group 7: SYS_SLEEP */
    test_register("syscall: sleep 0 ok",          test_sleep_zero_returns_ok);

    /* Group 8: SYS_BRK */
    test_register("syscall: brk kernel task",     test_brk_kernel_task);

    /* Group 9: ring-0 stub / frame roundtrip */
    test_register("syscall: stub frame roundtrip",  test_stub_frame_roundtrip);
    test_register("syscall: stub unknown nosys",    test_stub_unknown_nr_nosys);
    test_register("syscall: stub getpid",           test_stub_getpid);

    /* Group 10: idempotency */
    test_register("syscall: LSTAR stable re-init",  test_lstar_stable_after_second_init);

    /* Group 11: spawn/waitpid/exit zombie collection */
    test_register("syscall: spawn/waitpid/exit cycle", test_spawn_waitpid_exit_cycle);
}