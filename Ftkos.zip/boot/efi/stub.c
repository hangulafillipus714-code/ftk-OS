#include <efi.h>
#include <efilib.h>
#include <elf.h>
#include <ftk/bootinfo_shared.h>

#define KERNEL_VIRT_BASE  0xFFFFFFFF80000000ULL
#define PAGE_SIZE         4096
#define ALIGN_UP(addr, align) (((addr) + (align) - 1) & ~((align) - 1))

/* Forward declarations for freestanding compatibility */
static void *memcpy(void *dest, const void *src, UINTN n);
static void *memset(void *s, int c, UINTN n);
static int memcmp(const void *s1, const void *s2, UINTN n);
static void serial_init(void);
static void serial_write(char c);
extern const unsigned char _binary_kernel_blob_bin_start[];
extern const unsigned char _binary_kernel_blob_bin_end[];

typedef struct {
    EFI_PHYSICAL_ADDRESS kernel_phys_base;
    EFI_PHYSICAL_ADDRESS kernel_phys_end;
    EFI_PHYSICAL_ADDRESS kernel_entry;
    BootInfo boot_info;
} LoaderContext;

static void *memcpy(void *dest, const void *src, UINTN n) {
    unsigned char *d = dest;
    const unsigned char *s = src;
    while (n--) *d++ = *s++;
    return dest;
}

static void *memset(void *s, int c, UINTN n) {
    unsigned char *p = s;
    while (n--) *p++ = (unsigned char)c;
    return s;
}

static int memcmp(const void *s1, const void *s2, UINTN n) {
    const unsigned char *p1 = s1, *p2 = s2;
    while (n--) {
        if (*p1 != *p2) return *p1 - *p2;
        p1++; p2++;
    }
    return 0;
}

static void serial_init(void) {
    /* Initialize COM1 (0x3F8) */
    __asm__ volatile ("outb %0, %1" : : "a"((UINT8)0x00), "Nd"((UINT16)0x3F9)); /* Disable interrupts */
    __asm__ volatile ("outb %0, %1" : : "a"((UINT8)0x80), "Nd"((UINT16)0x3FB)); /* Enable DLAB */
    __asm__ volatile ("outb %0, %1" : : "a"((UINT8)0x01), "Nd"((UINT16)0x3F8)); /* 115200 baud low byte */
    __asm__ volatile ("outb %0, %1" : : "a"((UINT8)0x00), "Nd"((UINT16)0x3F9)); /* 115200 baud high byte */
    __asm__ volatile ("outb %0, %1" : : "a"((UINT8)0x03), "Nd"((UINT16)0x3FB)); /* 8n1 */
    __asm__ volatile ("outb %0, %1" : : "a"((UINT8)0xC7), "Nd"((UINT16)0x3FA)); /* Enable FIFO */
    __asm__ volatile ("outb %0, %1" : : "a"((UINT8)0x0B), "Nd"((UINT16)0x3FC)); /* IRQs enabled, RTS/DSR set */
}

static void serial_write(char c) {
    __asm__ volatile ("outb %0, %1" : : "a"((UINT8)c), "Nd"((UINT16)0x3F8));
    __asm__ volatile ("outb %0, %1" : : "a"((UINT8)c), "Nd"((UINT16)0xE9));
}

/* Safe memory allocation wrapper */
static EFI_STATUS AllocatePagesSafe(
    EFI_ALLOCATE_TYPE type,
    EFI_MEMORY_TYPE memory_type,
    UINTN pages,
    EFI_PHYSICAL_ADDRESS *memory
) {
    EFI_STATUS status = uefi_call_wrapper(
        BS->AllocatePages, 4,
        type, memory_type, pages, memory
    );
    
    if (EFI_ERROR(status)) {
        Print(L"AllocatePages failed: %r\n", status);
    }
    return status;
}

/* Load ELF64 kernel */
static EFI_STATUS LoadKernel(
    LoaderContext *ctx
) {
    EFI_STATUS status = EFI_SUCCESS;
    const unsigned char *kernel_image = _binary_kernel_blob_bin_start;
    UINTN kernel_size =
        (UINTN)(_binary_kernel_blob_bin_end - _binary_kernel_blob_bin_start);
    Elf64_Ehdr elf_header;
    
    if (kernel_size < sizeof(elf_header)) {
        serial_write('o');
        return EFI_LOAD_ERROR;
    }
    serial_write('1');
    
    /* Read ELF header */
    memcpy(&elf_header, kernel_image, sizeof(elf_header));
    serial_write('2');
    
    /* Verify ELF */
    if (elf_header.e_ident[EI_MAG0] != ELFMAG0 ||
        elf_header.e_ident[EI_MAG1] != ELFMAG1 ||
        elf_header.e_ident[EI_MAG2] != ELFMAG2 ||
        elf_header.e_ident[EI_MAG3] != ELFMAG3 ||
        elf_header.e_ident[EI_CLASS] != ELFCLASS64 ||
        elf_header.e_type != ET_EXEC) {
        serial_write('v');
        Print(L"Invalid ELF format\n");
        status = EFI_LOAD_ERROR;
        goto cleanup;
    }
    serial_write('3');
    
    /* Save kernel entry point (PHYSICAL) */
    /* Set kernel entry point (physical address in our ELF) */
    ctx->kernel_entry = elf_header.e_entry;
    
    /* Load each PT_LOAD segment */
    UINTN min_addr = (UINTN)-1, max_addr = 0;
    
    for (int i = 0; i < elf_header.e_phnum; i++) {
        Elf64_Phdr phdr;
        UINT64 file_pos = elf_header.e_phoff + i * elf_header.e_phentsize;
        
        /* Read program header */
        if (file_pos + sizeof(phdr) > kernel_size) {
            status = EFI_LOAD_ERROR;
            goto cleanup;
        }
        memcpy(&phdr, kernel_image + file_pos, sizeof(phdr));
        
        if (phdr.p_type != PT_LOAD) continue;
        
        /* Calculate memory region */
        EFI_PHYSICAL_ADDRESS seg_base = phdr.p_paddr;
        UINTN seg_size = ALIGN_UP(phdr.p_memsz, PAGE_SIZE);
        UINTN file_size = phdr.p_filesz;
        
        if (seg_size == 0) continue;
        serial_write('s');
        serial_write('0' + (i % 10));
        
        /* Track kernel bounds */
        if (seg_base < min_addr) min_addr = seg_base;
        if (seg_base + seg_size > max_addr) max_addr = seg_base + seg_size;
        
        /* Allocate pages */
        serial_write('p');
        status = AllocatePagesSafe(
            AllocateAddress,
            EfiLoaderData,
            seg_size / PAGE_SIZE,
            &seg_base
        );
        if (EFI_ERROR(status)) {
            serial_write('a');
            Print(L"Failed to allocate segment at %lx\n", seg_base);
            goto cleanup;
        }
        
        /* Load segment data */
        if (file_size > 0) {
            serial_write('m');
            if (phdr.p_offset + file_size > kernel_size) {
                serial_write('l');
                status = EFI_LOAD_ERROR;
                goto cleanup;
            }
            memcpy((VOID*)seg_base, kernel_image + phdr.p_offset, file_size);
        }
        
        /* Zero out BSS section */
        if (phdr.p_memsz > phdr.p_filesz) {
            memset((VOID*)(seg_base + phdr.p_filesz),
                   0, phdr.p_memsz - phdr.p_filesz);
        }
    }
    
    ctx->kernel_phys_base = min_addr;
    ctx->kernel_phys_end = max_addr;
    serial_write('4');
    
    status = EFI_SUCCESS;

cleanup:
    return status;
}

/* Convert raw UEFI memory map to FTK format */
static void ConvertMemoryMap(
    LoaderContext *ctx,
    VOID *memory_map,
    UINTN memory_map_size,
    UINTN descriptor_size
) {
    UINTN mmap_idx = 0;
    UINTN entry_count = memory_map_size / descriptor_size;
    
    for (UINTN i = 0; i < entry_count; i++) {
        EFI_MEMORY_DESCRIPTOR *desc = (EFI_MEMORY_DESCRIPTOR*)
            ((UINT8*)memory_map + i * descriptor_size);
        
        if (desc->NumberOfPages == 0) continue;
        
        mmap_entry_t *entry = &ctx->boot_info.mmap[mmap_idx++];
        entry->base = desc->PhysicalStart;
        entry->length = desc->NumberOfPages * PAGE_SIZE;
        entry->type = (desc->Type == EfiConventionalMemory ||
                       desc->Type == EfiLoaderCode ||
                       desc->Type == EfiLoaderData ||
                       desc->Type == EfiBootServicesCode ||
                       desc->Type == EfiBootServicesData) ?
                       MMAP_TYPE_AVAILABLE : MMAP_TYPE_RESERVED;
        entry->attributes = desc->Attribute;
    }
    ctx->boot_info.mmap_count = (UINT32)mmap_idx;
}

/* Find ACPI RSDP from UEFI configuration table */
static phys_addr_t FindRSDP(void) {
    EFI_GUID acpi1_guid = ACPI_TABLE_GUID;
    EFI_GUID acpi2_guid = ACPI_20_TABLE_GUID;
    EFI_CONFIGURATION_TABLE *config_table = ST->ConfigurationTable;
    UINTN count = ST->NumberOfTableEntries;
    
    serial_write('0' + (count < 10 ? count : 9));
    
    /* Search for ACPI 2.0 RSDP first (preferred — has XSDT, length, checksum) */
    for (UINTN i = 0; i < count; i++) {
        if (memcmp(&config_table[i].VendorGuid, &acpi2_guid, sizeof(EFI_GUID)) == 0) {
            phys_addr_t rsdp = (phys_addr_t)config_table[i].VendorTable;
            if (rsdp) {
                serial_write('2');
                return rsdp;
            }
        }
    }
    /* Fall back to ACPI 1.0 RSDP if 2.0 not found */
    for (UINTN i = 0; i < count; i++) {
        if (memcmp(&config_table[i].VendorGuid, &acpi1_guid, sizeof(EFI_GUID)) == 0) {
            phys_addr_t rsdp = (phys_addr_t)config_table[i].VendorTable;
            if (rsdp) {
                serial_write('1');
                return rsdp;
            }
        }
    }

    /* Fallback: search memory for RSDP signature */
    serial_write('M');
    for (phys_addr_t addr = 0xE0000; addr < 0x100000; addr += 16) {
        if (memcmp((void *)addr, "RSD PTR ", 8) == 0) {
            serial_write('T');
            return addr;
        }
    }
    for (phys_addr_t addr = 0x7F000000; addr < 0x80000000; addr += 16) {
        if (memcmp((void *)addr, "RSD PTR ", 8) == 0) {
            serial_write('U');
            return addr;
        }
    }
    
    serial_write('F');
    return 0;
}

/* Get framebuffer info */
static EFI_STATUS GetFramebufferInfo(LoaderContext *ctx) {
    EFI_GUID gop_guid = EFI_GRAPHICS_OUTPUT_PROTOCOL_GUID;
    EFI_GRAPHICS_OUTPUT_PROTOCOL *gop = NULL;
    EFI_STATUS status;
    
    status = uefi_call_wrapper(
        BS->LocateProtocol, 3,
        &gop_guid, NULL, (VOID**)&gop
    );
    
    if (EFI_ERROR(status) || !gop) {
        ctx->boot_info.fb_available = 0;
        return EFI_SUCCESS; /* Not fatal */
    }
    
    ctx->boot_info.fb_available = 1;
    ctx->boot_info.fb.base = gop->Mode->FrameBufferBase;
    ctx->boot_info.fb.width = gop->Mode->Info->HorizontalResolution;
    ctx->boot_info.fb.height = gop->Mode->Info->VerticalResolution;
    ctx->boot_info.fb.pitch = gop->Mode->Info->PixelsPerScanLine *
                              (gop->Mode->Info->PixelFormat == PixelBlueGreenRedReserved8BitPerColor ? 4 : 2);
    ctx->boot_info.fb.bpp = 32; /* Assume 32-bit for now */
    
    return EFI_SUCCESS;
}

#define HUGE_PAGE_SIZE (2 * 1024 * 1024)

EFI_STATUS EFIAPI efi_main(
    EFI_HANDLE image_handle,
    EFI_SYSTEM_TABLE *system_table
) {
    EFI_STATUS status;
    EFI_LOADED_IMAGE *loaded_image = NULL;
    EFI_PHYSICAL_ADDRESS ctx_addr = 0x1FFFFFFF;
    status = uefi_call_wrapper(
        BS->AllocatePages, 4, AllocateMaxAddress, EfiLoaderData,
        (sizeof(LoaderContext) + PAGE_SIZE - 1) / PAGE_SIZE, &ctx_addr
    );
    if (EFI_ERROR(status)) return status;
    
    LoaderContext *ctx = (LoaderContext *)ctx_addr;
    memset(ctx, 0, sizeof(LoaderContext));
    UINTN map_key = 0, descriptor_size = 0;
    
    /* Initialize UEFI */
    InitializeLib(image_handle, system_table);
    serial_init();
    /* Identity map kernel load region and transition */
    /* (This part was working before) */
    
    /* Get loaded image protocol */
    status = uefi_call_wrapper(
        BS->HandleProtocol, 3,
        image_handle, &gEfiLoadedImageProtocolGuid, (VOID**)&loaded_image
    );
    if (EFI_ERROR(status)) {
        Print(L"Failed to get loaded image protocol\n");
        serial_write('a');
        return status;
    }
    serial_write('B');
    
    /* Kernel is embedded in the EFI image; no filesystem access is required. */
    serial_write('C');
    serial_write('D');
    
    /* Load kernel */
    status = LoadKernel(ctx);
    if (EFI_ERROR(status)) {
        Print(L"Failed to load kernel\n");
        serial_write('d');
        return status;
    }
    serial_write('E');
    
    /* Get framebuffer info */
    GetFramebufferInfo(ctx);
    
    /* Find ACPI RSDP */
    ctx->boot_info.rsdp = FindRSDP();
    
    /* Fill BootInfo */
    ctx->boot_info.kernel_phys_base = ctx->kernel_phys_base;
    ctx->boot_info.kernel_phys_end = ctx->kernel_phys_end;
    ctx->boot_info.kernel_virt_base = KERNEL_VIRT_BASE;
    ctx->boot_info.kernel_virt_end = KERNEL_VIRT_BASE + 
                                   (ctx->kernel_phys_end - ctx->kernel_phys_base);
    
    /* Set bootloader info */
    memcpy(ctx->boot_info.bootloader_name, "FTK-UEFI", 9);
    ctx->boot_info.bootloader_version = 0x0100; /* 1.0 */
    
    /* Pre-allocate memory map buffer */
    UINTN memory_map_size = 0;
    EFI_MEMORY_DESCRIPTOR *memory_map = NULL;
    UINT32 descriptor_version;
    uefi_call_wrapper(BS->GetMemoryMap, 5, &memory_map_size, NULL, &map_key, &descriptor_size, &descriptor_version);
    memory_map_size += 4096; /* Extra space for new allocations */
    uefi_call_wrapper(BS->AllocatePool, 3, EfiLoaderData, memory_map_size, (VOID**)&memory_map);
    
    /* Pre-allocate kernel memory map buffer (generous estimate) */
    UINTN max_entries = memory_map_size / (descriptor_size ? descriptor_size : 48) + 16;
    EFI_PHYSICAL_ADDRESS mmap_safe_addr = 0x1FFFFFFF; // Max 512MB to remain in kernel identity map
    status = uefi_call_wrapper(
        BS->AllocatePages, 4, AllocateMaxAddress, EfiLoaderData,
        (max_entries * sizeof(mmap_entry_t) + PAGE_SIZE - 1) / PAGE_SIZE, &mmap_safe_addr
    );
    if (EFI_ERROR(status)) {
        Print(L"Failed to allocate safe memory map space.\n");
        return status;
    }
    ctx->boot_info.mmap = (mmap_entry_t*)mmap_safe_addr;


    /* Get memory map and exit boot services */
    UINTN allocated_mmap_size = memory_map_size;
    for (int retry = 0; retry < 5; retry++) {
        memory_map_size = allocated_mmap_size;
        status = uefi_call_wrapper(
            BS->GetMemoryMap, 5,
            &memory_map_size, memory_map,
            &map_key, &descriptor_size, &descriptor_version
        );
        if (EFI_ERROR(status)) {
            continue;
        }

        /* Convert the map AFTER successful GetMemoryMap but BEFORE ExitBootServices.
           We can do this because it doesn't involve any UEFI memory allocations. */
        ConvertMemoryMap(ctx, memory_map, memory_map_size, descriptor_size);

        status = uefi_call_wrapper(
            BS->ExitBootServices, 2,
            image_handle, map_key
        );
        if (status == EFI_SUCCESS) {
            break;
        }
    }

    if (EFI_ERROR(status)) {
        return status;
    }
    serial_write('J');
    
    /* Jump to kernel with System V ABI (arg in RDI) */
    __asm__ volatile (
        "movq %0, %%rdi\n\t"
        "jmp *%1"
        : : "r"(&ctx->boot_info), "r"(ctx->kernel_entry) : "rdi"
    );
    
    /* Never reached */
    return EFI_SUCCESS;
}
