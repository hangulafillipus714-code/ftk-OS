#include <ftk/printk.h>
#include <ftk/putchar.h>
#include <ftk/stdarg.h>
#include <ftk/string.h>

static void print_char(char c) {
    putchar(c);  // Uses modular backend (serial, VGA, etc.)
}

static void print_string(const char *str) {
    while (*str) {
        print_char(*str++);
    }
}

static void print_hex(u64 value) {
    const char *hex_digits = "0123456789ABCDEF";
    char buffer[17];
    buffer[16] = '\0';
    
    for (int i = 15; i >= 0; i--) {
        buffer[i] = hex_digits[value & 0xF];
        value >>= 4;
    }
    
    print_string("0x");
    print_string(buffer);
}

static void print_dec(u64 value) {
    char buffer[21];
    int i = 20;
    buffer[i] = '\0';
    
    if (value == 0) {
        print_char('0');
        return;
    }
    
    while (value > 0) {
        buffer[--i] = '0' + (value % 10);
        value /= 10;
    }
    
    print_string(&buffer[i]);
}

static int parse_length(const char *fmt) {
    if (*fmt == 'l') {
        if (*(fmt + 1) == 'l') return 2;
        return 1;
    }
    return 0;
}

static int snprint_char(char *buf, size_t *pos, size_t size, char c) {
    if (*pos < size - 1) {
        buf[*pos] = c;
    }
    (*pos)++;
    return 1;
}

static int snprint_str(char *buf, size_t *pos, size_t size, const char *s) {
    int count = 0;
    while (*s) {
        snprint_char(buf, pos, size, *s++);
        count++;
    }
    return count;
}

static int snprint_hex(char *buf, size_t *pos, size_t size, u64 value) {
    const char *hex = "0123456789ABCDEF";
    char tmp[17];
    int count = 0;
    for (int i = 15; i >= 0; i--) {
        tmp[i] = hex[value & 0xF];
        value >>= 4;
    }
    for (int i = 0; i < 16; i++) count += snprint_char(buf, pos, size, tmp[i]);
    return count;
}

static int snprint_dec(char *buf, size_t *pos, size_t size, u64 value) {
    char tmp[21];
    int i = 20;
    tmp[i] = 0;
    if (value == 0) {
        return snprint_char(buf, pos, size, '0');
    }
    int count = 0;
    while (value > 0) {
        tmp[--i] = '0' + (value % 10);
        value /= 10;
    }
    while (tmp[i]) {
        count += snprint_char(buf, pos, size, tmp[i++]);
    }
    return count;
}

int ksnprintf(char *buf, size_t size, const char *fmt, ...) {
    va_list args;
    va_start(args, fmt);
    int count = 0;
    size_t pos = 0;
    if (size == 0) return 0;

    while (*fmt) {
        if (*fmt == '%') {
            fmt++;
            int len = 0;
            while (*fmt == 'l') { len++; fmt++; }
            switch (*fmt) {
                case 's':
                    count += snprint_str(buf, &pos, size, va_arg(args, const char*));
                    break;
                case 'd':
                case 'i': {
                    u64 v;
                    if (len) v = va_arg(args, u64);
                    else v = (u64)(s64)va_arg(args, int);
                    count += snprint_dec(buf, &pos, size, v);
                    break;
                }
                case 'u': {
                    u64 v;
                    if (len) v = va_arg(args, u64);
                    else v = va_arg(args, unsigned int);
                    count += snprint_dec(buf, &pos, size, v);
                    break;
                }
                case 'x':
                case 'X': {
                    u64 v = va_arg(args, u64);
                    count += snprint_hex(buf, &pos, size, v);
                    break;
                }
                case 'p': {
                    u64 v = va_arg(args, u64);
                    snprint_str(buf, &pos, size, "0x");
                    count += 2 + snprint_hex(buf, &pos, size, v);
                    break;
                }
                case 'c':
                    count += snprint_char(buf, &pos, size, (char)va_arg(args, int));
                    break;
                case '%':
                    count += snprint_char(buf, &pos, size, '%');
                    break;
                default:
                    count += snprint_char(buf, &pos, size, *fmt);
                    break;
            }
        } else {
            count += snprint_char(buf, &pos, size, *fmt);
        }
        fmt++;
    }

    buf[pos < size ? pos : size - 1] = 0;
    va_end(args);
    return count;
}

void kprintf(const char *fmt, ...) {
    va_list args;
    va_start(args, fmt);
    
    while (*fmt) {
        if (*fmt == '%') {
            fmt++;
            int len = parse_length(fmt);
            fmt += len;
            
            switch (*fmt) {
                case 's': {
                    char *str = va_arg(args, char*);
                    print_string(str);
                    break;
                }
                case 'd':
                case 'i': {
                    u64 value;
                    if (len) value = va_arg(args, u64);
                    else value = (u64)(s64)va_arg(args, int);
                    print_dec(value);
                    break;
                }
                case 'u': {
                    u64 value;
                    if (len) value = va_arg(args, u64);
                    else value = va_arg(args, unsigned int);
                    print_dec(value);
                    break;
                }
                case 'x':
                case 'X': {
                    u64 value = va_arg(args, u64);
                    print_hex(value);
                    break;
                }
                case 'p': {
                    u64 value = va_arg(args, u64);
                    print_hex(value);
                    break;
                }
                case 'c': {
                    char c = va_arg(args, int);
                    print_char(c);
                    break;
                }
                case '%': {
                    print_char('%');
                    break;
                }
                default:
                    print_char(*fmt);
                    break;
            }
        } else {
            print_char(*fmt);
        }
        fmt++;
    }
    
    va_end(args);
}