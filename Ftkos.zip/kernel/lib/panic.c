#include <ftk/abi/types.h>
#include <drivers/char/serial.h>

__attribute__((noreturn))
void kernel_panic(const char *msg)
{
    serial_puts(LOG_CLR_RED "KERNEL PANIC: ");
    serial_puts(msg);
    serial_puts(LOG_CLR_RESET "\n");

    for (;;)
        __asm__ volatile ("hlt");
}