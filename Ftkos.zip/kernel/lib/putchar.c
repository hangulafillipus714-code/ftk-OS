#include <ftk/putchar.h>

/*
 * Weak fallback implementation.
 * Real output drivers override this symbol.
 */
__attribute__((weak))
int putchar(int c)
{
    return c;
}