/*
 * kernel/lib/string.c - Kernel string functions
 */

#include <ftk/stddef.h>

/* Copy memory */
void *memcpy(void *dest, const void *src, size_t n)
{
    char *d = dest;
    const char *s = src;
    
    for (size_t i = 0; i < n; i++) {
        d[i] = s[i];
    }
    
    return dest;
}

/* Set memory */
void *memset(void *s, int c, size_t n)
{
    unsigned char *p = s;
    
    for (size_t i = 0; i < n; i++) {
        p[i] = (unsigned char)c;
    }
    
    return s;
}

/* Copy string */
char *strcpy(char *dest, const char *src)
{
    char *d = dest;
    
    while ((*d++ = *src++));
    
    return dest;
}

/* Copy limited string */
char *strncpy(char *dest, const char *src, size_t n)
{
    char *d = dest;
    
    for (size_t i = 0; i < n; i++) {
        d[i] = src[i];
        if (src[i] == '\0') {
            break;
        }
    }
    
    return dest;
}

/* String length */
size_t strlen(const char *s)
{
    size_t len = 0;
    
    while (s[len]) {
        len++;
    }
    
    return len;
}

/* Compare strings */
int strcmp(const char *s1, const char *s2)
{
    while (*s1 && (*s1 == *s2)) {
        s1++;
        s2++;
    }
    
    return *(const unsigned char*)s1 - *(const unsigned char*)s2;
}

/* Compare limited strings */
int strncmp(const char *s1, const char *s2, size_t n)
{
    for (size_t i = 0; i < n; i++) {
        if (s1[i] != s2[i]) {
            return (unsigned char)s1[i] - (unsigned char)s2[i];
        }
        if (s1[i] == '\0') {
            return 0;
        }
    }
    
    return 0;
}

/* Find character in string */
char *strchr(const char *s, int c)
{
    while (*s) {
        if (*s == (char)c) {
            return (char*)s;
        }
        s++;
    }
    
    return NULL;
}

/* Compare memory */
int memcmp(const void *s1, const void *s2, size_t n)
{
    const unsigned char *p1 = s1;
    const unsigned char *p2 = s2;
    
    for (size_t i = 0; i < n; i++) {
        if (p1[i] != p2[i]) {
            return p1[i] - p2[i];
        }
    }
    
    return 0;
}