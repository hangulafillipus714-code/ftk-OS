#include <ftk/test.h>
#include <ftk/string.h>
#include <ftk/arch/x86_64/cpu.h>
#include <ftk/arch/x86_64/idt.h>
#include <ftk/memory.h>
#include <ftk/io.h>
#include <ftk/memory_layout.h>
#include <ftk/scheduler.h>
#include <ftk/per_cpu.h>

#define MAX_TESTS 512

static TestCase test_registry[MAX_TESTS];
static int test_count = 0;

int current_test_failed = 0;
const char *test_name = NULL;
int __test_count = 0;
int __test_failures = 0;

__attribute__((weak))
void test_suite_init(void) {}

void test_register(const char *name, test_func_t func) {
    if (test_count >= MAX_TESTS) return;
    test_registry[test_count].name = name;
    test_registry[test_count].func = func;
    test_registry[test_count].failed = 0;
    test_count++;
}

static void sys_state_dump(void) {
    char vendor[13];
    char brand[49];
    uint32_t eax, ebx, ecx, edx;
    uint64_t cr0, cr3, cr4;
    extern struct idt_ptr idtp;
    extern struct idt_entry idt[256];
    extern volatile u64 system_ticks;
    extern size_t pmm_get_free_page_count(void);
    extern size_t pmm_get_total_page_count(void);

    kprintf("\n========================================\n");
    kprintf("  FTK OS System State Dump\n");
    kprintf("========================================\n");

    /* Architecture */
    kprintf("[ARCH] x86_64\n");
    kprintf("[MODE] Long mode (64-bit)\n");

    /* CPU Info */
    cpu_get_vendor_id(vendor);
    kprintf("[CPU] Vendor: %s\n", vendor);
    if (cpu_get_brand_string(brand)) {
        kprintf("[CPU] Brand: %s\n", brand);
    }
    cpu_cpuid(1, 0, &eax, &ebx, &ecx, &edx);
    kprintf("[CPU] Family: %u, Model: %u, Stepping: %u\n",
            (eax >> 8) & 0xF, (eax >> 4) & 0xF, eax & 0xF);

    /* Feature flags */
    kprintf("[FEAT] EDX: 0x%08x ECX: 0x%08x\n", edx, ecx);
    cpu_cpuid(7, 0, &eax, &ebx, &ecx, &edx);
    kprintf("[FEAT7] EBX: 0x%08x ECX: 0x%08x EDX: 0x%08x\n", ebx, ecx, edx);

    /* Control registers */
    cr0 = read_cr0();
    cr3 = read_cr3();
    cr4 = read_cr4();
    kprintf("[CR0] 0x%016llx\n", cr0);
    kprintf("[CR3] 0x%016llx (PML4)\n", cr3);
    kprintf("[CR4] 0x%016llx\n", cr4);

    /* IDT */
    kprintf("[IDT] Base: 0x%llx Limit: %u Entries: %u\n",
            idtp.base, idtp.limit, (idtp.limit + 1) / 16);
    int idt_valid = 0;
    for (int i = 0; i < 256; i++) {
        if (idt[i].flags != 0) idt_valid++;
    }
    kprintf("[IDT] Valid entries: %d/256\n", idt_valid);

    /* PIC */
    uint8_t master_mask = inb(0x21);
    uint8_t slave_mask = inb(0xA1);
    kprintf("[PIC] Master mask: 0x%02x Slave mask: 0x%02x\n", master_mask, slave_mask);

    /* PIT / Timer */
    kprintf("[PIT] system_ticks: %llu (IRQ0 vector 32)\n", system_ticks);

    /* Memory */
    kprintf("[PMM] Free: %u pages, Total: %u pages\n",
            (unsigned int)pmm_get_free_page_count(),
            (unsigned int)pmm_get_total_page_count());
    kprintf("[VMM] Kernel virt base: 0x%llx\n", KERNEL_VIRT_BASE);

    kprintf("========================================\n");
}

int test_run_all(void) {
    __test_count = 0;
    __test_failures = 0;

    extern size_t pmm_get_free_page_count(void);
    extern size_t pmm_get_total_page_count(void);
    kprintf("[TEST] PMM: %u free / %u total pages\n",
            (unsigned int)pmm_get_free_page_count(),
            (unsigned int)pmm_get_total_page_count());

    test_suite_init();

    kprintf("\n========================================\n");
    kprintf("  FTK OS Test Runner\n");
    kprintf("  %d test(s) registered\n", test_count);
    kprintf("========================================\n\n");

    for (int i = 0; i < test_count; i++) {
        if (!current_task) {
            Task *fallback = kmalloc(sizeof(Task));
            if (fallback) {
                memset(fallback, 0, sizeof(Task));
                fallback->pid = 0;
                fallback->state = TASK_RUNNING;
                fallback->address_space = NULL;
                fallback->fd_table[0].used = 1;
                fallback->fd_table[1].used = 1;
                fallback->fd_table[2].used = 1;
                current_task = fallback;
            }
        }

        kprintf("[RUN] %s\n", test_registry[i].name);

        int count_before = __test_count;
        test_registry[i].func();
        /* If the test did not call TEST_END(), count it here */
        if (__test_count == count_before) {
            if (current_test_failed) {
                __test_failures++;
            }
            __test_count++;
        }

        if (current_test_failed) {
            test_registry[i].failed = 1;
            kprintf("[RESULT] %s: FAIL\n", test_registry[i].name);
        } else {
            kprintf("[RESULT] %s: PASS\n", test_registry[i].name);
        }
        current_test_failed = 0;
        kprintf("\n");
    }

    kprintf("========================================\n");
    kprintf("  RESULTS: %d passed, %d failed, %d total\n",
            __test_count - __test_failures, __test_failures, __test_count);
    kprintf("========================================\n");

    int all_pass = (__test_failures == 0);
    kprintf("[TEST] OVERALL: %s\n",
            all_pass ? "ALL TESTS PASSED" : "SOME TESTS FAILED");

    sys_state_dump();

    return __test_failures;
}
