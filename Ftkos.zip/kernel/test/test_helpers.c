#include <ftk/test.h>
#include <ftk/panic.h>
#include <ftk/string.h>

void test_expect_panic(void (*func)(void), const char *expected_msg) {
    kprintf("  Expecting panic: %s ... ", expected_msg);
    func();
    kprintf("DID NOT PANIC (FAIL)\n");
    current_test_failed = 1;
    __test_failures++;
}

void test_fill_pattern(void *buf, size_t size, u8 pattern) {
    memset(buf, pattern, size);
}

int test_check_pattern(const void *buf, size_t size, u8 pattern) {
    const u8 *p = (const u8 *)buf;
    for (size_t i = 0; i < size; i++) {
        if (p[i] != pattern) return 0;
    }
    return 1;
}
