/*
 * kernel/syscall/syscall.c — FTK OS system call subsystem
 *
 * Responsibilities:
 *   1. Program IA32_EFER.SCE, IA32_LSTAR, IA32_STAR, IA32_FMASK
 *   2. Set up per-CPU kernel stack pointers used by syscall_entry.S
 *   3. Provide a dispatch table and call individual handlers
 *   4. Implement the first-generation syscalls:
 *        SYS_EXIT(0), SYS_WRITE(1), SYS_READ(2),
 *        SYS_GETPID(3), SYS_SLEEP(4), SYS_YIELD(5), SYS_BRK(6)
 */

#include <ftk/syscall.h>
#include <ftk/abi/syscall.h>
#include <ftk/abi/types.h>
#include <ftk/uaccess.h>
#include <ftk/pmm.h>
#include <ftk/vmm.h>
#include <ftk/memory_layout.h>
#include <ftk/io.h>
#include <ftk/printk.h>
#include <ftk/putchar.h>
#include <ftk/scheduler.h>
#include <ftk/per_cpu.h>
#include <ftk/debug.h>
#include <ftk/elf.h>
#include <ftk/fs/vfs.h>
#include <ftk/memory_layout.h>
#include <ftk/memory.h>
#include <ftk/string.h>
#include <ftk/spinlock.h>
#include <drivers/char/console.h>
#include <drivers/char/keyboard.h>
#include <ftk/framebuffer.h>

/* Defined in gdt.c / tss init – RSP0 is the ring-0 stack top for this CPU */
extern u64 tss_rsp0_get(void);

/* Defined in syscall_entry.S – needs per-CPU data block address */
/* Per-CPU data for syscall entry — now part of per_cpu_data[].
 * Offsets 0 and 8 in per_cpu_data_t must match syscall_entry.S expectations:
 *   [0]  kern_rsp  – kernel stack top loaded on syscall entry
 *   [8]  user_rsp  – scratch slot to stash user RSP
 */

/* Kernel stack for BSP syscall path (separate from interrupt stack) */
#define SYSCALL_KSTACK_PAGES  4
static u8 syscall_kstack[SYSCALL_KSTACK_PAGES * 4096]
    __attribute__((aligned(16)));

/* Tracks whether syscall_init() was called */
static volatile int syscall_initialized = 0;

/*
 * syscall_set_kstack — update the per-CPU kernel stack pointer for syscall entry.
 *
 * Called from the scheduler on every context switch so that each task
 * uses its own kernel stack for syscall handling (instead of sharing
 * a single static syscall_kstack between all tasks).
 *
 * If rsp is 0 (idle/boot task), falls back to the static syscall_kstack.
 */
void syscall_set_kstack(u64 rsp)
{
    this_cpu()->kern_rsp = rsp ? rsp : (u64)(uintptr_t)(syscall_kstack + sizeof(syscall_kstack));
    kprintf("[DBG] syscall_set_kstack kern_rsp=0x%lx\n", (unsigned long)rsp);
}

/* ── MSR helpers ─────────────────────────────────────────── */

static inline void wrmsr(u32 msr, u64 val)
{
    u32 lo = (u32)(val & 0xFFFFFFFF);
    u32 hi = (u32)(val >> 32);
    __asm__ volatile("wrmsr" : : "c"(msr), "a"(lo), "d"(hi) : "memory");
}

static inline u64 rdmsr(u32 msr)
{
    u32 lo, hi;
    __asm__ volatile("rdmsr" : "=a"(lo), "=d"(hi) : "c"(msr));
    return ((u64)hi << 32) | lo;
}

/* ── Forward declarations ────────────────────────────────── */
static s64 sys_exit    (SyscallFrame *f);
static s64 sys_write   (SyscallFrame *f);
static s64 sys_read    (SyscallFrame *f);
static s64 sys_getpid  (SyscallFrame *f);
static s64 sys_sleep   (SyscallFrame *f);
static s64 sys_yield   (SyscallFrame *f);
static s64 sys_brk     (SyscallFrame *f);
static s64 sys_exec    (SyscallFrame *f);
static s64 sys_readfile(SyscallFrame *f);
static s64 sys_listdir (SyscallFrame *f);
static s64 sys_open    (SyscallFrame *f);
static s64 sys_close   (SyscallFrame *f);
static s64 sys_spawn   (SyscallFrame *f);
static s64 sys_waitpid (SyscallFrame *f);
static s64 sys_getdents(SyscallFrame *f);
static s64 sys_ps     (SyscallFrame *f);
static s64 sys_pipe   (SyscallFrame *f);
static s64 sys_dup2   (SyscallFrame *f);
static s64 sys_kill   (SyscallFrame *f);
static s64 sys_fb_info (SyscallFrame *f);
static s64 sys_fb_map  (SyscallFrame *f);
static s64 sys_fb_flush(SyscallFrame *f);
static s64 sys_getticks(SyscallFrame *f);
static s64 sys_getkey  (SyscallFrame *f);
static s64 sys_mmap    (SyscallFrame *f);
static s64 sys_munmap  (SyscallFrame *f);
static s64 sys_setcursor(SyscallFrame *f);
static s64 sys_gettime (SyscallFrame *f);
static s64 sys_poll    (SyscallFrame *f);

/* ── Internal helpers ────────────────────────────────────── */

/* Copy a null-terminated string from user space into kernel buffer */
static int copy_user_string(u64 user_ptr, char *kbuf, u64 maxlen)
{
    for (u64 i = 0; i < maxlen - 1; i++) {
        char c;
        if (copy_from_user(&c, (const char *)(uintptr_t)(user_ptr + i), 1) != 0)
            return -1;
        kbuf[i] = c;
        if (c == '\0')
            return 0;
    }
    kbuf[maxlen - 1] = '\0';
    return 0;
}

/* Find a free fd slot in current task's fd table */
static int fd_allocate(void)
{
    for (int i = 0; i < MAX_FDS; i++) {
        if (!current_task->fd_table[i].used)
            return i;
    }
    return -1;
}

/* ── Dispatch table ──────────────────────────────────────── */

static const syscall_handler_t syscall_table[SYSCALL_COUNT] = {
    [SYS_EXIT]   = sys_exit,
    [SYS_WRITE]  = sys_write,
    [SYS_READ]   = sys_read,
    [SYS_GETPID] = sys_getpid,
    [SYS_SLEEP]  = sys_sleep,
    [SYS_YIELD]  = sys_yield,
    [SYS_BRK]    = sys_brk,
    [SYS_EXEC]   = sys_exec,
    [SYS_READFILE] = sys_readfile,
    [SYS_LISTDIR]  = sys_listdir,
    [SYS_OPEN]   = sys_open,
    [SYS_CLOSE]  = sys_close,
    [SYS_SPAWN]   = sys_spawn,
    [SYS_WAITPID] = sys_waitpid,
    [SYS_GETDENTS]= sys_getdents,
    [SYS_PS]      = sys_ps,
    [SYS_PIPE]    = sys_pipe,
    [SYS_DUP2]    = sys_dup2,
    [SYS_DEBUG]   = (void*)0,
    [SYS_KILL]    = sys_kill,
    [SYS_FB_INFO]  = sys_fb_info,
    [SYS_FB_MAP]   = sys_fb_map,
    [SYS_FB_FLUSH] = sys_fb_flush,
    [SYS_GETTICKS] = sys_getticks,
    [SYS_GETKEY]   = sys_getkey,
    [SYS_MMAP]     = sys_mmap,
    [SYS_MUNMAP]   = sys_munmap,
    [SYS_SETCURSOR]= sys_setcursor,
    [SYS_GETTIME]  = sys_gettime,
    [SYS_POLL]     = sys_poll,
};

/* ── Initialisation ──────────────────────────────────────── */

/*
 * syscall_init – called once from kernel_main() after GDT + TSS are ready.
 *
 * Programs the four MSRs that enable the SYSCALL/SYSRET mechanism:
 *
 *  IA32_EFER   – set SCE (SysCall Enable) bit
 *  IA32_LSTAR  – 64-bit handler entry point (syscall_entry in .S)
 *  IA32_STAR   – segment selectors:
 *                bits [47:32] = kernel CS  (SYSCALL loads CS from here)
 *                bits [63:48] = user CS-16 (SYSRETQ loads CS from here+16,
 *                               SS from here+8 – Intel manual §3.6.3.2)
 *  IA32_FMASK  – RFLAGS bits to clear on entry (IF=bit9, DF=bit10)
 */
void syscall_init(void)
{
    /* 1. Enable SCE in IA32_EFER */
    u64 efer = rdmsr(MSR_EFER);
    efer |= EFER_SCE;
    wrmsr(MSR_EFER, efer);

    /* 2. Set entry point */
    extern void syscall_entry(void);
    wrmsr(MSR_LSTAR, (u64)(uintptr_t)syscall_entry);

    /*
     * 3. Set IA32_STAR segment layout.
     *    Bits [47:32]: kernel CS selector  → CPU uses this for CS on SYSCALL
     *                  CPU auto-sets SS = kernel CS + 8
     *    Bits [63:48]: user CS-16 selector → SYSRETQ sets CS = this+16,
     *                  SS = this+8
     *
     *    Our GDT layout (see gdt.c):
     *      0x00  null
     *      0x08  kernel code  (ring 0)
     *      0x10  kernel data  (ring 0)
     *      0x18  user data    (ring 3)  ← STAR high uses CS-16 = 0x18
     *      0x20  user code    (ring 3)  ← SYSRETQ loads CS from 0x18+16=0x28?
     *
     *    Intel: SYSRETQ sets CS = [63:48]+16, SS = [63:48]+8
     *    So [63:48] must be (user_code_sel - 16) = 0x20 - 0x10 = 0x10? No.
     *    Standard layout: place user data at 0x18, user code at 0x20.
     *    Then STAR high = 0x13 (0x18|3 – 8 = 0x13)? Use 0x18 directly and
     *    rely on RPL bits. The conventional encoding is:
     *      STAR[63:48] = user32_cs | 3  where user32_cs is the 32-bit
     *      placeholder; SYSRETQ adds 16 to get 64-bit user CS.
     *
     *    FTK GDT: null(0), kcode(8), kdata(16), udata(24), ucode(32)
     *    For SYSRETQ:  CS = STAR[63:48] + 16,  SS = STAR[63:48] + 8
     *    We want CS=32 (ucode), SS=24 (udata):
     *      STAR[63:48] + 16 = 32 → STAR[63:48] = 16 = 0x10
     *      STAR[63:48] +  8 = 24 → 16 + 8 = 24 ✓
     *
     *    For SYSCALL: CS = STAR[47:32], SS = STAR[47:32] + 8
     *    We want CS=8 (kcode), SS=16 (kdata):
     *      STAR[47:32] = 8 = 0x08  → SS = 8+8 = 16 ✓
     */
    u64 star = ((u64)GDT_KERNEL_CODE << 32)        /* bits [47:32] */
             | ((u64)(GDT_USER_DATA - 8) << 48);   /* bits [63:48] */
    wrmsr(MSR_STAR, star);

    /* 4. Clear IF (bit 9) and DF (bit 10) on syscall entry */
    wrmsr(MSR_FMASK, (1ULL << 9) | (1ULL << 10));

    /* 5. Set up per-CPU kernel stack in per_cpu_data for syscall_entry.S.
     *    IA32_GS_BASE / IA32_KERNEL_GS_BASE were already set to
     *    &per_cpu_data[0] by per_cpu_setup_gs_base(0) before syscall_init()
     *    was called, so we just populate the fields now.
     */
    per_cpu_data[0].kern_rsp = (u64)(uintptr_t)(syscall_kstack
                               + sizeof(syscall_kstack));
    per_cpu_data[0].user_rsp = 0;

    syscall_initialized = 1;

    kprintf("[SYSCALL] Initialized: LSTAR=%llx (wrote=%llx) STAR=%llx\n",
           (unsigned long long)rdmsr(MSR_LSTAR),
           (unsigned long long)(u64)(uintptr_t)syscall_entry,
           (unsigned long long)rdmsr(MSR_STAR));
    kprintf("[SYSCALL] %d syscalls registered\n", (int)SYSCALL_COUNT);
}

/* ── Public query helpers (used by tests) ────────────────── */

int syscall_is_initialized(void)
{
    return syscall_initialized;
}

u64 syscall_get_lstar(void)
{
    return rdmsr(MSR_LSTAR);
}

/* ── Dispatcher ──────────────────────────────────────────── */

/*
 * syscall_dispatch – called from syscall_entry.S with frame on kernel stack.
 * Sets frame->rax to the return value so SYSRETQ delivers it in RAX.
 */
/* Task list access (declared in scheduler.c) */
extern spinlock_t scheduler_lock;
extern Task *task_list;

void syscall_dispatch(SyscallFrame *frame)
{
    /* Check if this task has received SYS_KILL — if so, exit */
    if (current_task->killed) {
        kprintf("[KILL] PID %u (%s) killed, exiting\n",
                scheduler_current_pid(), current_task->name);
        frame->rdi = -1;  /* exit status */
        sys_exit(frame);
        /* unreachable */
    }

    u64 nr = frame->rax;

    if (nr >= SYSCALL_COUNT || syscall_table[nr] == (void*)0) {
        kprintf("[SYSCALL] Unknown syscall %llu from PID %u\n",
               (unsigned long long)nr,
               scheduler_current_pid());
        frame->rax = (u64)(s64)ESYS_NOSYS;
        return;
    }

    s64 ret = syscall_table[nr](frame);
    frame->rax = (u64)ret;

    /* Re-check after handler (handler may have set killed, e.g. via SYS_KILL to self) */
    if (current_task->killed) {
        kprintf("[KILL] PID %u (%s) killed after syscall, exiting\n",
                scheduler_current_pid(), current_task->name);
        frame->rdi = -1;
        sys_exit(frame);
    }
}

/* ── User Memory Boundary Checks ───────────────────────────── */
/* Implemented in kernel/mm/uaccess.c (copy_from_user / copy_to_user). */

/* ── Syscall implementations ─────────────────────────────── */

/*
 * SYS_EXIT (0)
 * exit(int status) – terminate the calling task.
 * RDI = exit status (currently ignored; task is removed from ready queue).
 */
static s64 sys_exit(SyscallFrame *frame)
{
    int status = (int)(s32)frame->rdi;
    u32 pid = scheduler_current_pid();

    kprintf("[EXIT] PID %u: exit(status=%d, name='%s', parent_pid=%u)\n",
            pid, status, current_task->name, current_task->parent_pid);

    /* Clean up open file descriptors */
    for (int i = 0; i < MAX_FDS; i++) {
        if (current_task->fd_table[i].used) {
            file_t *f = &current_task->fd_table[i];
            if (f->type == FD_TYPE_PIPE && f->pipe) {
                if (f->pipe_is_write == 1) f->pipe->writers--;
                f->pipe->refcount--;
                if (f->pipe->refcount <= 0) {
                    f->pipe->closed = 1;
                    kfree(f->pipe);
                }
            }
            if (f->node) {
                vfs_node_close(f->node);
            }
            f->used   = 0;
        }
    }

    /* Mark task as zombie/terminated and yield – scheduler picks next task. */
    scheduler_exit_current(status);

    /* scheduler_exit_current() does not return if there is another task. */
    /* If it somehow returns (single task), halt. */
    for (;;) {
        __asm__ volatile("hlt");
    }

    return ESYS_OK; /* unreachable */
}

/*
 * SYS_WRITE (1)
 * ssize_t write(int fd, const void *buf, size_t n)
 * RDI=fd  RSI=buf  RDX=n
 *
 * fd 1 (stdout) and 2 (stderr) → serial + framebuffer via putchar.
 * fd 3+ → write to open file (not yet supported).
 * Returns bytes written, or negative errno.
 */
static s64 sys_write(SyscallFrame *frame)
{
    int fd = (int)(s32)frame->rdi;
    const char *buf = (const char *)(uintptr_t)frame->rsi;
    u64    n   = frame->rdx;

    if (fd < 0 || fd >= MAX_FDS || !current_task->fd_table[fd].used) {
        return ESYS_BADF;
    }
    if (fd == FD_STDIN) {
        return ESYS_BADF;
    }
    if (buf == (void*)0) {
        return ESYS_FAULT;
    }
    if (n == 0) {
        return 0;
    }

    file_t *f = &current_task->fd_table[fd];

    /* Console output (fd 1, 2 — node is NULL for pre-opened stdio) */
    if (f->type == FD_TYPE_CONSOLE) {
        char kbuf[128];
        u64 written = 0;

        while (written < n) {
            u64 chunk = n - written;
            if (chunk > sizeof(kbuf)) chunk = sizeof(kbuf);

            if (copy_from_user(kbuf, buf + written, chunk) != 0) {
                return written > 0 ? (s64)written : ESYS_FAULT;
            }

            for (u64 i = 0; i < chunk; i++) {
                putchar(kbuf[i]);
            }
            written += chunk;
        }

        return (s64)written;
    }

    /* Pipe output */
    if (f->type == FD_TYPE_PIPE) {
        pipe_t *p = f->pipe;
        if (!p || p->closed) return ESYS_BADF;
        char kbuf[128];
        u64 written = 0;
        while (written < n) {
            u64 chunk = n - written;
            if (chunk > sizeof(kbuf)) chunk = sizeof(kbuf);
            if (copy_from_user(kbuf, buf + written, chunk) != 0)
                return written > 0 ? (s64)written : ESYS_FAULT;
            for (u64 i = 0; i < chunk; i++) {
                while (((p->write_pos + 1) % sizeof(p->data)) == p->read_pos) {
                    if (p->closed) return (s64)written;
                    scheduler_yield();
                }
                p->data[p->write_pos] = kbuf[i];
                p->write_pos = (p->write_pos + 1) % sizeof(p->data);
            }
            written += chunk;
        }
        return (s64)written;
    }

    /* File output — not yet supported (read-only FS) */
    return ESYS_BADF;
}

/*
 * SYS_READ (2)
 * ssize_t read(int fd, void *buf, size_t n)
 * RDI=fd  RSI=buf  RDX=n
 *
 * fd 0 (stdin) → console input (blocking, one char at a time).
 * fd 3+ → read from open file at current offset.
 * Returns bytes read, or negative errno.
 */
static s64 sys_read(SyscallFrame *frame)
{
    int fd = (int)(s32)frame->rdi;
    char *user_buf = (char *)(uintptr_t)frame->rsi;
    u64   n   = frame->rdx;

    if (fd < 0 || fd >= MAX_FDS || !current_task->fd_table[fd].used) {
        return ESYS_BADF;
    }
    if (fd == FD_STDOUT || fd == FD_STDERR) {
        return ESYS_BADF;
    }
    if (user_buf == (void*)0) {
        return ESYS_FAULT;
    }
    if (n == 0) {
        return 0;
    }

    file_t *f = &current_task->fd_table[fd];

    /* Console input (fd 0 — node is NULL for pre-opened stdin) */
    if (f->type == FD_TYPE_CONSOLE) {
        char c = console_getchar();

        if (copy_to_user(user_buf, &c, 1) != 0) {
            return ESYS_FAULT;
        }
        return 1;
    }

    /* Pipe input */
    if (f->type == FD_TYPE_PIPE) {
        pipe_t *p = f->pipe;
        if (!p) return ESYS_BADF;
        char kbuf[128];
        u64 to_read = n > sizeof(kbuf) ? sizeof(kbuf) : n;
        u64 i = 0;
        while (i < to_read) {
            if (p->read_pos == p->write_pos) {
                if (p->closed || p->writers == 0) break;
                scheduler_yield();
                continue;
            }
            kbuf[i++] = p->data[p->read_pos];
            p->read_pos = (p->read_pos + 1) % sizeof(p->data);
        }
        if (i > 0) {
            if (copy_to_user(user_buf, kbuf, i) != 0)
                return ESYS_FAULT;
        }
        return (s64)i;
    }

    /* File input — read from current offset */
    {
        u8 *kbuf = kmalloc(n);
        if (!kbuf) return ESYS_NOMEM;

        s64 bytes_read = f->node->read(f->node, f->offset, n, kbuf);
        if (bytes_read < 0) {
            kfree(kbuf);
            return ESYS_IO;
        }

        if (copy_to_user(user_buf, kbuf, (u64)bytes_read) != 0) {
            kfree(kbuf);
            return ESYS_FAULT;
        }

        f->offset += (u64)bytes_read;
        kfree(kbuf);
        return (s64)bytes_read;
    }
}

/*
 * SYS_GETPID (3)
 * pid_t getpid() → current task PID.
 */
static s64 sys_getpid(SyscallFrame *frame)
{
    (void)frame;
    return (s64)scheduler_current_pid();
}

/*
 * SYS_SLEEP (4)
 * sleep(uint64_t ticks) – sleep for N PIT ticks (100 ticks/sec).
 * RDI = tick count.
 */
static s64 sys_sleep(SyscallFrame *frame)
{
    u64 ticks = frame->rdi;
    if (ticks == 0) return ESYS_OK;

    extern u64 pit_get_ticks(void);
    u64 deadline = pit_get_ticks() + ticks;
    while (pit_get_ticks() < deadline) {
        scheduler_yield();
    }
    return ESYS_OK;
}

/*
 * SYS_YIELD (5)
 * yield() – voluntarily surrender the CPU to the next ready task.
 */
static s64 sys_yield(SyscallFrame *frame)
{
    (void)frame;
    scheduler_yield();
    return ESYS_OK;
}

/*
 * SYS_BRK (6)
 * void *brk(void *addr) — extend/contract the user heap break.
 * RDI = requested break (page-aligned); 0 queries current break.
 */
static s64 sys_brk(SyscallFrame *frame)
{
    if (!current_task || !current_task->is_user) {
        return ESYS_PERM;
    }

    virt_addr_t req = (virt_addr_t)frame->rdi;
    virt_addr_t old_brk = current_task->brk_current;
    AddressSpace *space = current_task->address_space;

    if (req == 0) {
        return (s64)old_brk;
    }

    if (req < current_task->brk_base || req > USER_SPACE_TOP) {
        return ESYS_INVAL;
    }

    if (!IS_ALIGNED(req, PAGE_SIZE)) {
        return ESYS_INVAL;
    }

    if (req == old_brk) {
        return (s64)old_brk;
    }

    if (req > old_brk) {
        for (virt_addr_t v = old_brk; v < req; v += PAGE_SIZE) {
            phys_addr_t phys = pmm_alloc_page();
            if (!phys) {
                return ESYS_NOMEM;
            }
            u64 flags = PTE_PRESENT | PTE_WRITABLE | PTE_USER | PTE_NX;
            if (vmm_map_page(space, v, phys, flags) != 0) {
                pmm_free_page(phys);
                return ESYS_NOMEM;
            }
        }
    } else {
        for (virt_addr_t v = req; v < old_brk; v += PAGE_SIZE) {
            vmm_unmap_and_free(space, v);
        }
    }

    current_task->brk_current = req;
    return (s64)req;
}

/*
 * SYS_EXEC (7)
 * int exec(const char *filename) — replace current process with a new ELF.
 * RDI = userspace filename string (null-terminated).
 *
 * Loads the ELF from disk via VFS, creates a fresh address space,
 * switches to it, and sets the syscall return to enter the new program.
 * On error, returns a negative errno and the shell continues.
 */
/* create_user_address_space is defined in sched/process.c */
extern AddressSpace *create_user_address_space(void);

static s64 sys_exec(SyscallFrame *frame)
{
    u64 user_argv   = frame->rsi;

    char kpath[256];
    if (copy_user_string(frame->rdi, kpath, sizeof(kpath)) != 0)
        return ESYS_FAULT;

    if (kpath[0] == '\0')
        return ESYS_INVAL;

    kprintf("[EXEC] PID %u executing '%s'\n", scheduler_current_pid(), kpath);

    /* Copy argv from user space first (while old address space is active) */
    u64 argc = 0;
    char *argv_strings[64];
    u64   argv_strlens[64];
    memset(argv_strings, 0, sizeof(argv_strings));
    memset(argv_strlens, 0, sizeof(argv_strlens));

    if (user_argv != 0) {
        while (argc < 64) {
            u64 ptr;
            if (copy_from_user(&ptr, (const void *)(uintptr_t)(user_argv + argc * 8), 8) != 0)
                break;
            if (ptr == 0) break;

            char tmp[256];
            u64 slen = 0;
            for (; slen < 255; slen++) {
                char c;
                if (copy_from_user(&c, (const void *)(uintptr_t)(ptr + slen), 1) != 0)
                    break;
                tmp[slen] = c;
                if (c == '\0') { slen++; break; }
            }
            argv_strings[argc] = kmalloc(slen + 1);
            if (!argv_strings[argc]) break;
            memcpy(argv_strings[argc], tmp, slen);
            argv_strings[argc][slen] = '\0';
            argv_strlens[argc] = slen;
            argc++;
        }
    }

    /* Open file via VFS */
    vfs_node_t *file = vfs_open(kpath);
    if (!file) {
        kprintf("[EXEC] File not found: %s\n", kpath);
        for (u64 a = 0; a < argc; a++) kfree(argv_strings[a]);
        return ESYS_NOENT;
    }

    void *elf_data = kmalloc(file->size);
    if (!elf_data) {
        vfs_node_close(file);
        for (u64 a = 0; a < argc; a++) kfree(argv_strings[a]);
        return ESYS_NOMEM;
    }

    if (file->read(file, 0, file->size, elf_data) < (s64)file->size) {
        kfree(elf_data);
        vfs_node_close(file);
        for (u64 a = 0; a < argc; a++) kfree(argv_strings[a]);
        return ESYS_IO;
    }

    AddressSpace *new_as = create_user_address_space();
    if (!new_as) {
        kfree(elf_data);
        vfs_node_close(file);
        for (u64 a = 0; a < argc; a++) kfree(argv_strings[a]);
        return ESYS_NOMEM;
    }

    elf_load_result_t result;
    if (elf_load(new_as, elf_data, file->size, &result) != 0) {
        kprintf("[EXEC] ELF load failed: %s\n", kpath);
        vmm_destroy_address_space(new_as);
        kfree(new_as);
        kfree(elf_data);
        vfs_node_close(file);
        for (u64 a = 0; a < argc; a++) kfree(argv_strings[a]);
        return ESYS_NOEXEC;
    }
    kfree(elf_data);
    vfs_node_close(file);

    /* Set up user stack (USER_STACK_PAGES pages).  Map up to and including
     * stack_top so that compiler-allocated locals at RSP+positive-offset
     * remain accessible even when RSP is near the end of the mapped area. */
    virt_addr_t stack_top = 0x7FFFFFFF0000ULL;
    virt_addr_t stack_base = ALIGN_DOWN(stack_top - USER_STACK_PAGES * PAGE_SIZE, PAGE_SIZE);

    for (virt_addr_t v = stack_base; v <= stack_top; v += PAGE_SIZE) {
        phys_addr_t upage = pmm_alloc_page();
        if (!upage) {
            vmm_destroy_address_space(new_as);
            kfree(new_as);
            for (u64 a = 0; a < argc; a++) kfree(argv_strings[a]);
            return ESYS_NOMEM;
        }
        u64 uflags = PTE_PRESENT | PTE_WRITABLE | PTE_USER;
        vmm_map_page(new_as, v, upage, uflags);
        memset((void *)PHYS_TO_VIRT(upage), 0, PAGE_SIZE);
    }

    /* Compute argv stack layout (SysV AMD64 ABI) */
    u64 str_total = 0;
    for (u64 i = 0; i < argc; i++)
        str_total += argv_strlens[i];

    u64 argv_slots = (argc + 1) * 8;
    u64 total = 8 + argv_slots + str_total;
    u64 stack_ptr = stack_top - total;
    stack_ptr &= ~15ULL;
    stack_ptr -= 8;  /* x86-64 ABI: RSP must be 8 mod 16 at function entry (simulates CALL) */

    /* Build the argv frame in a kernel buffer first, then publish it with
     * copy_to_user (which handles SMAP via STAC/CLAC).  Writing the user
     * stack directly here would fault because SMAP blocks supervisor-mode
     * access to user pages while the AC flag is clear. */
    u8 *karg = kmalloc(total);
    if (!karg) {
        vmm_destroy_address_space(new_as);
        kfree(new_as);
        for (u64 a = 0; a < argc; a++) kfree(argv_strings[a]);
        return ESYS_NOMEM;
    }

    u8 *ksp = karg;
    *(u64 *)ksp = argc;
    ksp += 8;
    u64 *argv_slot = (u64 *)ksp;
    ksp += argv_slots;
    for (u64 i = 0; i < argc; i++) {
        argv_slot[i] = stack_ptr + (u64)(uintptr_t)(ksp - karg);
        for (u64 j = 0; j < argv_strlens[i]; j++)
            *ksp++ = argv_strings[i][j];
    }
    argv_slot[argc] = 0;

    /* Destroy old user address space before switching */
    if (current_task->address_space &&
        current_task->address_space != &kernel_space) {
        vmm_destroy_address_space(current_task->address_space);
        kfree(current_task->address_space);
    }

    /* Switch to new address space and publish the argv frame */
    current_task->address_space = new_as;
    vmm_switch_address_space(new_as);

    if (copy_to_user((void *)(uintptr_t)stack_ptr, karg, total) != 0) {
        kfree(karg);
        return ESYS_FAULT;
    }
    kfree(karg);

    /* Now we are in the new address space. Frame is in kernel mapping so still valid. */
    current_task->address_space = new_as;
    current_task->brk_base = result.brk;
    current_task->brk_current = result.brk;
    current_task->user_stack = stack_top;

    frame->rcx = result.entry_point;             /* RIP */
    frame->rdi = argc;                            /* RDI = argc */
    frame->rsi = (u64)(stack_ptr + 8);            /* RSI = &argv[0] */
    this_cpu()->user_rsp = stack_ptr;

    return 0;
}

/*
 * SYS_READFILE (8)
 * ssize_t readfile(const char *path, void *buf, size_t n)
 * RDI=path, RSI=buf, RDX=n
 *
 * Opens the file at `path` via VFS, reads up to `n` bytes into `buf`.
 * Returns bytes read, or negative errno.
 */
static s64 sys_readfile(SyscallFrame *frame)
{
    const char *user_path = (const char *)(uintptr_t)frame->rdi;
    char *user_buf = (char *)(uintptr_t)frame->rsi;
    u64   n = frame->rdx;

    if (!user_path || !user_buf)
        return ESYS_FAULT;
    if (n == 0)
        return 0;

    /* Copy path from userspace */
    char kpath[256];
    {
        u64 i;
        for (i = 0; i < sizeof(kpath) - 1; i++) {
            char c;
            if (copy_from_user(&c, &user_path[i], 1) != 0)
                return ESYS_FAULT;
            kpath[i] = c;
            if (c == '\0') break;
        }
        kpath[sizeof(kpath) - 1] = '\0';
    }

    vfs_node_t *file = vfs_open(kpath);
    if (!file)
        return ESYS_NOENT;

    /* Read file into kernel buffer */
    u64 bufsize = file->size;
    if (bufsize > n) bufsize = n;
    if (bufsize == 0) { return 0; }

    u8 *kbuf = kmalloc(bufsize);
    if (!kbuf) { return ESYS_NOMEM; }

    if (file->read(file, 0, bufsize, kbuf) < 0) {
        kfree(kbuf);
        return ESYS_IO;
    }

    /* Copy to userspace */
    if (copy_to_user(user_buf, kbuf, bufsize) != 0) {
        kfree(kbuf);
        return ESYS_FAULT;
    }

    kfree(kbuf);
    return (s64)bufsize;
}

/*
 * SYS_LISTDIR (9)
 * ssize_t listdir(const char *path, void *buf, size_t n)
 * RDI=path, RSI=buf, RDX=n
 *
 * Lists directory entries at `path`. Each entry is written as
 * "name\n" into `buf`. Returns bytes written, or negative errno.
 */
static s64 sys_listdir(SyscallFrame *frame)
{
    const char *user_path = (const char *)(uintptr_t)frame->rdi;
    char *user_buf = (char *)(uintptr_t)frame->rsi;
    u64   n = frame->rdx;

    if (!user_path || !user_buf)
        return ESYS_FAULT;
    if (n == 0)
        return 0;

    /* Copy path from userspace */
    char kpath[256];
    {
        u64 i;
        for (i = 0; i < sizeof(kpath) - 1; i++) {
            char c;
            if (copy_from_user(&c, &user_path[i], 1) != 0)
                return ESYS_FAULT;
            kpath[i] = c;
            if (c == '\0') break;
        }
        kpath[sizeof(kpath) - 1] = '\0';
    }

    vfs_node_t *dir = vfs_open(kpath);
    if (!dir)
        return ESYS_NOENT;
    if (dir->type != VFS_DIRECTORY)
        return ESYS_INVAL;

    /* Build listing in kernel buffer (max 16 KB) */
    u8 *kbuf = kmalloc(16384);
    if (!kbuf) return ESYS_NOMEM;

    u64 written = 0;
    u64 idx = 0;
    vfs_dirent_t ent;

    while (written < 16384 && vfs_readdir(dir, idx, &ent) == 0) {
        u64 remain = 16384 - written;
        u64 slen = 0;
        while (ent.name[slen] && slen < 255) slen++;

        /* "name\n" = slen + 1 bytes */
        if (slen + 1 > remain - 1) break;  /* no room, stop */

        memcpy(kbuf + written, ent.name, slen);
        written += slen;
        kbuf[written++] = '\n';
        idx++;
    }

    u64 to_copy = written;
    if (to_copy > n) to_copy = n;

    s64 ret = (s64)to_copy;
    if (copy_to_user(user_buf, kbuf, to_copy) != 0)
        ret = ESYS_FAULT;

    kfree(kbuf);
    return ret;
}

/*
 * SYS_OPEN (10)
 * int open(const char *path, int flags)
 * RDI=path  RSI=flags  (flags = 0 for read-only)
 *
 * Opens a file via VFS and returns a new file descriptor.
 * Returns fd, or negative errno.
 */
static s64 sys_open(SyscallFrame *frame)
{
    const char *user_path = (const char *)(uintptr_t)frame->rdi;
    int         flags     = (int)(s32)frame->rsi;

    (void)flags; /* currently ignored (read-only) */

    if (!user_path)
        return ESYS_FAULT;

    char kpath[256];
    if (copy_user_string(frame->rdi, kpath, sizeof(kpath)) != 0)
        return ESYS_FAULT;

    vfs_node_t *node = vfs_open(kpath);
    if (!node)
        return ESYS_NOENT;

    int fd = fd_allocate();
    if (fd < 0) {
        vfs_node_close(node);
        return ESYS_NOMEM;
    }

    current_task->fd_table[fd].used  = 1;
    current_task->fd_table[fd].node  = node;
    current_task->fd_table[fd].type  = FD_TYPE_FILE;
    current_task->fd_table[fd].offset = 0;

    kprintf("[OPEN] fd=%d '%s' size=%llu\n", fd, kpath,
            (unsigned long long)node->size);

    return (s64)fd;
}

/*
 * SYS_CLOSE (11)
 * int close(int fd)
 * RDI=fd
 *
 * Closes a file descriptor and frees the underlying VFS node.
 * Returns 0 on success, or negative errno.
 */
static s64 sys_close(SyscallFrame *frame)
{
    int fd = (int)(s32)frame->rdi;

    if (fd < 0 || fd >= MAX_FDS || !current_task->fd_table[fd].used)
        return ESYS_BADF;

    /* stdin/stdout/stderr cannot be closed */
    if (fd <= 2)
        return ESYS_BADF;

    file_t *f = &current_task->fd_table[fd];

    /* Pipe cleanup */
    if (f->type == FD_TYPE_PIPE && f->pipe) {
        pipe_t *p = f->pipe;
        if (f->pipe_is_write == 1) p->writers--;
        p->refcount--;
        if (p->refcount <= 0) {
            p->closed = 1;
            kfree(p);
        }
    }

    if (f->node) {
        vfs_node_close(f->node);
    }
    f->used   = 0;
    f->node   = NULL;
    f->pipe   = NULL;
    f->offset = 0;
    f->type   = 0;

    kprintf("[CLOSE] fd=%d\n", fd);
    return ESYS_OK;
}

/*
 * SYS_WAITPID (14)
 * pid_t waitpid(int pid, int *status)
 * RDI=pid  RSI=status_ptr  (pid = -1 means any child)
 *
 * Blocks until a child exits. Collects the child's exit status and
 * returns the child PID.  Returns negative errno on error.
 */
static s64 sys_waitpid(SyscallFrame *frame)
{
    int target_pid = (int)(s32)frame->rdi;
    int *status_ptr = (int *)(uintptr_t)frame->rsi;

    if (target_pid < -1 || target_pid == 0)
        return ESYS_INVAL;

    kprintf("[WAITPID] PID %u entering waitpid(target_pid=%d, status_ptr=%p)\n",
            scheduler_current_pid(), target_pid, (void *)status_ptr);

    for (;;) {
        Task *zombie = NULL;
        int ret = scheduler_waitpid_prepare(target_pid, &zombie);

        if (ret == 1) {
            int status = zombie->exit_status;
            u32 child_pid = zombie->pid;

            kprintf("[WAITPID] PID %u collected child PID %u (status=%d)\n",
                    scheduler_current_pid(), child_pid, status);

            task_destroy(zombie);

            if (status_ptr) {
                if (copy_to_user(status_ptr, &status, sizeof(int)) != 0) {
                    kprintf("[WAITPID] PID %u: copy_to_user failed\n",
                            scheduler_current_pid());
                    return ESYS_FAULT;
                }
            }
            return (s64)child_pid;
        }

        if (ret == -1) {
            kprintf("[WAITPID] PID %u: child PID %d not found, returning ESYS_NOENT\n",
                    scheduler_current_pid(), target_pid);
            return ESYS_NOENT;
        }

        /* ret == 0: child exists but not zombie yet — block and retry.
         * scheduler_waitpid_prepare set us TASK_BLOCKED under scheduler_lock,
         * so scheduler_exit_current will wake us when the child exits. */
        kprintf("[WAITPID] PID %u: child PID %d alive, blocking...\n",
                scheduler_current_pid(), target_pid);
        scheduler_yield();
    }
}

/*
 * Userspace-visible directory entry (must match vfs_dirent_t layout).
 */
typedef struct {
    char name[256];
    u32  inode;
    u32  size;
    u8   attributes;
} ftk_dirent_t;

/*
 * SYS_GETDENTS (15)
 * int getdents(int fd, struct ftk_dirent *buf, int count)
 * RDI=fd  RSI=buf  RDX=count (max entries to read)
 *
 * Reads directory entries from an open directory fd.
 * Returns number of entries read, 0 at end, or negative errno.
 */
static s64 sys_getdents(SyscallFrame *frame)
{
    int fd = (int)(s32)frame->rdi;
    ftk_dirent_t *user_buf = (ftk_dirent_t *)(uintptr_t)frame->rsi;
    u64 count = frame->rdx;

    if (fd < 0 || fd >= MAX_FDS || !current_task->fd_table[fd].used)
        return ESYS_BADF;
    if (!user_buf)
        return ESYS_FAULT;
    if (count == 0)
        return 0;

    file_t *f = &current_task->fd_table[fd];
    if (!f->node || f->node->type != VFS_DIRECTORY)
        return ESYS_INVAL;
    if (!f->node->readdir)
        return ESYS_NOSYS;

    u64 idx = f->offset;
    u64 written = 0;
    ftk_dirent_t kent;

    while (written < count) {
        memset(&kent, 0, sizeof(kent));

        vfs_dirent_t vent;
        if (f->node->readdir(f->node, idx, &vent) != 0)
            break;

        /* Copy fields to userspace-visible struct */
        kent.inode = vent.inode;
        kent.size = vent.size;
        kent.attributes = vent.attributes;
        {
            int ni = 0;
            while (vent.name[ni] && ni < 255) {
                kent.name[ni] = vent.name[ni];
                ni++;
            }
            kent.name[ni] = '\0';
        }

        if (copy_to_user(&user_buf[written], &kent, sizeof(kent)) != 0)
            return ESYS_FAULT;

        written++;
        idx++;
    }

    f->offset = idx;
    return (s64)written;
}

/*
 * SYS_SPAWN (12)
 * int spawn(const char *path, char *const argv[])
 * RDI=path  RSI=argv (array of pointers in user space, NULL-terminated)
 *
 * Loads an ELF executable from `path`, sets up a new address space and
 * user stack with argv, and creates a new user task.  Returns the child PID.
 */
static s64 sys_spawn(SyscallFrame *frame)
{
    const char *user_path = (const char *)(uintptr_t)frame->rdi;
    u64         user_argv = frame->rsi;

    if (!user_path)
        return ESYS_FAULT;

    /* Copy path */
    char kpath[256];
    if (copy_user_string(frame->rdi, kpath, sizeof(kpath)) != 0)
        return ESYS_FAULT;

    kprintf("[SPAWN] Loading '%s'\n", kpath);

    /* Open file via VFS */
    vfs_node_t *file = vfs_open(kpath);
    if (!file) {
        kprintf("[SPAWN] File not found: %s\n", kpath);
        return ESYS_NOENT;
    }

    /* Read ELF into kernel buffer */
    void *elf_data = kmalloc(file->size);
    if (!elf_data) {
        vfs_node_close(file);
        return ESYS_NOMEM;
    }

    if (file->read(file, 0, file->size, elf_data) < (s64)file->size) {
        kprintf("[SPAWN] Read failed: %s\n", kpath);
        kfree(elf_data);
        vfs_node_close(file);
        return ESYS_IO;
    }

    /* Create new address space */
    AddressSpace *new_as = create_user_address_space();
    if (!new_as) {
        kfree(elf_data);
        vfs_node_close(file);
        return ESYS_NOMEM;
    }

    /* Load ELF */
    elf_load_result_t result;
    if (elf_load(new_as, elf_data, file->size, &result) != 0) {
        kprintf("[SPAWN] ELF load failed: %s\n", kpath);
        vmm_destroy_address_space(new_as);
        kfree(new_as);
        kfree(elf_data);
        vfs_node_close(file);
        return ESYS_NOEXEC;
    }
    kfree(elf_data);
    vfs_node_close(file);

    kprintf("[SPAWN] ELF loaded: entry=%p, brk=%p\n",
            (void *)result.entry_point, (void *)result.brk);

    /* Copy argv from PARENT's address space into kernel buffers first */
    u64 argc = 0;
    char *argv_strings[64];
    u64   argv_strlens[64];

    memset(argv_strings, 0, sizeof(argv_strings));
    memset(argv_strlens, 0, sizeof(argv_strlens));

    if (user_argv != 0) {
        /* Read argv pointers from parent's user space */
        while (argc < 64) {
            u64 ptr;
            if (copy_from_user(&ptr,
                    (const void *)(uintptr_t)(user_argv + argc * 8), 8) != 0)
                break;
            if (ptr == 0)
                break;

            /* Copy string from parent's user space */
            char tmp[256];
            u64 slen = 0;
            for (; slen < 255; slen++) {
                char c;
                if (copy_from_user(&c, (const void *)(uintptr_t)(ptr + slen), 1) != 0)
                    break;
                tmp[slen] = c;
                if (c == '\0') {
                    slen++;
                    break;
                }
            }

            argv_strings[argc] = kmalloc(slen + 1);
            if (!argv_strings[argc])
                break;
            memcpy(argv_strings[argc], tmp, slen);
            argv_strings[argc][slen] = '\0';
            argv_strlens[argc] = slen;
            argc++;
        }
    }

    /* Compute argv stack layout */
    u64 str_total = 0;
    for (u64 i = 0; i < argc; i++)
        str_total += argv_strlens[i];

    u64 argv_slots = (argc + 1) * 8;
    u64 total = 8 + argv_slots + str_total;
    u64 stack_top  = 0x7FFFFFFF0000ULL;
    u64 stack_ptr  = stack_top - total;
    stack_ptr &= ~15ULL;
    stack_ptr -= 8;  /* x86-64 ABI: RSP must be 8 mod 16 at function entry (simulates CALL) */

    /* Build the argv frame in a kernel buffer first; it is published to
     * the child's user stack below via copy_to_user (STAC/CLAC) so SMAP
     * does not fault on a direct supervisor write. */
    u8 *karg = kmalloc(total);
    if (!karg) {
        for (u64 a = 0; a < argc; a++)
            kfree(argv_strings[a]);
        vmm_destroy_address_space(new_as);
        kfree(new_as);
        return ESYS_NOMEM;
    }

    {
        u8 *ksp = karg;
        *(u64 *)ksp = argc;
        ksp += 8;
        u64 *argv_slot = (u64 *)ksp;
        ksp += argv_slots;
        for (u64 i = 0; i < argc; i++) {
            argv_slot[i] = stack_ptr + (u64)(uintptr_t)(ksp - karg);
            for (u64 j = 0; j < argv_strlens[i]; j++)
                *ksp++ = argv_strings[i][j];
        }
        argv_slot[argc] = 0;
    }

    /* Extract a short name from path */
    char task_name[32];
    {
        int last_slash = 0;
        for (int j = 0; kpath[j]; j++) {
            if (kpath[j] == '/')
                last_slash = j + 1;
        }
        int ni = 0;
        while (kpath[last_slash] && ni < 31)
            task_name[ni++] = kpath[last_slash++];
        task_name[ni] = '\0';
    }

    /* Create the user task FIRST — this allocates and maps the user
     * stack pages (4 pages at user_stack_base..stack_top) and builds
     * the initial iretq frame on the kernel stack. */
    Task *child = create_user_task(task_name, NULL, new_as,
                                   result.entry_point, stack_top);
    if (!child) {
        for (u64 a = 0; a < argc; a++)
            kfree(argv_strings[a]);
        vmm_destroy_address_space(new_as);
        kfree(new_as);
        return ESYS_NOMEM;
    }

    /* Disable preemption until the child's iretq frame override below
     * is complete.  create_user_task already inserted the child into the
     * run queue; without this guard the scheduler could pick the child
     * before RSP/RSI/RDI are set, causing a crash. */
    preempt_disable();

    /* Publish the argv frame onto the child's user stack.
     * Layout (conforming to SysV AMD64 ABI):
     *
     *   [stack_ptr]          = argc
     *   [stack_ptr + 8]      = argv[0]
     *   ...
     *   [stack_ptr + 8*argc] = argv[argc-1]
     *   [stack_ptr + 8*(argc+1)] = NULL
     *   [higher addresses]   = string data
     *
     * RDI gets argc, RSI gets &argv[0] (stack_ptr + 8).
     *
     * The frame is written with copy_to_user (STAC/CLAC) while pointed at
     * the child's address space; a direct supervisor write to the child's
     * user stack would fault because SMAP is enabled.
     */
    {
        AddressSpace *old_as = current_task->address_space;
        current_task->address_space = new_as;
        vmm_switch_address_space(new_as);

        s64 rc = copy_to_user((void *)(uintptr_t)stack_ptr, karg, total);

        vmm_switch_address_space(old_as);
        current_task->address_space = old_as;
        kfree(karg);

        if (rc != 0) {
            preempt_enable();
            for (u64 a = 0; a < argc; a++)
                kfree(argv_strings[a]);
            return ESYS_FAULT;
        }
    }

    /* Clean up argv copies */
    for (u64 i = 0; i < argc; i++)
        kfree(argv_strings[i]);

    /* Fix up iretq frame in child's kernel stack.
     * create_user_task built a default frame; override with our values.
     * Layout from task->context.rsp:
     *   [0] R15 (coop), [1] R14, [2] R13, [3] R12,
     *   [4] RBP, [5] RBX, [6] RFLAGS (coop),
     *   [7] ret_addr,
     *   [8] R15 (iretq), [9] R14, [10] R13, [11] R12,
     *   [12] R11, [13] R10, [14] R9, [15] R8,
     *   [16] RSI, [17] RDI,
     *   [18] RBP, [19] RDX, [20] RCX, [21] RBX, [22] RAX,
     *   [23] int_no, [24] err_code,
     *   [25] RIP, [26] CS, [27] RFLAGS, [28] RSP, [29] SS
     */
    {
        u64 *sp = (u64 *)child->context.rsp;
        sp[17] = argc;                   /* RDI = argc */
        sp[16] = (u64)(stack_ptr + 8);   /* RSI = &argv[0] */
        sp[28] = stack_ptr;              /* RSP = stack_ptr */
    }

    child->brk_base     = result.brk;
    child->brk_current  = result.brk;

    preempt_enable();

    kprintf("[SPAWN] PID %u spawned child PID %u ('%s', path='%s', entry=%p)\n",
            scheduler_current_pid(), child->pid, task_name, kpath,
            (void *)result.entry_point);

    return (s64)child->pid;
}

/* ── SYS_DUP2 (17) ─────────────────────────────────────────── */
static s64 sys_dup2(SyscallFrame *frame)
{
    int oldfd = (int)(s32)frame->rdi;
    int newfd = (int)(s32)frame->rsi;

    if (oldfd < 0 || oldfd >= MAX_FDS || !current_task->fd_table[oldfd].used)
        return ESYS_BADF;
    if (newfd < 0 || newfd >= MAX_FDS)
        return ESYS_INVAL;
    if (oldfd == newfd)
        return (s64)newfd;

    if (current_task->fd_table[newfd].used) {
        file_t *f = &current_task->fd_table[newfd];
        if (f->type == FD_TYPE_PIPE && f->pipe) {
            if (f->pipe_is_write == 1) f->pipe->writers--;
            f->pipe->refcount--;
            if (f->pipe->refcount <= 0) {
                f->pipe->closed = 1;
                kfree(f->pipe);
            }
        }
        if (f->node) vfs_node_close(f->node);
    }

    current_task->fd_table[newfd] = current_task->fd_table[oldfd];
    if (current_task->fd_table[newfd].pipe) {
        current_task->fd_table[newfd].pipe->refcount++;
        if (current_task->fd_table[newfd].pipe_is_write == 1)
            current_task->fd_table[newfd].pipe->writers++;
    }

    kprintf("[DUP2] PID %u: fd %d -> %d (type=%d)\n",
            scheduler_current_pid(), oldfd, newfd,
            current_task->fd_table[newfd].type);
    return (s64)newfd;
}

/* ── SYS_KILL (19) ──────────────────────────────────────────── */
static s64 sys_kill(SyscallFrame *frame)
{
    int pid = (int)(s32)frame->rdi;

    u64 rflags;
    spinlock_acquire_irqsave(&scheduler_lock, &rflags);

    Task *found = NULL;
    Task *t = task_list;
    if (t) {
        do {
            if ((int)t->pid == pid) {
                found = t;
                break;
            }
            t = t->next;
        } while (t != task_list);
    }

    if (!found) {
        spinlock_release_irqrestore(&scheduler_lock, rflags);
        return ESYS_SRCH;
    }

    found->killed = 1;
    if (found->state == TASK_BLOCKED)
        found->state = TASK_READY;
    spinlock_release_irqrestore(&scheduler_lock, rflags);

    kprintf("[KILL] PID %u: sent kill to PID %d (%s)\n",
            scheduler_current_pid(), pid, found->name);
    return 0;
}

/* ── SYS_PS (13) ──────────────────────────────────────────── */

static s64 sys_ps(SyscallFrame *frame)
{
    int pid = (int)(s32)frame->rdi;
    ps_info_t *user_buf = (ps_info_t *)(uintptr_t)frame->rsi;
    u64 count = frame->rdx;

    if (!user_buf) return ESYS_FAULT;
    if (count == 0) return 0;

    u64 rflags;
    spinlock_acquire_irqsave(&scheduler_lock, &rflags);

    ps_info_t kbuf[32];
    u64 written = 0;

    if (pid == -1) {
        Task *t = task_list;
        if (t) {
            do {
                if (written >= count || written >= 32) break;
                kbuf[written].pid = (int)t->pid;
                switch (t->state) {
                    case TASK_RUNNING: kbuf[written].state = PS_STATE_RUNNING; break;
                    case TASK_READY:   kbuf[written].state = PS_STATE_READY;   break;
                    case TASK_BLOCKED: kbuf[written].state = PS_STATE_BLOCKED; break;
                    case TASK_ZOMBIE:  kbuf[written].state = PS_STATE_ZOMBIE;  break;
                    default:           kbuf[written].state = PS_STATE_READY;   break;
                }
                int ni = 0;
                while (t->name[ni] && ni < PS_NAME_MAX - 1) {
                    kbuf[written].name[ni] = t->name[ni];
                    ni++;
                }
                kbuf[written].name[ni] = '\0';
                written++;
                t = t->next;
            } while (t != task_list);
        }
    } else {
        Task *t = task_list;
        if (t) {
            do {
                if ((int)t->pid == pid) {
                    kbuf[0].pid = (int)t->pid;
                    switch (t->state) {
                        case TASK_RUNNING: kbuf[0].state = PS_STATE_RUNNING; break;
                        case TASK_READY:   kbuf[0].state = PS_STATE_READY;   break;
                        case TASK_BLOCKED: kbuf[0].state = PS_STATE_BLOCKED; break;
                        case TASK_ZOMBIE:  kbuf[0].state = PS_STATE_ZOMBIE;  break;
                        default:           kbuf[0].state = PS_STATE_READY;   break;
                    }
                    int ni = 0;
                    while (t->name[ni] && ni < PS_NAME_MAX - 1) {
                        kbuf[0].name[ni] = t->name[ni];
                        ni++;
                    }
                    kbuf[0].name[ni] = '\0';
                    written = 1;
                    break;
                }
                t = t->next;
            } while (t != task_list);
        }
    }

    spinlock_release_irqrestore(&scheduler_lock, rflags);

    if (copy_to_user(user_buf, kbuf, written * sizeof(ps_info_t)) != 0)
        return ESYS_FAULT;

    return (s64)written;
}

/* ── SYS_PIPE (16) ─────────────────────────────────────────── */

static s64 sys_pipe(SyscallFrame *frame)
{
    int *user_pipefd = (int *)(uintptr_t)frame->rdi;
    if (!user_pipefd) return ESYS_FAULT;

    pipe_t *p = kmalloc(sizeof(pipe_t));
    if (!p) return ESYS_NOMEM;
    memset(p, 0, sizeof(pipe_t));
    p->refcount = 2;   /* read fd + write fd */
    p->writers  = 1;   /* pipefd[1] is a writer */

    int rdfd = -1, wrfd = -1;
    for (int i = 0; i < MAX_FDS; i++) {
        if (!current_task->fd_table[i].used) {
            if (rdfd < 0)
                rdfd = i;
            else if (wrfd < 0) {
                wrfd = i;
                break;
            }
        }
    }
    if (wrfd < 0) {
        kfree(p);
        return ESYS_NOMEM;
    }

    current_task->fd_table[rdfd].used  = 1;
    current_task->fd_table[rdfd].type  = FD_TYPE_PIPE;
    current_task->fd_table[rdfd].node  = NULL;
    current_task->fd_table[rdfd].pipe  = p;
    current_task->fd_table[rdfd].offset = 0;
    current_task->fd_table[rdfd].pipe_is_write = 0;

    current_task->fd_table[wrfd].used  = 1;
    current_task->fd_table[wrfd].type  = FD_TYPE_PIPE;
    current_task->fd_table[wrfd].node  = NULL;
    current_task->fd_table[wrfd].pipe  = p;
    current_task->fd_table[wrfd].offset = 0;
    current_task->fd_table[wrfd].pipe_is_write = 1;

    int fds[2] = { rdfd, wrfd };
    if (copy_to_user(user_pipefd, fds, sizeof(fds)) != 0) {
        current_task->fd_table[rdfd].used = 0;
        current_task->fd_table[wrfd].used = 0;
        kfree(p);
        return ESYS_FAULT;
    }

    return ESYS_OK;
}
/* ═══════════════════════════════════════════════════════════
 * GUI / Graphics Syscall Implementations
 * ═══════════════════════════════════════════════════════════
 *
 * Panic-prevention rules applied throughout:
 *  - Every user pointer validated via copy_to/from_user before dereference
 *  - vmm_map_page failures are tolerated (page already mapped = success)
 *  - All paths return a defined errno; no path reaches undefined behaviour
 *  - ftk_fb_base is the GOP physical address (identity-mapped in kernel)
 *  - current_task->address_space used directly — no fake AddressSpace on stack
 */

/* ── SYS_FB_INFO (20) ───────────────────────────────────────
 * Fills caller's ftk_fb_info_t with framebuffer geometry.
 */
static s64 sys_fb_info(SyscallFrame *frame)
{
    ftk_fb_info_t *user_out = (ftk_fb_info_t *)(uintptr_t)frame->rdi;
    if (!user_out)           return ESYS_FAULT;
    if (!ftk_fb_base || ftk_fb_width == 0) return ESYS_INVAL;

    ftk_fb_info_t info;
    info.width     = ftk_fb_width;
    info.height    = ftk_fb_height;
    info.pitch     = ftk_fb_pitch;
    info.bpp       = 32;
    info.phys_base = (unsigned long)(uintptr_t)ftk_fb_base;

    if (copy_to_user(user_out, &info, sizeof(info)) != 0)
        return ESYS_FAULT;
    return ESYS_OK;
}

/* ── SYS_FB_MAP (21) ────────────────────────────────────────
 * Maps the linear framebuffer into the calling process's VA space.
 * Fixed user VA: 0x00007F0000000000
 * Idempotent: calling it twice on the same process is safe.
 */
#define FB_USER_VA 0x00007F0000000000ULL

static s64 sys_fb_map(SyscallFrame *frame)
{
    (void)frame;
    if (!ftk_fb_base || ftk_fb_width == 0) return ESYS_INVAL;

    if (!current_task || !current_task->is_user) return ESYS_PERM;
    AddressSpace *as = current_task->address_space;
    if (!as) return ESYS_PERM;

    /* ftk_fb_base holds the GOP physical address (identity-mapped) */
    phys_addr_t phys_base = (phys_addr_t)(uintptr_t)ftk_fb_base;

    u64 fb_bytes  = (u64)ftk_fb_height * ftk_fb_pitch;
    u64 fb_pages  = (fb_bytes + 4095ULL) >> 12;

    for (u64 i = 0; i < fb_pages; i++) {
        virt_addr_t uva  = FB_USER_VA  + i * 4096;
        phys_addr_t phys = phys_base   + i * 4096;

        int r = vmm_map_page(as, uva, phys,
                             PTE_PRESENT | PTE_WRITABLE | PTE_USER);
        /* -1 means "already present" — idempotent, not an error */
        if (r != 0) {
            /* Verify the page is actually mapped (could be a real error) */
            u64 flags = 0;
            if (vmm_get_flags(as, uva, &flags, NULL) != 0) {
                kprintf("[SYS_FB_MAP] map failed page %llu phys=%p\n",
                        i, (void*)phys);
                return ESYS_NOMEM;
            }
            /* Already mapped — acceptable */
        }
    }

    return (s64)(uintptr_t)FB_USER_VA;
}

/* ── SYS_FB_FLUSH (22) ──────────────────────────────────────
 * Forward-compat stub (unified FB, no double buffer in v0.1).
 */
static s64 sys_fb_flush(SyscallFrame *frame)
{
    (void)frame;
    return ESYS_OK;
}

/* ── SYS_GETTICKS (23) ──────────────────────────────────────
 * 100 Hz PIT tick counter since boot.
 */
static s64 sys_getticks(SyscallFrame *frame)
{
    (void)frame;
    return (s64)(u64)ftk_ticks;
}

/* ── SYS_GETKEY (24) ────────────────────────────────────────
 * Non-blocking: dequeues one key event from the driver ring.
 * Returns 1 if event written to *user_ev, 0 if queue empty.
 */
static s64 sys_getkey(SyscallFrame *frame)
{
    ftk_key_event_t *user_ev = (ftk_key_event_t *)(uintptr_t)frame->rdi;
    if (!user_ev) return ESYS_FAULT;

    ftk_key_event_t ev;
    int got = keyboard_poll_event(&ev);
    if (!got) return 0;

    if (copy_to_user(user_ev, &ev, sizeof(ev)) != 0)
        return ESYS_FAULT;
    return 1;
}

/* ── SYS_MMAP (25) ──────────────────────────────────────────
 * Anonymous page allocation. Extends brk upward, zero-fills pages.
 * RDI=hint(ignored), RSI=len
 * Returns mapped user virtual address on success, negative errno on failure.
 */
static s64 sys_mmap(SyscallFrame *frame)
{
    u64 len = frame->rsi;
    if (len == 0) return ESYS_INVAL;
    if (!current_task || !current_task->is_user) return ESYS_PERM;

    AddressSpace *as = current_task->address_space;
    if (!as) return ESYS_PERM;

    u64 pages = (len + 4095ULL) >> 12;

    /* Align brk_current to page boundary */
    virt_addr_t va = (current_task->brk_current + 4095ULL) & ~4095ULL;

    for (u64 i = 0; i < pages; i++) {
        phys_addr_t pa = pmm_alloc_page();
        if (!pa) {
            /* Best-effort: pages already mapped remain; report OOM */
            return ESYS_NOMEM;
        }
        /* Zero the page through HHDM */
        void *kva = (void *)(uintptr_t)(pa + KERNEL_VIRT_BASE);
        memset(kva, 0, 4096);

        int r = vmm_map_page(as, va + i * 4096, pa,
                             PTE_PRESENT | PTE_WRITABLE | PTE_USER);
        if (r != 0) {
            /* Page already mapped at this VA — skip, keep pa mapped there */
            pmm_free_page(pa);
        }
    }

    current_task->brk_current = va + pages * 4096;
    return (s64)(uintptr_t)va;
}

/* ── SYS_MUNMAP (26) ────────────────────────────────────────
 * Unmaps [addr, addr+len) from the calling process.
 * Uses vmm_unmap_and_free to reclaim physical pages.
 */
static s64 sys_munmap(SyscallFrame *frame)
{
    virt_addr_t addr = (virt_addr_t)frame->rdi;
    u64         len  = (u64)frame->rsi;

    if (len == 0) return ESYS_OK;
    if (!current_task || !current_task->address_space) return ESYS_PERM;
    if (addr < 0x1000 || addr >= 0x00008000000000ULL) return ESYS_INVAL;

    AddressSpace *as = current_task->address_space;
    u64 pages = (len + 4095ULL) >> 12;
    addr &= ~4095ULL;

    for (u64 i = 0; i < pages; i++) {
        /* vmm_unmap_and_free is a no-op if page isn't mapped */
        vmm_unmap_and_free(as, addr + i * 4096);
    }
    return ESYS_OK;
}

/* ── SYS_SETCURSOR (27) ─────────────────────────────────────
 * Software cursor position (informational; WM tracks it in user space).
 */
static volatile int gui_cursor_x = 400;
static volatile int gui_cursor_y = 300;

static s64 sys_setcursor(SyscallFrame *frame)
{
    gui_cursor_x = (int)(s32)frame->rdi;
    gui_cursor_y = (int)(s32)frame->rsi;
    return ESYS_OK;
}

/* ── SYS_GETTIME (28) ───────────────────────────────────────
 * Reads CMOS RTC. BCD→binary, 2-digit year → 2000+year.
 */
static s64 sys_gettime(SyscallFrame *frame)
{
    ftk_time_t *user_t = (ftk_time_t *)(uintptr_t)frame->rdi;
    if (!user_t) return ESYS_FAULT;

#define CMOS_ADDR 0x70
#define CMOS_DATA 0x71
#define CMOS_READ(reg) ({ outb(CMOS_ADDR,(u8)(reg)); inb(CMOS_DATA); })
#define BCD2BIN(x)     (((u8)(x) >> 4) * 10 + ((u8)(x) & 0xF))

    /* Wait for RTC update to be complete */
    int retries = 8;
    while (retries-- > 0) {
        outb(CMOS_ADDR, 0x0A);
        if (!(inb(CMOS_DATA) & 0x80)) break;
    }

    ftk_time_t t;
    t.second = BCD2BIN(CMOS_READ(0x00));
    t.minute = BCD2BIN(CMOS_READ(0x02));
    t.hour   = BCD2BIN(CMOS_READ(0x04));
    t.day    = BCD2BIN(CMOS_READ(0x07));
    t.month  = BCD2BIN(CMOS_READ(0x08));
    t.year   = 2000 + BCD2BIN(CMOS_READ(0x09));

    /* Sanity clamp — corrupt RTC shouldn't reach user */
    if (t.month  < 1  || t.month  > 12) t.month  = 1;
    if (t.day    < 1  || t.day    > 31) t.day    = 1;
    if (t.hour   > 23)                  t.hour   = 0;
    if (t.minute > 59)                  t.minute = 0;
    if (t.second > 59)                  t.second = 0;

    if (copy_to_user(user_t, &t, sizeof(t)) != 0)
        return ESYS_FAULT;
    return ESYS_OK;
}

/* ── SYS_POLL (29) ──────────────────────────────────────────
 * Non-blocking readability check for a single fd.
 * RDI = fd
 * Returns 1 if data is available to read without blocking,
 *         0 if fd would block,
 *         negative errno on error.
 */
static s64 sys_poll(SyscallFrame *frame)
{
    int fd = (int)(s32)frame->rdi;
    if (fd < 0 || fd >= MAX_FDS || !current_task->fd_table[fd].used)
        return ESYS_BADF;

    file_t *f = &current_task->fd_table[fd];

    if (f->type == FD_TYPE_PIPE) {
        pipe_t *p = f->pipe;
        if (!p) return ESYS_BADF;
        /* Readable if read position != write position, or if all writers closed */
        int avail = (p->read_pos != p->write_pos) || (p->writers == 0 && p->closed);
        return avail ? 1 : 0;
    }

    /* Console fd: check raw keyboard buffer */
    if (f->type == FD_TYPE_CONSOLE) {
        char c;
        return keyboard_try_getchar(&c) ? 1 : 0;
        /* Note: we peeked the char but didn't consume it — acceptable since
         * keyboard_try_getchar just checks; the actual read dequeues it. */
    }

    /* File fds: always report readable (seekable) */
    if (f->type == FD_TYPE_FILE)
        return 1;

    return 0;
}
