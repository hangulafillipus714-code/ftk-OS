#include <ftk/acpi.h>
#include <ftk/string.h>
#include <ftk/printk.h>
#include <ftk/memory_layout.h>
#include <ftk/smp.h>

/* Global ACPI data */
u32 lapic_phys_addr = 0xFEE00000;  /* Default Intel APIC base */
u32 ioapic_phys_addr = 0;
u8 lapic_ids[256] = {0};
u32 num_cpus = 0;

/* ISA IRQ -> GSI remapping from MADT Interrupt Source Overrides.
 * Defaults to identity (irq N -> GSI N); overrides fill in the real
 * wiring, e.g. on QEMU q35 the PIT is ISA IRQ 0 -> GSI 2. */
#define MAX_ISA_IRQS 16
static u8 irq_override_gsi[MAX_ISA_IRQS];

u8 acpi_get_gsi_for_irq(u8 isa_irq)
{
    if (isa_irq < MAX_ISA_IRQS)
        return irq_override_gsi[isa_irq];
    return isa_irq;
}

/*
 * ACPI tables live in the first 2 GB of physical memory (OVMF places RSDP
 * at ~0x7Fxxxxxx, and XSDT/RSDT entries point within that region).
 * paging_init identity-maps 0 – 0x80000000 (2 GB) so PHYS_TO_VIRT works
 * for all ACPI addresses.
 */
static inline void *acpi_map_phys(phys_addr_t phys, size_t size)
{
    if (!phys || !size) return NULL;
    return (void *)PHYS_TO_VIRT(phys);
}

/* Simple checksum validation */
static int acpi_verify_checksum(const void *table, size_t length) {
    const u8 *bytes = (const u8 *)table;
    u8 sum = 0;
    for (size_t i = 0; i < length; i++) {
        sum += bytes[i];
    }
    return sum == 0;
}

/* Search for RSDP in EBDA (0x400-0x40F) and BIOS ROM (0xE0000-0xFFFFF) */
/* Also search high memory region for UEFI/OVMF */
const RSDPDescriptor20_t *acpi_find_rsdp(void) {
    /* Search EBDA area */
    for (u64 addr = 0x400; addr <= 0x40F; addr += 16) {
        const RSDPDescriptor20_t *rsdp = (const RSDPDescriptor20_t *)(PHYS_TO_VIRT(addr));
        if (memcmp(rsdp->v1.signature, "RSD PTR ", 8) == 0) {
            if (acpi_verify_checksum(rsdp, sizeof(RSDPDescriptor_t))) {
                if (rsdp->v1.revision >= 2) {
                    if (acpi_verify_checksum(rsdp, rsdp->length)) {
                        return rsdp;
                    }
                } else {
                    return rsdp;
                }
            }
        }
    }

    /* Search BIOS ROM area (0xE0000 - 0xFFFFF) */
    for (u64 addr = 0xE0000; addr < 0x100000; addr += 16) {
        const RSDPDescriptor20_t *rsdp = (const RSDPDescriptor20_t *)(PHYS_TO_VIRT(addr));
        if (memcmp(rsdp->v1.signature, "RSD PTR ", 8) == 0) {
            if (acpi_verify_checksum(rsdp, sizeof(RSDPDescriptor_t))) {
                if (rsdp->v1.revision >= 2) {
                    if (acpi_verify_checksum(rsdp, rsdp->length)) {
                        return rsdp;
                    }
                } else {
                    return rsdp;
                }
            }
        }
    }

    /* Search broad UEFI/OVMF area: 0x100000 to 0x80000000 at page granularity */
    /* OVMF can place RSDP anywhere in this range (not just near 2GB) */
    for (u64 addr = 0x100000; addr < 0x80000000; addr += PAGE_SIZE) {
        /* Check first 32 bytes of each page at 16-byte alignment */
        for (u64 offset = 0; offset < 32; offset += 16) {
            const RSDPDescriptor20_t *rsdp = (const RSDPDescriptor20_t *)(PHYS_TO_VIRT(addr + offset));
            if (memcmp(rsdp->v1.signature, "RSD PTR ", 8) == 0) {
                if (acpi_verify_checksum(rsdp, sizeof(RSDPDescriptor_t))) {
                    if (rsdp->v1.revision >= 2) {
                        if (acpi_verify_checksum(rsdp, rsdp->length)) {
                            kprintf("[ACPI] RSDP found at phys 0x%llx via scan\n", (u64)(addr + offset));
                            return rsdp;
                        }
                    } else {
                        return rsdp;
                    }
                }
            }
        }
    }

    return NULL;
}

/* Find ACPI table by signature (e.g., "APIC", "FACP") */
ACPISDTHeader_t *acpi_find_table(const char *signature) {
    const RSDPDescriptor20_t *rsdp = acpi_find_rsdp();
    if (!rsdp) {
        kprintf("[ACPI] RSDP not found\n");
        return NULL;
    }



    if (rsdp->v1.revision >= 2 && rsdp->xsdt_address) {
        /* Use XSDT (64-bit addresses) */
        XSDT_t *xsdt = (XSDT_t *)acpi_map_phys(rsdp->xsdt_address, sizeof(XSDT_t));
        if (!xsdt) {
            kprintf("[ACPI] Failed to map XSDT\n");
            return NULL;
        }
        if (!acpi_verify_checksum(xsdt, xsdt->header.length)) {
            kprintf("[ACPI] XSDT checksum failed\n");
            return NULL;
        }
        if (!acpi_map_phys(rsdp->xsdt_address, xsdt->header.length)) {
            kprintf("[ACPI] Failed to map full XSDT\n");
            return NULL;
        }
        xsdt = (XSDT_t *)acpi_map_phys(rsdp->xsdt_address, xsdt->header.length);
        int entries = (xsdt->header.length - sizeof(ACPISDTHeader_t)) / 8;
        for (int i = 0; i < entries; i++) {
            ACPISDTHeader_t *table = (ACPISDTHeader_t *)acpi_map_phys(xsdt->entries[i], sizeof(ACPISDTHeader_t));
            if (!table) continue;
            if (memcmp(table->signature, signature, 4) == 0) {
                void *full = acpi_map_phys(xsdt->entries[i], table->length);
                if (full) table = full;
                kprintf("[ACPI] Found table %.4s at phys %llx\n", table->signature, (u64)xsdt->entries[i]);
                return table;
            }
        }
    } else if (rsdp->v1.rsdt_address) {
        /* Use RSDT (32-bit addresses) */
        RSDT_t *rsdt = (RSDT_t *)acpi_map_phys(rsdp->v1.rsdt_address, sizeof(RSDT_t));
        if (!rsdt) {
            kprintf("[ACPI] Failed to map RSDT\n");
            return NULL;
        }
        if (!acpi_verify_checksum(rsdt, rsdt->header.length)) {
            kprintf("[ACPI] RSDT checksum failed\n");
            return NULL;
        }
        if (!acpi_map_phys(rsdp->v1.rsdt_address, rsdt->header.length)) {
            kprintf("[ACPI] Failed to map full RSDT\n");
            return NULL;
        }
        rsdt = (RSDT_t *)acpi_map_phys(rsdp->v1.rsdt_address, rsdt->header.length);
        int entries = (rsdt->header.length - sizeof(ACPISDTHeader_t)) / 4;
        for (int i = 0; i < entries; i++) {
            ACPISDTHeader_t *table = (ACPISDTHeader_t *)acpi_map_phys(rsdt->entries[i], sizeof(ACPISDTHeader_t));
            if (!table) continue;
            if (memcmp(table->signature, signature, 4) == 0) {
                void *full = acpi_map_phys(rsdt->entries[i], table->length);
                if (full) table = full;
                kprintf("[ACPI] Found table %.4s at phys %x\n", table->signature, rsdt->entries[i]);
                return table;
            }
        }
    }

    return NULL;
}

/* Get MADT table */
MADT_t *acpi_get_madt(void) {
    return (MADT_t *)acpi_find_table("APIC");
}

/* Parse MADT to find Local APIC, I/O APIC, and CPU information */
int acpi_parse_madt(void) {
    MADT_t *madt = acpi_get_madt();
    if (!madt) {
        kprintf("[ACPI] MADT not found\n");
        return -1;
    }

    /* acpi_find_table already mapped the table via acpi_map_phys */
    if (!acpi_verify_checksum(madt, madt->header.length)) {
        kprintf("[ACPI] MADT checksum failed\n");
        return -1;
    }

    lapic_phys_addr = madt->local_apic_address;
    kprintf("[ACPI] MADT: Local APIC at 0x%x, flags=0x%x\n", lapic_phys_addr, madt->flags);

    /* Walk MADT entries */
    u8 *entry_ptr = (u8 *)(madt + 1);
    u8 *end_ptr = (u8 *)madt + madt->header.length;

    while (entry_ptr + sizeof(MADTEntryHeader_t) <= end_ptr) {
        MADTEntryHeader_t *hdr = (MADTEntryHeader_t *)entry_ptr;
        if (entry_ptr + hdr->length > end_ptr) break;

        switch (hdr->type) {
            case 0: {  /* Processor Local APIC */
                MADTLocalAPIC_t *lapic = (MADTLocalAPIC_t *)entry_ptr;
if (lapic->flags & 1) {  /* LAPIC_ENABLED */
                        if (num_cpus < MAX_CPUS) {
                        lapic_ids[num_cpus] = lapic->apic_id;
                        kprintf("[ACPI] Found CPU %d: ACPI ID=%d, APIC ID=%d\n",
                                num_cpus, lapic->acpi_processor_id, lapic->apic_id);
                        num_cpus++;
                    }
                }
                break;
            }
            case 1: {  /* I/O APIC */
                MADTIOAPIC_t *ioapic = (MADTIOAPIC_t *)entry_ptr;
                ioapic_phys_addr = ioapic->io_apic_address;
                kprintf("[ACPI] Found I/O APIC %d at 0x%x, GSI base=%d\n",
                        ioapic->io_apic_id, ioapic_phys_addr, ioapic->global_system_interrupt_base);
                break;
            }
            case 2: {  /* Interrupt Source Override */
                MADTISO_t *iso = (MADTISO_t *)entry_ptr;
                kprintf("[ACPI] IRQ Override: bus=%d, irq=%d -> GSI=%d, flags=0x%x\n",
                        iso->bus_source, iso->irq_source, iso->global_system_interrupt, iso->flags);
                if (iso->bus_source == 0 && iso->irq_source < MAX_ISA_IRQS) {
                    irq_override_gsi[iso->irq_source] = (u8)iso->global_system_interrupt;
                }
                break;
            }
            case 4: {  /* Local APIC NMI */
                kprintf("[ACPI] MADT: Local APIC NMI (skipping)\n");
                break;
            }
            case 9: {  /* Processor Local x2APIC */
                MADTLocalx2APIC_t *x2apic = (MADTLocalx2APIC_t *)entry_ptr;
if (x2apic->flags & 1) {
                        if (num_cpus < MAX_CPUS) {
                        lapic_ids[num_cpus] = (u8)x2apic->x2apic_id;
                        kprintf("[ACPI] Found x2APIC CPU %d: UID=%d, x2APIC ID=%d\n",
                                num_cpus, x2apic->acpi_processor_uid, x2apic->x2apic_id);
                        num_cpus++;
                    }
                }
                break;
            }
            default:
                kprintf("[ACPI] Unknown MADT entry type %d\n", hdr->type);
                break;
        }
        entry_ptr += hdr->length;
    }

    if (num_cpus == 0) {
        kprintf("[ACPI] No enabled CPUs found in MADT\n");
        return -1;
    }

    kprintf("[ACPI] Total CPUs found: %d\n", num_cpus);
    return 0;
}

/* ACPI initialization - called from kernel_main */
int acpi_init(phys_addr_t rsdp_addr) {
    kprintf("[ACPI] Initializing... (rsdp_addr=0x%llx)\n", (u64)rsdp_addr);

    const RSDPDescriptor20_t *rsdp = NULL;

    /* Use RSDP from bootloader if provided */
    if (rsdp_addr) {
        rsdp = (const RSDPDescriptor20_t *)acpi_map_phys(rsdp_addr, sizeof(RSDPDescriptor20_t));
        if (rsdp && memcmp(rsdp->v1.signature, "RSD PTR ", 8) == 0) {
            kprintf("[ACPI] RSDP v%u at bootloader 0x%llx (oem_id=%.6s)\n",
                    (unsigned)rsdp->v1.revision, (u64)rsdp_addr, rsdp->v1.oem_id);
        } else {
            kprintf("[ACPI] Bootloader rsdp_addr=0x%llx but signature mismatch (rsdp=%p)\n",
                    (u64)rsdp_addr, rsdp);
            rsdp = NULL;
        }
    }

    /* Fall back to broad memory scan */
    if (!rsdp) {
        kprintf("[ACPI] Scanning memory for RSDP...\n");
        rsdp = acpi_find_rsdp();
    }
    if (!rsdp) {
        kprintf("[ACPI] RSDP not found - ACPI not available\n");
        return -1;
    }

    kprintf("[ACPI] RSDP v%d found at %p\n", rsdp->v1.revision, rsdp);
    if (rsdp->v1.revision >= 2) {
        kprintf("[ACPI] XSDT at 0x%llx\n", rsdp->xsdt_address);
    } else {
        kprintf("[ACPI] RSDT at 0x%x\n", rsdp->v1.rsdt_address);
    }

    if (acpi_parse_madt() != 0) {
        kprintf("[ACPI] MADT parsing failed\n");
        return -1;
    }

    kprintf("[ACPI] Initialization complete\n");
    return 0;
}