#include <ftk/apic.h>
#include <ftk/acpi.h>
#include <ftk/io.h>
#include <ftk/printk.h>
#include <ftk/memory.h>
#include <ftk/vmm.h>
#include <ftk/scheduler.h>

/* LAPIC and IOAPIC virtual base addresses */
volatile u32 *lapic_base = NULL;
volatile u32 *ioapic_base = NULL;

/* LAPIC MMIO base (set by ACPI, default 0xFEE00000) */
/* Use fixed virtual addresses OUTSIDE the kernel's higher-half mapping range */
/* Kernel maps [KERNEL_VIRT_BASE, KERNEL_VIRT_BASE + max_phys), ~ [0xFFFFFFFF80000000, 0xFFFFFFFFFFFFFFFF] */
#define LAPIC_VIRT_BASE  0xFFFFFFFF00000000ULL
#define IOAPIC_VIRT_BASE 0xFFFFFFFF00100000ULL

void lapic_init(void) {
    if (!lapic_phys_addr) {
        kprintf("[LAPIC] No LAPIC address from ACPI, using default 0xFEE00000\n");
        lapic_phys_addr = 0xFEE00000;
    }

    /* Map LAPIC MMIO region (1 page) */
    extern AddressSpace kernel_space;
    extern int vmm_map_page(AddressSpace *space, virt_addr_t virt, phys_addr_t phys, u64 flags);
    extern int vmm_get_flags(AddressSpace*, virt_addr_t, u64*, phys_addr_t*);
    
    lapic_base = (volatile u32 *)LAPIC_VIRT_BASE;
    vmm_map_page(&kernel_space, LAPIC_VIRT_BASE, lapic_phys_addr, 
                 PTE_PRESENT | PTE_WRITABLE | PTE_NX);

    kprintf("[LAPIC] Phys: 0x%x, Virt: 0x%llx\n", lapic_phys_addr, (u64)lapic_base);
    kprintf("[LAPIC] Version: 0x%x, ID: %d\n", lapic_read(LAPIC_VERSION) & 0xFF, lapic_get_id());

    /* Disable legacy PIC by masking all interrupts */
    outb(0x21, 0xFF);  /* Master PIC mask */
    outb(0xA1, 0xFF);  /* Slave PIC mask */
    kprintf("[PIC] Legacy PIC disabled (all IRQs masked)\n");

    /* Enable Local APIC */
    lapic_write(LAPIC_SVR, lapic_read(LAPIC_SVR) | (1 << 8));  /* APIC enable bit */

    /* Set spurious interrupt vector (vector 0xFF) */
    lapic_write(LAPIC_SVR, (1 << 8) | 0xFF);

    /* Mask all LVT entries initially */
    lapic_write(LAPIC_LVT_TIMER,   (1 << 16));  /* Mask */
    lapic_write(LAPIC_LVT_THERMAL, (1 << 16));
    lapic_write(LAPIC_LVT_PERF,    (1 << 16));

    /* LINT0: ExtINT delivery mode — forwards legacy PIC interrupts through LAPIC.
     * ExtINT = delivery mode 0b111 (bits 10:8 = 111), unmasked (bit 16 = 0). */
    lapic_write(LAPIC_LVT_LINT0,   (7 << 8));   /* ExtINT, unmasked */

    lapic_write(LAPIC_LVT_LINT1,   (1 << 16));  /* Mask */
    lapic_write(LAPIC_LVT_ERROR,   (1 << 16));

    /* Set up timer divide configuration */
    lapic_write(LAPIC_TIMER_DCR, 0x3);  /* Divide by 16 */

    kprintf("[LAPIC] Local APIC initialized\n");
}

void ioapic_init(void) {
    if (!ioapic_phys_addr) {
        kprintf("[IOAPIC] No I/O APIC address from ACPI\n");
        return;
    }

    /* Map I/O APIC MMIO */
    extern AddressSpace kernel_space;
    extern int vmm_map_page(AddressSpace *space, virt_addr_t virt, phys_addr_t phys, u64 flags);
    
    ioapic_base = (volatile u32 *)IOAPIC_VIRT_BASE;
    vmm_map_page(&kernel_space, IOAPIC_VIRT_BASE, ioapic_phys_addr,
                 PTE_PRESENT | PTE_WRITABLE | PTE_NX);

    u32 ver = ioapic_read(0x01);  /* IOAPICVER */
    u32 max_redir = (ver >> 16) & 0xFF;
    
    kprintf("[IOAPIC] Phys: 0x%x, Virt: 0x%llx, Version: 0x%x, Max redirection entries: %d\n",
            ioapic_phys_addr, (u64)ioapic_base, ver & 0xFF, max_redir + 1);

    /* Mask all interrupts by default */
    for (u32 i = 0; i <= max_redir; i++) {
        u64 redir = (1ULL << 16) | (0x20 + i);  /* Mask (bit 16) + Vector 0x20+ */
        ioapic_write(0x10 + i * 2, (u32)redir);       /* Low 32 bits */
        ioapic_write(0x11 + i * 2, (u32)(redir >> 32)); /* High 32 bits */
    }

    kprintf("[IOAPIC] Initialized, all %d IRQs masked\n", max_redir + 1);
}

void ioapic_redirect_irq(u8 irq, u8 vector, u8 dest_apic_id) {
    if (!ioapic_base) return;

    /* Redirection table entry: 64 bits */
    u64 entry = vector;                    /* Vector (bits 0-7) */
    entry |= ((u64)dest_apic_id) << 56;   /* Destination (bits 56-63) */
    entry &= ~(1ULL << 16);                /* Delivery mode: Fixed (bits 8-10 = 000) */
    entry &= ~(1ULL << 13);                /* Polarity: High active (bit 13 = 0) */
    entry &= ~(1ULL << 15);                /* Trigger: Edge (bit 15 = 0) */

    u32 reg_low = 0x10 + irq * 2;
    ioapic_write(reg_low, (u32)entry);
    ioapic_write(reg_low + 1, (u32)(entry >> 32));

    kprintf("[IOAPIC] IRQ %d -> Vector 0x%x, Dest APIC %d\n", irq, vector, dest_apic_id);
}

void lapic_set_timer(u32 vector, u32 initial_count, int periodic) {
    u32 lvt = (1 << 16) | vector;  /* Masked + vector */
    if (periodic) lvt |= (1 << 17);  /* Periodic mode */
    lapic_write(LAPIC_LVT_TIMER, lvt);
    lapic_write(LAPIC_TIMER_ICR, initial_count);
    kprintf("[LAPIC] Timer configured: vector=0x%x, count=%d, periodic=%d\n",
            vector, initial_count, periodic);
}

/* Get Local APIC ID */
u32 lapic_get_id(void) {
    return (lapic_read(LAPIC_ID) >> 24) & 0xFF;
}

/* Send EOI to Local APIC */
void lapic_eoi(void) {
    lapic_write(LAPIC_EOI, 0);
}

/* I/O APIC inline accessors */
u32 ioapic_read(u32 reg) {
    if (!ioapic_base) return 0;
    ioapic_base[0] = reg;  /* IOREGSEL */
    return ioapic_base[4]; /* IOWIN */
}

void ioapic_write(u32 reg, u32 val) {
    if (!ioapic_base) return;
    ioapic_base[0] = reg;  /* IOREGSEL */
    ioapic_base[4] = val;  /* IOWIN */
}