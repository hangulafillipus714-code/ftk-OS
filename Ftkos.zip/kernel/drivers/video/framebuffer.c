#include <ftk/framebuffer.h>
#include <ftk/memory_layout.h>
#include <ftk/string.h>
#include "font8x16.h"

/* Exported for GUI syscalls */
u32 *ftk_fb_base  = NULL;
u32 *ftk_fb_kernel_virt = NULL;
u32  ftk_fb_width  = 0;
u32  ftk_fb_height = 0;
u32  ftk_fb_pitch  = 0;

/* Tick counter exported for SYS_GETTICKS */
volatile u64 ftk_ticks = 0;

/* Cursor position for text console */
static int cursor_col = 0;
static int cursor_row = 0;

void framebuffer_init(fb_info_t *info) {
    ftk_fb_base   = (u32*)(uintptr_t)info->base;
    ftk_fb_kernel_virt = (u32*)(uintptr_t)(FRAMEBUFFER_VIRT_BASE + (info->base & 0xFFF));
    ftk_fb_width  = info->width;
    ftk_fb_height = info->height;
    ftk_fb_pitch  = info->pitch;
}

void framebuffer_put_pixel(u32 x, u32 y, u32 color) {
    if (x >= ftk_fb_width || y >= ftk_fb_height) return;
    ftk_fb_kernel_virt[y * (ftk_fb_pitch / 4) + x] = color;
}

void framebuffer_clear(u32 color) {
    for (u32 y = 0; y < ftk_fb_height; y++)
        for (u32 x = 0; x < ftk_fb_width; x++)
            ftk_fb_kernel_virt[y * (ftk_fb_pitch / 4) + x] = color;
}

void framebuffer_putchar(int c, int col, int row, u32 fg, u32 bg) {
    if (c < 0 || c > 255) return;
    int x0 = col * 8, y0 = row * 16;
    for (int yy = 0; yy < 16; yy++) {
        unsigned char bits = font8x16[c][yy];
        for (int xx = 0; xx < 8; xx++) {
            u32 color = (bits & (0x80 >> xx)) ? fg : bg;
            framebuffer_put_pixel(x0 + xx, y0 + yy, color);
        }
    }
}

void framebuffer_puts(const char *s, int col, int row, u32 fg, u32 bg) {
    while (*s) {
        if (*s >= ' ' && *s <= '~')
            framebuffer_putchar(*s, col++, row, fg, bg);
        else if (*s == '\n') { col = 0; row++; }
        s++;
    }
}

void framebuffer_scroll(void) {
    if (!ftk_fb_kernel_virt || ftk_fb_height <= 16) return;
    int char_height = 16;
    int row_bytes   = ftk_fb_pitch;
    for (u32 y = 0; y + (u32)char_height < ftk_fb_height; y++) {
        u32 *src = ftk_fb_kernel_virt + (y + char_height) * (ftk_fb_pitch / 4);
        u32 *dst = ftk_fb_kernel_virt + y * (ftk_fb_pitch / 4);
        memcpy(dst, src, row_bytes);
    }
    for (u32 y = ftk_fb_height - 16; y < ftk_fb_height; y++)
        for (u32 x = 0; x < ftk_fb_width; x++)
            ftk_fb_kernel_virt[y * (ftk_fb_pitch / 4) + x] = 0x000000;
    cursor_row--;
}

void framebuffer_write(const char *s) {
    if (!ftk_fb_kernel_virt) return;
    while (*s) {
        if (*s == '\n') { cursor_col = 0; cursor_row++; }
        else if (*s == '\r') { cursor_col = 0; }
        else if (*s >= ' ') {
            framebuffer_putchar(*s, cursor_col, cursor_row, 0xFFFFFF, 0x000000);
            cursor_col++;
            if (cursor_col >= FB_CONSOLE_COLS) { cursor_col = 0; cursor_row++; }
        }
        if (cursor_row >= FB_CONSOLE_ROWS) framebuffer_scroll();
        s++;
    }
}
