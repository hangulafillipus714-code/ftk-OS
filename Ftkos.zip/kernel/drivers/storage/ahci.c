#include <ftk/vmm.h>
#include <ftk/pmm.h>
#include <ftk/string.h>
#include <ftk/printk.h>
#include <ftk/drivers/ahci.h>
#include <ftk/memory_layout.h>
#include <ftk/spinlock.h>
#include <ftk/scheduler.h>
#include <ftk/io.h>

/* Virtual address for AHCI MMIO — above kernel direct-map range */
#define AHCI_VIRT_BASE 0xFFFFFF00C0000000ULL

/* PRDT entry */
typedef struct {
    u32 dba; u32 dbau; u32 rsv0; u32 dbc:22; u32 rsv1:9; u32 i:1;
} ahci_prdt_t;

/* Command table */
typedef struct {
    volatile u8 cfis[64]; volatile u8 acmd[16]; volatile u8 rsv[48];
    volatile ahci_prdt_t prdt[1];
} ahci_cmd_table_t;

/* Command header */
typedef struct {
    volatile u32 opts;
    volatile u32 prdbc;
    volatile u32 ctba;
    volatile u32 ctbau;
    volatile u32 rsv1[4];
} ahci_cmd_header_t;

#define AHCI_CMD_HDR_WRITE    0x40000000
#define AHCI_CMD_HDR_ATAPI    0x20000000
#define AHCI_CMD_HDR_PREFETCH 0x10000000
#define AHCI_CMD_HDR_RESET    0x08000000
#define AHCI_CMD_HDR_BIST     0x04000000
#define AHCI_CMD_HDR_CLR_BUSY 0x02000000
#define AHCI_CMD_HDR_PMP_MASK 0x0F000000
#define AHCI_CMD_HDR_CFL_MASK 0x1F

/* HBA port registers - volatile for MMIO */
typedef struct {
    volatile u32 clb; volatile u32 clbu; volatile u32 fb; volatile u32 fbu;
    volatile u32 is; volatile u32 ie;
    volatile u32 cmd; volatile u32 rsv0; volatile u32 tfd; volatile u32 sig; volatile u32 ssts;
    volatile u32 sctl; volatile u32 serr; volatile u32 sact; volatile u32 ci;
    volatile u32 sntf; volatile u32 fbs;
    volatile u32 rsv1[15];
} hba_port_t;

/* HBA memory registers (ABAR) - accessed via volatile for MMIO semantics */
typedef struct {
    volatile u32 cap; volatile u32 ghc; volatile u32 is; volatile u32 pi; volatile u32 vs;
    volatile u32 ccc_ctl; volatile u32 ccc_pts; volatile u32 em_loc; volatile u32 em_ctl;
    volatile u32 cap2; volatile u32 bohc;
    u8 rsv[0xA0 - 0x2C];
    u8 vendor[0x100 - 0xA0];
    volatile hba_port_t ports[32];
} hba_mem_t;

static volatile hba_mem_t* hba;
static volatile hba_port_t* port;
static spinlock_t ahci_lock = SPINLOCK_INIT;

/* Simple direct-mapped sector cache */
#define SECTOR_CACHE_ENTRIES 8
static struct {
    u64 lba;
    int valid;
    u8 data[512];
} sector_cache[SECTOR_CACHE_ENTRIES];

static int cache_lookup(u64 lba, void *buf) {
    u32 idx = (u32)(lba % SECTOR_CACHE_ENTRIES);
    if (sector_cache[idx].valid && sector_cache[idx].lba == lba) {
        memcpy(buf, sector_cache[idx].data, 512);
        return 1;
    }
    return 0;
}

static void cache_store(u64 lba, const void *data) {
    u32 idx = (u32)(lba % SECTOR_CACHE_ENTRIES);
    sector_cache[idx].lba = lba;
    sector_cache[idx].valid = 1;
    memcpy(sector_cache[idx].data, data, 512);
}

void ahci_init(u32 bar5) {
    phys_addr_t abar_phys = (phys_addr_t)bar5 & ~0xFULL;

    /* Map ABAR as uncacheable (PCD=bit4, PWT=bit3) for proper MMIO semantics */
    u64 mmio_flags = PTE_PRESENT | PTE_WRITABLE | PTE_NX | (1 << 4) | (1 << 3);
    int ret = vmm_map_page(&kernel_space, AHCI_VIRT_BASE, abar_phys, mmio_flags);
    kprintf("[AHCI] map page1: virt=%p phys=%p ret=%d\n", AHCI_VIRT_BASE, abar_phys, ret);
    if (ret != 0) {
        kprintf("[AHCI] Failed to map ABAR\n");
        return;
    }
    ret = vmm_map_page(&kernel_space, AHCI_VIRT_BASE + 0x1000, abar_phys + 0x1000, mmio_flags);
    kprintf("[AHCI] map page2: virt=%p phys=%p ret=%d\n", AHCI_VIRT_BASE + 0x1000, abar_phys + 0x1000, ret);
    if (ret != 0) {
        kprintf("[AHCI] Failed to map ABAR+0x1000\n");
    }

    hba = (hba_mem_t*)AHCI_VIRT_BASE;

    u32 cap = hba->cap;
    u32 ghc = hba->ghc;
    u32 pi = hba->pi;
    u32 vs = hba->vs;

    kprintf("[AHCI] CAP=0x%x GHC=0x%x PI=0x%x VS=0x%x\n", cap, ghc, pi, vs);

    if (pi == 0) {
        kprintf("[AHCI] No ports implemented; trying to enable AHCI mode\n");
        /* Set AHCI Enable bit in GHC */
        hba->ghc |= (1 << 31);
        pi = hba->pi;
        kprintf("[AHCI] After GHC.AE=1, PI=0x%x\n", pi);
    }

    for (int i = 0; i < 32; i++) {
        if (!(pi & (1 << i))) continue;

        port = &hba->ports[i];
        u32 sig = port->sig;
        u32 ssts = port->ssts;
        u32 tfd = port->tfd;
        u32 cmd = port->cmd;
        kprintf("[AHCI] Port %d: sig=0x%x ssts=0x%x tfd=0x%x cmd=0x%x\n",
                i, sig, ssts, tfd, cmd);

        if (sig == 0xEB140101) {
            kprintf("[AHCI] Port %d is ATAPI, skip\n", i);
            continue;
        }
        if (ssts != 0x00000113 && ssts != 0x00000123) {
            kprintf("[AHCI] Port %d no device detected\n", i);
            continue;
        }

        /* Clear any pending errors */
        port->serr = 0xFFFFFFFF;
        port->is = 0xFFFFFFFF;

        /* First, read firmware's CLB/FB to have known-good fallback */
        u32 fw_clb = port->clb;
        u32 fw_fb = port->fb;
        kprintf("[AHCI] Firmware CLB=%x FB=%x\n", fw_clb, fw_fb);

        /* Proper port initialization per QEMU/AHCI bit layout:
         *   bit 0  = ST (Command List Start)
         *   bit 4  = FRE (FIS Receive Enable)
         *   bit 14 = FR  (FIS Receive Running)
         *   bit 15 = CR  (Command List Running)
         *
         * First stop engines, then try firmware CLB/FB first.
         */
        port->cmd = 0;
        while (port->cmd & ((1 << 14) | (1 << 15)));

        if (fw_clb) { port->clb = fw_clb; port->clbu = 0; }
        if (fw_fb)  { port->fb  = fw_fb;  port->fbu  = 0; }
        if (!fw_clb || !fw_fb) {
            kprintf("[AHCI] Firmware CLB/FB missing, using own\n");
            if (!fw_clb) {
                port->clb = (u32)(pmm_alloc_page() & 0xFFFFFFFF);
                port->clbu = 0;
                memset((void*)PHYS_TO_VIRT((phys_addr_t)port->clb), 0, PAGE_SIZE);
            }
            if (!fw_fb) {
                port->fb = (u32)(pmm_alloc_page() & 0xFFFFFFFF);
                port->fbu = 0;
                memset((void*)PHYS_TO_VIRT((phys_addr_t)port->fb), 0, PAGE_SIZE);
            }
        }
        kprintf("[AHCI] Using CLB=%x FB=%x\n", port->clb, port->fb);

        port->cmd = (1 << 0) | (1 << 1) | (1 << 2) | (1 << 4);
        u32 cmd_check = port->cmd;
        kprintf("[AHCI] After cmd write: cmd=0x%lx\n", cmd_check);

        /* Wait for FR (bit 14) + CR (bit 15) after starting port */
        u32 fr_wait = 0;
        while (!(port->cmd & ((1 << 14) | (1 << 15))) && fr_wait < 100000) fr_wait++;
        u32 cmd_after = port->cmd;
        u32 tfd_after = port->tfd;
        u32 serr_after = port->serr;
        u32 sact_after = port->sact;
        u32 ci_after = port->ci;
        kprintf("[AHCI] Port %d: cmd=0x%lx tfd=0x%lx serr=0x%lx sact=0x%lx ci=0x%lx\n",
                i, cmd_after, tfd_after, serr_after, sact_after, ci_after);
        return;
    }

    kprintf("[AHCI] No suitable SATA port found\n");
    port = NULL;
}

int ahci_read(u64 lba, u32 count, void* buf) {
    if (!port || !buf || count == 0) return -1;

    /* A single character to serial forces a QEMU TCG exit, allowing
     * the event loop to complete AHCI DMA from a previous read. */
    u64 rflags;
    spinlock_acquire_irqsave(&ahci_lock, &rflags);

    /* Fast path: if count==1, check sector cache first */
    if (count == 1) {
        if (cache_lookup(lba, buf)) {
            spinlock_release_irqrestore(&ahci_lock, rflags);
            return 0;
        }
    }

    port->is = 0xFFFFFFFF;
    int slot = 0;

    u32 clb_val = port->clb;
    volatile ahci_cmd_header_t* hdr = (volatile ahci_cmd_header_t*)PHYS_TO_VIRT((phys_addr_t)clb_val);

    phys_addr_t ct_phys = 0;
    if (hdr->ctba != 0) {
        ct_phys = (phys_addr_t)hdr->ctba | ((phys_addr_t)hdr->ctbau << 32);
    } else {
        ct_phys = pmm_alloc_page();
        if (!ct_phys) {
            spinlock_release_irqrestore(&ahci_lock, rflags);
            return -1;
        }
        hdr->ctba = (u32)(ct_phys & 0xFFFFFFFF);
        hdr->ctbau = (u32)(ct_phys >> 32);
    }

    volatile ahci_cmd_table_t* tbl = (volatile ahci_cmd_table_t*)PHYS_TO_VIRT(ct_phys);
    memset((void*)tbl, 0, sizeof(ahci_cmd_table_t));

    hdr->opts = (5 << 0) | (0 << 25) | (1 << 16);
    hdr->prdbc = 0;

    phys_addr_t buf_phys = VIRT_TO_PHYS((virt_addr_t)buf);
    tbl->prdt[0].dba = (u32)((u64)buf_phys);
    tbl->prdt[0].dbau = (u32)(buf_phys >> 32);
    tbl->prdt[0].dbc = (count * 512) - 1;
    tbl->prdt[0].i = 1;

    u8* fis = (u8*)tbl->cfis;
    memset(fis, 0, 64);
    fis[0] = 0x27;
    fis[1] = 0x80;
    fis[2] = 0x25;
    fis[3] = 0;
    fis[4] = (u8)(lba & 0xFF);
    fis[5] = (u8)((lba >> 8) & 0xFF);
    fis[6] = (u8)((lba >> 16) & 0xFF);
    fis[7] = 0x40;
    fis[8] = (u8)((lba >> 24) & 0xFF);
    fis[9] = (u8)((lba >> 32) & 0xFF);
    fis[10] = (u8)((lba >> 40) & 0xFF);
    fis[11] = 0;
    fis[12] = (u8)(count & 0xFF);
    fis[13] = (u8)((count >> 8) & 0xFF);

    u32 timeout_tfd = 100000;
    while ((port->tfd & (0x80 | 0x08))) {
        if (--timeout_tfd == 0) {
            spinlock_release_irqrestore(&ahci_lock, rflags);
            kprintf("T"); /* TFD timeout */
            return -1;
        }
    }

    port->ci = (1 << slot);
    outb(0xE9, 0); /* force VM exit so QEMU processes DMA BH */

    u32 timeout = 100000;
    while (1) {
        if (!(port->ci & (1 << slot)))
            break;
        if ((port->is & (1 << 30))) {
            spinlock_release_irqrestore(&ahci_lock, rflags);
            return -1;
        }
        if (--timeout == 0) {
            /* Release lock temporarily so scheduler can run
             * (gives QEMU TCG a chance to process AHCI DMA). */
            spinlock_release_irqrestore(&ahci_lock, rflags);
            scheduler_yield();
            spinlock_acquire_irqsave(&ahci_lock, &rflags);
            timeout = 100000;
        }
    }

    /* Store in cache sector by sector */
    for (u32 i = 0; i < count; i++)
        cache_store(lba + i, (u8*)buf + i * 512);

    spinlock_release_irqrestore(&ahci_lock, rflags);
    return 0;
}
