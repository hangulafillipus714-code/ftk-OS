#include <ftk/putchar.h>
#include <ftk/framebuffer.h>
#include <ftk/scheduler.h>
#include <ftk/per_cpu.h>
#include <drivers/char/serial.h>

/*
 * Override putchar after serial_init() and framebuffer_init are called.
 * Writes to serial (if initialized) and to the framebuffer console.
 */
static int serial_ready = 0;

void putchar_serial_init(void) {
    serial_init();
    serial_ready = 1;
}

int putchar(int c) {
    if (serial_ready) {
        serial_write(c);
    }
    /* Only write to framebuffer from kernel context — user tasks don't
     * have the framebuffer mapped in their address space. */
    if (!current_task || current_task->address_space == &kernel_space) {
        char s[2] = { (char)c, '\0' };
        framebuffer_write(s);
    }
    return c;
}
