#include <drivers/char/serial.h>
#include <ftk/abi/types.h>
#include <ftk/io.h>
#include <ftk/scheduler.h>

#define SERIAL_PORT 0x3F8

void serial_init(void) {
    outb(SERIAL_PORT + 1, 0x00);
    outb(SERIAL_PORT + 3, 0x80);
    outb(SERIAL_PORT + 0, 0x03);
    outb(SERIAL_PORT + 1, 0x00);
    outb(SERIAL_PORT + 3, 0x03);
    outb(SERIAL_PORT + 2, 0xC7);
    outb(SERIAL_PORT + 4, 0x0B);
}

static int serial_transmit_empty(void) {
    return inb(SERIAL_PORT + 5) & 0x20;
}

/* LOW LEVEL — used by printf */
void serial_write(char c) {
    int timeout = 100000;
    if (c != 0) {
        while (!serial_transmit_empty() && --timeout > 0);
    }
    outb(SERIAL_PORT, c);
}

/* HIGH LEVEL — used manually */
void serial_puts(const char *s) {
    while (*s)
        serial_write(*s++);
}

void log_info(const char *msg) {
    serial_puts(LOG_CLR_GREEN "[INFO] " LOG_CLR_RESET);
    serial_puts(msg);
    serial_puts("\n");
}

void log_warn(const char *msg) {
    serial_puts(LOG_CLR_YELLOW "[WARN] " LOG_CLR_RESET);
    serial_puts(msg);
    serial_puts("\n");
}

void log_error(const char *msg) {
    serial_puts(LOG_CLR_RED "[ERROR] " LOG_CLR_RESET);
    serial_puts(msg);
    serial_puts("\n");
}

void log_debug(const char *msg) {
    serial_puts(LOG_CLR_CYAN "[DEBUG] " LOG_CLR_RESET);
    serial_puts(msg);
    serial_puts("\n");
}