#include <drivers/char/console.h>
#include <drivers/char/keyboard.h>
#include <drivers/char/serial.h>
#include <ftk/io.h>
#include <ftk/scheduler.h>

#define SERIAL_PORT 0x3F8

char console_getchar(void)
{
    char c;
    for (;;) {
        if (keyboard_try_getchar(&c))
            return c;
        if (inb(SERIAL_PORT + 5) & 1) {
            c = (char)inb(SERIAL_PORT);
            return c;
        }
        scheduler_yield();
    }
}

void console_init(void)
{
}
