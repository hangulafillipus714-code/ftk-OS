#ifndef FTK_DRIVERS_CHAR_KEYBOARD_H
#define FTK_DRIVERS_CHAR_KEYBOARD_H

#include <ftk/stddef.h>
#include <ftk/abi/syscall.h>    /* ftk_key_event_t */

void keyboard_init(void);
int  keyboard_try_getchar(char *c);
char keyboard_getchar(void);

/* Canonical TTY readline (blocking, line-buffered) */
int  tty_readline(char *out, size_t size);

/* GUI key-event polling (non-blocking) */
int  keyboard_poll_event(ftk_key_event_t *ev);

#endif
