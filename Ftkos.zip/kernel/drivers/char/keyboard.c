/*
 * kernel/drivers/char/keyboard.c — FTK OS PS/2 keyboard driver
 *
 * Provides:
 *   - Canonical TTY line buffer (blocking line reads for fsh)
 *   - Raw key-event ring buffer (non-blocking, for GUI apps)
 *   - Full US layout including Shift, Ctrl, Alt, Arrow, Fn keys
 */

#include <drivers/char/keyboard.h>
#include <ftk/arch/x86_64/isr.h>
#include <ftk/io.h>
#include <ftk/printk.h>
#include <ftk/spinlock.h>
#include <ftk/scheduler.h>
#include <ftk/string.h>
#include <ftk/abi/syscall.h>   /* ftk_key_event_t, FTK_KEY_*, FTK_MOD_* */

#define KEYBOARD_DATA_PORT 0x60
#define PIC1_DATA_PORT     0x21
#define KEYBOARD_IRQ       1
#define KEYBOARD_VECTOR    33

/* ── Modifier state ─────────────────────────────────────── */
static int shift_pressed = 0;
static int ctrl_pressed  = 0;
static int alt_pressed   = 0;
static int caps_lock     = 0;
static int e0_prefix     = 0;   /* extended scancode prefix 0xE0 */

/* ── Canonical TTY buffer (for fsh line input) ───────────── */
#define TTY_BUF_SIZE 512
typedef struct {
    char   buf[TTY_BUF_SIZE];
    size_t len;
    int    line_ready;
} tty_canon_t;

static tty_canon_t tty_canon = { .buf = {0}, .len = 0, .line_ready = 0 };
static spinlock_t  tty_lock  = SPINLOCK_INIT;

/* ── Raw key-event ring buffer (for GUI) ─────────────────── */
#define KEY_BUF_SIZE 64
static ftk_key_event_t key_buf[KEY_BUF_SIZE];
static volatile int key_head = 0;
static volatile int key_tail = 0;
static spinlock_t   key_lock = SPINLOCK_INIT;

/* ── Legacy raw char buffer ──────────────────────────────── */
#define KBD_BUFFER_SIZE 256
static char kbd_buffer[KBD_BUFFER_SIZE];
static volatile int kbd_head = 0;
static volatile int kbd_tail = 0;
static spinlock_t   kbd_lock = SPINLOCK_INIT;

/* ── US keyboard layout tables ──────────────────────────── */
/* Normal (unshifted) characters, indexed by scancode set-1 */
static const char scancode_normal[128] = {
    /* 0x00 */ 0,   0x1B, '1', '2',  '3', '4', '5', '6',
    /* 0x08 */ '7', '8',  '9', '0',  '-', '=', '\b','\t',
    /* 0x10 */ 'q', 'w',  'e', 'r',  't', 'y', 'u', 'i',
    /* 0x18 */ 'o', 'p',  '[', ']',  '\n', 0,  'a', 's',
    /* 0x20 */ 'd', 'f',  'g', 'h',  'j', 'k', 'l', ';',
    /* 0x28 */ '\'','`',  0,   '\\', 'z', 'x', 'c', 'v',
    /* 0x30 */ 'b', 'n',  'm', ',',  '.', '/', 0,   '*',
    /* 0x38 */ 0,   ' ',  0,   0,    0,   0,   0,   0,
    /* 0x40 */ 0,   0,    0,   0,    0,   0,   0,   '7',
    /* 0x48 */ '8', '9',  '-', '4',  '5', '6', '+', '1',
    /* 0x50 */ '2', '3',  '0', '.',  0,   0,   0,   0,
    /* 0x58 */ 0,   0,    0,   0,    0,   0,   0,   0,
    /* 0x60 */ 0,   0,    0,   0,    0,   0,   0,   0,
    /* 0x68 */ 0,   0,    0,   0,    0,   0,   0,   0,
    /* 0x70 */ 0,   0,    0,   0,    0,   0,   0,   0,
    /* 0x78 */ 0,   0,    0,   0,    0,   0,   0,   0,
};

/* Shifted characters */
static const char scancode_shifted[128] = {
    /* 0x00 */ 0,   0x1B,'!', '@',  '#', '$', '%', '^',
    /* 0x08 */ '&', '*',  '(', ')',  '_', '+', '\b','\t',
    /* 0x10 */ 'Q', 'W',  'E', 'R',  'T', 'Y', 'U', 'I',
    /* 0x18 */ 'O', 'P',  '{', '}',  '\n', 0,  'A', 'S',
    /* 0x20 */ 'D', 'F',  'G', 'H',  'J', 'K', 'L', ':',
    /* 0x28 */ '"', '~',  0,   '|',  'Z', 'X', 'C', 'V',
    /* 0x30 */ 'B', 'N',  'M', '<',  '>', '?', 0,   '*',
    /* 0x38 */ 0,   ' ',  0,   0,    0,   0,   0,   0,
    /* 0x40-0x7F: same as normal for keypad etc */
    0,0,0,0,0,0,0,'7','8','9','-','4','5','6','+','1',
    '2','3','0','.',0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
};

/* ── Push to raw char buffer ─────────────────────────────── */
static void kbd_push_char(char c)
{
    spinlock_acquire(&kbd_lock);
    int next = (kbd_head + 1) % KBD_BUFFER_SIZE;
    if (next != kbd_tail) {
        kbd_buffer[kbd_head] = c;
        kbd_head = next;
    }
    spinlock_release(&kbd_lock);
}

/* ── Push to GUI key-event buffer ────────────────────────── */
static void key_push_event(int type, int keycode, int mods)
{
    spinlock_acquire(&key_lock);
    int next = (key_head + 1) % KEY_BUF_SIZE;
    if (next != key_tail) {
        key_buf[key_head].type      = type;
        key_buf[key_head].keycode   = keycode;
        key_buf[key_head].modifiers = mods;
        key_head = next;
    }
    spinlock_release(&key_lock);
}

/* ── TTY echo helpers ────────────────────────────────────── */
static void tty_putchar_raw(char c)
{
    outb(0x3F8, c);
}

static void tty_process_char(char c)
{
    spinlock_acquire(&tty_lock);

    if (c == '\b' || c == 0x7F) {
        if (tty_canon.len > 0) {
            tty_canon.len--;
            tty_putchar_raw('\b');
            tty_putchar_raw(' ');
            tty_putchar_raw('\b');
        }
        spinlock_release(&tty_lock);
        return;
    }
    if (c == 0x03) { /* Ctrl+C */
        tty_canon.len = 0;
        tty_canon.line_ready = 0;
        tty_putchar_raw('^');
        tty_putchar_raw('C');
        tty_putchar_raw('\n');
        spinlock_release(&tty_lock);
        return;
    }
    if (c == '\r' || c == '\n') {
        tty_canon.buf[tty_canon.len] = '\0';
        tty_canon.line_ready = 1;
        tty_putchar_raw('\n');
        spinlock_release(&tty_lock);
        return;
    }
    if (c >= 0x20 && c < 0x7F) {
        if (tty_canon.len < TTY_BUF_SIZE - 1) {
            tty_canon.buf[tty_canon.len++] = c;
        }
        tty_putchar_raw(c);
    }
    spinlock_release(&tty_lock);
}

/* ── tty_readline (blocking, canonical) ──────────────────── */
int tty_readline(char *out, size_t size)
{
    if (!out || size == 0) return 0;
    for (;;) {
        u64 rflags;
        spinlock_acquire_irqsave(&tty_lock, &rflags);
        if (tty_canon.line_ready) {
            size_t n = tty_canon.len;
            if (n >= size) n = size - 1;
            memcpy(out, tty_canon.buf, n);
            out[n] = '\0';
            tty_canon.len = 0;
            tty_canon.line_ready = 0;
            spinlock_release_irqrestore(&tty_lock, rflags);
            return (int)n;
        }
        spinlock_release_irqrestore(&tty_lock, rflags);
        scheduler_yield();
    }
}

/* ── GUI key-event polling ───────────────────────────────── */
int keyboard_poll_event(ftk_key_event_t *ev)
{
    u64 rflags;
    spinlock_acquire_irqsave(&key_lock, &rflags);
    if (key_head != key_tail) {
        *ev = key_buf[key_tail];
        key_tail = (key_tail + 1) % KEY_BUF_SIZE;
        spinlock_release_irqrestore(&key_lock, rflags);
        return 1;
    }
    spinlock_release_irqrestore(&key_lock, rflags);
    return 0;
}

/* ── IRQ handler ─────────────────────────────────────────── */
static void keyboard_irq_handler(Registers *regs)
{
    (void)regs;
    u8 sc = inb(KEYBOARD_DATA_PORT);

    /* Extended prefix */
    if (sc == 0xE0) { e0_prefix = 1; return; }

    int is_release = (sc & 0x80) != 0;
    u8  code       = sc & 0x7F;
    int mods       = (shift_pressed ? FTK_MOD_SHIFT : 0)
                   | (ctrl_pressed  ? FTK_MOD_CTRL  : 0)
                   | (alt_pressed   ? FTK_MOD_ALT   : 0);

    /* Handle modifier make/break */
    if (e0_prefix) {
        e0_prefix = 0;
        int keycode = 0;
        switch (code) {
            case 0x48: keycode = FTK_KEY_UP;    break;
            case 0x50: keycode = FTK_KEY_DOWN;  break;
            case 0x4B: keycode = FTK_KEY_LEFT;  break;
            case 0x4D: keycode = FTK_KEY_RIGHT; break;
            case 0x47: keycode = FTK_KEY_HOME;  break;
            case 0x4F: keycode = FTK_KEY_END;   break;
            case 0x49: keycode = FTK_KEY_PGUP;  break;
            case 0x51: keycode = FTK_KEY_PGDN;  break;
            case 0x53: keycode = FTK_KEY_DEL;   break;
            case 0x38: /* RAlt */
                alt_pressed = !is_release;
                return;
            default: return;
        }
        if (!is_release) {
            key_push_event(FTK_KEY_PRESS, keycode, mods);
            /* Arrow keys also feed TTY as escape sequences */
            if (keycode == FTK_KEY_UP)    { tty_process_char('\x1b'); tty_process_char('['); tty_process_char('A'); }
            if (keycode == FTK_KEY_DOWN)  { tty_process_char('\x1b'); tty_process_char('['); tty_process_char('B'); }
            if (keycode == FTK_KEY_RIGHT) { tty_process_char('\x1b'); tty_process_char('['); tty_process_char('C'); }
            if (keycode == FTK_KEY_LEFT)  { tty_process_char('\x1b'); tty_process_char('['); tty_process_char('D'); }
        } else {
            key_push_event(FTK_KEY_RELEASE, keycode, mods);
        }
        return;
    }

    /* Non-extended scancodes */
    switch (code) {
        case 0x2A: case 0x36: shift_pressed = !is_release; return; /* LShift/RShift */
        case 0x1D: ctrl_pressed  = !is_release; return; /* Ctrl */
        case 0x38: alt_pressed   = !is_release; return; /* Alt  */
        case 0x3A: /* CapsLock */
            if (!is_release) caps_lock = !caps_lock;
            return;
        default: break;
    }

    /* Function keys */
    if (!is_release) {
        int fkey = 0;
        switch (code) {
            case 0x3B: fkey = FTK_KEY_F1;  break;
            case 0x3C: fkey = FTK_KEY_F2;  break;
            case 0x3D: fkey = FTK_KEY_F3;  break;
            case 0x3E: fkey = FTK_KEY_F4;  break;
            case 0x3F: fkey = FTK_KEY_F5;  break;
            case 0x44: fkey = FTK_KEY_F10; break;
            default:   break;
        }
        if (fkey) {
            key_push_event(FTK_KEY_PRESS, fkey, mods);
            return;
        }
    }

    if (code >= 128) return;

    /* Resolve character */
    int use_shift = shift_pressed;
    char base_ch = scancode_normal[code];
    if (base_ch >= 'a' && base_ch <= 'z') {
        use_shift ^= caps_lock;
    }
    char ch = use_shift ? scancode_shifted[code] : base_ch;
    if (!ch) return;

    /* Ctrl modifier: fold to control character */
    if (ctrl_pressed && ch >= 'a' && ch <= 'z') ch -= 96;
    if (ctrl_pressed && ch >= 'A' && ch <= 'Z') ch -= 64;

    int keycode = (unsigned char)ch;

    if (!is_release) {
        key_push_event(FTK_KEY_PRESS, keycode, mods);
        tty_process_char(ch);
        kbd_push_char(ch);
    } else {
        key_push_event(FTK_KEY_RELEASE, keycode, mods);
    }
}

/* ── keyboard_init ───────────────────────────────────────── */
void keyboard_init(void)
{
    isr_register_handler(KEYBOARD_VECTOR, keyboard_irq_handler);

    extern void ioapic_redirect_irq(u8 irq, u8 vector, u8 dest_apic_id);
    extern u32  lapic_get_id(void);
    extern u8   acpi_get_gsi_for_irq(u8 isa_irq);
    ioapic_redirect_irq(acpi_get_gsi_for_irq(KEYBOARD_IRQ), KEYBOARD_VECTOR, lapic_get_id());

    u8 mask = inb(PIC1_DATA_PORT);
    mask &= (u8)~(1u << KEYBOARD_IRQ);
    outb(PIC1_DATA_PORT, mask);
}

int keyboard_try_getchar(char *c)
{
    u64 rflags;
    spinlock_acquire_irqsave(&kbd_lock, &rflags);
    if (kbd_head != kbd_tail) {
        *c = kbd_buffer[kbd_tail];
        kbd_tail = (kbd_tail + 1) % KBD_BUFFER_SIZE;
        spinlock_release_irqrestore(&kbd_lock, rflags);
        return 1;
    }
    spinlock_release_irqrestore(&kbd_lock, rflags);
    return 0;
}

char keyboard_getchar(void)
{
    char c;
    while (!keyboard_try_getchar(&c)) scheduler_yield();
    return c;
}
