#include <ftk/io.h>
#include <ftk/printk.h>
#include <ftk/drivers/pci.h>
#include <ftk/drivers/ahci.h>

u32 pci_read_config(u8 bus, u8 slot, u8 func, u8 offset) {
    u32 address = (u32)((u32)bus << 16) | ((u32)slot << 11) |
                  ((u32)func << 8) | (offset & 0xFC) | ((u32)0x80000000);
    outl(0xCF8, address);
    return inl(0xCFC);
}

void pci_write_config(u8 bus, u8 slot, u8 func, u8 offset, u32 value) {
    u32 address = (u32)((u32)bus << 16) | ((u32)slot << 11) |
                  ((u32)func << 8) | (offset & 0xFC) | ((u32)0x80000000);
    outl(0xCF8, address);
    outl(0xCFC, value);
}

void pci_probe(void) {
    kprintf("[PCI] Probing bus...\n");
    static int ahci_done = 0;
    for (u32 bus = 0; bus < 256; bus++) {
        for (u32 slot = 0; slot < 32; slot++) {
            u32 vendor_device = pci_read_config(bus, slot, 0, 0);
            if ((vendor_device & 0xFFFF) == 0xFFFF) continue;

            for (u32 func = 0; func < 8; func++) {
                u32 config8 = pci_read_config(bus, slot, func, 0x08);
                u8 class_code = (config8 >> 24) & 0xFF;
                u8 sub_class  = (config8 >> 16) & 0xFF;

                if (class_code == 0x01 && sub_class == 0x06) {
                    if (ahci_done) continue;
                    u32 bar0 = pci_read_config(bus, slot, func, 0x10);
                    u32 bar1 = pci_read_config(bus, slot, func, 0x14);
                    u32 bar2 = pci_read_config(bus, slot, func, 0x18);
                    u32 bar3 = pci_read_config(bus, slot, func, 0x1C);
                    u32 bar4 = pci_read_config(bus, slot, func, 0x20);
                    u32 bar5 = pci_read_config(bus, slot, func, 0x24);
                    u32 bar5_hi = pci_read_config(bus, slot, func, 0x28);

                    /* CRITICAL UPGRADE: Enable MMIO and Bus Mastering */
                    u32 command = pci_read_config(bus, slot, func, 0x04);
                    kprintf("[PCI] Command before: 0x%x\n", command);
                    command |= (1 << 1) | (1 << 2);
                    pci_write_config(bus, slot, func, 0x04, command);
                    u32 command_after = pci_read_config(bus, slot, func, 0x04);
                    kprintf("[PCI] Command after: 0x%x\n", command_after);

                    phys_addr_t abar = (phys_addr_t)bar5 | ((phys_addr_t)(bar5_hi & 0xFFFFFFF0) << 32);
                    abar &= ~0xFULL;

                    kprintf("[PCI] AHCI SATA: %d:%d:%d\n", bus, slot, func);
                    kprintf("[PCI]   BAR0=%x BAR1=%x BAR2=%x\n", bar0, bar1, bar2);
                    kprintf("[PCI]   BAR3=%x BAR4=%x\n", bar3, bar4);
                    kprintf("[PCI]   BAR5=%x BAR5_HI=%x\n", bar5, bar5_hi);
                    kprintf("[PCI]   ABAR=%p\n", abar);
                    ahci_init((u32)(abar & 0xFFFFFFFF));
                    ahci_done = 1;
                }
            }
        }
    }
}
