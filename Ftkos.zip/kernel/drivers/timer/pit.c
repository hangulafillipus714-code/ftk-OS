#include <drivers/timer/pit.h>
#include <ftk/io.h>
#include <ftk/scheduler.h>
#include <ftk/apic.h>
#include <ftk/acpi.h>
#include <ftk/printk.h>

volatile u64 system_ticks = 0;

void pit_handler(Registers *regs) {
    system_ticks++;
    lapic_eoi();
    outb(0x20, 0x20);
    scheduler_yield();
}

void pit_init(u32 frequency) {
    u32 divisor = 1193180 / frequency;

    outb(0x43, 0x36);
    outb(0x40, (u8)(divisor & 0xFF));
    outb(0x40, (u8)((divisor >> 8) & 0xFF));

    isr_register_handler(32, pit_handler);

    /* Route PIT IRQ0 through I/O APIC (q35 masks everything by default).
     * Use the ACPI Interrupt Source Override: on QEMU q35 the PIT is
     * wired to ISA IRQ 0 -> GSI 2, not GSI 0. */
    extern void ioapic_redirect_irq(u8 irq, u8 vector, u8 dest_apic_id);
    extern u32 lapic_get_id(void);
    u8 pit_gsi = acpi_get_gsi_for_irq(0);
    ioapic_redirect_irq(pit_gsi, 32, lapic_get_id());
    kprintf("[PIT] IRQ0 routed to IOAPIC GSI %u (vector 32)\n", pit_gsi);

    u8 mask = inb(0x21);
    outb(0x21, mask & ~0x01);
}

u64 pit_get_ticks(void) {
    return system_ticks;
}
