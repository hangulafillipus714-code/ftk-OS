#include <ftk/arch/x86_64/cpu.h>
#include <ftk/per_cpu.h>
#include <ftk/apic.h>
#include <ftk/printk.h>
#include <ftk/abi/syscall.h>

static int smap_enabled = 0;

int cpu_smap_enabled(void)
{
    return smap_enabled;
}

/* Control registers */

uint64_t read_cr0(void)
{
    uint64_t value;
    __asm__ volatile ("mov %%cr0, %0" : "=r"(value));
    return value;
}

void write_cr0(uint64_t value)
{
    __asm__ volatile ("mov %0, %%cr0" :: "r"(value) : "memory");
}

uint64_t read_cr3(void)
{
    uint64_t value;
    __asm__ volatile ("mov %%cr3, %0" : "=r"(value));
    return value;
}

void write_cr3(uint64_t value)
{
    __asm__ volatile ("mov %0, %%cr3" :: "r"(value) : "memory");
}

uint64_t read_cr4(void)
{
    uint64_t value;
    __asm__ volatile ("mov %%cr4, %0" : "=r"(value));
    return value;
}

void write_cr4(uint64_t value)
{
    __asm__ volatile ("mov %0, %%cr4" :: "r"(value) : "memory");
}

/* CPU instructions */

void cpu_halt(void)
{
    __asm__ volatile ("hlt");
}

void cpu_pause(void)
{
    __asm__ volatile ("pause");
}

/* Interrupts */

void cpu_enable_interrupts(void)
{
    __asm__ volatile ("sti");
}

void cpu_disable_interrupts(void)
{
    __asm__ volatile ("cli");
}

/* Model Specific Registers */

uint64_t cpu_read_msr(uint32_t msr)
{
    uint32_t low, high;
    __asm__ volatile (
        "rdmsr"
        : "=a"(low), "=d"(high)
        : "c"(msr)
    );
    return ((uint64_t)high << 32) | low;
}

void cpu_write_msr(uint32_t msr, uint64_t value)
{
    uint32_t low  = (uint32_t)value;
    uint32_t high = (uint32_t)(value >> 32);
    __asm__ volatile (
        "wrmsr"
        :
        : "c"(msr), "a"(low), "d"(high)
    );
}

/* Time Stamp Counter */
uint64_t read_tsc(void)
{
    uint32_t low, high;
    __asm__ volatile ("rdtsc" : "=a"(low), "=d"(high));
    return ((uint64_t)high << 32) | low;
}

/* CPUID support */

void cpu_cpuid(uint32_t leaf, uint32_t subleaf, uint32_t *eax, uint32_t *ebx, uint32_t *ecx, uint32_t *edx)
{
    __asm__ volatile (
        "cpuid"
        : "=a"(*eax), "=b"(*ebx), "=c"(*ecx), "=d"(*edx)
        : "a"(leaf), "c"(subleaf)
    );
}

uint32_t cpu_get_vendor_id(char *buf)
{
    uint32_t eax, ebx, ecx, edx;
    cpu_cpuid(0, 0, &eax, &ebx, &ecx, &edx);
    ((uint32_t*)buf)[0] = ebx;
    ((uint32_t*)buf)[1] = edx;
    ((uint32_t*)buf)[2] = ecx;
    buf[12] = '\0';
    return eax;
}

uint32_t cpu_get_brand_string(char *buf)
{
    uint32_t eax, ebx, ecx, edx;
    cpu_cpuid(0x80000000, 0, &eax, &ebx, &ecx, &edx);
    if (eax < 0x80000004) {
        buf[0] = '\0';
        return 0;
    }
    cpu_cpuid(0x80000002, 0, &eax, &ebx, &ecx, &edx);
    ((uint32_t*)buf)[0] = eax; ((uint32_t*)buf)[1] = ebx; ((uint32_t*)buf)[2] = ecx; ((uint32_t*)buf)[3] = edx;
    cpu_cpuid(0x80000003, 0, &eax, &ebx, &ecx, &edx);
    ((uint32_t*)buf)[4] = eax; ((uint32_t*)buf)[5] = ebx; ((uint32_t*)buf)[6] = ecx; ((uint32_t*)buf)[7] = edx;
    cpu_cpuid(0x80000004, 0, &eax, &ebx, &ecx, &edx);
    ((uint32_t*)buf)[8] = eax; ((uint32_t*)buf)[9] = ebx; ((uint32_t*)buf)[10] = ecx; ((uint32_t*)buf)[11] = edx;
    buf[48] = '\0';
    return 1;
}

uint32_t cpu_get_feature_flags_ecx(void)
{
    uint32_t eax, ebx, ecx, edx;
    cpu_cpuid(1, 0, &eax, &ebx, &ecx, &edx);
    return ecx;
}

uint32_t cpu_get_feature_flags_edx(void)
{
    uint32_t eax, ebx, ecx, edx;
    cpu_cpuid(1, 0, &eax, &ebx, &ecx, &edx);
    return edx;
}

uint32_t cpu_get_extended_features_ebx(void)
{
    uint32_t eax, ebx, ecx, edx;
    cpu_cpuid(7, 0, &eax, &ebx, &ecx, &edx);
    return ebx;
}

uint32_t cpu_get_extended_features_ecx(void)
{
    uint32_t eax, ebx, ecx, edx;
    cpu_cpuid(7, 0, &eax, &ebx, &ecx, &edx);
    return ecx;
}

uint32_t cpu_get_extended_features_edx(void)
{
    uint32_t eax, ebx, ecx, edx;
    cpu_cpuid(7, 0, &eax, &ebx, &ecx, &edx);
    return edx;
}

/* Per-CPU GS base setup */

void cpu_init_per_cpu(u32 cpu_id)
{
    per_cpu_setup_gs_base(cpu_id);
}

void cpu_init_bsp_per_cpu(void)
{
    per_cpu_init(0, lapic_get_id(), 1);
    per_cpu_setup_gs_base(0);
}

void cpu_enable_security_features(void)
{
    uint32_t ebx = cpu_get_extended_features_ebx();

    /* Enable EFER.NXE so PTE_NX bit is honoured */
    uint64_t efer = cpu_read_msr(MSR_EFER);
    if (!(efer & EFER_NXE)) {
        efer |= EFER_NXE;
        cpu_write_msr(MSR_EFER, efer);
        kprintf("[CPU] EFER.NXE enabled\n");
    }

    /* Enable SMEP if supported by CPU */
    if (ebx & CPUID7_EBX_SMEP) {
        uint64_t cr4 = read_cr4();
        cr4 |= CR4_SMEP;
        write_cr4(cr4);
        kprintf("[kernel] SMEP enabled (CR4=0x%llx)\n", (unsigned long long)cr4);
    } else {
        kprintf("[kernel] SMEP not supported by CPU\n");
    }

    /* Enable SMAP if supported by CPU */
    if (ebx & CPUID7_EBX_SMAP) {
        uint64_t cr4 = read_cr4();
        cr4 |= CR4_SMAP;
        write_cr4(cr4);
        smap_enabled = 1;
        kprintf("[kernel] SMAP enabled (CR4=0x%llx)\n", (unsigned long long)cr4);
    } else {
        kprintf("[kernel] SMAP not supported by CPU\n");
    }
}