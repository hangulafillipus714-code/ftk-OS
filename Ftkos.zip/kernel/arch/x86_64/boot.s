section .text
global _start
extern kernel_main

_start:
    ; Clear direction flag
    cld
    
    ; Save boot info pointer passed by EFI stub
    mov [boot_info_ptr], rdi
    
    ; Set up stack
    mov rsp, stack_top
    
    ; Zero out BSS section
    extern bss_start
    extern bss_end
    mov rdi, bss_start
    mov rcx, bss_end
    sub rcx, rdi
    xor rax, rax
    rep stosb
    
    ; Set up GDT
    extern gdt_load
    call gdt_load
    
    ; Set up IDT
    extern idt_init
    call idt_init
    
    ; Set up paging
    extern paging_init
    call paging_init
    
    ; Jump to higher half kernel
    mov rax, higher_half
    jmp rax

higher_half:
    ; Now we're in higher half
    ; Call kernel main
    mov rdi, [boot_info_ptr]
    call kernel_main
    
    ; Halt if kernel_main returns
    cli
.hang:
    hlt
    jmp .hang

section .bss
align 16
stack_bottom:
    resb 65536  ; 64KB stack
stack_top:
boot_info_ptr:
    resq 1