/*
 * kernel/arch/x86_64/per_cpu.c — Per-CPU data management
 */

#include <ftk/per_cpu.h>
#include <ftk/apic.h>
#include <ftk/printk.h>
#include <ftk/memory.h>
#include <ftk/pmm.h>
#include <ftk/memory_layout.h>

per_cpu_data_t per_cpu_data[MAX_CPUS];

void per_cpu_init(u32 cpu_id, u32 apic_id, int is_bsp) {
    if (cpu_id >= MAX_CPUS) return;

    per_cpu_data_t *pcpu = &per_cpu_data[cpu_id];
    
    /* Zero the structure */
    for (size_t i = 0; i < sizeof(per_cpu_data_t); i++) {
        ((u8 *)pcpu)[i] = 0;
    }

    /* Set self-pointer (for this_cpu() macro */
    pcpu->self = pcpu;

    pcpu->cpu_id = cpu_id;
    pcpu->apic_id = apic_id;
    pcpu->is_bsp = is_bsp;

    /* Initialize scheduler runqueue lock */
    spinlock_init(&pcpu->runqueue_lock);

    /* Allocate kernel stack for this CPU if not BSP */
    if (!is_bsp) {
        phys_addr_t stack_phys = pmm_alloc_pages(4);  /* 16KB stack */
        if (stack_phys) {
            pcpu->kernel_stack_base = (void *)PHYS_TO_VIRT(stack_phys);
            pcpu->kernel_stack_top = (void *)((u64)pcpu->kernel_stack_base + 4 * PAGE_SIZE);
            kprintf("[PER-CPU] CPU %d: stack at %p-%p\n", 
                    cpu_id, pcpu->kernel_stack_base, pcpu->kernel_stack_top);
        }
    }

    kprintf("[PER-CPU] CPU %d (APIC %d) initialized%s\n", 
            cpu_id, apic_id, is_bsp ? " (BSP)" : "");
}

void per_cpu_setup_gs_base(u32 cpu_id) {
    if (cpu_id >= MAX_CPUS) return;
    
    per_cpu_data_t *pcpu = &per_cpu_data[cpu_id];
    
    /* Write GS base MSR */
    u64 base = (u64)pcpu;
    __asm__ volatile(
        "wrmsr"
        : : "c"(0xC0000101),  /* IA32_GS_BASE */
        "a"((u32)base),
        "d"((u32)(base >> 32))
        : "memory"
    );
    
    /* Also set kernel GS base for SWAPGS */
    __asm__ volatile(
        "wrmsr"
        : : "c"(0xC0000102),  /* IA32_KERNEL_GS_BASE */
        "a"((u32)base),
        "d"((u32)(base >> 32))
        : "memory"
    );
    
    kprintf("[PER-CPU] CPU %d GS base set to 0x%llx\n", cpu_id, base);
}

/* Called from AP trampoline after entering 64-bit mode */
void per_cpu_ap_init(void) {
    u32 cpu_id = this_cpu()->cpu_id;
    u32 apic_id = this_cpu()->apic_id;
    
    /* Initialize local APIC for this CPU */
    lapic_init();
    
    /* Set up GS base */
    per_cpu_setup_gs_base(cpu_id);
    
    kprintf("[PER-CPU] AP CPU %d (APIC %d) fully initialized\n", cpu_id, apic_id);
}