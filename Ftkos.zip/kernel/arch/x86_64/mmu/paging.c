#include <ftk/vmm.h>
#include <ftk/pmm.h>
#include <ftk/memory.h>
#include <ftk/string.h>
#include <ftk/panic.h>
#include <ftk/memory_layout.h>
#include <ftk/framebuffer.h>

extern AddressSpace kernel_space;

void paging_init(BootInfo *boot_info) {
    {
        const char *s = "[PAGING INIT]\n";
        while (*s) { __asm__ volatile("outb %0, %1" : : "a"((u8)*s++), "Nd"((u16)0x3F8)); }
    }
    { const char *s="A1:"; while(*s){ __asm__ volatile("outb %0,%1"::"a"((u8)*s++),"Nd"((u16)0x3F8)); } }
    phys_addr_t pml4_phys = pmm_alloc_page();
    if (!pml4_phys) PANIC("paging: failed to allocate PML4");
    { const char *s="B2:"; while(*s){ __asm__ volatile("outb %0,%1"::"a"((u8)*s++),"Nd"((u16)0x3F8)); } }
    kernel_space.pml4 = pml4_phys;
    kernel_space.pml4_virt = (u64*)PHYS_TO_VIRT(pml4_phys);
    memset(kernel_space.pml4_virt, 0, PAGE_SIZE);

    /* Map up to max of available regions AND any ACPI/reserved regions up to 4GB */
    u64 max_phys = 0x20000000;
    for(u32 i = 0; i < boot_info->mmap_count; i++) {
        if (boot_info->mmap[i].type != 1) continue;
        u64 end = boot_info->mmap[i].base + boot_info->mmap[i].length;
        if(end > max_phys && end <= 0x100000000ULL) max_phys = end;
    }

    /* Also cover ACPI table region (UEFI/OVMF places RSDP near top of 2GB) */
    if (max_phys < 0x80000000ULL) max_phys = 0x80000000ULL;
    max_phys = (max_phys + HUGE_PAGE_SIZE - 1) & ~(HUGE_PAGE_SIZE - 1);

    for (u64 i = 0; i < max_phys; i += HUGE_PAGE_SIZE) {
        if (vmm_map_page(&kernel_space, i, i, PTE_PRESENT | PTE_WRITABLE | PTE_HUGE))
            PANIC("paging: identity map failed");
        if (vmm_map_page(&kernel_space, KERNEL_VIRT_BASE + i, i, PTE_PRESENT | PTE_WRITABLE | PTE_HUGE))
            PANIC("paging: higher-half map failed");
    }
    { const char *s="C3:"; while(*s){ __asm__ volatile("outb %0,%1"::"a"((u8)*s++),"Nd"((u16)0x3F8)); } }

    if (boot_info && boot_info->fb.base) {
        { const char *s="D4:"; while(*s){ __asm__ volatile("outb %0,%1"::"a"((u8)*s++),"Nd"((u16)0x3F8)); } }
        u64 fb_base = boot_info->fb.base & ~(PAGE_SIZE - 1);
        u64 fb_size = (boot_info->fb.height * boot_info->fb.pitch + PAGE_SIZE - 1) & ~(PAGE_SIZE - 1);
        { const char *s="F5:"; while(*s){ __asm__ volatile("outb %0,%1"::"a"((u8)*s++),"Nd"((u16)0x3F8)); } }
        for (u64 i = 0; i < fb_size; i += PAGE_SIZE) {
            { const char *s="L"; while(*s){ __asm__ volatile("outb %0,%1"::"a"((u8)*s++),"Nd"((u16)0x3F8)); } }
            /* Identity map (legacy) */
            if (vmm_map_page(&kernel_space, fb_base + i, fb_base + i, PTE_PRESENT | PTE_WRITABLE))
                PANIC("paging: framebuffer map failed");
            { const char *s="M"; while(*s){ __asm__ volatile("outb %0,%1"::"a"((u8)*s++),"Nd"((u16)0x3F8)); } }
            /* Kernel-virtual alias in the top half, so the framebuffer stays
             * accessible after switching to a user address space (which clones
             * PML4 entries 256-511 only). */
            if (vmm_map_page(&kernel_space, FRAMEBUFFER_VIRT_BASE + i, fb_base + i,
                             PTE_PRESENT | PTE_WRITABLE))
                PANIC("paging: framebuffer virtual map failed");
            { const char *s="N"; while(*s){ __asm__ volatile("outb %0,%1"::"a"((u8)*s++),"Nd"((u16)0x3F8)); } }
        }
        { const char *s="G6:"; while(*s){ __asm__ volatile("outb %0,%1"::"a"((u8)*s++),"Nd"((u16)0x3F8)); } }
    }

    vmm_switch_address_space(&kernel_space);
    { const char *s="E5:"; while(*s){ __asm__ volatile("outb %0,%1"::"a"((u8)*s++),"Nd"((u16)0x3F8)); } }
    {
        const char *s = "[PAGING OK]\n";
        while (*s) { __asm__ volatile("outb %0, %1" : : "a"((u8)*s++), "Nd"((u16)0x3F8)); }
    }
}