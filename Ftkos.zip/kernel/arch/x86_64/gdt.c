#include <ftk/arch/x86_64/gdt.h>
#include <ftk/string.h>
#include <ftk/panic.h>
#include <ftk/printk.h>
#include <ftk/per_cpu.h>

static gdt_entry_t gdt[GDT_ENTRIES];
tss_t tss[MAX_CPUS];
gdt_ptr_t gdt_ptr;

void gdt_init(void) {
    gdt[0] = (gdt_entry_t){0};

    /* Kernel Code: present, ring0, code, readable */
    gdt[1] = (gdt_entry_t){
        .limit_low = 0xFFFF, .base_low = 0,
        .base_mid = 0, .access = 0x9A, .granularity = 0xA0,
        .base_high = 0
    };

    /* Kernel Data: present, ring0, data, writable */
    gdt[2] = (gdt_entry_t){
        .limit_low = 0xFFFF, .base_low = 0,
        .base_mid = 0, .access = 0x92, .granularity = 0xA0,
        .base_high = 0
    };

    /* User Data: present, ring3, data, writable (selector 0x18 = GDT_USER_DATA) */
    /* Granularity: G=1, D=0, bit5=0 (reserved for data segs), limit_hi=0 → 0x90 */
    gdt[3] = (gdt_entry_t){
        .limit_low = 0xFFFF, .base_low = 0,
        .base_mid = 0, .access = 0xF2, .granularity = 0x90,
        .base_high = 0
    };

    /* User Code: present, ring3, code, readable (selector 0x20 = GDT_USER_CODE) */
    /* Granularity: G=1, D=0, L=1 (bit5=1 for code segs), limit_hi=0 → 0xA0 */
    gdt[4] = (gdt_entry_t){
        .limit_low = 0xFFFF, .base_low = 0,
        .base_mid = 0, .access = 0xFA, .granularity = 0xA0,
        .base_high = 0
    };

    /* TSS descriptor — uses 2 GDT slots (entry 5 + 6) */
    u64 tss_base = (u64)&tss[0];
    gdt[5].limit_low = sizeof(tss_t) - 1;
    gdt[5].base_low = tss_base & 0xFFFF;
    gdt[5].base_mid = (tss_base >> 16) & 0xFF;
    gdt[5].access = 0x89; /* present, ring0, system=0, 32-bit TSS available */
    gdt[5].granularity = (sizeof(tss_t) >> 16) & 0x0F;
    gdt[5].base_high = (tss_base >> 24) & 0xFF;

    /* Upper 32 bits of TSS base go into the second TSS entry code.
     * In 64-bit mode, a system descriptor is 16 bytes (2 entries).
     * Entry 5 holds low 32b of base + limit/access. Entry 6 holds high 32b of base.
     */
    gdt[6].limit_low = (u16)(tss_base >> 32);
    gdt[6].base_low  = (u16)(tss_base >> 48);
    gdt[6].base_mid  = 0;
    gdt[6].access    = 0;
    gdt[6].granularity = 0;
    gdt[6].base_high = 0;

    gdt_ptr.limit = sizeof(gdt) - 1;
    gdt_ptr.base = (u64)gdt;

    /* Setup IST for #DF — use the top of the IST stack region */
    tss[0].ist[0] = (u64)ist_stack_top;  /* IST1 for Double Fault */

    gdt_load(&gdt_ptr);
    load_tr(0x28);  /* TSS selector = 5 * 8 */
}

/* Initialize GDT for AP CPU - each CPU has its own TSS */
void gdt_init_cpu(u32 cpu_id) {
    if (cpu_id >= MAX_CPUS) return;

    /* Use shared GDT but update TSS base for this CPU */
    u64 tss_base = (u64)&tss[cpu_id];
    
    gdt[5].limit_low = sizeof(tss_t) - 1;
    gdt[5].base_low = tss_base & 0xFFFF;
    gdt[5].base_mid = (tss_base >> 16) & 0xFF;
    gdt[5].access = 0x89;
    gdt[5].granularity = (sizeof(tss_t) >> 16) & 0x0F;
    gdt[5].base_high = (tss_base >> 24) & 0xFF;

    gdt[6].limit_low = (u16)(tss_base >> 32);
    gdt[6].base_low  = (u16)(tss_base >> 48);
    gdt[6].base_mid  = 0;
    gdt[6].access    = 0;
    gdt[6].granularity = 0;
    gdt[6].base_high = 0;

    gdt_ptr.limit = sizeof(gdt) - 1;
    gdt_ptr.base = (u64)gdt;

    /* Load GDT and TSS for this CPU */
    gdt_load(&gdt_ptr);
    load_tr(0x28);  /* TSS selector = 5 * 8 */

    kprintf("[GDT] CPU %d GDT/TSS initialized\n", cpu_id);
}

void tss_set_kernel_stack(u64 stack) {
    u32 cpu_id = this_cpu()->cpu_id;
    tss[cpu_id].rsp[0] = stack;
    kprintf("[DBG] tss_set_kernel_stack rsp0=0x%lx\n", stack);
}

u64 tss_rsp0_get(void) {
    u32 cpu_id = this_cpu()->cpu_id;
    return tss[cpu_id].rsp[0];
}