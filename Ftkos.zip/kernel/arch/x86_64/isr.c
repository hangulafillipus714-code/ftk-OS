/*
 * kernel/arch/x86_64/isr.c — Interrupt / Exception dispatch
 *
 * Panic-hardening policy:
 *   - Page fault (#PF, vector 14) in USER mode → log + kill the task,
 *     yield to the scheduler.  The kernel lives on.
 *   - Page fault in KERNEL mode → PANIC (real bug, must not continue).
 *   - General Protection Fault (#GP, vector 13) in user mode → kill task.
 *   - #GP in kernel mode → PANIC.
 *   - All other unhandled exceptions → PANIC regardless of mode.
 *   - Spurious / unregistered hardware IRQs (≥ 32) → log + EOI, continue.
 */

#include <ftk/arch/x86_64/isr.h>
#include <ftk/io.h>
#include <ftk/printk.h>
#include <ftk/abi/types.h>
#include <ftk/panic.h>
#include <ftk/stdbool.h>
#include <ftk/apic.h>
#include <ftk/scheduler.h>
#include <ftk/per_cpu.h>
#include <ftk/memory_layout.h>

/* ── Handler table ───────────────────────────────────────── */
isr_handler_t interrupt_handlers[256];

/* ── Exception names ─────────────────────────────────────── */
static const char *exc_names[] = {
    "Division By Zero",        /* 0  */
    "Debug",                   /* 1  */
    "NMI",                     /* 2  */
    "Breakpoint",              /* 3  */
    "Overflow",                /* 4  */
    "Bound Range Exceeded",    /* 5  */
    "Invalid Opcode",          /* 6  */
    "Device Not Available",    /* 7  */
    "Double Fault",            /* 8  */
    "Coprocessor Segment Overrun",/* 9 */
    "Invalid TSS",             /* 10 */
    "Segment Not Present",     /* 11 */
    "Stack-Segment Fault",     /* 12 */
    "General Protection Fault",/* 13 */
    "Page Fault",              /* 14 */
    "Reserved",                /* 15 */
    "x87 FP Exception",        /* 16 */
    "Alignment Check",         /* 17 */
    "Machine Check",           /* 18 */
    "SIMD FP Exception",       /* 19 */
    "Virtualisation Exception",/* 20 */
    "Control-Protection",      /* 21 */
};

/* ── Register dump ───────────────────────────────────────── */
static void dump_regs(Registers *r)
{
    kprintf("\n=== CPU STATE DUMP ===\n");
    kprintf("RAX=%p RBX=%p RCX=%p RDX=%p\n", r->rax, r->rbx, r->rcx, r->rdx);
    kprintf("RSI=%p RDI=%p RBP=%p RSP=%p\n", r->rsi, r->rdi, r->rbp, r->rsp);
    kprintf("R8 =%p R9 =%p R10=%p R11=%p\n", r->r8,  r->r9,  r->r10, r->r11);
    kprintf("R12=%p R13=%p R14=%p R15=%p\n", r->r12, r->r13, r->r14, r->r15);
    kprintf("RIP=%p  CS=%p  RFLAGS=%p\n",    r->rip, r->cs,  r->rflags);
    kprintf("SS =%p INT=%u  ERR=%p\n",        r->ss,  r->int_no, r->err_code);
    if (r->int_no == 14) {
        u64 cr2; __asm__ volatile("movq %%cr2,%0":"=r"(cr2));
        kprintf("CR2=%p  (faulting virtual address)\n", cr2);
    }
    kprintf("======================\n");
}

/* ── Is fault from user mode? ────────────────────────────── */
static inline bool from_user(Registers *r)
{
    /* CS low 2 bits = privilege level; 3 = user (ring 3) */
    return (r->cs & 3) == 3;
}

/* ── Kill the current task and yield ────────────────────── */
static void kill_current_task(void)
{
    if (current_task) {
        kprintf("[ISR] Killing user task '%s' (PID %u) due to fault\n",
                current_task->name, current_task->pid);
        scheduler_exit_current(-1);
        /* scheduler_exit_current does not return */
    }
    /* Should not reach here */
    PANIC("kill_current_task: no current task to kill");
}

/* ── Handler registration ────────────────────────────────── */
void isr_register_handler(u8 vector, isr_handler_t handler)
{
    interrupt_handlers[vector] = handler;
}

/* ── RAW serial (no kprintf/framebuffer — avoids recursion) ── */
static void raw_putc(char c)
{
    __asm__ volatile("outb %0, %1" : : "a"((u8)c), "Nd"((u16)0x3F8));
}
static void raw_puts(const char *s)
{
    while (*s) raw_putc(*s++);
}
static void raw_hex(u64 v)
{
    const char *h = "0123456789abcdef";
    raw_putc('0'); raw_putc('x');
    for (int i = 60; i >= 0; i -= 4) raw_putc(h[(v >> i) & 0xf]);
}
static void raw_pf_dump(u64 cr2, u64 cr3, u64 err, u64 rip)
{
    u64 rsp;
    __asm__ volatile("mov %%rsp, %0" : "=r"(rsp));
    raw_puts("\n[RAWPF] cr2="); raw_hex(cr2);
    raw_puts(" cr3="); raw_hex(cr3);
    raw_puts(" err="); raw_hex(err);
    raw_puts(" rip="); raw_hex(rip);
    raw_puts(" rsp="); raw_hex(rsp);
    if (current_task) { raw_puts(" task="); raw_hex(current_task->pid); }
    extern u64 tss_rsp0_get(void);
    raw_puts(" rsp0="); raw_hex(tss_rsp0_get());
    u64 pml4_idx = (cr2 >> 39) & 0x1ff, pdpt_idx = (cr2 >> 30) & 0x1ff;
    u64 pd_idx   = (cr2 >> 21) & 0x1ff, pt_idx   = (cr2 >> 12) & 0x1ff;
    u64 *pml4 = (u64*)(KERNEL_VIRT_BASE + (cr3 & ~0xfffULL));
    u64 pml4e = pml4[pml4_idx];
    raw_puts(" pml4e="); raw_hex(pml4e);
    raw_puts(" pml4[0]="); raw_hex(pml4[0]);
    raw_puts(" pml4[511]="); raw_hex(pml4[511]);
    if (pml4e & 1) {
        u64 *pdpt = (u64*)(KERNEL_VIRT_BASE + (pml4e & ~0xfffULL));
        u64 pdpte = pdpt[pdpt_idx];
        raw_puts(" pdpte="); raw_hex(pdpte);
        if (pdpte & 1) {
            u64 *pd = (u64*)(KERNEL_VIRT_BASE + (pdpte & ~0xfffULL));
            u64 pde = pd[pd_idx];
            raw_puts(" pde="); raw_hex(pde);
            if ((pde & 1) && !(pde & 0x80)) {
                u64 *pt = (u64*)(KERNEL_VIRT_BASE + (pde & ~0xfffULL));
                raw_puts(" pte="); raw_hex(pt[pt_idx]);
            }
        }
    }
    raw_putc('\n');
    u64 *p = (u64*)rsp;
    for (int i = 0; i < 40; i++) {
        raw_puts("  S"); raw_hex(i); raw_puts("="); raw_hex(p[i]);
    }
    raw_putc('\n');
}

/* ── Central ISR dispatch ────────────────────────────────── */

/* DEBUG: a kernel stack landing inside the LAPIC PD/PT alias region
 * (phys 0x11a000-0x11bfff → virt 0xffffffff8011a000) is the corruption
 * under investigation.  Catch it and dump the call chain. */
static void dbg_trap_bogus_stack(Registers *regs)
{
    u64 cur_rsp;
    __asm__ volatile("mov %%rsp, %0" : "=r"(cur_rsp));
    if (cur_rsp >= 0xffffffff8011a000ULL && cur_rsp <= 0xffffffff8011bfffULL) {
        extern u64 tss_rsp0_get(void);
        kprintf("\n*** BOGUS KERNEL STACK in LAPIC PD/PT alias region ***\n");
        kprintf("RSP=0x%lx vec=%u RIP=0x%lx RBP=0x%lx\n",
                cur_rsp, regs->int_no, regs->rip, regs->rbp);
        kprintf("TSS rsp0=0x%lx\n", tss_rsp0_get());
        kprintf("err=0x%lx cs=0x%lx ss=0x%lx\n",
                (unsigned long)regs->err_code, regs->cs, regs->ss);
        u64 *p = (u64 *)cur_rsp;
        for (int i = 0; i < 64 && p < (u64 *)0xffffffff8011c000; i++, p++) {
            kprintf("  +%03x: 0x%lx\n", (unsigned)((char*)p - (char*)cur_rsp), *p);
        }
        __asm__ volatile("cli");
        for (;;) __asm__ volatile("hlt");
    }
}

void isr_handler(Registers *regs)
{
    u32  vec     = regs->int_no;
    bool is_irq  = (vec >= 32 && vec < 256);
    bool handled = false;

    dbg_trap_bogus_stack(regs);

    /* Dispatch to registered handler (tests, drivers) */
    if (interrupt_handlers[vec]) {
        interrupt_handlers[vec](regs);
        handled = true;
    }

    /* ── CPU exception path (vec < 32) ──────────────────── */
    if (!handled && vec < 32) {
        const char *name = (vec < 22) ? exc_names[vec] : "Reserved";

        /* Page Fault (#PF) — differentiate user vs kernel */
        if (vec == 14) {
            u64 cr2; __asm__ volatile("movq %%cr2,%0":"=r"(cr2));
            u64 cr3; __asm__ volatile("movq %%cr3,%0":"=r"(cr3));
            raw_pf_dump(cr2, cr3, regs->err_code, regs->rip);
            kprintf("[PF] %s: CR2=%p err=%u RIP=%p %s\n",
                    name, cr2, (u32)regs->err_code, regs->rip,
                    from_user(regs) ? "(user)" : "(KERNEL)");
            if (from_user(regs)) {
                dump_regs(regs);
                kill_current_task();
                /* does not return */
            }
            /* Kernel page fault → panic */
            dump_regs(regs);
            PANIC("Kernel page fault — memory corruption or bad pointer");
        }

        /* General Protection Fault (#GP) */
        if (vec == 13) {
            kprintf("[GP] err=%u RIP=%p %s\n",
                    (u32)regs->err_code, regs->rip,
                    from_user(regs) ? "(user)" : "(KERNEL)");
            if (from_user(regs)) {
                dump_regs(regs);
                kill_current_task();
            }
            dump_regs(regs);
            PANIC("Kernel general protection fault");
        }

        /* Invalid Opcode from user (#UD) */
        if (vec == 6 && from_user(regs)) {
            kprintf("[UD] Invalid opcode in user task RIP=%p — killing\n",
                    regs->rip);
            kill_current_task();
        }

        /* All other exceptions → kernel panic */
        kprintf("\n*** EXCEPTION: %s (vector %u) RIP=%p ***\n",
                name, vec, regs->rip);
        dump_regs(regs);
        PANIC("Unhandled CPU exception");
    }

    /* ── Hardware IRQ EOI ────────────────────────────────── */
    if (is_irq) {
        /* LAPIC EOI (if APIC is active) */
        if (lapic_base) {
            lapic_eoi();
        }
        /* Legacy PIC EOI (belt-and-suspenders on QEMU) */
        if (vec >= 40) outb(0xA0, 0x20); /* slave PIC */
        outb(0x20, 0x20);                /* master PIC */

        if (!handled) {
            kprintf("[IRQ] Unregistered vector %u — ignored\n", vec);
        }
    }
}

void irq_handler(Registers *regs)  { (void)regs; }
void isr_generic_handler(void)
{
    kprintf("isr_generic_handler: spurious interrupt\n");
}
