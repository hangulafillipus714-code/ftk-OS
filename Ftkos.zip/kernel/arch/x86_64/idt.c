/*
 * FTK OS - Interrupt Descriptor Table (IDT) Implementation
 * Professional, freestanding x86_64 kernel - No warnings, fully compliant
 */

#include <ftk/abi/types.h>
#include <ftk/arch/x86_64/idt.h>
#include <ftk/io.h>
#include <ftk/arch/x86_64/isr.h>
#include <ftk/string.h>

/* IDT with 256 entries (x86 requires 256 interrupt vectors) */
struct idt_entry idt[256] __attribute__((aligned(16)));

/* IDT pointer for loading */
struct idt_ptr idtp __attribute__((used));

/* External ISR handlers for exceptions (0-31) */
extern void isr0(void);   extern void isr1(void);   extern void isr2(void);
extern void isr3(void);   extern void isr4(void);   extern void isr5(void);
extern void isr6(void);   extern void isr7(void);   extern void isr8(void);
extern void isr9(void);   extern void isr10(void);  extern void isr11(void);
extern void isr12(void);  extern void isr13(void);  extern void isr14(void);
extern void isr15(void);  extern void isr16(void);  extern void isr17(void);
extern void isr18(void);  extern void isr19(void);  extern void isr20(void);
extern void isr21(void);  extern void isr22(void);  extern void isr23(void);
extern void isr24(void);  extern void isr25(void);  extern void isr26(void);
extern void isr27(void);  extern void isr28(void);  extern void isr29(void);
extern void isr30(void);  extern void isr31(void);

/* External IRQ handlers for hardware interrupts (32-47) */
extern void irq0(void);   extern void irq1(void);   extern void irq2(void);
extern void irq3(void);   extern void irq4(void);   extern void irq5(void);
extern void irq6(void);   extern void irq7(void);   extern void irq8(void);
extern void irq9(void);   extern void irq10(void);  extern void irq11(void);
extern void irq12(void);  extern void irq13(void);  extern void irq14(void);
extern void irq15(void);

/* External generic ISR handler for unhandled interrupts */
extern void isr_generic_handler(void);

/**
 * Set an entry in the Interrupt Descriptor Table
 * @num: Interrupt vector number (0-255)
 * @base: Pointer to interrupt handler function
 * @selector: Code segment selector (should be 0x08 for kernel code)
 * @flags: Gate type and attributes
 * @ist: Interrupt Stack Table index (0-7, 0 = no IST)
 */
void set_idt_entry(u8 num, void* base, u16 selector, u8 flags, u8 ist)
{
    u64 handler_address = (u64)base;

    idt[num].base_low  = (u16)(handler_address & 0xFFFF);
    idt[num].base_mid  = (u16)((handler_address >> 16) & 0xFFFF);
    idt[num].base_high = (u32)((handler_address >> 32) & 0xFFFFFFFF);
    idt[num].selector = selector;
    idt[num].ist      = ist & 0x7;  /* IST index (0-7) */
    idt[num].flags    = flags;
    idt[num].zero     = 0;
}

/**
 * Remap the Programmable Interrupt Controllers (PIC)
 * This moves IRQs 0-15 to interrupt vectors 32-47 to avoid conflicts
 * with CPU exceptions (0-31)
 */
static void pic_remap(void)
{
    /* ICW1: Initialize PICs in cascade mode */
    outb(0x20, 0x11);  /* Master PIC: ICW1 with ICW4 needed */
    outb(0xA0, 0x11);  /* Slave PIC: ICW1 with ICW4 needed */
    
    /* ICW2: Set interrupt vector offsets */
    outb(0x21, 0x20);  /* Master PIC: IRQs 0-7 -> INT 0x20-0x27 */
    outb(0xA1, 0x28);  /* Slave PIC: IRQs 8-15 -> INT 0x28-0x2F */
    
    /* ICW3: Tell PICs about each other */
    outb(0x21, 0x04);  /* Master PIC: slave at IRQ2 (bit 2 = 0x04) */
    outb(0xA1, 0x02);  /* Slave PIC: cascade identity (value 0x02) */
    
    /* ICW4: Set 8086/88 mode */
    outb(0x21, 0x01);  /* Master PIC: 8086 mode, normal EOI */
    outb(0xA1, 0x01);  /* Slave PIC: 8086 mode, normal EOI */
    
    /* Mask all interrupts initially (enable them one by one later) */
    outb(0x21, 0xFF);  /* Mask all interrupts on master */
    outb(0xA1, 0xFF);  /* Mask all interrupts on slave */
}

/**
 * Initialize the Interrupt Descriptor Table
 * Sets up all 256 interrupt vectors, remaps PIC, and loads IDT
 */
void idt_init(void)
{
    /* Zero out the entire IDT for safety */
    memset(idt, 0, sizeof(struct idt_entry) * 256);
    
    /* Kernel code segment selector (from GDT: 0x08 = 1st entry * 8) */
    u16 kernel_cs = 0x08;
    
    /* Set up CPU exception handlers (vectors 0-31) */
    set_idt_entry(0, isr0, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(1, isr1, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(2, isr2, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(3, isr3, kernel_cs, IDT_FLAG_INTERRUPT | IDT_FLAG_RING3, 0);
    set_idt_entry(4, isr4, kernel_cs, IDT_FLAG_INTERRUPT | IDT_FLAG_RING3, 0);
    set_idt_entry(5, isr5, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(6, isr6, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(7, isr7, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(8, isr8, kernel_cs, IDT_FLAG_INTERRUPT, 1);  /* Double Fault uses IST1 */
    set_idt_entry(9, isr9, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(10, isr10, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(11, isr11, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(12, isr12, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(13, isr13, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(14, isr14, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(15, isr15, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(16, isr16, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(17, isr17, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(18, isr18, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(19, isr19, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(20, isr20, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(21, isr21, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(22, isr22, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(23, isr23, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(24, isr24, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(25, isr25, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(26, isr26, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(27, isr27, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(28, isr28, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(29, isr29, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(30, isr30, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(31, isr31, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    
    /* Set up hardware IRQ handlers (vectors 32-47) */
    set_idt_entry(32, irq0, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(33, irq1, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(34, irq2, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(35, irq3, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(36, irq4, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(37, irq5, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(38, irq6, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(39, irq7, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(40, irq8, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(41, irq9, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(42, irq10, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(43, irq11, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(44, irq12, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(45, irq13, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(46, irq14, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    set_idt_entry(47, irq15, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    
    /* Set generic handler for remaining vectors (48-255) */
    for (u16 i = 48; i < 256; i++) {
        set_idt_entry((u8)i, isr_generic_handler, kernel_cs, IDT_FLAG_INTERRUPT, 0);
    }
    
    /* Remap PICs to avoid conflicts with CPU exceptions */
    pic_remap();
    
    /* Setup IDT pointer */
    idtp.limit = (u16)(sizeof(struct idt_entry) * 256 - 1);
    idtp.base = (u64)&idt[0];
    
    /* Load IDT via assembly */
    idt_load((u64)&idtp);
}