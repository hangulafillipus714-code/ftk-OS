#ifndef FTK_STDDEF_H
#define FTK_STDDEF_H

#include <ftk/abi/types.h>

/* Null pointer */
#define NULL ((void*)0)

/* Pointer difference type */
typedef long ptrdiff_t;

/* offsetof macro */
#define offsetof(type, member) ((size_t) &(((type *)0)->member))

#endif /* FTK_STDDEF_H */