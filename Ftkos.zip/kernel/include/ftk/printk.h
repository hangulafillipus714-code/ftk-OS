#ifndef FTK_PRINTK_H
#define FTK_PRINTK_H

#include <ftk/abi/types.h>
#include <ftk/stddef.h>

void kprintf(const char *fmt, ...);
int ksnprintf(char *buf, size_t size, const char *fmt, ...);

#endif