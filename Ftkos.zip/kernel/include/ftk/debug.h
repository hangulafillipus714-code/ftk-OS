#ifndef FTK_DEBUG_H
#define FTK_DEBUG_H

void debug_putchar(char c);
void debug_puts(const char *str);
void debug_hexdump(const void *data, size_t size);

#endif