#ifndef FTK_FS_RAMFS_H
#define FTK_FS_RAMFS_H

void ramfs_init(void);

#endif
