#ifndef FTK_FS_FAT32_H
#define FTK_FS_FAT32_H

#include <ftk/abi/types.h>
#include <ftk/fs/vfs.h>

typedef struct {
    u8  jump[3];
    u8  oem[8];
    u16 bytes_per_sector;
    u8  sectors_per_cluster;
    u16 reserved_sectors;
    u8  fat_count;
    u16 root_entries;
    u16 total_sectors_16;
    u8  media_descriptor;
    u16 sectors_per_fat_16;
    u16 sectors_per_track;
    u16 heads;
    u32 hidden_sectors;
    u32 total_sectors_32;
    u32 sectors_per_fat_32;
    u16 ext_flags;
    u16 fs_version;
    u32 root_cluster;
    u16 fs_info_sector;
    u16 backup_boot_sector;
    u8  reserved[12];
    u8  drive_number;
    u8  reserved1;
    u8  boot_signature;
    u32 volume_id;
    u8  volume_label[11];
    u8  fs_type[8];
} __attribute__((packed)) fat32_bpb_t;

#define FAT32_EOC 0x0FFFFFF8
#define FAT32_FREE 0x00000000

void fat32_init(void);
vfs_node_t* fat32_open(const char* path);

#endif
