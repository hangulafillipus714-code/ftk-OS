#ifndef FTK_FS_VFS_H
#define FTK_FS_VFS_H

#include <ftk/abi/types.h>

typedef enum { VFS_FILE, VFS_DIRECTORY, VFS_BLOCK_DEVICE } vfs_type_t;

typedef struct {
    char name[256];
    u32  inode;
    u32  size;
    u8   attributes;
} vfs_dirent_t;

struct vfs_node;
struct filesystem;

typedef struct vfs_node {
    char name[256];
    vfs_type_t type;
    u64 size;
    u32 inode;
    struct vfs_node* parent;
    struct filesystem *fs;           /* owning filesystem */
    void *private_data;              /* fs-specific (e.g. cluster for FAT32) */
    int refcount;                    /* reference count for fd table sharing */
    int (*read)(struct vfs_node* node, u64 offset, u64 size, void* buffer);
    int (*readdir)(struct vfs_node* node, u64 index, vfs_dirent_t* entry);
} vfs_node_t;

/*
 * Filesystem driver interface.
 * Each registered filesystem provides open + readdir operations.
 */
typedef struct filesystem {
    const char *name;
    vfs_node_t* (*open)(struct filesystem *fs, const char *path);
    int (*readdir)(struct vfs_node *node, u64 index, vfs_dirent_t *entry);
    void (*destroy_node)(struct vfs_node *node);
} filesystem_t;

/* Mount entry: maps a mount point path to a filesystem instance */
typedef struct mount {
    char path[256];
    filesystem_t *fs;
    void *private_data;              /* e.g., root cluster number */
    struct mount *next;
} mount_t;

/* VFS API */
void vfs_init(void);
int vfs_register_filesystem(filesystem_t *fs);
int vfs_mount(const char *path, const char *fs_name, void *private_data);
vfs_node_t* vfs_open(const char *path);
int vfs_readdir(vfs_node_t* node, u64 index, vfs_dirent_t* entry);
void vfs_node_close(vfs_node_t *node);

#endif
