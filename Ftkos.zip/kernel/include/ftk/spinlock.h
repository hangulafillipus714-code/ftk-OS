#ifndef FTK_SPINLOCK_H
#define FTK_SPINLOCK_H

#include <ftk/abi/types.h>

typedef struct spinlock {
    volatile u32 locked;
} spinlock_t;

#define SPINLOCK_INIT { 0 }

static inline void spinlock_init(spinlock_t *lock) {
    lock->locked = 0;
}

static inline void spinlock_acquire(spinlock_t *lock) {
    while (__sync_lock_test_and_set(&lock->locked, 1)) {
        while (lock->locked) {
            __asm__ volatile("pause");
        }
    }
}

static inline void spinlock_release(spinlock_t *lock) {
    __sync_lock_release(&lock->locked);
}

static inline int spinlock_try_acquire(spinlock_t *lock) {
    return !__sync_lock_test_and_set(&lock->locked, 1);
}

static inline void spinlock_acquire_irqsave(spinlock_t *lock, u64 *rflags) {
    __asm__ volatile("pushfq; pop %0; cli" : "=r" (*rflags) : : "memory");
    spinlock_acquire(lock);
}

static inline void spinlock_release_irqrestore(spinlock_t *lock, u64 rflags) {
    spinlock_release(lock);
    __asm__ volatile("push %0; popfq" : : "r" (rflags) : "memory");
}

#endif /* FTK_SPINLOCK_H */