/* ftk/pmm.h */
#ifndef FTK_PMM_H
#define FTK_PMM_H

#include <ftk/abi/types.h>
#include <ftk/memory_layout.h>
#include <ftk/stddef.h>
#include <ftk/stdbool.h>

/* Page constants (must match memory_layout.h) */
#define PAGE_SHIFT 12

_Static_assert(PAGE_SIZE == 4096, "PMM: PAGE_SIZE mismatch");

/* Alignment helpers */
#ifndef ALIGN_UP
#define ALIGN_UP(addr, align)   (((addr) + (align) - 1) & ~((align) - 1))
#endif
#ifndef ALIGN_DOWN
#define ALIGN_DOWN(addr, align) ((addr) & ~((align) - 1))
#endif
#define PAGE_ALIGN_UP(addr)     ALIGN_UP(addr, PAGE_SIZE)
#define PAGE_ALIGN_DOWN(addr)   ALIGN_DOWN(addr, PAGE_SIZE)

/* Memory region descriptor */
#define MAX_MEMORY_REGIONS 32

typedef struct mem_region {
    phys_addr_t start;          /* Page-aligned start */
    phys_addr_t end;            /* Page-aligned end (exclusive) */
    size_t total_pages;         /* Total pages in region */
    size_t free_pages;          /* Free pages in region */
    size_t bitmap_offset;       /* Bit offset into global bitmap */
    size_t last_scanned_index;  /* Last scanned page for O(1) allocation */
    bool valid;                 /* Region is initialized */
} mem_region_t;

/*
 * Initialize PMM with bootloader memory map
 *
 * boot_info_ptr:
 *   Virtual address of BootInfo structure
 *
 * Requirements:
 *   - Must be called exactly once
 *   - Must be called before VMM init
 */
void pmm_init(uintptr_t boot_info_ptr);

/*
 * Allocate a single physical page
 *
 * Returns:
 *   Physical address of allocated page, or 0 on failure
 */
phys_addr_t pmm_alloc_page(void);

/*
 * Allocate multiple contiguous physical pages
 *
 * count:
 *   Number of pages to allocate (must be > 0)
 *
 * Returns:
 *   Physical address of first page, or 0 on failure
 */
phys_addr_t pmm_alloc_pages(size_t count);

/*
 * Free a single physical page
 */
void pmm_free_page(phys_addr_t page);

/*
 * Free multiple contiguous physical pages
 */
void pmm_free_pages(phys_addr_t page, size_t count);

/*
 * Get number of free pages
 */
size_t pmm_get_free_page_count(void);

/*
 * Get total number of managed pages
 */
size_t pmm_get_total_page_count(void);

/*
 * Get start of first managed physical memory region
 */
phys_addr_t pmm_get_region_start(void);

/*
 * Get end of last managed physical memory region
 */
phys_addr_t pmm_get_region_end(void);

/*
 * Get bitmap physical address
 */
phys_addr_t pmm_get_bitmap_phys(void);

/*
 * Get bitmap size in bytes
 */
size_t pmm_get_bitmap_size(void);

/*
 * Update bitmap virtual address after VMM remap
 *
 * new_virt_addr:
 *   New virtual address of bitmap
 */
void pmm_set_bitmap_virt(virt_addr_t new_virt_addr);

/*
 * Get number of memory regions
 */
size_t pmm_get_region_count(void);

/*
 * Get memory region by index
 */
mem_region_t *pmm_get_region(size_t index);

#endif /* FTK_PMM_H */