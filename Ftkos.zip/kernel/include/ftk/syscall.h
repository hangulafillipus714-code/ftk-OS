#ifndef FTK_SYSCALL_H
#define FTK_SYSCALL_H

#include <ftk/abi/types.h>
#include <ftk/abi/syscall.h>

/*
 * SyscallFrame – register state saved by syscall_entry (syscall_entry.S)
 * on the kernel stack before the C dispatcher is called.
 *
 * Layout must match the push order in syscall_entry.S exactly.
 * Offsets are used by the assembly stub so keep in sync!
 */
typedef struct SyscallFrame {
    /*
     * Field order = ascending memory address = reverse of push order.
     * syscall_entry.S pushes: r15 first (highest addr), rax last (lowest addr).
     * So rax is at offset 0 (RSP after all pushes), r15 is at offset 14*8.
     */
    u64 rax;                    /* offset  0: syscall nr / return val */
    u64 rcx;                    /* offset  8: user RIP (SYSCALL→RCX) */
    u64 rdi;                    /* offset 16: arg1                    */
    u64 rsi;                    /* offset 24: arg2                    */
    u64 rdx;                    /* offset 32: arg3                    */
    u64 r8;                     /* offset 40: arg5                    */
    u64 r9;                     /* offset 48: arg6                    */
    u64 r10;                    /* offset 56: arg4                    */
    u64 r11;                    /* offset 64: RFLAGS (SYSCALL→R11)   */
    u64 rbx;                    /* offset 72: callee-saved            */
    u64 rbp;                    /* offset 80: callee-saved            */
    u64 r12;                    /* offset 88: callee-saved            */
    u64 r13;                    /* offset 96: callee-saved            */
    u64 r14;                    /* offset 104: callee-saved           */
    u64 r15;                    /* offset 112: callee-saved           */
} SyscallFrame;

/*
 * syscall_handler_t – signature for individual syscall implementations.
 * Returns value placed in RAX on sysret.
 */
typedef s64 (*syscall_handler_t)(SyscallFrame *frame);

/* ── Public API ──────────────────────────────────────────── */

/* Called once from kernel_main() after GDT/IDT are ready. */
void syscall_init(void);

/*
 * C-level dispatcher – called from syscall_entry.S.
 * Do NOT call directly from C.
 */
void syscall_dispatch(SyscallFrame *frame);

/* Query whether syscall subsystem is active (for tests). */
int  syscall_is_initialized(void);

/* Retrieve MSR_LSTAR value (for tests). */
u64  syscall_get_lstar(void);

/*
 * Update the per-CPU kernel stack pointer used by the SYSCALL entry.
 * Called from the scheduler on every context switch so that each task
 * uses its own kernel stack for syscall handling.
 */
void syscall_set_kstack(u64 rsp);

#endif /* FTK_SYSCALL_H */