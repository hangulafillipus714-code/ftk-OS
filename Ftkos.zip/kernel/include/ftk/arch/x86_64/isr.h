#ifndef _FTK_ISR_H
#define _FTK_ISR_H

#include <ftk/abi/types.h>

/*
 * x86_64 interrupt stack frame
 * MUST match what your assembly pushes
 */
typedef struct Registers {
    u64 r15, r14, r13, r12, r11, r10, r9, r8;
    u64 rsi, rdi, rbp, rdx, rcx, rbx, rax;
    u64 int_no;
    u64 err_code;
    u64 rip, cs, rflags, rsp, ss;
} Registers;

/* ISR handler function type */
typedef void (*isr_handler_t)(Registers *regs);

/* Register an ISR handler */
void isr_register_handler(u8 interrupt, isr_handler_t handler);

/* Common ISR handler (called from ASM) */
void isr_handler(Registers *regs);

/* IRQ handler */
void irq_handler(Registers *regs);

#endif /* _FTK_ISR_H */