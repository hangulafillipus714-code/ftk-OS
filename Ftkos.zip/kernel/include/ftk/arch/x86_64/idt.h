#ifndef _FTK_IDT_H
#define _FTK_IDT_H

#include <ftk/abi/types.h>

/* Interrupt Descriptor Table Entry (16 bytes in 64-bit mode) */
struct idt_entry {
    u16 base_low;      /* Lower 16 bits of handler address */
    u16 selector;      /* Kernel code segment selector */
    u8  ist;           /* Interrupt Stack Table (0 for no IST) */
    u8  flags;         /* Type attributes (P, DPL, gate type) */
    u16 base_mid;      /* Middle 16 bits of handler address */
    u32 base_high;     /* Upper 32 bits of handler address */
    u32 zero;          /* Must be zero (reserved) */
} __attribute__((packed));

/* IDT Pointer for LIDT instruction (10 bytes) */
struct idt_ptr {
    u16 limit;         /* Size of IDT minus 1 */
    u64 base;          /* Linear address of IDT */
} __attribute__((packed));

/* IDT Flags (Type and Attributes) */
#define IDT_FLAG_PRESENT    (1 << 7)      /* Segment present in memory */
#define IDT_FLAG_RING0      (0 << 5)      /* Descriptor privilege level 0 */
#define IDT_FLAG_RING3      (3 << 5)      /* Descriptor privilege level 3 */
#define IDT_FLAG_STORAGE    (1 << 4)      /* Storage segment (S=0 for gates; S=1 for code/data) */

/* Gate Types (bits 0-3 of flags) */
#define IDT_GATE_TASK32     0x5           /* 32-bit task gate */
#define IDT_GATE_INT16      0x6           /* 16-bit interrupt gate */
#define IDT_GATE_TRAP16     0x7           /* 16-bit trap gate */
#define IDT_GATE_INT32      0xE           /* 32-bit interrupt gate */
#define IDT_GATE_TRAP32     0xF           /* 32-bit trap gate */

/* Combined flag values for common cases */
/* Gate descriptors MUST have S=0 (bit 4). S=1 marks a code/data segment, not a gate. */
#define IDT_FLAG_INTERRUPT  (IDT_FLAG_PRESENT | IDT_FLAG_RING0 | IDT_GATE_INT32)
#define IDT_FLAG_TRAP       (IDT_FLAG_PRESENT | IDT_FLAG_RING0 | IDT_GATE_TRAP32)

/* External assembly function to load IDT */
extern void idt_load(u64 ptr);

/* Function prototypes */
void idt_init(void);
void set_idt_entry(u8 num, void* base, u16 selector, u8 flags, u8 ist);

/* For testing/inspection */
extern struct idt_entry idt[256];
extern struct idt_ptr idtp;

#endif /* _FTK_IDT_H */