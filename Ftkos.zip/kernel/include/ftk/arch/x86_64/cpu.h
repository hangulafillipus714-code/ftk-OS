#pragma once
/*
 * x86_64 CPU control
 * This file is part of the FTK kernel heart.
 * DO NOT add policy here. DO NOT include high-level headers.
 */

#include <ftk/stdint.h>
#include <ftk/apic.h>

/* Control register access */
void write_cr0(uint64_t value);
uint64_t read_cr0(void);

void write_cr3(uint64_t value);
uint64_t read_cr3(void);

void write_cr4(uint64_t value);
uint64_t read_cr4(void);

/* CPU instructions */
void cpu_halt(void);
void cpu_pause(void);

/* Interrupt control */
void cpu_enable_interrupts(void);
void cpu_disable_interrupts(void);

/* Model Specific Registers */
uint64_t cpu_read_msr(uint32_t msr);
void cpu_write_msr(uint32_t msr, uint64_t value);

/* Time Stamp Counter */
uint64_t read_tsc(void);

/* CPUID */
void cpu_cpuid(uint32_t leaf, uint32_t subleaf, uint32_t *eax, uint32_t *ebx, uint32_t *ecx, uint32_t *edx);
uint32_t cpu_get_vendor_id(char *buf);
uint32_t cpu_get_brand_string(char *buf);
uint32_t cpu_get_feature_flags_ecx(void);
uint32_t cpu_get_feature_flags_edx(void);
uint32_t cpu_get_extended_features_ebx(void);
uint32_t cpu_get_extended_features_ecx(void);
uint32_t cpu_get_extended_features_edx(void);

/* CR4 feature bits */
#define CR4_SMEP    (1ULL << 20)
#define CR4_SMAP    (1ULL << 21)

/* EFER bits */
#define EFER_NXE    (1ULL << 11)

/* CPUID feature flags (leaf 7 EBX) */
#define CPUID7_EBX_SMEP   (1U << 7)
#define CPUID7_EBX_SMAP   (1U << 20)

/* Per-CPU initialization */
void cpu_init_per_cpu(u32 cpu_id);
void cpu_init_bsp_per_cpu(void);

/* Enable hardware security features (SMEP, SMAP, NXE) */
void cpu_enable_security_features(void);

/* Returns 1 if SMAP is supported and was enabled on this CPU */
int cpu_smap_enabled(void);