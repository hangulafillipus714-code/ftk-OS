#ifndef _FTK_GDT_H
#define _FTK_GDT_H

#include <ftk/abi/types.h>
#include <ftk/per_cpu.h>

/* GDT Entry count — null + 4 segments + TSS (2 entries for 64-bit) */
#define GDT_ENTRIES 7

/* GDT Entry Structure (8 bytes) */
typedef struct gdt_entry {
    u16 limit_low;
    u16 base_low;
    u8  base_mid;
    u8  access;
    u8  granularity;
    u8  base_high;
} __attribute__((packed)) gdt_entry_t;

/* GDT Pointer Structure (10 bytes) */
typedef struct gdt_ptr {
    u16 limit;
    u64 base;
} __attribute__((packed)) gdt_ptr_t;

/* Task State Segment (x86_64, 104 bytes) */
typedef struct tss {
    u32 reserved0;
    u64 rsp[3];
    u64 reserved1;
    u64 ist[7];        /* IST1-IST7 as array for indexed access */
    u64 reserved2;
    u16 reserved3;
    u16 iomap_base;
} __attribute__((packed)) tss_t;

/* Exposed from linker script — IST stack top.
 * Declared as extern array so the symbol resolves to its ADDRESS,
 * not the 8-byte value stored at that address. */
extern char ist_stack_top[];

/* Per-CPU TSS array */
extern tss_t tss[MAX_CPUS];

/* Expose GDT pointer for AP bringup (AP loads BSP's GDT) */
extern gdt_ptr_t gdt_ptr;

/* — GDT lifetime API — */
void gdt_init(void);
void gdt_init_cpu(u32 cpu_id);
void gdt_load(gdt_ptr_t *gdtp);
void load_tr(u16 sel);
void tss_set_kernel_stack(u64 stack);

#endif /* _FTK_GDT_H */