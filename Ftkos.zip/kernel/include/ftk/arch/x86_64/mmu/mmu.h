#pragma once
#include <ftk/abi/types.h>

void mmu_load_cr3(phys_addr_t pml4);
void mmu_invlpg(virt_addr_t addr);