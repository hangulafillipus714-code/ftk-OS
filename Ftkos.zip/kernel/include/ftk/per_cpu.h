#ifndef FTK_PER_CPU_H
#define FTK_PER_CPU_H

#include <ftk/abi/types.h>
#include <ftk/scheduler.h>
#include <ftk/spinlock.h>

/* Per-CPU data structure - accessed via GS segment base
 *
 * Offsets 0 and 8 must be kern_rsp / user_rsp to match syscall_entry.S
 * expectations (GS:0 loaded as kernel RSP, GS:8 stashes user RSP).
 * The self pointer is at offset 16 for this_cpu().
 */
typedef struct per_cpu_data {
    u64 kern_rsp;                    /* offset  0 — kernel stack top (syscall entry) */
    u64 user_rsp;                    /* offset  8 — user RSP scratch (syscall entry) */
    struct per_cpu_data *self;       /* offset 16 — for this_cpu() macro */

    /* CPU identification */
    u32 cpu_id;                      /* offset 24 */
    u32 apic_id;                     /* offset 28 */
    u32 is_bsp;                      /* offset 32 */

    /* Scheduler */
    struct Task *current_task;      /* Currently running task on this CPU */
    struct Task *idle_task;         /* Idle task for this CPU */
    spinlock_t runqueue_lock;       /* Lock for this CPU's run queue */
    struct Task *runqueue_head;     /* Head of run queue */
    struct Task *runqueue_tail;     /* Tail of run queue */

    /* Interrupt handling */
    u64 irq_count;          /* Total interrupts handled */
    u64 irq_counts[256];    /* Per-vector interrupt counts */
    u64 spurious_irqs;      /* Spurious interrupt count */

    /* Timer */
    u64 timer_ticks;        /* Local timer ticks */
    u64 next_timer_deadline; /* Next timer event (TSC) */

    /* IPI tracking */
    u64 ipi_sent;           /* IPIs sent */
    u64 ipi_received;       /* IPIs received */
    u64 ipi_counts[16];     /* Per-vector IPI counts */

    /* Memory management */
    struct AddressSpace *current_as;  /* Current address space */
    void *kernel_stack_top;           /* Top of kernel stack */
    void *kernel_stack_base;          /* Base of kernel stack */

    /* Statistics */
    u64 context_switches;   /* Context switches on this CPU */
    u64 syscalls;           /* System calls handled */
    u64 page_faults;        /* Page faults handled */

    /* TSS and GDT */
    void *tss;              /* Task State Segment */
    u64 gdt_base;           /* GDT base address */
    u16 gdt_limit;          /* GDT limit */

    /* Debug / profiling */
    u64 last_tsc;           /* Last TSC read */
    u64 idle_start_tsc;     /* When idle started */

    /* Cache line padding to avoid false sharing */
    u8 pad[64];
} per_cpu_data_t;

/* Maximum CPUs */
#define MAX_CPUS 256

/* Global per-CPU data array */
extern per_cpu_data_t per_cpu_data[MAX_CPUS];

/* Get per-CPU data for current CPU (via GS base, self at offset 16) */
static inline per_cpu_data_t *this_cpu(void) {
    per_cpu_data_t *ptr;
    __asm__ volatile("mov %%gs:16, %0" : "=r"(ptr));
    return ptr;
}

/* Get per-CPU data by CPU ID */
static inline per_cpu_data_t *get_cpu_data(u32 cpu_id) {
    if (cpu_id >= MAX_CPUS) return NULL;
    return &per_cpu_data[cpu_id];
}

/* Get current CPU ID */
static inline u32 get_cpu_id(void) {
    return this_cpu()->cpu_id;
}

/* Get current APIC ID */
static inline u32 get_apic_id(void) {
    return this_cpu()->apic_id;
}

/* Get current task */
static inline struct Task *get_current_task(void) {
    return this_cpu()->current_task;
}

/* Set current task */
static inline void set_current_task(struct Task *task) {
    this_cpu()->current_task = task;
}

/* Per-CPU current_task macro — replaces the old global.
 * All existing code referencing current_task continues to work
 * because this macro resolves to the per-CPU field. */
#undef current_task
#define current_task (this_cpu()->current_task)

/* Per-CPU variable macros */
#define PER_CPU(var) (this_cpu()->var)
#define PER_CPU_PTR(var) (&this_cpu()->var)

/* Initialize per-CPU data for a CPU */
void per_cpu_init(u32 cpu_id, u32 apic_id, int is_bsp);

/* Set up GS base for current CPU */
void per_cpu_setup_gs_base(u32 cpu_id);

#endif /* FTK_PER_CPU_H */