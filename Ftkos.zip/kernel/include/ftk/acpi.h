#ifndef FTK_ACPI_H
#define FTK_ACPI_H

#include <ftk/abi/types.h>

/* ACPI Table Signatures */
#define RSDP_SIGNATURE      "RSD PTR "
#define RSDT_SIGNATURE      "RSDT"
#define XSDT_SIGNATURE      "XSDT"
#define MADT_SIGNATURE      "APIC"
#define FADT_SIGNATURE      "FACP"
#define MCFG_SIGNATURE      "MCFG"
#define HPET_SIGNATURE      "HPET"

/* MADT Entry Types */
#define MADT_TYPE_LAPIC          0  /* Processor Local APIC */
#define MADT_TYPE_IOAPIC         1  /* I/O APIC */
#define MADT_TYPE_ISO            2  /* Interrupt Source Override */
#define MADT_TYPE_NMI            3  /* Non-maskable Interrupt Source */
#define MADT_TYPE_LAPIC_NMI      4  /* Local APIC NMI */
#define MADT_TYPE_LAPIC_OVERRIDE 5  /* Local APIC Address Override */
#define MADT_TYPE_LAPIC_X2APIC   9  /* x2APIC */

/* MADT Flags */
#define MADT_PCAT_COMPAT (1 << 0)  /* PC-AT dual PIC compatibility */

/* LAPIC Flags */
#define LAPIC_ENABLED (1 << 0)

/* Generic ACPI table header */
typedef struct {
    char signature[4];
    u32 length;
    u8 revision;
    u8 checksum;
    char oem_id[6];
    char oem_table_id[8];
    u32 oem_revision;
    u32 creator_id;
    u32 creator_revision;
} __attribute__((packed)) ACPISDTHeader_t;

/* RSDP (Root System Description Pointer) - v1.0 */
typedef struct {
    char signature[8];
    u8 checksum;
    char oem_id[6];
    u8 revision;
    u32 rsdt_address;
} __attribute__((packed)) RSDPDescriptor_t;

/* RSDP v2.0 (ACPI 2.0+) - extended */
typedef struct {
    RSDPDescriptor_t v1;
    u32 length;
    u64 xsdt_address;
    u8 extended_checksum;
    u8 reserved[3];
} __attribute__((packed)) RSDPDescriptor20_t;

/* RSDT (Root System Description Table) */
typedef struct {
    ACPISDTHeader_t header;
    u32 entries[];  /* Variable length: (length - sizeof(header)) / 4 */
} __attribute__((packed)) RSDT_t;

/* XSDT (Extended System Description Table) */
typedef struct {
    ACPISDTHeader_t header;
    u64 entries[];  /* Variable length */
} __attribute__((packed)) XSDT_t;

/* MADT (Multiple APIC Description Table) - APIC */
typedef struct {
    ACPISDTHeader_t header;
    u32 local_apic_address;
    u32 flags;
    u8 entries[];  /* Variable length MADT entries */
} __attribute__((packed)) MADT_t;

/* MADT Entry Header */
typedef struct {
    u8 type;
    u8 length;
} __attribute__((packed)) MADTEntryHeader_t;

/* MADT Type 0: Processor Local APIC */
typedef struct {
    MADTEntryHeader_t header;
    u8 acpi_processor_id;
    u8 apic_id;
    u32 flags;
} __attribute__((packed)) MADTLocalAPIC_t;

/* MADT Type 1: I/O APIC */
typedef struct {
    MADTEntryHeader_t header;
    u8 io_apic_id;
    u8 reserved;
    u32 io_apic_address;
    u32 global_system_interrupt_base;
} __attribute__((packed)) MADTIOAPIC_t;

/* MADT Type 2: Interrupt Source Override */
typedef struct {
    MADTEntryHeader_t header;
    u8 bus_source;
    u8 irq_source;
    u32 global_system_interrupt;
    u16 flags;
} __attribute__((packed)) MADTISO_t;

/* MADT Type 9: Processor Local x2APIC */
typedef struct {
    MADTEntryHeader_t header;
    u16 reserved;
    u32 x2apic_id;
    u32 flags;
    u32 acpi_processor_uid;
} __attribute__((packed)) MADTLocalx2APIC_t;

/* Global ACPI state */
extern u32 lapic_phys_addr;
extern u32 ioapic_phys_addr;
extern u8 lapic_ids[256];
extern u32 num_cpus;

/* ACPI initialization and table parsing */
int acpi_init(phys_addr_t rsdp_addr);
const RSDPDescriptor20_t *acpi_find_rsdp(void);
ACPISDTHeader_t *acpi_find_table(const char *signature);
MADT_t *acpi_get_madt(void);
int acpi_parse_madt(void);

/* Map an ISA IRQ to its I/O APIC GSI, honouring MADT Interrupt Source
 * Overrides (e.g. PIT IRQ 0 -> GSI 2 on QEMU q35). Falls back to the
 * IRQ number itself when no override is present. */
u8 acpi_get_gsi_for_irq(u8 isa_irq);

#endif /* FTK_ACPI_H */