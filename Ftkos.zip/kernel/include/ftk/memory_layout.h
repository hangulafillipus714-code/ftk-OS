#ifndef _FTK_MEMORY_LAYOUT_H
#define _FTK_MEMORY_LAYOUT_H

#include <ftk/abi/types.h>

/* ================= ARCH & ABI ENFORCEMENT ================= */

#ifndef FTK_ABI_TYPES_LOCKED
#error "ftk/abi/types.h must be included before memory_layout.h"
#endif

#if !defined(__x86_64__)
#error "FTK memory layout requires x86_64 architecture"
#endif

#if __SIZEOF_POINTER__ != 8
#error "FTK requires 64-bit pointers"
#endif

/* ================= KERNEL ADDRESS SPACE ================= */

/* Fixed Kernel Virtual Base - NEVER CHANGE THIS */
#define KERNEL_VIRT_BASE 0xFFFFFFFF80000000ULL

_Static_assert(sizeof(KERNEL_VIRT_BASE) == 8,
               "KERNEL_VIRT_BASE must be 64-bit");

_Static_assert((KERNEL_VIRT_BASE & 0xFFF) == 0,
               "KERNEL_VIRT_BASE must be page-aligned");

/* ================= MEMORY CONSTANTS ================= */

#define PAGE_SIZE       4096ULL
#define PAGE_MASK       (~(PAGE_SIZE - 1))
#define HUGE_PAGE_SIZE  (2ULL * 1024 * 1024)  /* 2MB */

#define PML4_ENTRIES        512
#define PAGE_TABLE_ENTRIES  512

_Static_assert(PAGE_SIZE == 4096,
               "ABI violation: PAGE_SIZE must be 4096");

_Static_assert(HUGE_PAGE_SIZE == 0x200000,
               "ABI violation: Huge pages must be 2MB");

/* ================= ALIGNMENT ================= */

#ifndef ALIGN_UP
#define ALIGN_UP(addr, align)   (((addr) + (align) - 1) & ~((align) - 1))
#endif
#ifndef ALIGN_DOWN
#define ALIGN_DOWN(addr, align) ((addr) & ~((align) - 1))
#endif
#define IS_ALIGNED(addr, align) (((addr) & ((align) - 1)) == 0)

/* ================= ADDRESS CONVERSION ================= */

/* These macros EXPECT phys_addr_t / virt_addr_t */
#define PHYS_TO_VIRT(phys)  ((virt_addr_t)((phys_addr_t)(phys) + KERNEL_VIRT_BASE))
#define VIRT_TO_PHYS(virt)  ((phys_addr_t)((virt_addr_t)(virt) - KERNEL_VIRT_BASE))

/* ================= PAGE TABLE SHIFTS ================= */

#define PML4_SHIFT  39
#define PDPT_SHIFT  30
#define PD_SHIFT    21
#define PT_SHIFT    12

_Static_assert(PML4_SHIFT == 39, "Invalid PML4 shift");
_Static_assert(PDPT_SHIFT == 30, "Invalid PDPT shift");
_Static_assert(PD_SHIFT   == 21, "Invalid PD shift");
_Static_assert(PT_SHIFT   == 12, "Invalid PT shift");

/* ================= PAGE TABLE INDEXING ================= */

#define PML4_INDEX(virt)  ((((virt_addr_t)(virt)) >> PML4_SHIFT) & 0x1FF)
#define PDPT_INDEX(virt)  ((((virt_addr_t)(virt)) >> PDPT_SHIFT) & 0x1FF)
#define PD_INDEX(virt)    ((((virt_addr_t)(virt)) >> PD_SHIFT)   & 0x1FF)
#define PT_INDEX(virt)    ((((virt_addr_t)(virt)) >> PT_SHIFT)   & 0x1FF)

/* ================= FINAL LOCK ================= */

#define FTK_MEMORY_LAYOUT_LOCKED 1

#endif /* _FTK_MEMORY_LAYOUT_H */