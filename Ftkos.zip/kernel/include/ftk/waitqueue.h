#ifndef FTK_WAITQUEUE_H
#define FTK_WAITQUEUE_H

#include <ftk/abi/types.h>

/* Forward-declare Task to avoid circular dependency with scheduler.h */
struct Task;

/*
 * Wait queue: a list of tasks blocked waiting for an event.
 * Producers call wake_up() to unblock the first waiter.
 * Consumers call wait_event(queue, condition) or wait_event_raw().
 *
 * Thread safety: all operations are internally synchronized with a
 * per-queue spinlock.
 */

typedef struct wait_queue_entry {
    struct wait_queue_entry *next;
    struct Task             *task;
} wait_queue_entry_t;

typedef struct wait_queue_head {
    wait_queue_entry_t *head;
    wait_queue_entry_t *tail;
} wait_queue_head_t;

#define WAIT_QUEUE_INIT { NULL, NULL }

void init_waitqueue_head(wait_queue_head_t *wq);
void wait_event(wait_queue_head_t *wq);
void wake_up(wait_queue_head_t *wq);
void wake_up_all(wait_queue_head_t *wq);
int  waitqueue_is_empty(wait_queue_head_t *wq);

#endif /* FTK_WAITQUEUE_H */
