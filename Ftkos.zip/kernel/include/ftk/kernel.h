#ifndef FTK_KERNEL_H
#define FTK_KERNEL_H

#include <ftk/abi/types.h>

void kernel_panic(const char *message);
void kernel_log(const char *fmt, ...);
void kernel_early_init(void);
void kernel_init(void);

#endif