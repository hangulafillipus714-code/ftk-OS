#ifndef FTK_SMP_H
#define FTK_SMP_H

#include <ftk/abi/types.h>
#include <ftk/apic.h>
#include <ftk/per_cpu.h>

/* Maximum number of CPUs supported */
#define MAX_CPUS 256

/* CPU states */
typedef enum {
    SMP_STATE_OFFLINE = 0,
    SMP_STATE_STARTING,
    SMP_STATE_RUNNING,
    SMP_STATE_HALTED
} smp_cpu_state_t;

/* Global SMP state */
extern u8 lapic_ids[MAX_CPUS];
extern u32 num_cpus;
extern volatile u32 ap_ready;

/* AP trampoline binary symbols (embedded as blob) */
extern char _binary_arch_x86_64_ap_trampoline_bin_start[];
extern char _binary_arch_x86_64_ap_trampoline_bin_end[];

/* Fixed offsets in AP trampoline binary (at 0x8000) */
#define AP_PML4_OFFSET      0x04
#define AP_STACK_OFFSET     0x0C
#define AP_ENTRY_OFFSET     0x14
#define AP_CPU_ID_OFFSET    0x1C

/* AP trampoline address (below 1MB for real mode access) */
#define AP_TRAMPOLINE_ADDR  0x8000

/* Function declarations */
int smp_init(void);
void smp_ap_entry(u32 cpu_id);
void smp_ipi_broadcast(u8 vector);
void smp_ipi_single(u32 cpu_id, u8 vector);

/* Per-CPU data accessors (using per_cpu.h inline functions) */
static inline u32 get_cpu_count(void) { return num_cpus; }

/* CPU hotplug support (future) */
int smp_cpu_online(u32 cpu_id);
int smp_cpu_offline(u32 cpu_id);

#endif /* FTK_SMP_H */