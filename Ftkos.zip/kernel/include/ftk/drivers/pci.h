#ifndef FTK_DRIVERS_PCI_H
#define FTK_DRIVERS_PCI_H

#include <ftk/abi/types.h>

#define PCI_CONFIG_ADDRESS 0xCF8
#define PCI_CONFIG_DATA    0xCFC

u32 pci_read_config(u8 bus, u8 slot, u8 func, u8 offset);
void pci_write_config(u8 bus, u8 slot, u8 func, u8 offset, u32 value);
void pci_probe(void);

#endif
