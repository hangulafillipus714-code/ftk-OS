#ifndef FTK_DRIVERS_AHCI_H
#define FTK_DRIVERS_AHCI_H

#include <ftk/abi/types.h>

#define AHCI_MAX_PORTS 32

void ahci_init(u32 bar5);
int ahci_read(u64 lba, u32 count, void* buf);

#endif
