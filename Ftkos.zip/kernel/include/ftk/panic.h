#ifndef FTK_PANIC_H
#define FTK_PANIC_H

#include <ftk/kernel.h>

#define PANIC(msg) kernel_panic(msg)
#define ASSERT(cond) if (!(cond)) PANIC("Assertion failed: " #cond)

#endif