#ifndef _FTK_ABI_TYPES_H
#define _FTK_ABI_TYPES_H

#if !defined(__x86_64__)
#error "FTK ABI requires x86_64"
#endif

#if __SIZEOF_POINTER__ != 8
#error "FTK ABI requires 64-bit pointers"
#endif

/* Standard integer types - NO VARIATIONS */
typedef unsigned char           u8;
typedef unsigned short          u16;
typedef unsigned int            u32;
typedef unsigned long long      u64;

typedef signed char             s8;
typedef signed short            s16;
typedef signed int              s32;
typedef signed long long        s64;

/* Address types */
typedef u64 phys_addr_t;
typedef u64 virt_addr_t;

/* Size types */
#ifndef __EFI__
typedef u64 size_t;
typedef u64 uintptr_t;
#endif

/* NULL */
#ifndef NULL
#define NULL ((void*)0)
#endif 

/* ABI enforcement */
_Static_assert(sizeof(u8)  == 1, "ABI: u8");
_Static_assert(sizeof(u16) == 2, "ABI: u16");
_Static_assert(sizeof(u32) == 4, "ABI: u32");
_Static_assert(sizeof(u64) == 8, "ABI: u64");

_Static_assert(sizeof(size_t) == 8, "ABI: size_t");
_Static_assert(sizeof(uintptr_t) == 8, "ABI: uintptr_t");

_Static_assert(sizeof(phys_addr_t) == 8, "ABI: phys_addr_t");
_Static_assert(sizeof(virt_addr_t) == 8, "ABI: virt_addr_t");

#define FTK_ABI_TYPES_LOCKED 1

#endif /* _FTK_ABI_TYPES_H */