#ifndef FTK_BOOTINFO_H
#define FTK_BOOTINFO_H

/*
 * Kernel-only bootinfo wrapper
 * Extends shared boot ABI with kernel helpers only
 */

#include <ftk/abi/types.h>
#include <ftk/stdbool.h>
#include <ftk/bootinfo_shared.h>

/*
 * IMPORTANT:
 * Do NOT redefine BootInfo, mmap_entry, or fb_info here.
 * They must match the UEFI ABI exactly.
 */

/* Kernel helper */
static inline bool bootinfo_has_fb(const BootInfo *bi) {
    return bi->fb_available;
}

#endif /* FTK_BOOTINFO_H */