#ifndef FTK_ABI_SYSCALL_H
#define FTK_ABI_SYSCALL_H

/*
 * FTK OS Syscall ABI
 * ------------------
 * Entry:    SYSCALL instruction
 * Number:   RAX
 * Args:     RDI, RSI, RDX, R10, R8, R9  (System V AMD64)
 *           NOTE: R10 replaces RCX (SYSCALL clobbers RCX with return RIP)
 * Return:   RAX  (0 = success, negative errno on error)
 * Clobbers: RCX, R11 (saved by SYSCALL hardware)
 *
 * MSRs:
 *   IA32_LSTAR  (0xC0000082) = syscall_entry (64-bit handler)
 *   IA32_STAR   (0xC0000081) = kernel CS | user CS << 48
 *   IA32_FMASK  (0xC0000084) = flags to clear on entry (IF, DF)
 *   IA32_EFER   (0xC0000080) = must have SCE bit set
 */

/* ── Syscall numbers ─────────────────────────────────────── */
#define SYS_EXIT        0   /* exit(int status)                        */
#define SYS_WRITE       1   /* write(int fd, const void *buf, size_t n)*/
#define SYS_READ        2   /* read(int fd, void *buf, size_t n)       */
#define SYS_GETPID      3   /* getpid() → pid_t                        */
#define SYS_SLEEP       4   /* sleep(uint64_t ticks)                   */
#define SYS_YIELD       5   /* yield() – voluntary context switch      */
#define SYS_BRK         6   /* brk(void *addr) – heap extension        */
#define SYS_EXEC        7   /* exec(const char *filename)              */
#define SYS_READFILE    8   /* readfile(path, buf, n)                  */
#define SYS_LISTDIR     9   /* listdir(path, buf, n)                   */
#define SYS_OPEN        10  /* open(path, flags) → fd                  */
#define SYS_CLOSE       11  /* close(fd)                               */
#define SYS_SPAWN       12  /* spawn(path, argv[]) → pid               */
#define SYS_PS          13  /* ps(pid, buf, count)                     */
#define SYS_WAITPID     14  /* waitpid(pid, *status)                   */
#define SYS_GETDENTS    15  /* getdents(fd, buf, count)                */
#define SYS_PIPE        16  /* pipe(pipefd[2])                         */
#define SYS_DUP2        17  /* dup2(oldfd, newfd)                      */
#define SYS_DEBUG       18  /* debug(char c)                           */
#define SYS_KILL        19  /* kill(pid)                               */

/* ── GUI / Graphics syscalls (20-31) ─────────────────────── */
#define SYS_FB_INFO     20  /* fb_info(ftk_fb_info_t *out) → 0        */
#define SYS_FB_MAP      21  /* fb_map() → user vaddr of framebuffer   */
#define SYS_FB_FLUSH    22  /* fb_flush(x,y,w,h) — mark region dirty  */
#define SYS_GETTICKS    23  /* getticks() → u64 timer ticks since boot*/
#define SYS_GETKEY      24  /* getkey(ftk_key_event_t *ev) → 1/0      */
#define SYS_MMAP        25  /* mmap(NULL,len,prot,flags,-1,0) → vaddr */
#define SYS_MUNMAP      26  /* munmap(vaddr, len)                      */
#define SYS_SETCURSOR   27  /* setcursor(x, y) — set mouse cursor pos */
#define SYS_GETTIME     28  /* gettime(ftk_time_t *out) → 0           */

#define SYS_POLL        29  /* poll(int fd) → 1 if readable, 0 if not  */
#define SYSCALL_COUNT   30  /* total number of syscalls                */

/* ── File descriptor constants ───────────────────────────── */
#define FD_STDIN    0
#define FD_STDOUT   1
#define FD_STDERR   2

/* ── Process info structure (for SYS_PS) ─────────────────── */
#define PS_NAME_MAX 32
#define PS_STATE_RUNNING 0
#define PS_STATE_READY   1
#define PS_STATE_BLOCKED 2
#define PS_STATE_ZOMBIE  3

typedef struct {
    int  pid;
    int  state;
    char name[PS_NAME_MAX];
} ps_info_t;

/* ── Framebuffer info (for SYS_FB_INFO) ─────────────────── */
typedef struct {
    unsigned int  width;
    unsigned int  height;
    unsigned int  pitch;      /* bytes per row                       */
    unsigned int  bpp;        /* bits per pixel (always 32 for FTK)  */
    unsigned long phys_base;  /* physical address (informational)    */
} ftk_fb_info_t;

/* ── Key event (for SYS_GETKEY) ─────────────────────────── */
#define FTK_KEY_PRESS   1
#define FTK_KEY_RELEASE 0

/* Special key codes (> 0x7F, returned in ftk_key_event_t.keycode) */
#define FTK_KEY_UP      0x100
#define FTK_KEY_DOWN    0x101
#define FTK_KEY_LEFT    0x102
#define FTK_KEY_RIGHT   0x103
#define FTK_KEY_F1      0x111
#define FTK_KEY_F2      0x112
#define FTK_KEY_F3      0x113
#define FTK_KEY_F4      0x114
#define FTK_KEY_F5      0x115
#define FTK_KEY_F10     0x11A
#define FTK_KEY_HOME    0x120
#define FTK_KEY_END     0x121
#define FTK_KEY_PGUP    0x122
#define FTK_KEY_PGDN    0x123
#define FTK_KEY_DEL     0x124
#define FTK_KEY_ESC     0x1B
#define FTK_KEY_TAB     0x09
#define FTK_KEY_ENTER   0x0D
#define FTK_KEY_BKSP    0x08

/* Modifier flags */
#define FTK_MOD_SHIFT   (1 << 0)
#define FTK_MOD_CTRL    (1 << 1)
#define FTK_MOD_ALT     (1 << 2)

typedef struct {
    int type;       /* FTK_KEY_PRESS or FTK_KEY_RELEASE      */
    int keycode;    /* ASCII or FTK_KEY_* special             */
    int modifiers;  /* FTK_MOD_* bitmask                     */
} ftk_key_event_t;

/* ── Time structure (for SYS_GETTIME) ───────────────────── */
typedef struct {
    int year;
    int month;   /* 1-12 */
    int day;     /* 1-31 */
    int hour;    /* 0-23 */
    int minute;  /* 0-59 */
    int second;  /* 0-59 */
} ftk_time_t;

/* ── Error codes (negative errno in RAX) ─────────────────── */
#define ESYS_OK         0
#define ESYS_INVAL     -1
#define ESYS_NOSYS     -2
#define ESYS_FAULT     -3
#define ESYS_BADF      -4
#define ESYS_PERM      -5
#define ESYS_NOMEM     -6
#define ESYS_NOENT     -7
#define ESYS_IO        -8
#define ESYS_NOEXEC    -9
#define ESYS_SRCH      -10

/* ── MSR addresses ────────────────────────────────────────── */
#define MSR_EFER        0xC0000080
#define MSR_STAR        0xC0000081
#define MSR_LSTAR       0xC0000082
#define MSR_FMASK       0xC0000084
#define EFER_SCE        (1ULL << 0)

/* GDT segment selectors */
#define GDT_KERNEL_CODE  0x08
#define GDT_KERNEL_DATA  0x10
#define GDT_USER_DATA    0x18
#define GDT_USER_CODE    0x20

#endif /* FTK_ABI_SYSCALL_H */
