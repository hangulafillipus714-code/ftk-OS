#pragma once

/*
 * Core kernel output ABI
 *
 * This is the lowest-level character output interface.
 * Real devices (serial, vga, fb) override this.
 */
int putchar(int c);