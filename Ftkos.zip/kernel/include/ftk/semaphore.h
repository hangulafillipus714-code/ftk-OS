#ifndef FTK_SEMAPHORE_H
#define FTK_SEMAPHORE_H

#include <ftk/abi/types.h>
#include <ftk/waitqueue.h>

/*
 * Counting semaphore.
 *
 * sem_wait()   — P() — decrement; block if count reaches zero.
 * sem_signal() — V() — increment; wake one blocked task if any.
 */

typedef struct semaphore {
    volatile s32      count;
    wait_queue_head_t waiters;
} semaphore_t;

void sem_init(semaphore_t *sem, s32 initial);
void sem_wait(semaphore_t *sem);       /* P() */
int  sem_try_wait(semaphore_t *sem);   /* non-blocking P() */
void sem_signal(semaphore_t *sem);     /* V() */

#endif /* FTK_SEMAPHORE_H */
