#ifndef FTK_SCHEDULER_H
#define FTK_SCHEDULER_H

#include <ftk/abi/types.h>
#include <ftk/vmm.h>
#include <ftk/waitqueue.h>

/* Number of pages to allocate for the user stack (64 KB with 16 pages) */
#define USER_STACK_PAGES 16

typedef struct TaskContext {
    u64 rsp;
} TaskContext;

/* Stack layout for task_switch (low→high):
 *   rflags (8 bytes) — set by pushfq / restored by popfq
 *   rbx (8 bytes)
 *   rbp (8 bytes)
 *   r12 (8 bytes)
 *   r13 (8 bytes)
 *   r14 (8 bytes)
 *   r15 (8 bytes)
 *   return_address (8 bytes)
 */

typedef enum { TASK_READY, TASK_RUNNING, TASK_BLOCKED, TASK_ZOMBIE } TaskState;

struct vfs_node;

/* Pipe buffer structure */
typedef struct {
    u8  data[4096];
    u32 read_pos;
    u32 write_pos;
    int closed;
    int refcount;
    int writers;  /* number of open write-end references */
} pipe_t;

#define MAX_FDS 32

typedef struct {
    struct vfs_node *node;
    u64 offset;
    int used;
    int type;          /* 0=console, 1=file, 2=pipe */
    pipe_t *pipe;      /* non-NULL for pipe fds */
    int pipe_is_write; /* 1=write end, 0=read end, -1=not pipe */
} file_t;

#define FD_TYPE_CONSOLE 0
#define FD_TYPE_FILE    1
#define FD_TYPE_PIPE    2

typedef struct Task {
    u32 pid;
    char name[32];
    TaskState state;
    u64 ticks;
    TaskContext context;
    u64 kernel_stack_top;       /* Kernel stack top for TSS RSP0 update */
    phys_addr_t kernel_stack_phys; /* Physical base of kernel stack (for teardown) */
    u64 user_rsp;               /* Saved user RSP (gs:8 slot, for sysretq) */
    u8 is_user;                /* 1 = Ring 3 task, 0 = Ring 0 */
    virt_addr_t user_stack;    /* User-mode stack base (Ring 3 only) */
    virt_addr_t brk_base;      /* Initial program break from ELF loader */
    virt_addr_t brk_current;   /* Current program break */
    s32 preempt_count;         /* >0 = preemption disabled (nesting-safe) */
    AddressSpace *address_space;
    file_t fd_table[MAX_FDS];  /* Per-process file descriptor table */
    u32 parent_pid;            /* PID of parent (0 = orphan) */
    int exit_status;           /* Set when task exits, valid in TASK_ZOMBIE */
    int killed;                  /* 1 = kill signal received, check on next syscall entry */
    struct Task *next;
    struct Task *prev;
} Task;

void scheduler_init(void);
void scheduler_tick(void);
void switch_task(Task *next);
void scheduler_start(void);
Task *create_task(const char *name, void (*entry)(void));
Task *create_user_task(const char *name, void (*entry)(void),
                       AddressSpace *space, virt_addr_t user_entry,
                       virt_addr_t user_stack_top);
AddressSpace *create_user_address_space(void);
int create_init_process(void);
void scheduler_exit_current(int status);
u32 scheduler_current_pid(void);
void scheduler_yield(void);
Task *scheduler_collect_zombie(int target_pid);
int   scheduler_has_child(int target_pid);
int   scheduler_waitpid_prepare(int target_pid, Task **zombie_out);
void task_destroy(Task *task);
Task *find_task_by_pid(u32 pid);

/*
 * Preemption control (now regular functions, defined in scheduler.c).
 */
void preempt_disable(void);
void preempt_enable(void);
int is_preempt_disabled(void);

/* Assembly routines */
extern void task_switch(TaskContext *prev, TaskContext *next);
extern void ret_from_interrupt(void);

/* SMP scheduler functions */
void scheduler_init_cpu(u32 cpu_id);
void scheduler_start_cpu(void);

/* current_task — production code gets this as a per-CPU macro from <ftk/per_cpu.h>.
 * Unit-test compilation units that only include scheduler.h (not per_cpu.h) need
 * an extern declaration so the identifier resolves to the linker shim in
 * sched/current_task_shim.c.  per_cpu.h's #define current_task overrides this
 * extern at all usage sites when per_cpu.h is included. */
#ifndef FTK_PER_CPU_H
extern struct Task *current_task;
#endif

#endif /* FTK_SCHEDULER_H */
