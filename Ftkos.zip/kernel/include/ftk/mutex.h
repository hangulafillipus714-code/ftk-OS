#ifndef FTK_MUTEX_H
#define FTK_MUTEX_H

#include <ftk/abi/types.h>

/*
 * Compact mutex (8 bytes) for kernel use.
 *
 * Under contention, the task spins briefly, then blocks on a wait queue,
 * yielding the CPU rather than burning cycles.
 *
 * Trylock, lock, unlock adhere to the standard mutex API.
 */

/* Forward-declare Task to avoid circular dependency */
struct Task;

typedef struct mutex_waiter {
    struct mutex_waiter *next;
    struct Task         *task;
} mutex_waiter_t;

typedef struct mutex {
    volatile u32    locked;    /* 0 = unlocked, 1 = locked */
    mutex_waiter_t *waiters;   /* singly-linked list of blocked tasks */
} mutex_t;

#define MUTEX_INIT { 0, NULL }

void mutex_init(mutex_t *m);
void mutex_lock(mutex_t *m);
int  mutex_trylock(mutex_t *m);
void mutex_unlock(mutex_t *m);

#endif /* FTK_MUTEX_H */
