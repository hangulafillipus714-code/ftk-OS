#ifndef FTK_MEMORY_H
#define FTK_MEMORY_H

#include <ftk/abi/types.h>
#include <ftk/abi/bootinfo.h>
#include <ftk/stddef.h>

// Memory regions
typedef enum {
    MEMORY_FREE = 1,
    MEMORY_RESERVED,
    MEMORY_ACPI_RECLAIMABLE,
    MEMORY_ACPI_NVS,
    MEMORY_BAD
} MemoryType;

typedef struct {
    phys_addr_t base;
    u64 length;
    MemoryType type;
} MemoryRegion;

// Virtual memory permissions
typedef enum {
    VM_READ = 1 << 0,
    VM_WRITE = 1 << 1,
    VM_EXECUTE = 1 << 2,
    VM_USER = 1 << 3,
    VM_GLOBAL = 1 << 4
} VMPermissions;

void memory_init(BootInfo *boot_info);
void* kmalloc(size_t size);
void kfree(void *ptr);
void* kmalloc_aligned(size_t size, size_t alignment);

#endif