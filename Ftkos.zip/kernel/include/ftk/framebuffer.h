#ifndef FTK_FRAMEBUFFER_H
#define FTK_FRAMEBUFFER_H

#include <ftk/abi/types.h>
#include <ftk/bootinfo_shared.h>

#define FB_CONSOLE_COLS 80
#define FB_CONSOLE_ROWS 25

/* Kernel-virtual alias of the linear framebuffer.  Mapped into the top half
 * (cloned into every user address space) by paging.c, so the kernel console
 * can draw on the FB regardless of the active CR3.  Kept distinct from
 * ftk_fb_base (the GOP *physical* address used by SYS_FB_INFO / SYS_FB_MAP). */
#define FRAMEBUFFER_VIRT_BASE 0xFFFFFFFF00200000ULL

void framebuffer_init(fb_info_t *info);
void framebuffer_put_pixel(u32 x, u32 y, u32 color);
void framebuffer_clear(u32 color);
void framebuffer_putchar(int c, int col, int row, u32 fg, u32 bg);
void framebuffer_puts(const char *s, int col, int row, u32 fg, u32 bg);
void framebuffer_scroll(void);
void framebuffer_write(const char *s);

/* Global framebuffer state (defined in framebuffer.c, used by syscall layer) */
extern u32 *ftk_fb_base;        /* GOP physical address (identity-mapped in kernel) */
extern u32 *ftk_fb_kernel_virt; /* kernel-virtual alias, valid in every address space */
extern u32  ftk_fb_width;
extern u32  ftk_fb_height;
extern u32  ftk_fb_pitch;

/* Global tick counter (incremented in scheduler_tick, read by SYS_GETTICKS) */
extern volatile u64 ftk_ticks;

#endif
