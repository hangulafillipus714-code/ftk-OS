#ifndef FTK_STDBOOL_H
#define FTK_STDBOOL_H

#include <ftk/abi/types.h>

/* Kernel boolean type */
typedef u8 bool;

#define true  1
#define false 0

#endif /* FTK_STDBOOL_H */