#ifndef _BOOTINFO_SHARED_H
#define _BOOTINFO_SHARED_H

#include <ftk/stdint.h>
#include <ftk/abi/types.h>

#pragma pack(push, 1)

/* Memory Map Entry */
typedef struct mmap_entry {
    uint64_t base;
    uint64_t length;
    uint32_t type;
    uint32_t attributes;
} mmap_entry_t;

/* Framebuffer Info */
typedef struct fb_info {
    uint64_t base;
    uint32_t width;
    uint32_t height;
    uint32_t pitch;
    uint32_t bpp;
    uint8_t  red_mask;
    uint8_t  green_mask;
    uint8_t  blue_mask;
    uint8_t  reserved;
} fb_info_t;

/* Main BootInfo Structure */
typedef struct BootInfo {
    mmap_entry_t *mmap;
    uint32_t mmap_count;
    uint64_t total_memory;
    uint64_t free_memory;
    
    fb_info_t fb;
    uint32_t fb_available;
    
    phys_addr_t rsdp;
    
    phys_addr_t kernel_phys_base;
    phys_addr_t kernel_phys_end;
    virt_addr_t kernel_virt_base;
    virt_addr_t kernel_virt_end;
    
    char bootloader_name[64];
    uint32_t bootloader_version;
    char cmdline[256];
} BootInfo;

#pragma pack(pop)

/* Memory Map Types */
#define MMAP_TYPE_AVAILABLE     1
#define MMAP_TYPE_RESERVED      2
#define MMAP_TYPE_ACPI_RECLAIM  3
#define MMAP_TYPE_ACPI_NVS      4
#define MMAP_TYPE_BAD_MEMORY    5

#endif /* _BOOTINFO_SHARED_H */