#ifndef FTK_APIC_H
#define FTK_APIC_H

#include <ftk/abi/types.h>

/* Local APIC MMIO base (set by ACPI parsing) */
extern u32 lapic_phys_addr;
extern volatile u32 *lapic_base;

/* LAPIC Register Offsets (from Intel SDM Vol 3A, Chapter 10) */
#define LAPIC_ID              0x020  /* Local APIC ID */
#define LAPIC_VERSION         0x030  /* Local APIC Version */
#define LAPIC_TPR             0x080  /* Task Priority Register */
#define LAPIC_APR             0x090  /* Arbitration Priority Register */
#define LAPIC_PPR             0x0A0  /* Processor Priority Register */
#define LAPIC_EOI             0x0B0  /* End of Interrupt */
#define LAPIC_RRR             0x0C0  /* Remote Read Register */
#define LAPIC_LDR             0x0D0  /* Logical Destination Register */
#define LAPIC_DFR             0x0E0  /* Destination Format Register */
#define LAPIC_SVR             0x0F0  /* Spurious Interrupt Vector Register */
#define LAPIC_ISR             0x100  /* In-Service Register (8 x 32-bit) */
#define LAPIC_TMR             0x180  /* Trigger Mode Register (8 x 32-bit) */
#define LAPIC_IRR             0x200  /* Interrupt Request Register (8 x 32-bit) */
#define LAPIC_ESR             0x280  /* Error Status Register */
#define LAPIC_ICR_LOW         0x300  /* Interrupt Command Register (low) */
#define LAPIC_ICR_HIGH        0x310  /* Interrupt Command Register (high) */
#define LAPIC_LVT_TIMER       0x320  /* LVT Timer */
#define LAPIC_LVT_THERMAL     0x330  /* LVT Thermal Sensor */
#define LAPIC_LVT_PERF        0x340  /* LVT Performance Monitoring */
#define LAPIC_LVT_LINT0       0x350  /* LVT LINT0 */
#define LAPIC_LVT_LINT1       0x360  /* LVT LINT1 */
#define LAPIC_LVT_ERROR       0x370  /* LVT Error */
#define LAPIC_TIMER_ICR       0x380  /* Timer Initial Count Register */
#define LAPIC_TIMER_CCR       0x390  /* Timer Current Count Register */
#define LAPIC_TIMER_DCR       0x3E0  /* Timer Divide Configuration Register */

/* SVR bits */
#define LAPIC_SVR_ENABLE      (1 << 8)  /* APIC enable bit */
#define LAPIC_SVR_VECTOR_MASK 0xFF      /* Spurious vector */

/* LVT bits */
#define LAPIC_LVT_MASK        (1 << 16)  /* Mask interrupt */
#define LAPIC_LVT_TIMER_PERIODIC (1 << 17)  /* Periodic timer mode */
#define LAPIC_LVT_DELIVERY_FIXED   0x0
#define LAPIC_LVT_DELIVERY_SMI     0x2
#define LAPIC_LVT_DELIVERY_NMI     0x4
#define LAPIC_LVT_DELIVERY_EXTINT  0x7
#define LAPIC_LVT_DELIVERY_MASK    0x700

/* Timer Divide Configuration Register values */
#define LAPIC_TIMER_DIV_1     0xB
#define LAPIC_TIMER_DIV_2     0x0
#define LAPIC_TIMER_DIV_4     0x1
#define LAPIC_TIMER_DIV_8     0x2
#define LAPIC_TIMER_DIV_16    0x3
#define LAPIC_TIMER_DIV_32    0x8
#define LAPIC_TIMER_DIV_64    0x9
#define LAPIC_TIMER_DIV_128   0xA

/* ICR Delivery Mode */
#define LAPIC_ICR_DELIVERY_FIXED    0x0
#define LAPIC_ICR_DELIVERY_LOWPRI   0x1
#define LAPIC_ICR_DELIVERY_SMI      0x2
#define LAPIC_ICR_DELIVERY_NMI      0x4
#define LAPIC_ICR_DELIVERY_INIT     0x5
#define LAPIC_ICR_DELIVERY_STARTUP  0x6
#define LAPIC_ICR_DELIVERY_EXTINT   0x7

/* ICR Destination Mode */
#define LAPIC_ICR_DEST_PHYSICAL  0x0
#define LAPIC_ICR_DEST_LOGICAL   0x1

/* ICR Level */
#define LAPIC_ICR_LEVEL_DEASSERT 0x0
#define LAPIC_ICR_LEVEL_ASSERT   0x1

/* ICR Trigger Mode */
#define LAPIC_ICR_TRIGGER_EDGE   0x0
#define LAPIC_ICR_TRIGGER_LEVEL  0x1

/* ICR Destination Shorthand */
#define LAPIC_ICR_DEST_NONE      0x0
#define LAPIC_ICR_DEST_SELF      0x1
#define LAPIC_ICR_DEST_ALL_INC   0x2
#define LAPIC_ICR_DEST_ALL_EXC   0x3

/* I/O APIC Register Offsets */
#define IOAPIC_ID               0x00
#define IOAPIC_VER              0x01
#define IOAPIC_ARB              0x02
#define IOAPIC_REDTBL_BASE      0x10  /* 2 registers per entry (low/high) */

/* Redirection Table Entry bits */
#define IOAPIC_RED_DELIVERY_FIXED   0x0
#define IOAPIC_RED_DELIVERY_LOWPRI  0x1
#define IOAPIC_RED_DELIVERY_SMI     0x2
#define IOAPIC_RED_DELIVERY_NMI     0x4
#define IOAPIC_RED_DELIVERY_INIT    0x5
#define IOAPIC_RED_DELIVERY_EXTINT  0x7

#define IOAPIC_RED_DEST_PHYSICAL  0x0
#define IOAPIC_RED_DEST_LOGICAL   0x1

#define IOAPIC_RED_ACTIVE_HIGH    0x0
#define IOAPIC_RED_ACTIVE_LOW     0x1
#define IOAPIC_RED_EDGE           0x0
#define IOAPIC_RED_LEVEL          0x1

#define IOAPIC_RED_MASK           (1 << 16)

/* Local APIC inline accessors */
static inline u32 lapic_read(u32 reg) {
    return lapic_base[reg >> 2];
}

static inline void lapic_write(u32 reg, u32 val) {
    lapic_base[reg >> 2] = val;
}

/* Send IPI to specific APIC ID with full ICR control */
static inline void lapic_send_ipi(u8 dest_apic_id, u8 vector, u8 delivery_mode,
                                   u8 trigger_mode, u8 level) {
    /* Wait for ICR to be idle */
    while (lapic_read(LAPIC_ICR_LOW) & (1 << 12)) {
        __asm__ volatile("pause");
    }

    lapic_write(LAPIC_ICR_HIGH, (u32)dest_apic_id << 24);
    lapic_write(LAPIC_ICR_LOW, 
                (u32)vector | 
                ((u32)delivery_mode << 8) | 
                (LAPIC_ICR_DEST_PHYSICAL << 11) | 
                ((u32)level << 14) |
                ((u32)trigger_mode << 15) |
                (LAPIC_ICR_DEST_NONE << 18));
}

/* Send INIT IPI to start an AP (level-triggered, assert) */
static inline void lapic_send_init_ipi(u8 dest_apic_id) {
    /* INIT uses level-triggered assert per Intel SDM */
    lapic_send_ipi(dest_apic_id, 0, LAPIC_ICR_DELIVERY_INIT,
                   LAPIC_ICR_TRIGGER_LEVEL, LAPIC_ICR_LEVEL_ASSERT);
}

/* Send STARTUP IPI to AP (edge-triggered, deassert) */
static inline void lapic_send_startup_ipi(u8 dest_apic_id, u8 vector) {
    /* STARTUP uses edge-triggered deassert per Intel SDM */
    lapic_send_ipi(dest_apic_id, vector, LAPIC_ICR_DELIVERY_STARTUP,
                   LAPIC_ICR_TRIGGER_EDGE, LAPIC_ICR_LEVEL_DEASSERT);
}

/* Function declarations */
void lapic_init(void);
void lapic_eoi(void);
void lapic_enable(void);
void lapic_disable(void);
u32 lapic_get_id(void);
void lapic_set_timer(u32 vector, u32 initial_count, int periodic);

void ioapic_init(void);
void ioapic_redirect_irq(u8 irq, u8 vector, u8 dest_apic_id);
u32 ioapic_read(u32 reg);
void ioapic_write(u32 reg, u32 val);

#endif /* FTK_APIC_H */