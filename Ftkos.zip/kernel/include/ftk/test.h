#ifndef FTK_TEST_H
#define FTK_TEST_H

#include <ftk/abi/types.h>
#include <ftk/printk.h>

#define TEST_PASS 0
#define TEST_FAIL 1

typedef void (*test_func_t)(void);

typedef struct {
    const char *name;
    test_func_t func;
    int failed;
} TestCase;

#define TEST_ASSERT(cond, msg) do { \
    if (!(cond)) { \
        kprintf("  FAIL at %s:%d: %s\n", __FILE__, __LINE__, msg); \
        current_test_failed = 1; \
    } \
} while(0)

#define TEST_ASSERT_EQ(a, b, msg) do { \
    if ((u64)(a) != (u64)(b)) { \
        kprintf("  FAIL at %s:%d: %s (0x%llx != 0x%llx)\n", \
                __FILE__, __LINE__, msg, (u64)(a), (u64)(b)); \
        current_test_failed = 1; \
    } \
} while(0)

#define TEST_START(name) do { \
    kprintf("[TEST] %s ... ", name); \
    test_name = name; \
    current_test_failed = 0; \
} while(0)

#define TEST_END() do { \
    if (current_test_failed) { \
        kprintf("FAIL\n"); \
        __test_failures++; \
    } else { \
        kprintf("OK\n"); \
    } \
    __test_count++; \
} while(0)

extern int current_test_failed;
extern const char *test_name;
extern int __test_count;
extern int __test_failures;

void test_register(const char *name, test_func_t func);
int test_run_all(void);

#endif
