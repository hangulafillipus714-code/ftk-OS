#ifndef FTK_RWLOCK_H
#define FTK_RWLOCK_H

#include <ftk/abi/types.h>

/*
 * Ticket-based rwlock.
 * - Readers increment the reader counter; wait if write-locked.
 * - Writers must wait for ALL readers to drain + no other writer.
 * - Uses atomic builtins for lock-free reader fast path.
 */

typedef struct rwlock {
    volatile u32 readers;
    volatile u32 writer;
} rwlock_t;

#define RWLOCK_INIT { 0, 0 }

void rwlock_read_lock(rwlock_t *l);
void rwlock_read_unlock(rwlock_t *l);
void rwlock_write_lock(rwlock_t *l);
void rwlock_write_unlock(rwlock_t *l);

#endif /* FTK_RWLOCK_H */
