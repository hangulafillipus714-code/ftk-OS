#ifndef FTK_ELF_H
#define FTK_ELF_H

#include <ftk/abi/types.h>
#include <ftk/vmm.h>

/* ELF Magic Numbers */
#define ELFMAG0 0x7F
#define ELFMAG1 'E'
#define ELFMAG2 'L'
#define ELFMAG3 'F'

/* ELF Classes */
#define ELFCLASSNONE 0
#define ELFCLASS32   1
#define ELFCLASS64   2

/* ELF Data Encoding */
#define ELFDATANONE 0
#define ELFDATA2LSB 1
#define ELFDATA2MSB 2

/* ELF Types */
#define ET_NONE   0
#define ET_REL    1
#define ET_EXEC   2
#define ET_DYN    3
#define ET_CORE   4

/* ELF Machine Types */
#define EM_NONE   0
#define EM_386    3
#define EM_X86_64 62

/* ELF Program Header Types */
#define PT_NULL    0
#define PT_LOAD    1
#define PT_DYNAMIC 2
#define PT_INTERP  3
#define PT_NOTE    4
#define PT_SHLIB   5
#define PT_PHDR    6

/* ELF Program Header Flags */
#define PF_X 1
#define PF_W 2
#define PF_R 4

typedef struct {
    u8  e_ident[16];
    u16 e_type;
    u16 e_machine;
    u32 e_version;
    u64 e_entry;
    u64 e_phoff;
    u64 e_shoff;
    u32 e_flags;
    u16 e_ehsize;
    u16 e_phentsize;
    u16 e_phnum;
    u16 e_shentsize;
    u16 e_shnum;
    u16 e_shstrndx;
} Elf64_Ehdr;

typedef struct {
    u32 p_type;
    u32 p_flags;
    u64 p_offset;
    u64 p_vaddr;
    u64 p_paddr;
    u64 p_filesz;
    u64 p_memsz;
    u64 p_align;
} Elf64_Phdr;

typedef struct {
    virt_addr_t entry_point;
    virt_addr_t brk;        /* end of loaded segments */
} elf_load_result_t;

/* 
 * Parse and load an ELF64 executable into the given address space.
 * Returns 0 on success, < 0 on error.
 */
int elf_load(AddressSpace *space, const void *elf_data, size_t elf_size, 
             elf_load_result_t *result);

#endif /* FTK_ELF_H */
