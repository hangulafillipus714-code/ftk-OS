#ifndef FTK_UACCESS_H
#define FTK_UACCESS_H

#include <ftk/abi/types.h>
#include <ftk/vmm.h>

/*
 * User-space memory access helpers.
 *
 * Every syscall that touches user pointers must route through these
 * functions. They validate canonical addresses, page presence, and
 * PTE_USER before performing the copy.
 */

#define USER_SPACE_TOP 0x00007FFFFFFFFFFFULL
#define USER_BRK_MIN   0x0000000000400000ULL  /* 4 MiB – below ELF load area */

/* Access intent for range validation */
#define UACCESS_READ  0x01
#define UACCESS_WRITE 0x02

/*
 * Validate that [addr, addr+n) lies in canonical user space and that
 * every page in the range is mapped with PTE_USER and the requested
 * access rights.
 *
 * Returns 0 on success, -1 on fault.
 */
int uaccess_validate_range(AddressSpace *space, virt_addr_t addr,
                           size_t n, u8 access);

/*
 * Copy n bytes from user space into a kernel buffer.
 * Returns 0 on success, -1 (EFAULT) on fault.
 */
int copy_from_user(void *dst, const void *user_src, size_t n);

/*
 * Copy n bytes from a kernel buffer into user space.
 * Returns 0 on success, -1 (EFAULT) on fault.
 */
int copy_to_user(void *user_dst, const void *src, size_t n);

#endif /* FTK_UACCESS_H */
