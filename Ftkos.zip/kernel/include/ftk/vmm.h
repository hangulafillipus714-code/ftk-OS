#ifndef FTK_VMM_H
#define FTK_VMM_H

#include <ftk/memory_layout.h>
#include <ftk/abi/types.h>

/* Page Table Entry flags */
#define PTE_PRESENT   (1ULL << 0)
#define PTE_WRITABLE  (1ULL << 1)
#define PTE_USER      (1ULL << 2)
#define PTE_HUGE      (1ULL << 7)
#define PTE_GLOBAL    (1ULL << 8)
#define PTE_NX        (1ULL << 63)

/* Alignment helper */
#ifndef IS_ALIGNED
#define IS_ALIGNED(addr, align) (((addr) & ((align) - 1)) == 0)
#endif

/* Address space structure */
typedef struct AddressSpace {
    phys_addr_t pml4;  /* Physical address of PML4 */
    u64 *pml4_virt; /* Virtual address of PML4 */
} AddressSpace;

/* Kernel flag shortcuts */
#define PTE_KERNEL_FLAGS (PTE_PRESENT | PTE_WRITABLE)
#define PTE_USER_FLAGS   (PTE_PRESENT | PTE_WRITABLE | PTE_USER)

/* Kernel address space (defined in vmm.c) */
extern AddressSpace kernel_space;

/* Virtual Memory Manager API */
void vmm_init(void);
int vmm_map_page(AddressSpace *space, virt_addr_t virt, phys_addr_t phys, u64 flags);
void vmm_switch_address_space(AddressSpace *space);
phys_addr_t vmm_virt_to_phys(virt_addr_t virt);
int vmm_unmap_page(AddressSpace *space, virt_addr_t virt);
int vmm_unmap_and_free(AddressSpace *space, virt_addr_t virt);
int vmm_get_flags(AddressSpace *space, virt_addr_t virt, u64 *flags_out, phys_addr_t *phys_out);
void vmm_destroy_address_space(AddressSpace *space);
void invlpg(virt_addr_t virt);

/* Convenience aliases matching GUI syscall code */
#define PAGE_PRESENT  PTE_PRESENT
#define PAGE_WRITE    PTE_WRITABLE
#define PAGE_USER     PTE_USER

/* Map a single page directly into a PML4 address space (used by SYS_FB_MAP, SYS_MMAP) */
static inline int vmm_map_page_in(phys_addr_t pml4, virt_addr_t virt,
                                   phys_addr_t phys, u64 flags)
{
    AddressSpace tmp;
    tmp.pml4      = pml4;
    tmp.pml4_virt = (u64 *)(uintptr_t)(pml4 + KERNEL_VIRT_BASE);
    return vmm_map_page(&tmp, virt, phys, flags);
}

#endif /* FTK_VMM_H */