#pragma once

#define LOG_CLR_RESET   "\x1b[0m"
#define LOG_CLR_RED     "\x1b[31m"
#define LOG_CLR_GREEN   "\x1b[32m"
#define LOG_CLR_YELLOW  "\x1b[33m"
#define LOG_CLR_CYAN    "\x1b[36m"

void serial_init(void);
void serial_write(char c);
void serial_puts(const char *s);

void log_info(const char *msg);
void log_warn(const char *msg);
void log_error(const char *msg);
void log_debug(const char *msg);