#ifndef FTK_DRIVERS_CHAR_CONSOLE_H
#define FTK_DRIVERS_CHAR_CONSOLE_H

void console_init(void);
char console_getchar(void);

#endif
