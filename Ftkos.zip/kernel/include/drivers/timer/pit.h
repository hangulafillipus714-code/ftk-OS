#ifndef PIT_H
#define PIT_H

#include <ftk/abi/types.h>
#include <ftk/arch/x86_64/isr.h>

/* Initialize PIT to desired frequency */
void pit_init(u32 frequency);

/* PIT interrupt handler */
void pit_handler(Registers *regs);

/* System tick counter, incremented by pit_handler */
extern volatile u64 system_ticks;

/* Get current system tick count */
u64 pit_get_ticks(void);

#endif /* PIT_H */
