/*
 * kernel/user/elf.c — ELF64 executable loader
 *
 * Loads PT_LOAD segments into a user address space with correct
 * permission flags (NX on non-executable pages). Handles overlapping
 * segment page boundaries and rolls back on failure.
 */

#include <ftk/elf.h>
#include <ftk/pmm.h>
#include <ftk/vmm.h>
#include <ftk/string.h>
#include <ftk/printk.h>
#include <ftk/memory_layout.h>

/* ALIGN_DOWN/ALIGN_UP provided by pmm.h — do not redefine */

static u64 elf_segment_flags(u32 p_flags) {
    u64 flags = PTE_PRESENT | PTE_USER;
    if (p_flags & PF_W) flags |= PTE_WRITABLE;
    if (!(p_flags & PF_X)) flags |= PTE_NX;
    return flags;
}

static int elf_ensure_page(AddressSpace *space, virt_addr_t vaddr, u64 flags) {
    u64 existing = 0;
    if (vmm_get_flags(space, vaddr, &existing, NULL) == 0) {
        return 0;
    }

    phys_addr_t phys = pmm_alloc_page();
    if (!phys) return -1;

    if (vmm_map_page(space, vaddr, phys, flags) != 0) {
        pmm_free_page(phys);
        return -1;
    }

    memset((void *)PHYS_TO_VIRT(phys), 0, PAGE_SIZE);
    return 0;
}

static void elf_unmap_range(AddressSpace *space, virt_addr_t start,
                            virt_addr_t end) {
    for (virt_addr_t v = start; v < end; v += PAGE_SIZE) {
        vmm_unmap_and_free(space, v);
    }
}

int elf_load(AddressSpace *space, const void *elf_data, size_t elf_size,
             elf_load_result_t *result) {
    if (!space || !elf_data || !result || elf_size < sizeof(Elf64_Ehdr)) {
        return -1;
    }

    const Elf64_Ehdr *ehdr = (const Elf64_Ehdr *)elf_data;

    if (ehdr->e_ident[0] != ELFMAG0 || ehdr->e_ident[1] != ELFMAG1 ||
        ehdr->e_ident[2] != ELFMAG2 || ehdr->e_ident[3] != ELFMAG3) {
        kprintf("[ELF] Invalid magic number\n");
        return -1;
    }

    if (ehdr->e_ident[4] != ELFCLASS64) {
        kprintf("[ELF] Not a 64-bit ELF\n");
        return -1;
    }
    if (ehdr->e_machine != EM_X86_64) {
        kprintf("[ELF] Not an x86_64 ELF\n");
        return -1;
    }

    if (ehdr->e_type != ET_EXEC && ehdr->e_type != ET_DYN) {
        kprintf("[ELF] Not an executable\n");
        return -1;
    }

    if (ehdr->e_phoff + (ehdr->e_phnum * ehdr->e_phentsize) > elf_size) {
        kprintf("[ELF] Program headers out of bounds\n");
        return -1;
    }

    virt_addr_t max_brk = 0;
    virt_addr_t mapped_start = (virt_addr_t)-1;
    virt_addr_t mapped_end = 0;

    for (int i = 0; i < ehdr->e_phnum; i++) {
        const Elf64_Phdr *phdr = (const Elf64_Phdr *)((u8 *)elf_data + ehdr->e_phoff +
                                                      (i * ehdr->e_phentsize));

        if (phdr->p_type != PT_LOAD) continue;
        if (phdr->p_memsz == 0) continue;

        if (phdr->p_offset + phdr->p_filesz > elf_size) {
            kprintf("[ELF] Segment out of bounds\n");
            goto rollback;
        }

        virt_addr_t vaddr = phdr->p_vaddr;
        virt_addr_t memsz = phdr->p_memsz;
        virt_addr_t filesz = phdr->p_filesz;
        u64 seg_flags = elf_segment_flags(phdr->p_flags);

        virt_addr_t start_page = ALIGN_DOWN(vaddr, PAGE_SIZE);
        virt_addr_t end_page = ALIGN_UP(vaddr + memsz, PAGE_SIZE);

        for (virt_addr_t page = start_page; page < end_page; page += PAGE_SIZE) {
            if (elf_ensure_page(space, page, seg_flags) != 0) {
                kprintf("[ELF] Out of memory mapping segment\n");
                goto rollback;
            }
            if (page < mapped_start) mapped_start = page;
            if (page + PAGE_SIZE > mapped_end) mapped_end = page + PAGE_SIZE;
        }

        virt_addr_t remaining = filesz;
        virt_addr_t dest = vaddr;
        virt_addr_t src_off = phdr->p_offset;

        while (remaining > 0) {
            virt_addr_t page_base = ALIGN_DOWN(dest, PAGE_SIZE);
            u64 offset = dest - page_base;

            phys_addr_t phys = 0;
            if (vmm_get_flags(space, page_base, NULL, &phys) != 0) {
                kprintf("[ELF] Segment mapping lost during copy\n");
                goto rollback;
            }

            u64 chunk = PAGE_SIZE - offset;
            if (chunk > remaining) chunk = remaining;

            memcpy((u8 *)PHYS_TO_VIRT(phys) + offset,
                   (const u8 *)elf_data + src_off, chunk);

            dest += chunk;
            src_off += chunk;
            remaining -= chunk;
        }

        if (vaddr + memsz > max_brk) {
            max_brk = vaddr + memsz;
        }
    }

    result->entry_point = ehdr->e_entry;
    result->brk = ALIGN_UP(max_brk, PAGE_SIZE);
    return 0;

rollback:
    if (mapped_end > mapped_start) {
        elf_unmap_range(space, mapped_start, mapped_end);
    }
    return -1;
}
