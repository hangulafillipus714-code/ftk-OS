#include <ftk/abi/types.h>
#include <ftk/stdint.h>
#include <drivers/char/serial.h>

/*
 * Weak stubs
 * Real implementations will override these
 */

/* Stack protector failure handler — called by GCC when canary mismatch detected.
 * Must NOT be weak so it takes precedence over the libgcc fallback. */
__attribute__((noreturn))
void __stack_chk_fail(void) {
    const char msg[] = "\n*** STACK SMASHING DETECTED ***\n";
    const char *p = msg;
    while (*p) {
        __asm__ volatile("outb %0, %1" : : "a"((u8)*p), "Nd"((u16)0x3F8));
        p++;
    }
    for (;;) {
        __asm__ volatile("cli; hlt");
    }
}

__attribute__((weak))
void memory_init(void *boot_info) {
    (void)boot_info;
}

__attribute__((weak))
void scheduler_init(void) {}

__attribute__((weak))
void pit_init(uint32_t frequency) {
    (void)frequency;
}

__attribute__((weak))
int create_init_process(void) {
    return 0;
}

__attribute__((weak))
void scheduler_start(void) {}

__attribute__((weak))
int putchar(int c) {
    return c;
}
