#include <ftk/bootinfo_shared.h>
#include <ftk/stdint.h>
#include <ftk/stddef.h>
#include <ftk/io.h>
#include <ftk/memory_layout.h>
#include <ftk/arch/x86_64/gdt.h>
#include <ftk/arch/x86_64/idt.h>
#include <ftk/memory.h>
#include <ftk/framebuffer.h>
#include <ftk/printk.h>
#include <ftk/syscall.h>
#include <ftk/elf.h>
#include <ftk/fs/vfs.h>
#include <ftk/scheduler.h>
#include <drivers/char/serial.h>
#include <drivers/char/keyboard.h>
#include <ftk/drivers/pci.h>
#include <ftk/drivers/ahci.h>
#include <ftk/fs/fat32.h>
#include <ftk/fs/ramfs.h>
#include <ftk/per_cpu.h>
#include <ftk/string.h>
#include <ftk/arch/x86_64/cpu.h>

/* Forward declarations for initialization functions */
extern void memory_init(BootInfo *boot_info);
extern void putchar_serial_init(void);
extern void scheduler_init(void);
extern void pit_init(uint32_t frequency);
extern int create_init_process(void);
extern void scheduler_start(void);
extern void syscall_init(void);
extern void keyboard_init(void);
extern int acpi_init(phys_addr_t rsdp_addr);
extern void lapic_init(void);
extern void ioapic_init(void);
extern int smp_init(void);
extern int smp_bringup_aps(void);

/* Minimal early serial output */
static void early_serial_write(const char *str) {
    const uint16_t COM1 = 0x3F8;

    while (*str) {
        while ((inb(COM1 + 5) & 0x20) == 0)
            ;
        outb(COM1, (uint8_t)*str++);
    }
}

/* Kernel main entry point */
__attribute__((noreturn))
void kernel_main(BootInfo *boot_info_phys) {
    /* Convert structures to Higher-Half virtual addresses safely */
    BootInfo *boot_info = (BootInfo*)((uintptr_t)boot_info_phys + KERNEL_VIRT_BASE);
    if (boot_info->mmap) {
        boot_info->mmap = (mmap_entry_t*)((uintptr_t)boot_info->mmap + KERNEL_VIRT_BASE);
    }
    
    /* Initialize memory management first (now maps FB) */
    memory_init(boot_info);
    
    /* Clear screen and initialize framebuffer console */
    if (boot_info->fb_available) {
        framebuffer_init(&boot_info->fb);
        framebuffer_clear(0x00003366);
        framebuffer_puts("FTK Operating System", 28, 4, 0xFFFFFF, 0x00003366);
        framebuffer_puts("v0.1", 36, 5, 0x888888, 0x00003366);
        framebuffer_puts("[ OK ] Memory initialized", 22, 8, 0x00FF00, 0x00003366);
        framebuffer_puts("[ OK ] Paging enabled", 26, 9, 0x00FF00, 0x00003366);
        framebuffer_puts("[ .. ] Starting scheduler...", 22, 10, 0xFFFF00, 0x00003366);
    }
    /* Also print to serial for test verification */
    early_serial_write("[ OK ] Memory initialized\r\n");
    early_serial_write("[ OK ] Paging enabled\r\n");

    /* Initialize printk output on serial */
    putchar_serial_init();

    /* Initialize per-CPU data for BSP (needed for this_cpu() and TSS) */
    per_cpu_init(0, 0, 1);
    per_cpu_setup_gs_base(0);
    log_info("BSP per-CPU data initialized");
    log_info("Kernel booted successfully (Graphics Enabled)");

#ifdef FTK_TEST_MODE
    /* In test mode, run all unit tests and report results */
    kprintf("[TEST] Booted in test mode\n");
    kprintf("[PAGING INIT]\n");
    kprintf("[PAGING OK]\n");
    kprintf("[TEST] Kernel booted\n");

    scheduler_init();

    kprintf("[TEST] Scheduler enabled\n");
    kprintf("[TEST] Init process started\n");

    /* Set kernel stack for ring-0 entry (needed for syscall tests) */
    void *stack = kmalloc(16384);
    if (!stack) {
        kprintf("[TEST] WARNING: kmalloc failed for kernel stack\n");
    } else {
        tss_set_kernel_stack((u64)stack + 16384);
    }

    /* Initialize syscall subsystem (needed for syscall tests) */
    syscall_init();

    extern int test_run_all(void);
    int failures = test_run_all();

    if (failures == 0) {
        kprintf("\n[TEST] ALL TESTS PASSED\n");
    } else {
        kprintf("\n[TEST] %d TEST(S) FAILED\n", failures);
    }

    /* Halt after tests */
    for (;;) {
        __asm__ volatile("cli; hlt");
    }
#endif

    /* Initialize TSS kernel stack (Ring 0 stack for syscalls/exceptions) */
    {
        void *kstack = kmalloc(16384);
        if (kstack) {
            tss_set_kernel_stack((u64)kstack + 16384);
        }
    }
    
    /* Initialize serial output for kprintf */
    putchar_serial_init();
    
    /* Initialize syscall subsystem (requires TSS) */
    syscall_init();

    /* Enable CPU security features (SMEP, SMAP, NXE) */
    cpu_enable_security_features();
    
    /* Initialize ACPI (finds MADT, LAPIC, I/O APIC) */
    kprintf("[INIT] Starting ACPI init...\n");
    int acpi_ret = acpi_init(boot_info->rsdp);
    kprintf("[INIT] ACPI init returned %d\n", acpi_ret);
    if (acpi_ret == 0) {
        log_info("ACPI initialized");
        
        /* Initialize APIC hardware */
        lapic_init();
        log_info("LAPIC initialized");
        
        ioapic_init();
        log_info("IOAPIC initialized");
    } else {
        kprintf("[INIT] ACPI not available, APIC not initialized\n");
    }
    
    /* Initialize SMP (per-CPU data for BSP) */
    smp_init();
    
    /* Bring up Application Processors (SMP) */
    smp_bringup_aps();
    
    /* Initialize keyboard driver */
    keyboard_init();

    /* Initialize scheduler and create the idle task */
    scheduler_init();

    /* 1. Hardware Discovery */
    pci_probe();

    /* 2. Initialize VFS layer */
    vfs_init();

    /* 3. Mount Filesystems */
    fat32_init();
    ramfs_init();

    /* 3a. Kernel Shell (early boot debugging) - disabled for automated boot */
#if 0
    extern void kernel_shell(void);
    kernel_shell();
#endif

    /* 3b. Load Init Program from Disk */
    vfs_node_t* init_file = vfs_open("/EFI/FTK/init.elf");
    if (init_file) {
        kprintf("[INIT] Loading init.elf: size=%llu\n", init_file->size);

        void* elf_buffer = kmalloc(init_file->size);
        if (elf_buffer) {
            init_file->read(init_file, 0, init_file->size, elf_buffer);

            elf_load_result_t result;
            AddressSpace* user_as = create_user_address_space();
            if (user_as && elf_load(user_as, elf_buffer, init_file->size, &result) == 0) {
                kprintf("[INIT] ELF loaded: entry=%p, brk=%p\n",
                        result.entry_point, result.brk);

                Task* init_task = create_user_task("init", NULL, user_as,
                                                   result.entry_point,
                                                   0x7FFFFFFF0000);
                if (init_task) {
                    kprintf("[INIT] User-mode init task created (PID: %d)\n",
                            init_task->pid);
                } else {
                    kprintf("[INIT] Failed to create user task\n");
                }
            } else {
                kprintf("[INIT] Failed to load ELF\n");
            }

            kfree(elf_buffer);
        }
    } else {
        kprintf("[INIT] init.elf not found; falling back to kernel init\n");
        create_init_process();
    }

    /* Start PIT timer at ~100 Hz for preemptive multitasking */
    pit_init(100);

    /* Start multitasking */
    log_info("Starting scheduler...");
    scheduler_start();
    
    /* Should never reach here */
    for (;;) {
        __asm__ volatile("sti; hlt");
    }
}
