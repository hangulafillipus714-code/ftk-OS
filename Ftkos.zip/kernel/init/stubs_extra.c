#include <ftk/stdint.h>

/*
 * Interrupt / syscall weak stubs
 * Real arch-specific handlers override these
 */

__attribute__((weak))
void isr_handler(void) {
    /* default: do nothing */
}

__attribute__((weak))
void irq_handler(void) {
    /* default: do nothing */
}

__attribute__((weak))
void syscall_handler(void) {
    /* default: do nothing */
}
