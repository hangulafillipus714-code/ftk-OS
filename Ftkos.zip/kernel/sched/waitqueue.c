/*
 * kernel/sched/waitqueue.c — Blocking wait queue implementation
 *
 * A wait queue is a list of tasks blocked on an event. The queue is
 * protected by a spinlock to ensure safe concurrent access from
 * interrupt and process context.
 */

#include <ftk/waitqueue.h>
#include <ftk/scheduler.h>
#include <ftk/per_cpu.h>
#include <ftk/memory.h>
#include <ftk/spinlock.h>

static spinlock_t wq_spinlock = SPINLOCK_INIT;

void init_waitqueue_head(wait_queue_head_t *wq) {
    wq->head = NULL;
    wq->tail = NULL;
}

void wait_event(wait_queue_head_t *wq) {
    wait_queue_entry_t *entry = kmalloc(sizeof(wait_queue_entry_t));
    if (!entry) return;  /* OOM — cannot block, caller retries */

    entry->task = current_task;
    entry->next = NULL;

    u64 rflags;
    spinlock_acquire_irqsave(&wq_spinlock, &rflags);

    if (!wq->tail) {
        wq->head = entry;
        wq->tail = entry;
    } else {
        wq->tail->next = entry;
        wq->tail = entry;
    }

    current_task->state = TASK_BLOCKED;
    spinlock_release_irqrestore(&wq_spinlock, rflags);

    scheduler_yield();
}

void wake_up(wait_queue_head_t *wq) {
    u64 rflags;
    spinlock_acquire_irqsave(&wq_spinlock, &rflags);

    wait_queue_entry_t *entry = wq->head;
    if (entry) {
        wq->head = entry->next;
        if (!wq->head)
            wq->tail = NULL;

        entry->task->state = TASK_READY;
        kfree(entry);
    }

    spinlock_release_irqrestore(&wq_spinlock, rflags);
}

void wake_up_all(wait_queue_head_t *wq) {
    u64 rflags;
    spinlock_acquire_irqsave(&wq_spinlock, &rflags);

    wait_queue_entry_t *entry = wq->head;
    while (entry) {
        entry->task->state = TASK_READY;
        wait_queue_entry_t *next = entry->next;
        kfree(entry);
        entry = next;
    }

    wq->head = NULL;
    wq->tail = NULL;
    spinlock_release_irqrestore(&wq_spinlock, rflags);
}

int waitqueue_is_empty(wait_queue_head_t *wq) {
    u64 rflags;
    spinlock_acquire_irqsave(&wq_spinlock, &rflags);
    int empty = (wq->head == NULL);
    spinlock_release_irqrestore(&wq_spinlock, rflags);
    return empty;
}
