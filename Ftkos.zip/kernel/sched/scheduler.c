/*
 * kernel/sched/scheduler.c — FTK OS Scheduler
 *
 * Round-robin preemptive scheduler with IRQ-safe spinlock-protected run queue.
 * - scheduler_yield() performs cooperative context switch via task_switch()
 * - PIT handler calls scheduler_yield() for preemptive switching
 * - TSS RSP0 is updated on every switch for proper Ring 3 support
 * - Terminated tasks are removed from the queue and resources reclaimed
 * - Preemption can be suppressed via preempt_disable()/preempt_enable()
 */

#include <ftk/scheduler.h>
#include <ftk/framebuffer.h>   /* ftk_ticks */
#include <ftk/per_cpu.h>
#include <ftk/memory.h>
#include <ftk/pmm.h>
#include <ftk/string.h>
#include <ftk/printk.h>
#include <ftk/spinlock.h>
#include <ftk/arch/x86_64/gdt.h>
#include <ftk/syscall.h>
#include <ftk/io.h>
Task *task_list = NULL;
u32 next_pid = 1;

extern AddressSpace kernel_space;

spinlock_t scheduler_lock = SPINLOCK_INIT;
spinlock_t wq_spinlock = SPINLOCK_INIT;

/*
 * scheduler_collect_zombie — find and remove a zombie child from the task list.
 *
 * target_pid = -1 matches any child; otherwise matches specific PID.
 * Returns the zombie Task (removed from list) or NULL.
 * The caller must task_destroy() the returned task after reading exit_status.
 */
Task *scheduler_collect_zombie(int target_pid)
{
    if (!task_list || !current_task) return NULL;

    u64 rflags;
    spinlock_acquire_irqsave(&scheduler_lock, &rflags);

    Task *result = NULL;
    Task *t = task_list;
    do {
        if (t->parent_pid == current_task->pid &&
            t->state == TASK_ZOMBIE &&
            (target_pid == -1 || (int)t->pid == target_pid)) {
            /* Remove from list */
            t->prev->next = t->next;
            t->next->prev = t->prev;
            if (task_list == t) {
                task_list = (t->next == t) ? NULL : t->next;
            }
            result = t;
            break;
        }
        t = t->next;
    } while (t != task_list);

    spinlock_release_irqrestore(&scheduler_lock, rflags);
    return result;
}

/*
 * scheduler_waitpid_prepare — atomically check for zombie and prepare to block.
 *
 * Under scheduler_lock (IRQs disabled):
 *   1. Search for a zombie child matching target_pid
 *   2. If found, remove from task list, return it in *zombie_out
 *   3. If no zombie but child exists, set TASK_BLOCKED (directly, no waitqueue)
 *   4. If no child at all, return -1
 *
 * Returns:  1 = zombie collected (*zombie_out), 0 = blocked (caller yields + retries),
 *           -1 = no child
 *
 * This avoids the TOCTOU race between checking for zombie/child and blocking.
 * scheduler_exit_current holds scheduler_lock when it wakes the parent via
 * direct state change, so no wakeup is lost.
 */
int scheduler_waitpid_prepare(int target_pid, Task **zombie_out)
{
    if (!task_list || !current_task) return -1;

    u64 rflags;
    spinlock_acquire_irqsave(&scheduler_lock, &rflags);

    Task *t = task_list;
    do {
        if (t->parent_pid == current_task->pid &&
            t->state == TASK_ZOMBIE &&
            (target_pid == -1 || (int)t->pid == target_pid)) {
            /* Unlink from circular list before handing back to caller.
             * Must update task_list head if we are removing it,
             * otherwise task_list will point at a freed/destroyed
             * task after task_destroy() runs in sys_waitpid. */
            t->prev->next = t->next;
            t->next->prev = t->prev;
            if (task_list == t) {
                task_list = (t->next == t) ? NULL : t->next;
            }
            *zombie_out = t;
            spinlock_release_irqrestore(&scheduler_lock, rflags);
            return 1;
        }
        t = t->next;
    } while (t != task_list);

    t = task_list;
    do {
        if (t->parent_pid == current_task->pid &&
            (target_pid == -1 || (int)t->pid == target_pid)) {
            current_task->state = TASK_BLOCKED;
            spinlock_release_irqrestore(&scheduler_lock, rflags);
            return 0;
        }
        t = t->next;
    } while (t != task_list);

    spinlock_release_irqrestore(&scheduler_lock, rflags);
    return -1;
}

/*
 * scheduler_has_child — check whether the current task has any child
 * with the given PID (or any child if target_pid == -1).
 */
int scheduler_has_child(int target_pid)
{
    if (!task_list || !current_task) return 0;

    u64 rflags;
    spinlock_acquire_irqsave(&scheduler_lock, &rflags);

    int found = 0;
    Task *t = task_list;
    do {
        if (t->parent_pid == current_task->pid &&
            (target_pid == -1 || (int)t->pid == target_pid)) {
            found = 1;
            break;
        }
        t = t->next;
    } while (t != task_list);

    spinlock_release_irqrestore(&scheduler_lock, rflags);
    return found;
}

/* Internal: caller must hold scheduler_lock (or be in a context where
 * the task list cannot change) */
static Task *find_task_by_pid_locked(u32 pid) {
    if (!task_list) return NULL;
    Task *t = task_list;
    do {
        if (t->pid == pid) return t;
        t = t->next;
    } while (t != task_list);
    return NULL;
}

Task *find_task_by_pid(u32 pid) {
    u64 rflags;
    spinlock_acquire_irqsave(&scheduler_lock, &rflags);
    Task *t = find_task_by_pid_locked(pid);
    spinlock_release_irqrestore(&scheduler_lock, rflags);
    return t;
}

static int task_is_runnable(const Task *task) {
    return task && (task->state == TASK_READY || task->state == TASK_RUNNING);
}

static Task *scheduler_pick_next(Task *from) {
    if (!from || !task_list) return NULL;

    Task *cursor = from->next;
    size_t guard = 0;
    Task *idle_fallback = NULL;

    while (cursor != from) {
        if (task_is_runnable(cursor)) {
            if (cursor->pid == 0) {
                idle_fallback = cursor;  /* remember idle, but keep looking */
            } else {
                return cursor;  /* prefer non-idle tasks */
            }
        }
        cursor = cursor->next;
        if (++guard > 4096) break;
    }

    /* If we only found idle, check if from is runnable (and not idle) */
    if (task_is_runnable(from)) {
        if (from->pid == 0) {
            return idle_fallback;  /* only idle is runnable */
        }
        return from;
    }

    return idle_fallback;
}

void scheduler_init(void) {
    current_task = kmalloc(sizeof(Task));
    memset(current_task, 0, sizeof(Task));

    strncpy(current_task->name, "idle", 31);
    current_task->pid = 0;
    current_task->state = TASK_RUNNING;
    current_task->address_space = &kernel_space;
    current_task->is_user = 0;
    current_task->kernel_stack_top = 0;
    current_task->preempt_count = 0;

    for (int i = 0; i < MAX_FDS; i++)
        current_task->fd_table[i].used = 0;
    current_task->fd_table[0].used = 1;
    current_task->fd_table[1].used = 1;
    current_task->fd_table[2].used = 1;

    task_list = current_task;
    current_task->next = current_task;
    current_task->prev = current_task;
}

void switch_task(Task *next) {
    if (!current_task || !next || current_task == next) return;

    u64 rflags;
    spinlock_acquire_irqsave(&scheduler_lock, &rflags);

    Task *prev = current_task;
    if (prev->state == TASK_RUNNING)
        prev->state = TASK_READY;
    next->state = TASK_RUNNING;
    current_task = next;

    syscall_set_kstack(current_task->kernel_stack_top);

    if (next->kernel_stack_top) {
        tss_set_kernel_stack(next->kernel_stack_top);
    }

    if (next->address_space != prev->address_space) {
        vmm_switch_address_space(next->address_space);
    }

    /* Save/restore user RSP (gs:8 slot) to prevent corruption when a
     * different task's syscall entry overwrites it between context switch
     * and the original task's sysretq. */
    u64 saved_usrsp;
    __asm__ volatile(
        "mov %%gs:8, %0\n\t"
        "mov %1, %%gs:8"
        : "=&r"(saved_usrsp)
        : "r"(next->user_rsp)
        : "memory");
    prev->user_rsp = saved_usrsp;

    /* Release the lock BEFORE task_switch — a new task's forged stack
     * returns to ret_from_interrupt (not back into this C frame), so any
     * lock release after task_switch would never execute, leaving the
     * scheduler_lock held and deadlocking the next timer IRQ.
     *
     * IRQs stay disabled here (we saved rflags but haven't restored yet).
     * task_switch's 'popfq' on the resume path will restore IF to the
     * value saved by THIS stack frame on entry (which is what we want,
     * because resume returns to HERE, and then the explicit push/popfq
     * below does the matching restore from this function's rflags local). */
    spinlock_release(&scheduler_lock);

    task_switch(&prev->context, &next->context);

    /* task_switch returned into the resuming task's stack.  The local
     * variable 'rflags' was saved by THIS function on the resuming task's
     * stack when it first entered switch_task, so it correctly reflects
     * the IRQ state that task needs to return with.  Do NOT call
     * spinlock_release again: the lock was already dropped above, and
     * another task may currently hold it. */
    __asm__ volatile(
        "mov %0, %%gs:8"
        :
        : "r"(current_task->user_rsp)
        : "memory");

    __asm__ volatile("push %0; popfq" : : "r"(rflags) : "memory");
}

void scheduler_tick(void) {
    ftk_ticks++;
    if (!current_task) return;
    current_task->ticks++;
}

void scheduler_start(void) {
    kprintf("[SCHED] Multi-tasking enabled. Switching to first task...\n");

    if (!task_list || !current_task) {
        kprintf("[SCHED] ERROR: No tasks to run!\n");
        for (;;) __asm__ volatile("hlt");
    }

    Task *next = scheduler_pick_next(current_task);
    if (!next) {
        kprintf("[SCHED] ERROR: No runnable tasks!\n");
        for (;;) __asm__ volatile("hlt");
    }

    kprintf("[SCHED] Switching to task PID %u (%s)\n", next->pid, next->name);

    __asm__ volatile("sti");

    switch_task(next);

    for (;;) {
        __asm__ volatile("hlt");
    }
}

void task_destroy(Task *task) {
    if (!task || task->pid == 0) return;

    if (task->kernel_stack_phys) {
        pmm_free_pages(task->kernel_stack_phys, 4);
        task->kernel_stack_phys = 0;
        task->kernel_stack_top = 0;
    }

    if (task->address_space && task->address_space != &kernel_space) {
        vmm_destroy_address_space(task->address_space);
        kfree(task->address_space);
        task->address_space = NULL;
    }

    kfree(task);
}

void scheduler_exit_current(int status) {
    if (!current_task || current_task->pid == 0) {
        for (;;) {
            __asm__ volatile("hlt");
        }
    }

    u64 rflags;
    spinlock_acquire_irqsave(&scheduler_lock, &rflags);

    current_task->exit_status = status;
    current_task->state = TASK_ZOMBIE;

    kprintf("[SCHED] PID %u (%s) exited with status %d, parent PID %u\n",
            current_task->pid, current_task->name, status,
            current_task->parent_pid);

    /* Wake up parent if it exists */
    if (current_task->parent_pid != 0) {
        Task *parent = find_task_by_pid_locked(current_task->parent_pid);
        if (parent) {
            kprintf("[SCHED] Waking parent PID %u for child PID %u\n",
                    parent->pid, current_task->pid);
            if (parent->state == TASK_BLOCKED)
                parent->state = TASK_READY;
        } else {
            kprintf("[SCHED] Parent PID %u not found for child PID %u (orphaned)\n",
                    current_task->parent_pid, current_task->pid);
        }
    }

    /* Pick next runnable task (zombies are skipped by task_is_runnable) */
    Task *to_run = scheduler_pick_next(task_list);
    if (!to_run) {
        spinlock_release_irqrestore(&scheduler_lock, rflags);
        for (;;) {
            __asm__ volatile("hlt");
        }
    }

    Task *victim = current_task;
    to_run->state = TASK_RUNNING;
    current_task = to_run;

    syscall_set_kstack(current_task->kernel_stack_top);

    if (to_run->kernel_stack_top) {
        tss_set_kernel_stack(to_run->kernel_stack_top);
    }

    if (to_run->address_space != victim->address_space) {
        vmm_switch_address_space(to_run->address_space);
    }

    /* Save/restore user RSP (gs:8 slot) to prevent corruption when a
     * different task's syscall entry overwrites it between context switch
     * and the original task's sysretq. */
    u64 saved_usrsp;
    __asm__ volatile(
        "mov %%gs:8, %0\n\t"
        "mov %1, %%gs:8"
        : "=&r"(saved_usrsp)
        : "r"(to_run->user_rsp)
        : "memory");
    victim->user_rsp = saved_usrsp;

    /* Release the lock BEFORE task_switch — see switch_task for the full
     * reasoning.  Without this, a switch to a newly-spawned task (whose
     * forged stack returns through ret_from_interrupt, not back into this
     * C frame) would leave scheduler_lock held and deadlock the next
     * timer IRQ.
     *
     * The victim is TASK_ZOMBIE and will never resume through this stack,
     * so any post-task_switch lines are unreachable with the current
     * stack-forging scheme — they exist only as a defensive guard. */
    spinlock_release(&scheduler_lock);

    task_switch(&victim->context, &to_run->context);

    /* UNREACHABLE under the current task-forging scheme (see comment
     * above): new tasks jump to ret_from_interrupt, and previously
     * preempted tasks resume inside their own scheduler_yield frame
     * (which runs its own IRQ restoration).  If a future change ever
     * makes the victim's stack a resumable frame, restore IRQs here. */
    __asm__ volatile(
        "mov %0, %%gs:8"
        :
        : "r"(current_task->user_rsp)
        : "memory");
    __asm__ volatile("push %0; popfq" : : "r"(rflags) : "memory");
    __builtin_unreachable();
}

u32 scheduler_current_pid(void) {
    if (!current_task) return 0;
    return current_task->pid;
}

void scheduler_yield(void) {
    if (!current_task || !task_list) return;

    if (is_preempt_disabled()) return;

    u64 rflags;
    spinlock_acquire_irqsave(&scheduler_lock, &rflags);

    Task *prev = current_task;
    Task *next = scheduler_pick_next(prev);

    if (!next || next == prev) {
        spinlock_release_irqrestore(&scheduler_lock, rflags);
        return;
    }

    if (prev->state == TASK_RUNNING)
        prev->state = TASK_READY;
    next->state = TASK_RUNNING;
    current_task = next;

    syscall_set_kstack(current_task->kernel_stack_top);

    if (next->kernel_stack_top) {
        tss_set_kernel_stack(next->kernel_stack_top);
    }

    if (next->address_space != prev->address_space) {
        vmm_switch_address_space(next->address_space);
    }

    /* Save/restore user RSP (gs:8 slot) to prevent corruption when a
     * different task's syscall entry overwrites it between context switch
     * and the original task's sysretq. */
    u64 saved_usrsp;
    __asm__ volatile(
        "mov %%gs:8, %0\n\t"
        "mov %1, %%gs:8"
        : "=&r"(saved_usrsp)
        : "r"(next->user_rsp)
        : "memory");
    prev->user_rsp = saved_usrsp;

    /* Release the lock BEFORE task_switch — see switch_task for the full
     * reasoning.  Without this, a switch to a newly-spawned task (whose
     * forged stack returns through ret_from_interrupt, not back into this
     * C frame) would leak the lock and deadlock the next timer IRQ.
     *
     * IRQs stay disabled between 'spinlock_release' and 'task_switch' so
     * there is no race window in which a timer IRQ could re-enter the
     * scheduler while we are mid-switch. */
    spinlock_release(&scheduler_lock);

    task_switch(&prev->context, &next->context);

    /* task_switch returned into the (now-current) task's stack.  The
     * local variable 'rflags' was saved by THIS function on the resuming
     * task's stack on its original entry to scheduler_yield, so it
     * correctly reflects the IRQ state that task must return with.
     *
     * We must NOT call spinlock_release again here: the lock was already
     * released above on THIS stack frame's prev-side execution; and by
     * the time resume runs, some OTHER task may have acquired the lock
     * (e.g. a periodic timer-driven scheduler_yield), so blindly calling
     * spinlock_release would corrupt their lock state.
     *
     * Just restore IRQs via the saved rflags directly. */
    __asm__ volatile(
        "mov %0, %%gs:8"
        :
        : "r"(current_task->user_rsp)
        : "memory");

    __asm__ volatile("push %0; popfq" : : "r"(rflags) : "memory");
}

/* Preemption control — non-inline, uses per-CPU current_task */
void preempt_disable(void) {
    if (current_task)
        __sync_fetch_and_add(&current_task->preempt_count, 1);
}

void preempt_enable(void) {
    if (current_task)
        __sync_fetch_and_sub(&current_task->preempt_count, 1);
}

int is_preempt_disabled(void) {
    if (!current_task) return 0;
    return current_task->preempt_count > 0;
}

/* Per-CPU scheduler — set up resources and enter idle loop */
void scheduler_init_cpu(u32 cpu_id) {
    (void)cpu_id;
}

void scheduler_start_cpu(void) {
    __asm__ volatile("sti");
    for (;;) {
        __asm__ volatile("hlt");
    }
}
