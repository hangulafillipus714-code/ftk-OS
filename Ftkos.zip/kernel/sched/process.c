/*
 * kernel/sched/process.c — user process / address-space creation
 *
 * FTK OS
 */
#include <ftk/scheduler.h>
#include <ftk/pmm.h>
#include <ftk/vmm.h>
#include <ftk/string.h>
#include <ftk/memory.h>
#include <ftk/memory_layout.h>

extern AddressSpace kernel_space;

/*
 * create_user_address_space
 *
 * Creates a new PML4 for a user process.
 * The top half (entries 256-511) is cloned from the kernel's PML4,
 * ensuring the kernel is mapped identically in all processes.
 * The bottom half (entries 0-255) is left empty for user mappings.
 */
AddressSpace *create_user_address_space(void) {
    phys_addr_t pml4_phys = pmm_alloc_page();
    if (!pml4_phys) {
        return NULL;
    }
    
    AddressSpace *space = kmalloc(sizeof(AddressSpace));
    if (!space) {
        pmm_free_page(pml4_phys);
        return NULL;
    }
    
    space->pml4 = pml4_phys;
    space->pml4_virt = (u64 *)PHYS_TO_VIRT(pml4_phys);
    
    /* Clear the lower half */
    memset(space->pml4_virt, 0, PAGE_SIZE);
    
    /* Clone the kernel half (entries 256-511) */
    for (int i = 256; i < 512; i++) {
        space->pml4_virt[i] = kernel_space.pml4_virt[i];
    }
    
    return space;
}
