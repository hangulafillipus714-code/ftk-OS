#include <ftk/scheduler.h>

/*
 * This file provides a real linker symbol `current_task` so that
 * legacy unit tests that declare `extern Task *current_task;` can
 * resolve at link time.
 *
 * The kernel uses a per-CPU macro `#define current_task (this_cpu()->current_task)`
 * from <ftk/per_cpu.h>, which shadows this global in production code.
 * Only test files (which do not include per_cpu.h) reference this symbol.
 */
Task *current_task;
