/*
 * kernel/sched/task.c — FTK OS Task Creation
 *
 * Creates kernel-mode and user-mode tasks with properly forged
 * iretq stack frames so that preemptive context switching works
 * correctly from day one.
 *
 * Stack layout for new tasks (created by create_task):
 *
 *   === Cooperative frame (popped by task_switch's 'ret') ===
 *   R15, R14, R13, R12, RBP, RBX    (callee-saved registers)
 *   return address = ret_from_interrupt
 *
 *   === iretq frame (popped by ret_from_interrupt) ===
 *   R15..RAX          (15 general-purpose registers)
 *   int_no, err_code  (dummy, skipped by addq $16,%rsp)
 *   RIP               (task entry point)
 *   CS                (0x08 for kernel, 0x20|3 for user)
 *   RFLAGS            (0x202 = IF set)
 *   RSP               (task stack top)
 *   SS                (0x10 for kernel, 0x18|3 for user)
 */

#include <ftk/scheduler.h>
#include <ftk/per_cpu.h>
#include <ftk/memory.h>
#include <ftk/pmm.h>
#include <ftk/vmm.h>
#include <ftk/string.h>
#include <ftk/printk.h>
#include <ftk/arch/x86_64/isr.h>
#include <drivers/char/serial.h>
#include <ftk/fs/vfs.h>

extern Task *task_list;
extern u32 next_pid;
extern AddressSpace kernel_space;

/* GDT selectors (must match gdt.c and syscall.h) */
#define KERNEL_CS  0x08
#define KERNEL_DS  0x10
#define USER_DS    (0x18 | 3)   /* Ring 3 data segment */
#define USER_CS    (0x20 | 3)   /* Ring 3 code segment */

/* Default RFLAGS: IF=1 (bit 9), reserved bit 1 always set */
#define DEFAULT_RFLAGS 0x202

/*
 * create_task — create a Ring 0 kernel task
 *
 * Forges a full iretq-compatible stack frame so that the new task
 * can be entered via ret_from_interrupt after task_switch.
 */
Task *create_task(const char *name, void (*entry)(void)) {
    if (!entry) return NULL;

    Task *task = kmalloc(sizeof(Task));
    if (!task) return NULL;

    memset(task, 0, sizeof(Task));
    strncpy(task->name, name, 31);
    task->address_space = &kernel_space;
    task->is_user = 0;

    /* Initialize fd table for kernel tasks too (needed by unit tests) */
    for (int i = 0; i < MAX_FDS; i++)
        task->fd_table[i].used = 0;
    task->fd_table[0].used = 1;
    task->fd_table[1].used = 1;
    task->fd_table[2].used = 1;

    /* Allocate 16KB kernel stack */
    phys_addr_t stack_phys = pmm_alloc_pages(4);
    if (!stack_phys) {
        kfree(task);
        return NULL;
    }
    virt_addr_t stack_virt = PHYS_TO_VIRT(stack_phys);
    u64 stack_top_addr = stack_virt + 4 * PAGE_SIZE;

    task->kernel_stack_top = stack_top_addr;
    task->kernel_stack_phys = stack_phys;

    /*
     * Build the stack from top (high address) to bottom (low address).
     *
     * Phase 1: iretq frame (popped by ret_from_interrupt)
     *   SS, RSP, RFLAGS, CS, RIP
     *   err_code, int_no  (dummy padding)
     *   RAX, RBX, RCX, RDX, RBP, RDI, RSI, R8..R15
     *
     * Phase 2: cooperative frame (popped by task_switch)
     *   return address = ret_from_interrupt
     *   RBX, RBP, R12, R13, R14, R15
     */
    u64 *sp = (u64 *)stack_top_addr;

    /* --- Phase 1: iretq frame --- */
    *(--sp) = KERNEL_DS;           /* SS */
    *(--sp) = stack_top_addr;      /* RSP (task uses its own stack) */
    *(--sp) = DEFAULT_RFLAGS;      /* RFLAGS (IF=1) */
    *(--sp) = KERNEL_CS;           /* CS */
    *(--sp) = (u64)entry;          /* RIP */

    /* Padding: err_code and int_no (skipped by addq $16, %rsp) */
    *(--sp) = 0;                   /* err_code */
    *(--sp) = 0;                   /* int_no */

    /* General-purpose registers (matching isr_entry.S push order, reversed) */
    *(--sp) = 0;                   /* RAX */
    *(--sp) = 0;                   /* RBX */
    *(--sp) = 0;                   /* RCX */
    *(--sp) = 0;                   /* RDX */
    *(--sp) = 0;                   /* RBP */
    *(--sp) = 0;                   /* RDI */
    *(--sp) = 0;                   /* RSI */
    *(--sp) = 0;                   /* R8 */
    *(--sp) = 0;                   /* R9 */
    *(--sp) = 0;                   /* R10 */
    *(--sp) = 0;                   /* R11 */
    *(--sp) = 0;                   /* R12 */
    *(--sp) = 0;                   /* R13 */
    *(--sp) = 0;                   /* R14 */
    *(--sp) = 0;                   /* R15 */

    /* --- Phase 2: cooperative frame for task_switch --- */
    *(--sp) = (u64)ret_from_interrupt;  /* return address */
    *(--sp) = 0x202;                 /* RFLAGS (IF=1) */
    *(--sp) = 0;                     /* RBX */
    *(--sp) = 0;                     /* RBP */
    *(--sp) = 0;                     /* R12 */
    *(--sp) = 0;                     /* R13 */
    *(--sp) = 0;                     /* R14 */
    *(--sp) = 0;                     /* R15 */

    task->context.rsp = (u64)sp;
    task->pid = next_pid++;
    task->state = TASK_READY;
    task->parent_pid = scheduler_current_pid();

    /* Insert into circular task list */
    if (task_list) {
        task->next = task_list;
        task->prev = task_list->prev;
        task_list->prev->next = task;
        task_list->prev = task;
    }
    return task;
}

/*
 * create_user_task — create a Ring 3 user-mode task
 *
 * Similar to create_task but forges an iretq frame with user-mode
 * segment selectors and a separate user stack.
 */
Task *create_user_task(const char *name, void (*entry)(void),
                       AddressSpace *space, virt_addr_t user_entry,
                       virt_addr_t user_stack_top) {
    if (!entry && !user_entry) return NULL;

    Task *task = kmalloc(sizeof(Task));
    if (!task) return NULL;

    memset(task, 0, sizeof(Task));
    strncpy(task->name, name, 31);
    task->address_space = space ? space : &kernel_space;
    task->is_user = 1;
    task->user_stack = user_stack_top;

    /* Inherit fd table from parent task (if any), so pipe/dup2 redirections work.
     * If no parent (boot), use default stdin/stdout/stderr. */

    int inherited = 0;
    if (current_task) {
        for (int i = 0; i < MAX_FDS; i++) {
            task->fd_table[i] = current_task->fd_table[i];
            if (task->fd_table[i].used) {
                inherited++;
                if (task->fd_table[i].node)
                    task->fd_table[i].node->refcount++;
                if (task->fd_table[i].pipe) {
                    task->fd_table[i].pipe->refcount++;
                    if (task->fd_table[i].pipe_is_write == 1)
                        task->fd_table[i].pipe->writers++;
                }
            }
        }
    } else {
        for (int i = 0; i < MAX_FDS; i++)
            task->fd_table[i].used = 0;
        task->fd_table[0].used = 1;  /* stdin  → console input  (console_getchar) */
        task->fd_table[1].used = 1;  /* stdout → console output (putchar) */
        task->fd_table[2].used = 1;  /* stderr → console output (putchar) */
    }

    /* Allocate separate kernel stack for syscall/interrupt handling */
    phys_addr_t kstack_phys = pmm_alloc_pages(4);
    if (!kstack_phys) {
        kfree(task);
        return NULL;
    }
    virt_addr_t kstack_virt = PHYS_TO_VIRT(kstack_phys);
    u64 kstack_top = kstack_virt + 4 * PAGE_SIZE;

    task->kernel_stack_top = kstack_top;
    task->kernel_stack_phys = kstack_phys;

    /* Allocate and map user stack pages so interrupts don't #PF on user stack.
     * The loop includes the page at user_stack_top because the compiler may
     * place local variables at positive offsets from RSP; if RSP is near the
     * top of the mapped region, those offsets can land just above the nominal
     * stack boundary.  Mapping one extra page at the top prevents spurious
     * page faults on such accesses. */
    virt_addr_t user_stack_base = ALIGN_DOWN(user_stack_top - USER_STACK_PAGES * PAGE_SIZE, PAGE_SIZE);
    for (virt_addr_t v = user_stack_base; v <= user_stack_top; v += PAGE_SIZE) {
        phys_addr_t upage = pmm_alloc_page();
        if (!upage) {
            pmm_free_pages(kstack_phys, 4);
            kfree(task);
            return NULL;
        }
        u64 uflags = PTE_PRESENT | PTE_WRITABLE | PTE_USER;
        if (vmm_map_page(task->address_space, v, upage, uflags) != 0) {
            pmm_free_page(upage);
            pmm_free_pages(kstack_phys, 4);
            kfree(task);
            return NULL;
        }
        memset((void *)PHYS_TO_VIRT(upage), 0, PAGE_SIZE);
    }

    /* Build stack on the kernel stack (CPU switches to this on interrupt) */
    u64 *sp = (u64 *)kstack_top;

    virt_addr_t rip = user_entry ? user_entry : (virt_addr_t)entry;

    /* --- Phase 1: iretq frame with user segments --- */
    *(--sp) = USER_DS;             /* SS (user data + RPL 3) */
    *(--sp) = user_stack_top - 8;  /* RSP (user stack) — 8 mod 16 per x86-64 ABI */
    *(--sp) = DEFAULT_RFLAGS;      /* RFLAGS (IF=1) */
    *(--sp) = USER_CS;             /* CS (user code + RPL 3) */
    *(--sp) = rip;                 /* RIP (user entry point) */

    *(--sp) = 0;                   /* err_code */
    *(--sp) = 0;                   /* int_no */

    /* General-purpose registers */
    *(--sp) = 0;                   /* RAX */
    *(--sp) = 0;                   /* RBX */
    *(--sp) = 0;                   /* RCX */
    *(--sp) = 0;                   /* RDX */
    *(--sp) = 0;                   /* RBP */
    *(--sp) = 0;                   /* RDI */
    *(--sp) = 0;                   /* RSI */
    *(--sp) = 0;                   /* R8 */
    *(--sp) = 0;                   /* R9 */
    *(--sp) = 0;                   /* R10 */
    *(--sp) = 0;                   /* R11 */
    *(--sp) = 0;                   /* R12 */
    *(--sp) = 0;                   /* R13 */
    *(--sp) = 0;                   /* R14 */
    *(--sp) = 0;                   /* R15 */

    /* --- Phase 2: cooperative frame for task_switch --- */
    *(--sp) = (u64)ret_from_interrupt;
    *(--sp) = 0x202;               /* RFLAGS (IF=1) */
    *(--sp) = 0;                   /* RBX */
    *(--sp) = 0;                   /* RBP */
    *(--sp) = 0;                   /* R12 */
    *(--sp) = 0;                   /* R13 */
    *(--sp) = 0;                   /* R14 */
    *(--sp) = 0;                   /* R15 */

    task->context.rsp = (u64)sp;
    task->pid = next_pid++;
    task->state = TASK_READY;
    task->parent_pid = scheduler_current_pid();

    kprintf("[TASK] %s (PID %u) inherited %d fd(s) from parent PID %u\n",
            name, task->pid, inherited, current_task->pid);

    if (task_list) {
        task->next = task_list;
        task->prev = task_list->prev;
        task_list->prev->next = task;
        task_list->prev = task;
    }
    return task;
}

/*
 * init_main — first kernel process
 *
 * Note: NO manual 'sti' needed — RFLAGS.IF is set via the iretq frame
 * forged by create_task. Interrupts are enabled automatically.
 */
static void init_main(void) {
    kprintf("\n[INIT] Process 1 started! Multitasking is working.\n");
    u64 counter = 0;
    while(1) {
        if (++counter % 50000000 == 0) kprintf(".");
    }
}

int create_init_process(void) {
    Task *init = create_task("init", init_main);
    if (init) {
        kprintf("[SCHED] Init process created (PID: %d)\n", init->pid);
        return 0;
    }
    return -1;
}