/*
 * kernel/sync/rwlock.c — Read-write lock implementation
 *
 * Ticket-based design:
 * - Readers atomically increment the reader count; wait if write-locked.
 * - Writers acquire a write flag, then wait for all readers to drain.
 */

#include <ftk/rwlock.h>

void rwlock_read_lock(rwlock_t *l) {
    for (;;) {
        /* Wait for any writer to release */
        while (l->writer) __asm__ volatile("pause");
        /* Increment reader count */
        __sync_fetch_and_add(&l->readers, 1);
        /* Double-check: if a writer arrived, undo and retry */
        if (!l->writer) return;
        __sync_fetch_and_sub(&l->readers, 1);
    }
}

void rwlock_read_unlock(rwlock_t *l) {
    __sync_fetch_and_sub(&l->readers, 1);
}

void rwlock_write_lock(rwlock_t *l) {
    /* Acquire exclusive writer flag */
    while (__sync_lock_test_and_set(&l->writer, 1)) {
        while (l->writer) __asm__ volatile("pause");
    }
    /* Wait for all readers to drain */
    while (l->readers) __asm__ volatile("pause");
}

void rwlock_write_unlock(rwlock_t *l) {
    __sync_lock_release(&l->writer);
}
