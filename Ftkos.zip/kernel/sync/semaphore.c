/*
 * kernel/sync/semaphore.c — Counting semaphore implementation
 *
 * Built on top of wait queues for blocking.
 */

#include <ftk/semaphore.h>
#include <ftk/scheduler.h>

void sem_init(semaphore_t *sem, s32 initial) {
    sem->count = initial;
    init_waitqueue_head(&sem->waiters);
}

void sem_wait(semaphore_t *sem) {
    while (__sync_sub_and_fetch(&sem->count, 1) < 0) {
        /* Count went negative — we need to block.
         * Restore the count before sleeping so other threads see accurate state.
         */
        __sync_fetch_and_add(&sem->count, 1);
        wait_event(&sem->waiters);
    }
}

int sem_try_wait(semaphore_t *sem) {
    s32 old;
    do {
        old = sem->count;
        if (old <= 0) return -1;  /* would block */
    } while (!__sync_bool_compare_and_swap(&sem->count, old, old - 1));
    return 0;
}

void sem_signal(semaphore_t *sem) {
    __sync_fetch_and_add(&sem->count, 1);
    /* Wake one waiter if any are blocked */
    if (!waitqueue_is_empty(&sem->waiters)) {
        wake_up(&sem->waiters);
    }
}
