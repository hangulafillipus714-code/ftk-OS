/*
 * kernel/sync/mutex.c — Sleeping mutex implementation
 *
 * Fast path: uncontended CAS to acquire.
 * Slow path: block on internal wait queue, then re-acquire on wakeup.
 */

#include <ftk/mutex.h>
#include <ftk/scheduler.h>
#include <ftk/per_cpu.h>
#include <ftk/spinlock.h>
#include <ftk/memory.h>

/* Internal spinlock protects the mutex waiter list */
static spinlock_t mutex_internal_lock = SPINLOCK_INIT;

void mutex_init(mutex_t *m) {
    m->locked  = 0;
    m->waiters = NULL;
}

void mutex_lock(mutex_t *m) {
    /* Fast path: uncontended */
    if (__sync_bool_compare_and_swap(&m->locked, 0, 1))
        return;

    /* Slow path: contended — add self to waiter list and block */
    u64 rflags;
    spinlock_acquire_irqsave(&mutex_internal_lock, &rflags);

    mutex_waiter_t *w = kmalloc(sizeof(mutex_waiter_t));
    if (!w) {
        spinlock_release_irqrestore(&mutex_internal_lock, rflags);
        /* OOM fallback: spin until available */
        while (__sync_lock_test_and_set(&m->locked, 1)) {
            while (m->locked) __asm__ volatile("pause");
        }
        return;
    }

    w->task = current_task;
    w->next = m->waiters;
    m->waiters = w;

    current_task->state = TASK_BLOCKED;

    spinlock_release_irqrestore(&mutex_internal_lock, rflags);

    /* Yield CPU until woken by unlock */
    scheduler_yield();

    /* Re-acquire after wakeup */
    while (__sync_lock_test_and_set(&m->locked, 1)) {
        while (m->locked) __asm__ volatile("pause");
    }
}

int mutex_trylock(mutex_t *m) {
    return __sync_bool_compare_and_swap(&m->locked, 0, 1);
}

void mutex_unlock(mutex_t *m) {
    u64 rflags;
    spinlock_acquire_irqsave(&mutex_internal_lock, &rflags);

    mutex_waiter_t *w = m->waiters;
    if (w) {
        /* Wake the first waiter */
        m->waiters = w->next;
        w->task->state = TASK_READY;
        kfree(w);

        /* Release the lock so the woken task can acquire it */
        __sync_lock_release(&m->locked);
        spinlock_release_irqrestore(&mutex_internal_lock, rflags);
    } else {
        spinlock_release_irqrestore(&mutex_internal_lock, rflags);
        /* No waiters — plain release */
        __sync_lock_release(&m->locked);
    }
}
