#include <ftk/abi/types.h>
#include <ftk/io.h>
#include <ftk/printk.h>
#include <ftk/string.h>
#include <ftk/pmm.h>
#include <ftk/fs/vfs.h>
#include <ftk/drivers/pci.h>
#include <ftk/arch/x86_64/cpu.h>
#include <drivers/char/keyboard.h>

#define SERIAL_PORT 0x3F8

static int serial_can_read(void) {
    return inb(SERIAL_PORT + 5) & 1;
}

static char serial_read(void) {
    while (!serial_can_read());
    return inb(SERIAL_PORT);
}

static void ksh_prompt(void) {
    kprintf("ksh> ");
}

/*
 * ksh_readline — canonical line read from serial
 * Strips \r/\n, handles backspace echo, returns line length.
 * Caller must zero buffer before calling.
 */
static int ksh_readline(char *line, int maxlen)
{
    int pos = 0;
    for (;;) {
        char c = serial_read();
        if (c == '\r' || c == '\n') {
            kprintf("\n");
            line[pos] = '\0';
            return pos;
        }
        if (c == '\b' || c == 0x7F) {
            if (pos > 0) { pos--; kprintf("\b \b"); }
            continue;
        }
        if (c >= 0x20 && c < 0x7F && pos < maxlen - 1) {
            line[pos++] = c;
            kprintf("%c", c);
        }
    }
}

/*
 * ksh_tokenize — split line into argv array (blueprint Phase C)
 * Strips trailing newline, splits on whitespace, NULL-terminates argv.
 */
static int ksh_tokenize(char *line, char **argv, int max)
{
    size_t len = strlen(line);
    if (len > 0 && (line[len-1] == '\n' || line[len-1] == '\r'))
        line[--len] = '\0';

    int argc = 0;
    char *tok = line;
    while (*tok) {
        while (*tok == ' ' || *tok == '\t') tok++;
        if (!*tok) break;
        argv[argc++] = tok;
        if (argc >= max) break;
        while (*tok && *tok != ' ' && *tok != '\t') tok++;
        if (*tok) *tok++ = '\0';
    }
    argv[argc] = NULL;
    return argc;
}

static void cmd_help(void) {
    kprintf(
        "Commands:\n"
        "  help     - this help\n"
        "  clear    - clear screen\n"
        "  mem      - show memory info\n"
        "  cpu      - show CPU info\n"
        "  pci      - list PCI devices\n"
        "  ls       - list root filesystem\n"
        "  mount    - show mounted filesystems\n"
        "  boot     - continue booting to user mode\n"
        "  reboot   - reboot system\n"
        "  shutdown - power off\n");
}

static void cmd_clear(void) {
    kprintf("\x1b[2J\x1b[H");
}

static void cmd_mem(void) {
    size_t total = pmm_get_total_page_count();
    size_t free  = pmm_get_free_page_count();
    kprintf("Memory: %llu KB total, %llu KB free (%llu pages free of %llu)\n",
            (unsigned long long)((total * 4096) / 1024),
            (unsigned long long)((free * 4096) / 1024),
            (unsigned long long)free, (unsigned long long)total);
}

static void cmd_cpu(void) {
    char vendor[16] = {0};
    char brand[64] = {0};
    cpu_get_vendor_id(vendor);
    cpu_get_brand_string(brand);
    uint32_t ecx = cpu_get_feature_flags_ecx();
    uint32_t edx = cpu_get_feature_flags_edx();
    kprintf("Vendor: %s\nBrand: %s\nFeatures: SSE2=%d SSE3=%d SSSE3=%d "
            "SSE4.1=%d SSE4.2=%d POPCNT=%d AVX=%d\n",
            vendor, brand,
            (edx >> 26) & 1, (ecx >> 0) & 1, (ecx >> 9) & 1,
            (ecx >> 19) & 1, (ecx >> 20) & 1, (ecx >> 23) & 1,
            (ecx >> 28) & 1);
}

static void cmd_pci(void) {
    kprintf("PCI Devices:\n");
    for (u16 bus = 0; bus < 256; bus++) {
        for (u8 slot = 0; slot < 32; slot++) {
            u32 id = pci_read_config(bus, slot, 0, 0);
            if (id == 0xFFFFFFFF) continue;
            u16 vendor = id & 0xFFFF;
            u16 device = (id >> 16) & 0xFFFF;
            u32 cc = pci_read_config(bus, slot, 0, 8);
            u8 class_code = (cc >> 24) & 0xFF;
            u8 subclass = (cc >> 16) & 0xFF;
            kprintf("  %02x:%02x.%d %04x:%04x class=%02x subclass=%02x\n",
                    bus, slot, 0, vendor, device, class_code, subclass);
        }
    }
}

static void cmd_ls(void) {
    vfs_node_t *dir = vfs_open("/");
    if (!dir) { kprintf("ls: failed to open root\n"); return; }
    vfs_dirent_t entry;
    u64 idx = 0;
    kprintf("/:\n");
    while (vfs_readdir(dir, idx, &entry) == 0) {
        kprintf("  %s\n", entry.name);
        idx++;
    }
    vfs_node_close(dir);
    dir = vfs_open("/tmp");
    if (dir) {
        kprintf("/tmp:\n");
        idx = 0;
        while (vfs_readdir(dir, idx, &entry) == 0) {
            kprintf("  %s\n", entry.name);
            idx++;
        }
        vfs_node_close(dir);
    }
}

static void cmd_mount(void) {
    extern mount_t *vfs_get_mount_list(void);
    mount_t *m = vfs_get_mount_list();
    if (!m) { kprintf("No mounts\n"); return; }
    kprintf("Mounted filesystems:\n");
    while (m) {
        kprintf("  %s -> %s\n", m->path, m->fs->name);
        m = m->next;
    }
}

static void cmd_reboot(void) {
    kprintf("Rebooting...\n");
    u8 good = 0x02;
    while (good & 0x02) good = inb(0x64);
    outb(0x64, 0xFE);
    for (;;) __asm__ volatile("cli; hlt");
}

static void cmd_shutdown(void) {
    kprintf("Shutting down...\n");
    outw(0x604, 0x2000);
    outw(0xB004, 0x2000);
    for (;;) __asm__ volatile("cli; hlt");
}

static int ksh_should_boot = 0;

static void cmd_boot(void) {
    kprintf("Booting to user mode...\n");
    ksh_should_boot = 1;
}

int kernel_shell_active(void) {
    return !ksh_should_boot ? 1 : 0;
}

void kernel_shell(void) {
    kprintf("\n=== FTK Kernel Shell ===\n");
    kprintf("Type 'b' to boot (auto-boot in 5s)\n");

    ksh_should_boot = 0;

    /* Wait a bit for serial/keyboard input before auto-booting.
     * Poll for ~5 seconds, showing a countdown.  If 'b' is received, boot. */
    {
        int wait = 5000;
        int prev_sec = 5;
        kprintf("Booting in %d...", prev_sec);
        while (wait > 0) {
            if (serial_can_read()) {
                char c = serial_read();
                if (c == 'b') {
                    kprintf("\n");
                    return;
                }
            }
            {
                char dummy;
                if (keyboard_try_getchar(&dummy)) {
                }
            }
            for (volatile int d = 0; d < 100000; d++);
            wait--;
            int sec = wait / 1000 + 1;
            if (sec != prev_sec) {
                prev_sec = sec;
                kprintf("\rBooting in %d...", sec);
            }
        }
        kprintf("\n");
        return;
    }

    for (;;) {
        char line[256] = {0};
        char *argv[32] = {0};
        int argc = 0;

        ksh_prompt();
        if (ksh_readline(line, sizeof(line)) == 0)
            continue;

        argc = ksh_tokenize(line, argv, 31);
        if (argc == 0 || argv[0] == NULL)
            continue;

        if (strcmp(argv[0], "help") == 0)       cmd_help();
        else if (strcmp(argv[0], "clear") == 0)  cmd_clear();
        else if (strcmp(argv[0], "mem") == 0)    cmd_mem();
        else if (strcmp(argv[0], "cpu") == 0)    cmd_cpu();
        else if (strcmp(argv[0], "pci") == 0)    cmd_pci();
        else if (strcmp(argv[0], "ls") == 0)     cmd_ls();
        else if (strcmp(argv[0], "mount") == 0)  cmd_mount();
        else if (strcmp(argv[0], "b") == 0)      { cmd_boot(); return; }
        else if (strcmp(argv[0], "boot") == 0)   { cmd_boot(); return; }
        else if (strcmp(argv[0], "reboot") == 0) cmd_reboot();
        else if (strcmp(argv[0], "shutdown") == 0) cmd_shutdown();
        else {
            kprintf("Unknown command: %s\n", argv[0]);
        }
    }
}
