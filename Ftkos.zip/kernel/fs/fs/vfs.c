#include <ftk/fs/vfs.h>
#include <ftk/string.h>
#include <ftk/memory.h>
#include <ftk/printk.h>

/* Mount table - linked list of mount points */
static mount_t *mount_list = NULL;

/* Registered filesystem list */
typedef struct fs_reg {
    filesystem_t *fs;
    struct fs_reg *next;
} fs_reg_t;
static fs_reg_t *fs_reg_list = NULL;

static int vfs_initialized = 0;

void vfs_init(void) {
    mount_list = NULL;
    fs_reg_list = NULL;
    vfs_initialized = 1;
    kprintf("[VFS] Initialized\n");
}

int vfs_register_filesystem(filesystem_t *fs) {
    if (!fs || !fs->name) return -1;
    fs_reg_t *reg = kmalloc(sizeof(fs_reg_t));
    if (!reg) return -1;
    reg->fs = fs;
    reg->next = fs_reg_list;
    fs_reg_list = reg;
    kprintf("[VFS] Registered filesystem: %s\n", fs->name);
    return 0;
}

int vfs_mount(const char *path, const char *fs_name, void *private_data) {
    if (!path || !fs_name) return -1;

    /* Find the filesystem by name in the mount list or built-in list.
     * For now, scan registered mounts or known fs types. */
    filesystem_t *fs = NULL;

    /* Look through registered filesystems */
    fs_reg_t *reg = fs_reg_list;
    while (reg) {
        if (strcmp(reg->fs->name, fs_name) == 0) {
            fs = reg->fs;
            break;
        }
        reg = reg->next;
    }

    if (!fs) {
        kprintf("[VFS] Filesystem '%s' not found\n", fs_name);
        return -1;
    }

    mount_t *entry = kmalloc(sizeof(mount_t));
    if (!entry) return -1;
    memset(entry, 0, sizeof(mount_t));
    strncpy(entry->path, path, 255);
    entry->fs = fs;
    entry->private_data = private_data;
    entry->next = mount_list;
    mount_list = entry;

    kprintf("[VFS] Mounted '%s' on '%s'\n", fs_name, path);
    return 0;
}

/* Find the deepest mount that matches the given path */
static mount_t *vfs_find_mount(const char *path) {
    mount_t *best = NULL;
    size_t best_len = 0;
    mount_t *m = mount_list;

    while (m) {
        size_t mlen = strlen(m->path);
        if (strncmp(path, m->path, mlen) == 0) {
            /* Exact match, path continues with /, or root mount (/) matches everything */
            if (path[mlen] == '\0' || path[mlen] == '/' || (mlen == 1 && m->path[0] == '/')) {
                if (mlen > best_len) {
                    best = m;
                    best_len = mlen;
                }
            }
        }
        m = m->next;
    }
    return best;
}

vfs_node_t* vfs_open(const char *path) {
    if (!path || !*path) return NULL;

    /* Resolve relative paths against root */
    char abs_path[256];
    if (path[0] != '/') {
        abs_path[0] = '/';
        strncpy(abs_path + 1, path, 254);
        abs_path[255] = '\0';
        path = abs_path;
    }

    mount_t *mnt = vfs_find_mount(path);
    if (!mnt)
        return NULL;

    size_t mnt_len = strlen(mnt->path);
    const char *local_path = path + mnt_len;
    if (*local_path == '\0') local_path = "/";

    vfs_node_t *node = mnt->fs->open(mnt->fs, local_path);
    if (!node)
        return NULL;

    node->fs = mnt->fs;
    return node;
}

int vfs_readdir(vfs_node_t* node, u64 index, vfs_dirent_t* entry) {
    if (!node || !entry || !node->readdir)
        return -1;
    return node->readdir(node, index, entry);
}

mount_t* vfs_get_mount_list(void) {
    return mount_list;
}

void vfs_node_close(vfs_node_t *node) {
    if (!node) return;
    node->refcount--;
    if (node->refcount <= 0) {
        if (node->fs && node->fs->destroy_node)
            node->fs->destroy_node(node);
        else
            kfree(node);
    }
}
