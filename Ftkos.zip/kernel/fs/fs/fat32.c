#include <ftk/fs/fat32.h>
#include <ftk/string.h>
#include <ftk/memory.h>
#include <ftk/printk.h>
#include <ftk/drivers/ahci.h>

#define PARTITION_OFFSET 2048

/* FAT32 directory entry */
typedef struct {
    u8  name[11];
    u8  attributes;
    u8  nt_reserved;
    u8  creation_tenths;
    u16 creation_time;
    u16 creation_date;
    u16 last_access_date;
    u16 cluster_high;
    u16 write_time;
    u16 write_date;
    u16 cluster_low;
    u32 file_size;
} __attribute__((packed)) fat32_dir_entry_t;

/* Long file name entry */
typedef struct {
    u8  order;
    u16 chars1[5];
    u8  attributes;
    u8  entry_type;
    u8  checksum;
    u16 chars2[6];
    u16 zero;
    u16 chars3[2];
} __attribute__((packed)) fat32_lfn_entry_t;

#define ATTR_READ_ONLY  0x01
#define ATTR_HIDDEN     0x02
#define ATTR_SYSTEM     0x04
#define ATTR_VOLUME_ID  0x08
#define ATTR_DIRECTORY  0x10
#define ATTR_ARCHIVE    0x20
#define ATTR_LFN        0x0F

#define LFN_LAST        0x40

static fat32_bpb_t bpb;
static int fat32_mounted = 0;

/*
 * 16-entry LRU sector cache for FAT32 operations.
 * Caches recently-read 512-byte sectors so repeated accesses
 * (e.g. walking the FAT chain, reading directory clusters)
 * don't hit the disk every time.
 */
#define SECTOR_CACHE_ENTRIES 16

typedef struct {
    u32 lba;
    u8  data[512];
    u32 age;       /* higher = more recently used/inserted */
    u8  valid;
} sector_cache_entry_t;

static sector_cache_entry_t sector_cache[SECTOR_CACHE_ENTRIES];
static u32 cache_age_counter = 0;

/* Bump age counter */
static inline u32 cache_next_age(void) {
    return ++cache_age_counter;
}

static int sector_cache_lookup(u32 lba, u8 *out) {
    for (int i = 0; i < SECTOR_CACHE_ENTRIES; i++) {
        if (sector_cache[i].valid && sector_cache[i].lba == lba) {
            sector_cache[i].age = cache_next_age();
            memcpy(out, sector_cache[i].data, 512);
            return 1;
        }
    }
    return 0;
}

static void sector_cache_insert(u32 lba, const u8 *data) {
    /* Find LRU entry (lowest age, i.e. least recently used) or empty slot */
    int lru_idx = 0;
    u32 min_age = ~0u;
    for (int i = 0; i < SECTOR_CACHE_ENTRIES; i++) {
        if (!sector_cache[i].valid) {
            lru_idx = i;
            break;
        }
        if (sector_cache[i].age < min_age) {
            min_age = sector_cache[i].age;
            lru_idx = i;
        }
    }
    sector_cache[lru_idx].lba   = lba;
    sector_cache[lru_idx].age   = cache_next_age();
    sector_cache[lru_idx].valid = 1;
    memcpy(sector_cache[lru_idx].data, data, 512);
}

/* Wrapper around ahci_read that goes through the sector cache.
 * For single-sector reads (count==1), checks the LRU cache first.
 * Multi-sector reads bypass the cache but get stored entry-by-entry. */
static int fat32_cache_read(u32 lba, u32 count, u8 *buffer) {
    if (count == 1) {
        if (sector_cache_lookup(lba, buffer))
            return 0;
        if (ahci_read(lba, 1, buffer) != 0)
            return -1;
        sector_cache_insert(lba, buffer);
        return 0;
    }
    /* Multi-sector: bypass cache for performance */
    return ahci_read(lba, count, buffer);
}

static u32 fat32_cluster_to_lba(u32 cluster) {
    u32 first_data_sector = bpb.reserved_sectors + (bpb.fat_count * bpb.sectors_per_fat_32);
    return PARTITION_OFFSET + first_data_sector + (cluster - 2) * bpb.sectors_per_cluster;
}

static u32 fat32_read_fat_entry(u32 cluster) {
    u32 fat_offset = cluster * 4;
    u32 fat_sector = bpb.reserved_sectors + (fat_offset / bpb.bytes_per_sector);
    u32 byte_offset = fat_offset % bpb.bytes_per_sector;

    u32 lba = PARTITION_OFFSET + fat_sector;
    u8 buf[512];
    if (fat32_cache_read(lba, 1, buf) != 0) {
        return FAT32_EOC;
    }

    u32 entry;
    memcpy(&entry, &buf[byte_offset], sizeof(u32));
    entry &= 0x0FFFFFFF;
    return entry;
}

static int read_cluster(u32 cluster, u32 sector_offset, u32 sector_count, u8* buffer) {
    u32 lba = fat32_cluster_to_lba(cluster);
    return fat32_cache_read(lba + sector_offset, sector_count, buffer);
}

static int fat32_read_dir_entry(u32 cluster, u32 index, fat32_dir_entry_t* entry) {
    u32 entries_per_sector = bpb.bytes_per_sector / 32;
    u32 sector_in_cluster = (index / entries_per_sector) % bpb.sectors_per_cluster;
    u32 entry_in_sector = index % entries_per_sector;

    u8 buf[512];
    if (read_cluster(cluster, sector_in_cluster, 1, buf) != 0)
        return -1;
    memcpy(entry, buf + (entry_in_sector * 32), 32);
    return 0;
}

static int char_ieq(char a, char b) {
    if (a >= 'a' && a <= 'z') a -= 32;
    if (b >= 'a' && b <= 'z') b -= 32;
    return a == b;
}

static int fat32_compare_name(const char* name, const fat32_dir_entry_t* entry) {
    char dos_name[12];
    int di = 0;

    for (int i = 0; i < 8; i++) {
        if (entry->name[i] == ' ') break;
        dos_name[di++] = entry->name[i];
    }

    if (entry->name[8] != ' ') {
        dos_name[di++] = '.';
        for (int i = 8; i < 11; i++) {
            if (entry->name[i] == ' ') break;
            dos_name[di++] = entry->name[i];
        }
    }

    dos_name[di] = '\0';

    /* Case-insensitive comparison */
    const char* a = name;
    const char* b = dos_name;
    while (*a && *b) {
        if (!char_ieq(*a, *b)) return *a - *b;
        a++; b++;
    }
    return *a - *b;
}

static u32 fat32_find_in_dir(u32 dir_cluster, const char* name, fat32_dir_entry_t* out_entry) {
    u32 cluster = dir_cluster;

    while (cluster >= 2 && cluster < FAT32_EOC) {
        u32 entries_per_cluster = (bpb.bytes_per_sector * bpb.sectors_per_cluster) / 32;

        for (u32 i = 0; i < entries_per_cluster; i++) {
            fat32_dir_entry_t entry;
            if (fat32_read_dir_entry(cluster, i, &entry) != 0) {
                return 0;
            }

            if (entry.name[0] == 0x00) {
                return 0;
            }
            if (entry.name[0] == 0xE5) {
                continue;
            }
            if ((entry.attributes & ATTR_LFN) == ATTR_LFN) {
                continue;
            }
            if (entry.name[0] == '.' && (entry.name[1] == ' ' || entry.name[1] == '.')) {
                continue;
            }

            if (fat32_compare_name(name, &entry) == 0) {
                if (out_entry) memcpy(out_entry, &entry, sizeof(fat32_dir_entry_t));
                return (u32)entry.cluster_low | ((u32)entry.cluster_high << 16);
            }
        }

        cluster = fat32_read_fat_entry(cluster);
    }

    return 0;
}

static int fat32_read_node(vfs_node_t* node, u64 offset, u64 size, void* buffer) {
    if (!node || !buffer) return -1;

    if (offset >= node->size) return 0;
    u64 avail = node->size - offset;
    if (size > avail) size = avail;
    if (size == 0) return 0;

    u32 cluster = node->inode;
    u32 bytes_per_cluster = bpb.bytes_per_sector * bpb.sectors_per_cluster;
    u64 cluster_start = 0;
    u64 buf_pos = 0;
    u8* buf = (u8*)buffer;

    while (cluster >= 2 && cluster < FAT32_EOC && cluster_start + bytes_per_cluster <= offset) {
        cluster_start += bytes_per_cluster;
        cluster = fat32_read_fat_entry(cluster);
    }

    while (cluster >= 2 && cluster < FAT32_EOC && buf_pos < size) {
        u64 cluster_off = offset - cluster_start;
        u64 to_read = bytes_per_cluster - cluster_off;
        if (to_read > size - buf_pos) to_read = size - buf_pos;

        u32 lba_start = fat32_cluster_to_lba(cluster);
        u32 sector_off = cluster_off / bpb.bytes_per_sector;
        u32 sector_count = (to_read + bpb.bytes_per_sector - 1) / bpb.bytes_per_sector;
        u32 total_bytes = sector_count * bpb.bytes_per_sector;

        u8* tmp = kmalloc(total_bytes);
        if (!tmp) return -1;

        if (fat32_cache_read(lba_start + sector_off, sector_count, tmp) != 0) {
            kfree(tmp);
            return -1;
        }

        u64 skip = cluster_off % bpb.bytes_per_sector;
        memcpy(buf + buf_pos, tmp + skip, to_read);
        kfree(tmp);

        buf_pos += to_read;
        offset += to_read;

        if (buf_pos >= size) break;
        cluster_start += bytes_per_cluster;
        cluster = fat32_read_fat_entry(cluster);
    }

    return (int)buf_pos;
}

static vfs_node_t* fat32_fs_open(struct filesystem *fs, const char *path) {
    (void)fs;
    return fat32_open(path);
}

static void fat32_destroy_node(vfs_node_t *node) {
    if (node) kfree(node);
}

filesystem_t fat32_fs = {
    .name = "fat32",
    .open = fat32_fs_open,
    .readdir = NULL,
    .destroy_node = fat32_destroy_node,
};

void fat32_init(void) {
    u8* sector0 = kmalloc(512);
    if (!sector0) {
        kprintf("[FAT32] Out of memory\n");
        return;
    }

    if (ahci_read(PARTITION_OFFSET, 1, sector0) == 0) {
        if (sector0[510] == 0x55 && sector0[511] == 0xAA) {
            memcpy(&bpb, sector0, sizeof(fat32_bpb_t));

            if (bpb.bytes_per_sector != 512) {
                kprintf("[FAT32] Unsupported bytes per sector: %d\n", bpb.bytes_per_sector);
                kfree(sector0);
                return;
            }

            if (bpb.sectors_per_cluster == 0) {
                kprintf("[FAT32] Invalid sectors per cluster\n");
                kfree(sector0);
                return;
            }

            fat32_mounted = 1;
            kprintf("[FAT32] Volume mounted. Root cluster: %d, SPC: %d, FAT size: %d\n",
                    bpb.root_cluster, bpb.sectors_per_cluster, bpb.sectors_per_fat_32);
        } else {
            kprintf("[FAT32] Invalid BPB signature at LBA %d\n", PARTITION_OFFSET);
            kfree(sector0);
            return;
        }
    } else {
        kprintf("[FAT32] Disk read failed\n");
        kfree(sector0);
        return;
    }

    kfree(sector0);

    /* Register with VFS */
    vfs_register_filesystem(&fat32_fs);
    vfs_mount("/", "fat32", (void*)(uintptr_t)bpb.root_cluster);
}

static int fat32_readdir(vfs_node_t* node, u64 index, vfs_dirent_t* out) {
    if (!node) return -1;
    u32 cluster = node->inode;
    u64 global_index = 0;

    while (cluster >= 2 && cluster < FAT32_EOC) {
        u32 entries_per_cluster = (bpb.bytes_per_sector * bpb.sectors_per_cluster) / 32;
        for (u32 i = 0; i < entries_per_cluster; i++) {
            fat32_dir_entry_t entry;
            if (fat32_read_dir_entry(cluster, i, &entry) != 0)
                return -1;
            if (entry.name[0] == 0x00)
                return -1;
            if (entry.name[0] == 0xE5)
                continue;
            if ((entry.attributes & ATTR_LFN) == ATTR_LFN)
                continue;
            if (entry.name[0] == '.' && (entry.name[1] == ' ' || entry.name[1] == '.'))
                continue;

            if (global_index == index) {
                int di = 0;
                for (int j = 0; j < 8; j++) {
                    if (entry.name[j] == ' ') break;
                    char c = entry.name[j];
                    if (c >= 'A' && c <= 'Z') c += 32;
                    out->name[di++] = c;
                }
                if (entry.name[8] != ' ') {
                    out->name[di++] = '.';
                    for (int j = 8; j < 11; j++) {
                        if (entry.name[j] == ' ') break;
                        char c = entry.name[j];
                        if (c >= 'A' && c <= 'Z') c += 32;
                        out->name[di++] = c;
                    }
                }
                out->name[di] = '\0';
                out->inode = (u32)entry.cluster_low | ((u32)entry.cluster_high << 16);
                out->size = entry.file_size;
                out->attributes = entry.attributes;
                return 0;
            }
            global_index++;
        }
        cluster = fat32_read_fat_entry(cluster);
    }
    return -1;
}

vfs_node_t* fat32_open(const char* path) {
    if (!fat32_mounted) return NULL;
    kprintf("[FAT32] open('%s')\n", path);

    char path_copy[256];
    strncpy(path_copy, path, 255);
    path_copy[255] = '\0';

    u32 current_cluster = bpb.root_cluster;

    char* token = path_copy;

    /* Skip leading slash */
    if (*token == '/') token++;

    /* Handle root directory */
    if (!token || !*token) {
        vfs_node_t* node = kmalloc(sizeof(vfs_node_t));
        if (!node) return NULL;
        memset(node, 0, sizeof(vfs_node_t));
        strncpy(node->name, "/", 255);
        node->type = VFS_DIRECTORY;
        node->inode = bpb.root_cluster;
        node->readdir = fat32_readdir;
        node->refcount = 1;
        return node;
    }

    while (token && *token) {
        char* slash = strchr(token, '/');
        if (slash) *slash = '\0';

        if (strlen(token) == 0) {
            token = slash ? slash + 1 : NULL;
            continue;
        }

        fat32_dir_entry_t entry;
        u32 next = fat32_find_in_dir(current_cluster, token, &entry);
        if (!next) {
            kprintf("[FAT32] '%s' not found in path '%s'\n", token, path);
            return NULL;
        }

        if (slash) {
            if (!(entry.attributes & ATTR_DIRECTORY)) {
                kprintf("[FAT32] '%s' is not a directory\n", token);
                return NULL;
            }
            current_cluster = next;
        } else {
            vfs_node_t* node = kmalloc(sizeof(vfs_node_t));
            if (!node) return NULL;

            memset(node, 0, sizeof(vfs_node_t));
            strncpy(node->name, token, 255);
            node->type = (entry.attributes & ATTR_DIRECTORY) ? VFS_DIRECTORY : VFS_FILE;
            node->size = entry.file_size;
            node->inode = next;
            node->refcount = 1;
            node->parent = NULL;
            node->read = fat32_read_node;
            if (entry.attributes & ATTR_DIRECTORY)
                node->readdir = fat32_readdir;

            return node;
        }

        token = slash ? slash + 1 : NULL;
    }

    return NULL;
}
