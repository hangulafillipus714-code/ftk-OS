/*
 * kernel/fs/fs/ramfs.c — Simple in-memory filesystem (ramfs)
 *
 * Demonstrates how to add a new filesystem under the VFS layer.
 * Provides a small in-memory directory hierarchy that can be
 * mounted at /tmp or /proc.
 */

#include <ftk/fs/vfs.h>
#include <ftk/string.h>
#include <ftk/memory.h>
#include <ftk/printk.h>

/* A single ramfs node (file or directory) */
typedef struct ramfs_node {
    char name[256];
    vfs_type_t type;
    u32 size;
    u8 *data;                      /* file content (NULL for directories) */
    struct ramfs_node *children;   /* first child (for directories) */
    struct ramfs_node *next;       /* sibling link */
    struct ramfs_node *parent;     /* parent directory */
} ramfs_node_t;

static ramfs_node_t *ramfs_root = NULL;

static ramfs_node_t* ramfs_find(ramfs_node_t *dir, const char *name) {
    ramfs_node_t *n = dir->children;
    while (n) {
        if (strcmp(n->name, name) == 0)
            return n;
        n = n->next;
    }
    return NULL;
}

/* Split path into components and traverse */
static ramfs_node_t* ramfs_resolve(ramfs_node_t *root, const char *path) {
    if (!root || !path) return NULL;
    if (strcmp(path, "/") == 0) return root;

    ramfs_node_t *cur = root;
    char buf[256];
    strncpy(buf, path, 255);
    buf[255] = '\0';

    char *token = buf;
    if (*token == '/') token++;

    while (token && *token) {
        char *slash = strchr(token, '/');
        if (slash) *slash = '\0';

        if (strlen(token) == 0) {
            token = slash ? slash + 1 : NULL;
            continue;
        }

        cur = ramfs_find(cur, token);
        if (!cur) return NULL;

        if (slash) {
            if (cur->type != VFS_DIRECTORY) return NULL;
        } else {
            return cur;
        }
        token = slash ? slash + 1 : NULL;
    }
    return cur;
}

/* VFS node operations */
static int ramfs_read_node(vfs_node_t *node, u64 offset, u64 size, void *buffer) {
    if (!node || !buffer) return -1;
    ramfs_node_t *rn = (ramfs_node_t *)node->private_data;
    if (!rn || !rn->data) return -1;
    if (offset >= rn->size) return 0;
    u64 avail = rn->size - offset;
    if (size > avail) size = avail;
    memcpy(buffer, rn->data + offset, size);
    return (int)size;
}

static int ramfs_readdir_node(vfs_node_t *node, u64 index, vfs_dirent_t *entry) {
    if (!node || !entry) return -1;
    ramfs_node_t *rn = (ramfs_node_t *)node->private_data;
    if (!rn || rn->type != VFS_DIRECTORY) return -1;

    ramfs_node_t *child = rn->children;
    u64 i = 0;
    while (child) {
        if (i == index) {
            strncpy(entry->name, child->name, 255);
            entry->inode = (u32)(uintptr_t)child;
            entry->size = child->size;
            entry->attributes = (child->type == VFS_DIRECTORY) ? 0x10 : 0x20;
            return 0;
        }
        i++;
        child = child->next;
    }
    return -1;
}

static vfs_node_t* ramfs_vfs_open(struct filesystem *fs, const char *path) {
    (void)fs;
    if (!ramfs_root) return NULL;

    ramfs_node_t *rn = ramfs_resolve(ramfs_root, path);
    if (!rn) return NULL;

    vfs_node_t *node = kmalloc(sizeof(vfs_node_t));
    if (!node) return NULL;
    memset(node, 0, sizeof(vfs_node_t));
    strncpy(node->name, rn->name, 255);
    node->type = rn->type;
    node->size = rn->size;
    node->inode = (u32)(uintptr_t)rn;
    node->private_data = rn;
    node->refcount = 1;
    node->read = ramfs_read_node;
    if (rn->type == VFS_DIRECTORY)
        node->readdir = ramfs_readdir_node;
    return node;
}

static void ramfs_destroy_node(vfs_node_t *node) {
    if (node) kfree(node);
}

static filesystem_t ramfs_fs = {
    .name = "ramfs",
    .open = ramfs_vfs_open,
    .readdir = NULL,
    .destroy_node = ramfs_destroy_node,
};

/* Public API */
void ramfs_init(void) {
    ramfs_root = kmalloc(sizeof(ramfs_node_t));
    if (!ramfs_root) {
        kprintf("[RAMFS] Failed to allocate root\n");
        return;
    }
    memset(ramfs_root, 0, sizeof(ramfs_node_t));
    strncpy(ramfs_root->name, "/", 255);
    ramfs_root->type = VFS_DIRECTORY;

    vfs_register_filesystem(&ramfs_fs);
    vfs_mount("/tmp", "ramfs", NULL);

    kprintf("[RAMFS] Initialized, mounted at /tmp\n");
}
