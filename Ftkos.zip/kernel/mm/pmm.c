/*
 * pmm.c — FTK OS Physical Memory Manager
 *
 * Bitmap-based allocator supporting multiple memory regions.
 * All operations are physical-address only. Thread-safe via spinlock.
 */

#include <ftk/pmm.h>
#include <ftk/abi/bootinfo.h>
#include <ftk/string.h>
#include <ftk/panic.h>
#include <ftk/io.h>
#include <ftk/spinlock.h>
#include <ftk/printk.h>

/* =======================
 * State management
 * ======================= */

static u8 *bitmap = NULL;             /* Virtual address of bitmap */
static phys_addr_t bitmap_phys = 0;   /* Physical address of bitmap */
static size_t bitmap_size = 0;        /* Size in bytes */
static size_t total_pages = 0;        /* Total managed pages */
static size_t free_pages = 0;         /* Current free pages */

static mem_region_t regions[MAX_MEMORY_REGIONS];
static size_t region_count = 0;

static spinlock_t pmm_lock = SPINLOCK_INIT;

/* =======================
 * Bitmap operations
 * ======================= */

static inline void bitmap_set(size_t index) {
    bitmap[index / 8] |= (1u << (index % 8));
}

static inline void bitmap_clear(size_t index) {
    bitmap[index / 8] &= ~(1u << (index % 8));
}

static inline bool bitmap_test(size_t index) {
    return (bitmap[index / 8] & (1u << (index % 8))) != 0;
}

/* =======================
 * Region management
 * ======================= */

static mem_region_t *region_for_page(size_t page_idx) {
    for (size_t i = 0; i < region_count; i++) {
        mem_region_t *r = &regions[i];
        if (!r->valid) continue;
        if (page_idx >= r->bitmap_offset &&
            page_idx < r->bitmap_offset + r->total_pages) {
            return r;
        }
    }
    return NULL;
}

static mem_region_t *region_for_phys(phys_addr_t phys) {
    for (size_t i = 0; i < region_count; i++) {
        mem_region_t *r = &regions[i];
        if (!r->valid) continue;
        if (phys >= r->start && phys < r->end) {
            return r;
        }
    }
    return NULL;
}

static void mark_pages_used(size_t start_page, size_t count) {
    for (size_t i = 0; i < count; i++) {
        size_t page_idx = start_page + i;
        if (page_idx >= total_pages) break;
        if (!bitmap_test(page_idx)) {
            bitmap_set(page_idx);
            free_pages--;
            mem_region_t *r = region_for_page(page_idx);
            if (r) r->free_pages--;
        }
    }
}

static void mark_region_used(phys_addr_t phys_start, phys_addr_t phys_end) {
    for (size_t i = 0; i < region_count; i++) {
        mem_region_t *r = &regions[i];
        if (!r->valid) continue;
        if (phys_end <= r->start || phys_start >= r->end) continue;

        phys_addr_t mark_start = phys_start > r->start ? phys_start : r->start;
        phys_addr_t mark_end   = phys_end < r->end ? phys_end : r->end;

        mark_start = PAGE_ALIGN_UP(mark_start);
        mark_end   = PAGE_ALIGN_DOWN(mark_end);

        if (mark_end <= mark_start) continue;

        size_t start_page = (mark_start - r->start) / PAGE_SIZE;
        size_t end_page   = (mark_end   - r->start) / PAGE_SIZE;

        mark_pages_used(r->bitmap_offset + start_page, end_page - start_page);
    }
}

/* =======================
 * Allocation helpers
 * ======================= */

static size_t find_free_pages_in_region(mem_region_t *r, size_t count) {
    if (count > r->free_pages) return (size_t)-1;

    size_t start_idx = r->last_scanned_index;
    size_t consecutive = 0;
    size_t start = 0;
    size_t scanned = 0;
    size_t max_scan = r->total_pages;

    while (scanned < max_scan) {
        size_t idx = (start_idx + scanned) % r->total_pages;
        size_t global_idx = r->bitmap_offset + idx;

        if (!bitmap_test(global_idx)) {
            if (consecutive == 0) start = idx;
            if (++consecutive == count) {
                r->last_scanned_index = (start + count) % r->total_pages;
                return r->bitmap_offset + start;
            }
        } else {
            consecutive = 0;
        }
        scanned++;
    }
    return (size_t)-1;
}

static size_t find_free_pages(size_t count) {
    for (size_t i = 0; i < region_count; i++) {
        mem_region_t *r = &regions[i];
        if (!r->valid) continue;
        size_t result = find_free_pages_in_region(r, count);
        if (result != (size_t)-1) return result;
    }
    return (size_t)-1;
}

/* =======================
 * PMM initialization
 * ======================= */

void pmm_init(uintptr_t boot_info_ptr) {
    BootInfo *boot_info = (BootInfo *)boot_info_ptr;
    if (!boot_info) PANIC("PMM: NULL boot_info");

    for (u32 i = 0; i < boot_info->mmap_count; i++) {
        if (boot_info->mmap[i].type != MMAP_TYPE_AVAILABLE) continue;

        phys_addr_t base = boot_info->mmap[i].base;
        phys_addr_t end  = base + boot_info->mmap[i].length;

        phys_addr_t region_start = PAGE_ALIGN_UP(base);
        phys_addr_t region_end   = PAGE_ALIGN_DOWN(end);
        if (region_end <= region_start) continue;

        size_t region_pages = (region_end - region_start) / PAGE_SIZE;
        if (region_count >= MAX_MEMORY_REGIONS) break;

        mem_region_t *r = &regions[region_count];
        r->start = region_start;
        r->end = region_end;
        r->total_pages = region_pages;
        r->free_pages = region_pages;
        r->bitmap_offset = total_pages;
        r->last_scanned_index = 0;
        r->valid = true;

        total_pages += region_pages;
        free_pages += region_pages;
        region_count++;
    }

    if (!total_pages) PANIC("PMM: No usable memory");

    bitmap_size = (total_pages + 7) / 8;
    size_t bitmap_pages = (bitmap_size + PAGE_SIZE - 1) / PAGE_SIZE;

    phys_addr_t bitmap_candidate = 0;
    for (size_t i = 0; i < region_count; i++) {
        mem_region_t *r = &regions[i];
        if (r->total_pages >= bitmap_pages) {
            bitmap_candidate = r->start;
            break;
        }
    }
    if (!bitmap_candidate) PANIC("PMM: No region large enough for bitmap");

    if (boot_info->kernel_phys_base >= bitmap_candidate &&
        boot_info->kernel_phys_base < bitmap_candidate + bitmap_pages * PAGE_SIZE) {
        bitmap_candidate = PAGE_ALIGN_UP(boot_info->kernel_phys_end);
    }

    bitmap_phys = bitmap_candidate;

    if (bitmap_phys + bitmap_pages * PAGE_SIZE > regions[region_count - 1].end)
        PANIC("PMM: Bitmap overflow");

    bitmap = (u8 *)bitmap_phys;
    memset(bitmap, 0, bitmap_size);

    /* Mark bitmap pages */
    for (size_t i = 0; i < region_count; i++) {
        mem_region_t *r = &regions[i];
        if (r->valid && r->start <= bitmap_phys &&
            bitmap_phys + bitmap_pages * PAGE_SIZE <= r->end) {
            size_t local_page = (bitmap_phys - r->start) / PAGE_SIZE;
            size_t global_start = r->bitmap_offset + local_page;
            mark_pages_used(global_start, bitmap_pages);
            break;
        }
    }

    mark_region_used(boot_info->kernel_phys_base, boot_info->kernel_phys_end);

    for (u32 i = 0; i < boot_info->mmap_count; i++) {
        if (boot_info->mmap[i].type != MMAP_TYPE_AVAILABLE) {
            mark_region_used(boot_info->mmap[i].base,
                             boot_info->mmap[i].base + boot_info->mmap[i].length);
        }
    }

    mark_region_used(0, 0x100000);

    kprintf("[PMM] %zu regions, %zu total pages, %zu free pages\n",
            region_count, total_pages, free_pages);
}

/* =======================
 * Public API
 * ======================= */

phys_addr_t pmm_alloc_page(void) {
    return pmm_alloc_pages(1);
}

static u32 dbg_alloc_count = 0;

phys_addr_t pmm_alloc_pages(size_t count) {
    if (!count || count > free_pages) return 0;

    spinlock_acquire(&pmm_lock);
    size_t start = find_free_pages(count);
    if (start == (size_t)-1) {
        spinlock_release(&pmm_lock);
        return 0;
    }

    for (size_t i = 0; i < count; i++)
        bitmap_set(start + i);

    free_pages -= count;

    mem_region_t *r = region_for_page(start);
    if (r) r->free_pages -= count;

    phys_addr_t phys = 0;
    if (r) {
        size_t local_start = start - r->bitmap_offset;
        phys = r->start + local_start * PAGE_SIZE;
    }
    /* DEBUG: track allocations in the low region where page tables/stacks live */
    if (phys >= 0x100000 && phys < 0x300000 && dbg_alloc_count++ < 4000) {
        void *caller = __builtin_return_address(0);
        kprintf("[DBGALLOC] phys=0x%lx count=0x%lx caller=0x%lx\n",
                (unsigned long)phys, (unsigned long)count, (unsigned long)caller);
    }
    spinlock_release(&pmm_lock);
    return phys;
}

void pmm_free_page(phys_addr_t page) {
    pmm_free_pages(page, 1);
}

void pmm_free_pages(phys_addr_t page, size_t count) {
    if (!count) return;

    spinlock_acquire(&pmm_lock);
    mem_region_t *r = region_for_phys(page);
    if (!r) {
        spinlock_release(&pmm_lock);
        return;
    }

    if (PAGE_ALIGN_DOWN(page) != page) {
        spinlock_release(&pmm_lock);
        return;
    }

    size_t start = (page - r->start) / PAGE_SIZE;
    if (start + count > r->total_pages) {
        spinlock_release(&pmm_lock);
        return;
    }

    size_t global_start = r->bitmap_offset + start;

    for (size_t i = 0; i < count; i++) {
        if (bitmap_test(global_start + i)) {
            bitmap_clear(global_start + i);
            free_pages++;
            r->free_pages++;
        }
    }
    spinlock_release(&pmm_lock);
}

size_t pmm_get_free_page_count(void) {
    spinlock_acquire(&pmm_lock);
    size_t count = free_pages;
    spinlock_release(&pmm_lock);
    return count;
}

size_t pmm_get_total_page_count(void) {
    return total_pages;
}

phys_addr_t pmm_get_region_start(void) {
    if (region_count == 0) return 0;
    return regions[0].start;
}

phys_addr_t pmm_get_region_end(void) {
    if (region_count == 0) return 0;
    return regions[region_count - 1].end;
}

size_t pmm_get_bitmap_size(void) {
    return bitmap_size;
}

phys_addr_t pmm_get_bitmap_phys(void) {
    return bitmap_phys;
}

void pmm_set_bitmap_virt(virt_addr_t new_virt_addr) {
    if (!new_virt_addr)
        PANIC("PMM: bitmap virtual address is NULL");

    spinlock_acquire(&pmm_lock);
    bitmap = (u8 *)new_virt_addr;
    spinlock_release(&pmm_lock);
}

size_t pmm_get_region_count(void) {
    return region_count;
}

mem_region_t *pmm_get_region(size_t index) {
    if (index >= region_count) return NULL;
    return &regions[index];
}
