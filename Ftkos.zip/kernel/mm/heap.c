#include <ftk/memory_layout.h>
#include <ftk/memory.h>
#include <ftk/pmm.h>
#include <ftk/string.h>
#include <ftk/panic.h>
#include <ftk/config.h>
#include <ftk/spinlock.h>

#define HEAP_MAGIC 0xDEADBEEF
#define HEAP_MIN_SIZE 0x10000  // 64KB

typedef struct heap_block {
    u32 magic;
    u32 size;
    struct heap_block *next;
    struct heap_block *prev;
    u8 used;
} HeapBlock;

static HeapBlock *heap_start = NULL;
static HeapBlock *heap_end = NULL;

static spinlock_t heap_lock = SPINLOCK_INIT;

void heap_init(void) {
    spinlock_acquire(&heap_lock);
    // Allocate initial heap space
    phys_addr_t phys =
    pmm_alloc_pages((HEAP_MIN_SIZE + PAGE_SIZE - 1) / PAGE_SIZE);
    if (!phys) {
        spinlock_release(&heap_lock);
        kernel_panic("Failed to allocate heap");
    }
    
    heap_start = (HeapBlock*)PHYS_TO_VIRT(phys);
    heap_start->magic = HEAP_MAGIC;
    heap_start->size = HEAP_MIN_SIZE - sizeof(HeapBlock);
    heap_start->next = NULL;
    heap_start->prev = NULL;
    heap_start->used = 0;
    
    heap_end = heap_start;
    spinlock_release(&heap_lock);
}

void* kmalloc(size_t size) {
    if (!heap_start) heap_init();
    
    // Align size to 8 bytes
    size = (size + 7) & ~7;
    
    spinlock_acquire(&heap_lock);
    HeapBlock *block = heap_start;
    while (block) {
        if (!block->used && block->size >= size) {
            // Split block if large enough
            if (block->size > size + sizeof(HeapBlock) + 8) {
                HeapBlock *new_block = (HeapBlock*)((u8*)block + sizeof(HeapBlock) + size);
                new_block->magic = HEAP_MAGIC;
                new_block->size = block->size - size - sizeof(HeapBlock);
                new_block->next = block->next;
                new_block->prev = block;
                new_block->used = 0;
                
                if (block->next) {
                    block->next->prev = new_block;
                }
                block->next = new_block;
                block->size = size;

                if (block == heap_end)
                    heap_end = new_block;
            }
            
            block->used = 1;
            void *ptr = (void*)((u8*)block + sizeof(HeapBlock));
            spinlock_release(&heap_lock);
            return ptr;
        }
        block = block->next;
    }
    
    // No suitable block found, expand heap
    size_t needed = size + sizeof(HeapBlock);
    size_t pages = (needed + PAGE_SIZE - 1) / PAGE_SIZE;
    
    phys_addr_t phys = pmm_alloc_pages(pages);
    if (!phys) {
        spinlock_release(&heap_lock);
        return NULL;
    }
    
    HeapBlock *new_block = (HeapBlock*)PHYS_TO_VIRT(phys);
    new_block->magic = HEAP_MAGIC;
    new_block->size = pages * PAGE_SIZE - sizeof(HeapBlock);
    new_block->next = NULL;
    new_block->used = 0;

    HeapBlock *last = heap_start;
    while (last && last->next)
        last = last->next;
    new_block->prev = last;
    last->next = new_block;
    heap_end = new_block;
    
    spinlock_release(&heap_lock);
    return kmalloc(size);  // Try again with expanded heap
}

void kfree(void *ptr) {
    if (!ptr) return;
    
    spinlock_acquire(&heap_lock);
    HeapBlock *block = (HeapBlock*)((u8*)ptr - sizeof(HeapBlock));
    if (block->magic != HEAP_MAGIC) {
        spinlock_release(&heap_lock);
        kernel_panic("Invalid heap block");
    }
    
    if (!block->used) {
        spinlock_release(&heap_lock);
        kernel_panic("Double free detected");
    }

    block->used = 0;

    /* Merge ONLY if physically/virtually contiguous */
    if (block->next && !block->next->used) {
        if ((u8*)block + sizeof(HeapBlock) + block->size == (u8*)block->next) {
            block->size += sizeof(HeapBlock) + block->next->size;
            block->next = block->next->next;
            if (block->next) block->next->prev = block;
        }
    }

    if (block->prev && !block->prev->used) {
        if ((u8*)block->prev + sizeof(HeapBlock) + block->prev->size == (u8*)block) {
            block->prev->size += sizeof(HeapBlock) + block->size;
            block->prev->next = block->next;
            if (block->next) block->next->prev = block->prev;
            block = block->prev;
        }
    }

    if (block->next == NULL)
        heap_end = block;

    spinlock_release(&heap_lock);
}