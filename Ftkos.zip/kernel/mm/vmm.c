#include <ftk/vmm.h>
#include <ftk/pmm.h>
#include <ftk/abi/bootinfo.h>
#include <ftk/string.h>
#include <ftk/spinlock.h>

AddressSpace kernel_space;
static AddressSpace* current_space = NULL;

static spinlock_t vmm_lock = SPINLOCK_INIT;

static u64* get_pte(AddressSpace* space, virt_addr_t virt, bool create, u64 flags) {
    u64* pml4 = space->pml4_virt;
    u64* pdpt, *pd, *pt;
    
    /* PML4 Entry */
    u64 pml4_idx = PML4_INDEX(virt);
    if (!(pml4[pml4_idx] & PTE_PRESENT)) {
        if (!create) return NULL;
        phys_addr_t pdpt_phys = pmm_alloc_page();
        if (!pdpt_phys) return NULL;
        pml4[pml4_idx] = pdpt_phys | PTE_PRESENT | PTE_WRITABLE | (flags & PTE_USER ? PTE_USER : 0);
        pdpt = (u64*)PHYS_TO_VIRT(pdpt_phys);
        memset(pdpt, 0, PAGE_SIZE);
    } else {
        pdpt = (u64*)PHYS_TO_VIRT((u64)(pml4[pml4_idx] & PAGE_MASK));
    }
    
    /* PDPT Entry */
    u64 pdpt_idx = PDPT_INDEX(virt);
    if (!(pdpt[pdpt_idx] & PTE_PRESENT)) {
        if (!create) return NULL;
        phys_addr_t pd_phys = pmm_alloc_page();
        if (!pd_phys) return NULL;
        pdpt[pdpt_idx] = pd_phys | PTE_PRESENT | PTE_WRITABLE | (flags & PTE_USER ? PTE_USER : 0);
        pd = (u64*)PHYS_TO_VIRT(pd_phys);
        memset(pd, 0, PAGE_SIZE);
    } else {
        pd = (u64*)PHYS_TO_VIRT((u64)(pdpt[pdpt_idx] & PAGE_MASK));
    }
    
    /* PD Entry - Stop here for 2MB Huge Pages */
    u64 pd_idx = PD_INDEX(virt);
    if (flags & PTE_HUGE) {
        return &pd[pd_idx];
    }
    
    if (!(pd[pd_idx] & PTE_PRESENT)) {
        if (!create) return NULL;
        phys_addr_t pt_phys = pmm_alloc_page();
        if (!pt_phys) return NULL;
        pd[pd_idx] = pt_phys | PTE_PRESENT | PTE_WRITABLE | (flags & PTE_USER ? PTE_USER : 0);
        pt = (u64*)PHYS_TO_VIRT(pt_phys);
        memset(pt, 0, PAGE_SIZE);
    } else if (pd[pd_idx] & PTE_HUGE) {
        return &pd[pd_idx];
    } else {
        pt = (u64*)PHYS_TO_VIRT((u64)(pd[pd_idx] & PAGE_MASK));
    }
    
    /* PT Entry */
    u64 pt_idx = PT_INDEX(virt);
    return &pt[pt_idx];
}

int vmm_map_page(AddressSpace* space, virt_addr_t virt, phys_addr_t phys, u64 flags) {
    if (!IS_ALIGNED(virt, PAGE_SIZE) || !IS_ALIGNED(phys, PAGE_SIZE)) return -1;
    
    spinlock_acquire(&vmm_lock);
    u64* pte = get_pte(space, virt, true, flags);
    if (!pte || (*pte & PTE_PRESENT)) {
        spinlock_release(&vmm_lock);
        return -1;
    }
    *pte = (phys & PAGE_MASK) | flags;
    invlpg(virt);
    spinlock_release(&vmm_lock);
    return 0;
}

void vmm_init(void) {
    current_space = &kernel_space;
}

void vmm_switch_address_space(AddressSpace* space) {
    if (!space || space == current_space) return;
    spinlock_acquire(&vmm_lock);
    current_space = space;
    __asm__ volatile("mov %0, %%cr3" : : "r"(space->pml4));
    spinlock_release(&vmm_lock);
}

phys_addr_t vmm_virt_to_phys(virt_addr_t virt) {
    if (!current_space) return 0;
    spinlock_acquire(&vmm_lock);
    u64* pte = get_pte(current_space, virt, false, 0);
    phys_addr_t result = 0;
    if (pte && (*pte & PTE_PRESENT)) {
        if (*pte & PTE_HUGE) result = (*pte & 0x0000FFFFFC000000ULL) | (virt & 0x3FFFFF);
        else result = (*pte & 0x000FFFFFFFFF000ULL) | (virt & 0xFFF);
    }
    spinlock_release(&vmm_lock);
    return result;
}

int vmm_get_flags(AddressSpace* space, virt_addr_t virt, u64* flags_out, phys_addr_t* phys_out) {
    if (!space || !IS_ALIGNED(virt, PAGE_SIZE)) return -1;
    spinlock_acquire(&vmm_lock);
    u64* pte = get_pte(space, virt, false, 0);
    int ret = -1;
    if (pte && (*pte & PTE_PRESENT)) {
        u64 pte_flags = *pte & ~0x000FFFFFFFFF000ULL;
        if (flags_out) *flags_out = pte_flags;
        if (phys_out) {
            if (*pte & PTE_HUGE) *phys_out = (*pte & 0x0000FFFFFC000000ULL) | (virt & 0x3FFFFF);
            else *phys_out = *pte & 0x000FFFFFFFFF000ULL;
        }
        ret = 0;
    }
    spinlock_release(&vmm_lock);
    return ret;
}

int vmm_unmap_page(AddressSpace* space, virt_addr_t virt) {
    if (!IS_ALIGNED(virt, PAGE_SIZE)) return -1;
    spinlock_acquire(&vmm_lock);
    u64* pte = get_pte(space, virt, false, 0);
    int ret = -1;
    if (pte && (*pte & PTE_PRESENT)) {
        *pte = 0;
        invlpg(virt);
        ret = 0;
    }
    spinlock_release(&vmm_lock);
    return ret;
}

int vmm_unmap_and_free(AddressSpace *space, virt_addr_t virt) {
    if (!IS_ALIGNED(virt, PAGE_SIZE)) return -1;

    spinlock_acquire(&vmm_lock);
    u64 *pte = get_pte(space, virt, false, 0);
    int ret = -1;

    if (pte && (*pte & PTE_PRESENT)) {
        phys_addr_t phys;
        if (*pte & PTE_HUGE) {
            phys = (*pte & 0x0000FFFFFC000000ULL) | (virt & 0x3FFFFF);
        } else {
            phys = *pte & 0x000FFFFFFFFF000ULL;
        }
        *pte = 0;
        invlpg(virt);
        pmm_free_page(phys);
        ret = 0;
    }

    spinlock_release(&vmm_lock);
    return ret;
}

static void vmm_free_table(u64 *table, int level) {
    if (!table) return;

    for (int i = 0; i < 512; i++) {
        u64 entry = table[i];
        if (!(entry & PTE_PRESENT)) continue;

        if (level == 3) {
            pmm_free_page(entry & 0x000FFFFFFFFF000ULL);
            continue;
        }

        if (level == 2 && (entry & PTE_HUGE)) {
            pmm_free_pages(entry & 0x0000FFFFFC000000ULL,
                           HUGE_PAGE_SIZE / PAGE_SIZE);
            continue;
        }

        u64 *child = (u64 *)PHYS_TO_VIRT(entry & 0x000FFFFFFFFF000ULL);
        vmm_free_table(child, level + 1);
        pmm_free_page(entry & 0x000FFFFFFFFF000ULL);
    }
}

void vmm_destroy_address_space(AddressSpace *space) {
    if (!space || space == &kernel_space) return;

    spinlock_acquire(&vmm_lock);

    for (int i = 0; i < 256; i++) {
        u64 entry = space->pml4_virt[i];
        if (!(entry & PTE_PRESENT)) continue;

        u64 *pdpt = (u64 *)PHYS_TO_VIRT(entry & 0x000FFFFFFFFF000ULL);
        vmm_free_table(pdpt, 1);
        pmm_free_page(entry & 0x000FFFFFFFFF000ULL);
        space->pml4_virt[i] = 0;
    }

    phys_addr_t pml4_phys = space->pml4;
    spinlock_release(&vmm_lock);

    pmm_free_page(pml4_phys);
}

void invlpg(virt_addr_t virt) {
    __asm__ volatile("invlpg %0" : : "m"(*(char *)virt) : "memory");
}