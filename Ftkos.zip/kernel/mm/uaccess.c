/*
 * kernel/mm/uaccess.c — User-space memory access validation and copy
 *
 * Validates every page in a user buffer against the current task's
 * address space before memcpy. Kernel tasks bypass validation.
 *
 * Uses STAC/CLAC (set/clear AC flag) to safely access user memory
 * when SMAP is active.
 */

#include <ftk/uaccess.h>
#include <ftk/scheduler.h>
#include <ftk/per_cpu.h>
#include <ftk/string.h>
#include <ftk/arch/x86_64/cpu.h>

static inline void stac(void)
{
    __asm__ volatile("stac" ::: "memory");
}

static inline void clac(void)
{
    __asm__ volatile("clac" ::: "memory");
}

int uaccess_validate_range(AddressSpace *space, virt_addr_t addr,
                           size_t n, u8 access)
{
    if (!space || n == 0) {
        return 0;
    }

    /* Overflow and canonical upper-bound check */
    if (addr > USER_SPACE_TOP || n > USER_SPACE_TOP - addr + 1) {
        return -1;
    }

    virt_addr_t start = addr;
    virt_addr_t end   = addr + n;

    for (virt_addr_t page = ALIGN_DOWN(start, PAGE_SIZE);
         page < end;
         page += PAGE_SIZE) {

        u64 flags = 0;
        if (vmm_get_flags(space, page, &flags, NULL) != 0) {
            return -1;
        }

        if (!(flags & PTE_PRESENT) || !(flags & PTE_USER)) {
            return -1;
        }

        if ((access & UACCESS_WRITE) && !(flags & PTE_WRITABLE)) {
            return -1;
        }
    }

    return 0;
}

int copy_from_user(void *dst, const void *user_src, size_t n)
{
    if (!dst || !user_src) {
        return -1;
    }
    if (n == 0) {
        return 0;
    }

    if (!current_task || !current_task->is_user) {
        memcpy(dst, user_src, n);
        return 0;
    }

    AddressSpace *space = current_task->address_space;
    if (uaccess_validate_range(space, (virt_addr_t)(uintptr_t)user_src,
                                n, UACCESS_READ) != 0) {
        return -1;
    }

    if (cpu_smap_enabled()) {
        stac();
        memcpy(dst, user_src, n);
        clac();
    } else {
        memcpy(dst, user_src, n);
    }
    return 0;
}

int copy_to_user(void *user_dst, const void *src, size_t n)
{
    if (!user_dst || !src) {
        return -1;
    }
    if (n == 0) {
        return 0;
    }

    if (!current_task || !current_task->is_user) {
        memcpy(user_dst, src, n);
        return 0;
    }

    AddressSpace *space = current_task->address_space;
    if (uaccess_validate_range(space, (virt_addr_t)(uintptr_t)user_dst,
                                n, UACCESS_WRITE) != 0) {
        return -1;
    }

    if (cpu_smap_enabled()) {
        stac();
        memcpy(user_dst, src, n);
        clac();
    } else {
        memcpy(user_dst, src, n);
    }
    return 0;
}
