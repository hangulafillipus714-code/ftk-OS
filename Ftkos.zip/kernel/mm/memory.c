#include <ftk/memory.h>
#include <ftk/pmm.h>
#include <ftk/vmm.h>

extern void paging_init(BootInfo *boot_info);

void memory_init(BootInfo *boot_info) {
    /* 1. Initialize physical memory manager */
    pmm_init((uintptr_t)boot_info);
    
    /* 2. Initialize architecture-specific paging and map kernel/fb */
    paging_init(boot_info);
    
    /* 3. Update PMM bitmap to use higher-half virtual address */
    pmm_set_bitmap_virt(PHYS_TO_VIRT(pmm_get_bitmap_phys()));
    
    /* 4. Initialize virtual memory manager */
    vmm_init();
}
