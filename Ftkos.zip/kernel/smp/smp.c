/*
 * kernel/smp/smp.c -- SMP bringup and management
 *
 * Handles AP initialization via INIT-SIPI-SIPI sequence
 */

#include <ftk/smp.h>
#include <ftk/apic.h>
#include <ftk/acpi.h>
#include <ftk/printk.h>
#include <ftk/per_cpu.h>
#include <ftk/scheduler.h>
#include <ftk/io.h>
#include <ftk/memory.h>
#include <ftk/pmm.h>
#include <ftk/vmm.h>
#include <ftk/memory_layout.h>
#include <ftk/arch/x86_64/gdt.h>
#include <ftk/arch/x86_64/idt.h>

/* BSP APIC ID */
u32 bsp_apic_id = 0;

/* AP startup synchronization */
volatile u32 ap_ready = 0;

int smp_init(void) {
    kprintf("[SMP] Initializing SMP...\n");

    bsp_apic_id = lapic_get_id();
    kprintf("[SMP] BSP APIC ID: %d\n", bsp_apic_id);

    per_cpu_data[0].cpu_id = 0;
    per_cpu_data[0].apic_id = bsp_apic_id;
    per_cpu_data[0].is_bsp = 1;

    kprintf("[SMP] BSP initialized, %d CPUs detected by ACPI\n", num_cpus);
    return 0;
}

void copy_ap_trampoline(void) {
    size_t size = _binary_arch_x86_64_ap_trampoline_bin_end
                - _binary_arch_x86_64_ap_trampoline_bin_start;
    u8 *dst = (u8 *)PHYS_TO_VIRT(AP_TRAMPOLINE_ADDR);
    u8 *src = (u8 *)_binary_arch_x86_64_ap_trampoline_bin_start;

    for (size_t i = 0; i < size; i++)
        dst[i] = src[i];

    kprintf("[SMP] Trampoline copied to 0x%x (%zu bytes)\n", AP_TRAMPOLINE_ADDR, size);
    __asm__ volatile("outb %%al, %%dx" : : "a"((u8)'T'), "Nd"((u16)0x3F8));
}

int smp_bringup_aps(void) {
    if (num_cpus <= 1) {
        kprintf("[SMP] No APs to start\n");
        return 0;
    }

    kprintf("[SMP] Starting %d APs...\n", num_cpus - 1);

    /* Ensure trampoline area is identity-mapped in kernel page tables */
    extern AddressSpace kernel_space;
    extern int vmm_map_page(AddressSpace *space, virt_addr_t virt, phys_addr_t phys, u64 flags);
    for (phys_addr_t p = AP_TRAMPOLINE_ADDR; p < AP_TRAMPOLINE_ADDR + 0x1000; p += PAGE_SIZE)
        vmm_map_page(&kernel_space, PHYS_TO_VIRT(p), p, PTE_PRESENT | PTE_WRITABLE | PTE_NX);

    /* Copy trampoline to low memory */
    copy_ap_trampoline();

    /* Ensure LAPIC MMIO is accessible via identity-mapped address */
    vmm_map_page(&kernel_space, 0xFEE00000, 0xFEE00000, PTE_PRESENT | PTE_WRITABLE | PTE_NX);

    /* Also ensure trampoline data can be read via identity map by setting up PTEs */
    /* The identity mapping from paging_init uses 2MB pages, which covers our trampoline */

    /* Get kernel PML4 physical address from CR3 */
    phys_addr_t kernel_pml4;
    __asm__ volatile("mov %%cr3, %0" : "=r"(kernel_pml4));

    /* For each AP: allocate resources, patch trampoline, send INIT-SIPI-SIPI */
    for (u32 i = 1; i < num_cpus; i++) {
        u8 apic_id = lapic_ids[i];

        /* Initialize per-CPU data for this AP */
        extern void per_cpu_init(u32 cpu_id, u32 apic_id, int is_bsp);
        per_cpu_init(i, apic_id, 0);

        u64 stack_top = (u64)per_cpu_data[i].kernel_stack_top;

        kprintf("[SMP] Bringing up CPU %d (APIC ID %d)...\n", i, apic_id);

        /* Patch trampoline variables at known offsets */
        volatile u64 *pml4_dst = (volatile u64 *)PHYS_TO_VIRT(AP_TRAMPOLINE_ADDR + AP_PML4_OFFSET);
        volatile u64 *stack_dst = (volatile u64 *)PHYS_TO_VIRT(AP_TRAMPOLINE_ADDR + AP_STACK_OFFSET);
        volatile u64 *entry_dst = (volatile u64 *)PHYS_TO_VIRT(AP_TRAMPOLINE_ADDR + AP_ENTRY_OFFSET);
        volatile u32 *cpu_id_dst = (volatile u32 *)PHYS_TO_VIRT(AP_TRAMPOLINE_ADDR + AP_CPU_ID_OFFSET);

        *pml4_dst = kernel_pml4;
        *stack_dst = stack_top;
        *entry_dst = (u64)smp_ap_entry;
        *cpu_id_dst = i;

        /* Debug: output I (INIT before) then send INIT */
        __asm__ volatile("outb %%al, %%dx" : : "a"((u8)'I'), "Nd"((u16)0x3F8));
        /* Set ap_ready = 0 BEFORE any SIPI so we don't miss the AP's signal */
        ap_ready = 0;
        /* Step 1: INIT IPI (assert) — puts AP into WAIT-for-SIPI state
         * NOTE: Do NOT send deassert! On QEMU TCG the BSP never yields,
         * so the deassert would clear CPU_INTERRUPT_INIT before the AP
         * processes it, preventing WAIT-for-SIPI. The AP stays in
         * WAIT-for-SIPI after INIT assert without deassert (per SDM). */
        lapic_send_init_ipi(apic_id);

        /* Give AP time to process INIT and enter WAIT-for-SIPI */
        for (volatile int j = 0; j < 100000; j++) __asm__ volatile("pause");

        __asm__ volatile("outb %%al, %%dx" : : "a"((u8)'1'), "Nd"((u16)0x3F8));
        /* Step 2: First SIPI */
        u8 vector = AP_TRAMPOLINE_ADDR / 0x1000;
        lapic_send_startup_ipi(apic_id, vector);

        /* Wait 200us for AP to start trampoline */
        for (volatile int j = 0; j < 20000; j++) __asm__ volatile("pause");

        __asm__ volatile("outb %%al, %%dx" : : "a"((u8)'2'), "Nd"((u16)0x3F8));
        /* Step 3: Second SIPI */
        lapic_send_startup_ipi(apic_id, vector);
        __asm__ volatile("outb %%al, %%dx" : : "a"((u8)'W'), "Nd"((u16)0x3F8));

        /* Wait for AP to signal ready */
        for (int timeout = 0; timeout < 100000000; timeout++) {
            if (ap_ready) break;
            __asm__ volatile("pause");
        }

        if (!ap_ready) {
            kprintf("[SMP] AP %d (APIC %d) failed to start\n", i, apic_id);
            continue;
        }

        kprintf("[SMP] CPU %d started successfully\n", i);
    }

    kprintf("[SMP] All APs started\n");
    return 0;
}

void smp_ap_entry(u32 cpu_id) {
    __asm__ volatile("outb %%al, %%dx" : : "a"((u8)'E' + (u8)cpu_id), "Nd"((u16)0x3F8));

    /* Load BSP's GDT (reloads CS with 64-bit kernel code selector 0x08) */
    gdt_load(&gdt_ptr);

    /* Load BSP's IDT so exceptions don't triple-fault */
    idt_load((u64)&idtp);

    /* Set up per-CPU data: GS base, TSS, kernel stack */
    per_cpu_setup_gs_base(cpu_id);
    gdt_init_cpu(cpu_id);

    /* Configure per-CPU scheduler */
    scheduler_init_cpu(cpu_id);

    /* Signal BSP we're alive */
    ap_ready = 1;

    /* Enter per-CPU idle loop (interrupts enabled, HLT) */
    scheduler_start_cpu();
}

void smp_ipi_broadcast(u8 vector) {
    u32 icr_low = vector | (0x0 << 8) | (0 << 11) | (1 << 14) | (0x2 << 18);
    u32 icr_high = 0;

    lapic_write(LAPIC_ICR_HIGH, icr_high);
    lapic_write(LAPIC_ICR_LOW, icr_low);
}

void smp_ipi_single(u32 cpu_id, u8 vector) {
    if (cpu_id >= num_cpus) return;
    u8 dest_apic_id = per_cpu_data[cpu_id].apic_id;

    u32 icr_low = vector | (0x0 << 8) | (0 << 11) | (1 << 14) | (0x0 << 18);
    u32 icr_high = (u32)dest_apic_id << 24;

    while (lapic_read(LAPIC_ICR_LOW) & (1 << 12)) __asm__ volatile("pause");

    lapic_write(LAPIC_ICR_HIGH, icr_high);
    lapic_write(LAPIC_ICR_LOW, icr_low);
}

int smp_cpu_online(u32 cpu_id) { (void)cpu_id; return -1; }
int smp_cpu_offline(u32 cpu_id) { (void)cpu_id; return -1; }