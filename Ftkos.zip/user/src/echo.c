#define SYS_WRITE 1
#define SYS_EXIT  0

#define FD_STDOUT 1

static long syscall(long nr, long a0, long a1, long a2) {
    long ret;
    __asm__ volatile("syscall"
        : "=a"(ret)
        : "a"(nr), "D"(a0), "S"(a1), "d"(a2)
        : "rcx", "r11", "memory");
    return ret;
}

static void putstr(const char *s) {
    long len = 0;
    while (s[len]) len++;
    if (len > 0)
        syscall(SYS_WRITE, FD_STDOUT, (long)s, len);
}

static void putchar(char c) {
    syscall(SYS_WRITE, FD_STDOUT, (long)&c, 1);
}

void _start(void) {
    long argc;
    char **argv;
    __asm__("mov %%rdi, %0\n\tmov %%rsi, %1" : "=r"(argc), "=r"(argv));

    for (long i = 1; i < argc; i++) {
        if (i > 1) putchar(' ');
        putstr(argv[i]);
    }
    putstr("\n");

    syscall(SYS_EXIT, 0, 0, 0);
}
