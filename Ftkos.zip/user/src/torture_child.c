/*
 * torture_child.c — Instant-exit helper for torture_spawn
 *
 * Just enters and exits. Used by torture_spawn to verify the kernel
 * can rapidly create and reap processes without leaking memory.
 */

#define SYS_EXIT  0

static long syscall(long nr, long a0, long a1, long a2) {
    long ret;
    __asm__ volatile("syscall"
        : "=a"(ret)
        : "a"(nr), "D"(a0), "S"(a1), "d"(a2)
        : "rcx", "r11", "memory");
    return ret;
}

void _start(void) {
    syscall(SYS_EXIT, 0, 0, 0);
    for (;;) { __asm__ volatile("hlt"); }
}
