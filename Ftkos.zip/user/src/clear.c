#define SYS_WRITE 1
#define SYS_EXIT  0

#define FD_STDOUT 1

static long syscall(long nr, long a0, long a1, long a2) {
    long ret;
    __asm__ volatile("syscall"
        : "=a"(ret)
        : "a"(nr), "D"(a0), "S"(a1), "d"(a2)
        : "rcx", "r11", "memory");
    return ret;
}

void _start(void) {
    /* Clear screen via ANSI escape */
    const char esc[] = "\x1b[2J\x1b[H";
    long len = 0;
    while (esc[len]) len++;
    syscall(SYS_WRITE, FD_STDOUT, (long)esc, len);

    /* Also scroll up 40 lines for terminal compatibility */
    for (int i = 0; i < 40; i++)
        syscall(SYS_WRITE, FD_STDOUT, (long)"\n", 1);

    syscall(SYS_EXIT, 0, 0, 0);
}
