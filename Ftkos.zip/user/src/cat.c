#define SYS_OPEN     10
#define SYS_READ      2
#define SYS_WRITE     1
#define SYS_CLOSE    11
#define SYS_EXIT      0

#define FD_STDIN  0
#define FD_STDOUT 1

static long syscall(long nr, long a0, long a1, long a2) {
    long ret;
    __asm__ volatile("syscall"
        : "=a"(ret)
        : "a"(nr), "D"(a0), "S"(a1), "d"(a2)
        : "rcx", "r11", "memory");
    return ret;
}

static void putstr(const char *s) {
    long len = 0;
    while (s[len]) len++;
    if (len > 0)
        syscall(SYS_WRITE, FD_STDOUT, (long)s, len);
}

void _start(void) {
    long argc;
    char **argv;
    __asm__("mov %%rdi, %0\n\tmov %%rsi, %1" : "=r"(argc), "=r"(argv));

    long fd;
    if (argc < 2) {
        fd = FD_STDIN;
    } else {
        const char *path = argv[1];
        fd = syscall(SYS_OPEN, (long)path, 0, 0);
        if (fd < 0) {
            putstr("cat: ");
            putstr(path);
            putstr(": not found\n");
            syscall(SYS_EXIT, 1, 0, 0);
        }
    }

    char buf[256];
    long n;
    while ((n = syscall(SYS_READ, fd, (long)buf, 256)) > 0) {
        long written = 0;
        while (written < n) {
            long chunk = n - written;
            if (chunk > 128) chunk = 128;
            long r = syscall(SYS_WRITE, FD_STDOUT, (long)(buf + written), chunk);
            if (r <= 0) break;
            written += r;
        }
    }
    syscall(SYS_CLOSE, fd, 0, 0);
    putstr("\n");
    syscall(SYS_EXIT, 0, 0, 0);
}
