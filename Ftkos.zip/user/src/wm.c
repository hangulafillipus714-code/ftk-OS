/*
 * user/src/wm.c — FTK OS Desktop Window Manager  v0.2
 *
 * Real terminal: pipes stdin/stdout to a live /bin/fsh child process.
 * Calculator and Calendar are in-process widgets (no FPU).
 *
 * Build:
 *   gcc -std=c11 -ffreestanding -nostdlib -nostdinc \
 *       -mno-red-zone -mcmodel=small -mno-sse -mno-sse2 -O2 \
 *       -Iuser/lib -c user/src/wm.c -o user/src/wm.o
 *   ld -T user/init.ld user/src/wm.o user/lib/gui.o -o user/wm.elf
 */

#include "../lib/gui.h"

/* ── Syscall ABI ─────────────────────────────────────────── */
#define SYS_EXIT      0
#define SYS_WRITE     1
#define SYS_READ      2
#define SYS_YIELD     5
#define SYS_OPEN      10
#define SYS_CLOSE     11
#define SYS_SPAWN     12
#define SYS_WAITPID   14
#define SYS_PIPE      16
#define SYS_DUP2      17
#define SYS_KILL      19
#define SYS_GETTIME   28
#define SYS_POLL      29

static inline long sc0(long nr){
    long r; __asm__ volatile("syscall":"=a"(r):"a"(nr),"D"(0),"S"(0),"d"(0):"rcx","r11","memory"); return r;
}
static inline long sc1(long nr,long a){
    long r; __asm__ volatile("syscall":"=a"(r):"a"(nr),"D"(a),"S"(0),"d"(0):"rcx","r11","memory"); return r;
}
static inline long sc2(long nr,long a,long b){
    long r; __asm__ volatile("syscall":"=a"(r):"a"(nr),"D"(a),"S"(b),"d"(0):"rcx","r11","memory"); return r;
}
static inline long sc3(long nr,long a,long b,long c){
    long r; __asm__ volatile("syscall":"=a"(r):"a"(nr),"D"(a),"S"(b),"d"(c):"rcx","r11","memory"); return r;
}
#define sys_yield()           sc0(SYS_YIELD)
#define sys_close(fd)         sc1(SYS_CLOSE,(long)(fd))
#define sys_kill(pid)         sc1(SYS_KILL,(long)(pid))
#define sys_poll(fd)          sc1(SYS_POLL,(long)(fd))
#define sys_dup2(o,n)         sc2(SYS_DUP2,(long)(o),(long)(n))
#define sys_write(fd,p,n)     sc3(SYS_WRITE,(long)(fd),(long)(p),(long)(n))
#define sys_read(fd,p,n)      sc3(SYS_READ,(long)(fd),(long)(p),(long)(n))
#define sys_spawn(p,av)       sc2(SYS_SPAWN,(long)(p),(long)(av))
#define sys_waitpid(pid,st)   sc2(SYS_WAITPID,(long)(pid),(long)(st))

static void wm_putstr(const char *s){ sys_write(1,s,gui_strlen(s)); }

/* ── Clipboard ───────────────────────────────────────────── */
#define CLIP_SIZE 512
static char clipboard[CLIP_SIZE];
static int  clip_len = 0;
static void clip_copy(const char *s,int n){
    if(n>=CLIP_SIZE)n=CLIP_SIZE-1;
    gui_memcpy(clipboard,s,n); clipboard[n]=0; clip_len=n;
}
static int clip_paste(char *dst,int max){
    int n=clip_len<max?clip_len:max;
    gui_memcpy(dst,clipboard,n); return n;
}

/* ── Window ──────────────────────────────────────────────── */
#define MAX_WINS 8
typedef enum { APP_NONE=0, APP_CALC, APP_CAL, APP_TERM } AppId;
typedef struct {
    int   active, focused;
    int   x,y,w,h;
    char  title[32];
    AppId app;
} Win;
static Win  wins[MAX_WINS];
static int  focused_win = -1;

/* ── Calculator state ────────────────────────────────────── */
typedef struct {
    char  display[32];
    char  pending_op;
    long long acc;
    int   new_num, error;
} CalcState;
static CalcState calc;

/* ── Calendar state ──────────────────────────────────────── */
typedef struct { int year,month; ftk_time_t now; } CalState;
static CalState cal;

/* ── Terminal state ──────────────────────────────────────── */
#define TERM_COLS  72
#define TERM_ROWS  22
#define OBUF_SIZE  4096

typedef struct {
    /* Screen buffer */
    char  lines[TERM_ROWS][TERM_COLS+2];
    int   nlines;        /* highest used row */
    int   scroll;        /* rows scrolled (top of view) */

    /* Current partial output line being assembled */
    char  cur_line[TERM_COLS+2];
    int   cur_len;

    /* Input line */
    char  input[TERM_COLS+1];
    int   input_len;
    int   cursor;        /* cursor column in input */

    /* Child process */
    int   child_pid;     /* -1 = dead/not started */
    int   to_child;      /* write end: WM → fsh stdin  */
    int   from_child;    /* read  end: fsh stdout → WM */

    /* Pending output from child */
    char  outbuf[OBUF_SIZE];
    int   outlen;
} TermState;
static TermState term;

/* ── Forward declarations ────────────────────────────────── */
static void win_draw_all(void);
static void win_focus(int idx);
static int  win_open(AppId app);
static void win_close(int idx);

static void calc_init(void);
static void calc_draw(int wx,int wy,int ww,int wh);
static void calc_key(int keycode);

static void cal_init(void);
static void cal_draw(int wx,int wy,int ww,int wh);
static void cal_key(int keycode);

static void term_init(void);
static void term_draw(int wx,int wy,int ww,int wh);
static void term_key(int keycode,int mod);
static void term_poll(void);
static void term_append_output(const char *s, int n);

static void draw_desktop(void);
static void draw_menu(int vis);
static void draw_cursor(void);

/* ── Menu ────────────────────────────────────────────────── */
static int menu_open = 0;
#define MENU_N 3
static const char *menu_label[MENU_N] = {"Calculator","Calendar","Terminal"};
static AppId       menu_app  [MENU_N] = {APP_CALC, APP_CAL, APP_TERM};

/* ══════════════════════════════════════════════════════════
 * Desktop / menu
 * ══════════════════════════════════════════════════════════ */
static void draw_desktop(void)
{
    int W=(int)gui_fb_w, H=(int)gui_fb_h;
    for(int y=0;y<H-24;y++){
        unsigned r=(0x1A*(H-24-y)+0x10*y)/(H-24);
        unsigned g=(0x1A*(H-24-y)+0x04*y)/(H-24);
        unsigned b=(0x2E*(H-24-y)+0x30*y)/(H-24);
        gui_draw_hline(0,y,W,((r&0xFF)<<16)|((g&0xFF)<<8)|(b&0xFF));
    }
    if(!wins[0].active && !wins[1].active && !wins[2].active){
        gui_draw_str_transp(W/2-80,H/2-30,"FTK OS — Press F1 F2 F3",COL_WIN_BORD);
        gui_draw_str_transp(W/2-96,H/2-12,"Calculator  Calendar  Terminal",COL_DGRAY);
    }
}

static void draw_menu(int vis)
{
    if(!vis) return;
    int H=(int)gui_fb_h;
    int mx=0, my=H-24-MENU_N*28-4, mw=144, mh=MENU_N*28+4;
    gui_fill_rect(mx,my,mw,mh,COL_WIN_TITLE);
    gui_draw_rect(mx,my,mw,mh,COL_WIN_BORD);
    for(int i=0;i<MENU_N;i++){
        int iy=my+4+i*28;
        gui_fill_rect(mx+2,iy,mw-4,24,COL_WIN_TITLE);
        gui_draw_str_transp(mx+10,iy+4,menu_label[i],COL_TEXT);
    }
}

/* ══════════════════════════════════════════════════════════
 * Window management
 * ══════════════════════════════════════════════════════════ */
static int win_open(AppId app)
{
    for(int i=0;i<MAX_WINS;i++){
        if(!wins[i].active){
            wins[i].active=1; wins[i].focused=1;
            switch(app){
                case APP_CALC:
                    wins[i].x=60;wins[i].y=50;wins[i].w=260;wins[i].h=310;
                    gui_strcpy(wins[i].title,"Calculator"); calc_init(); break;
                case APP_CAL:
                    wins[i].x=340;wins[i].y=50;wins[i].w=390;wins[i].h=330;
                    gui_strcpy(wins[i].title,"Calendar");   cal_init();  break;
                case APP_TERM:
                    wins[i].x=40;wins[i].y=30;wins[i].w=590;wins[i].h=380;
                    gui_strcpy(wins[i].title,"Terminal — /bin/fsh"); term_init(); break;
                default: wins[i].active=0; return -1;
            }
            wins[i].app=app;
            win_focus(i);
            return i;
        }
    }
    return -1;
}

static void win_close(int idx)
{
    if(idx<0||idx>=MAX_WINS||!wins[idx].active) return;
    if(wins[idx].app==APP_TERM && term.child_pid>0){
        sys_kill(term.child_pid); term.child_pid=-1;
        if(term.to_child>=0)  sys_close(term.to_child);
        if(term.from_child>=0)sys_close(term.from_child);
        term.to_child=-1; term.from_child=-1;
    }
    wins[idx].active=0;
    if(focused_win==idx) focused_win=-1;
}

static void win_focus(int idx){
    for(int i=0;i<MAX_WINS;i++) wins[i].focused=0;
    if(idx>=0){wins[idx].focused=1; focused_win=idx;}
}

static void win_raise(int idx){
    if(idx<=0||idx>=MAX_WINS) return;
    Win tmp=wins[idx];
    for(int i=idx;i>0;i--) wins[i]=wins[i-1];
    wins[0]=tmp; focused_win=0; wins[0].focused=1;
}

static void win_draw_all(void)
{
    draw_desktop();
    for(int i=MAX_WINS-1;i>=0;i--){
        if(!wins[i].active) continue;
        Win *w=&wins[i];
        gui_draw_window(w->x,w->y,w->w,w->h,w->title,w->focused);
        int cx=w->x, cy=w->y+20, cw=w->w, ch=w->h-20;
        switch(w->app){
            case APP_CALC: calc_draw(cx,cy,cw,ch); break;
            case APP_CAL:  cal_draw (cx,cy,cw,ch); break;
            case APP_TERM: term_draw(cx,cy,cw,ch); break;
            default: break;
        }
    }
    gui_draw_taskbar("FTK Desktop");
    draw_menu(menu_open);
}

/* ══════════════════════════════════════════════════════════
 * Calculator
 * ══════════════════════════════════════════════════════════ */
static void calc_init(void){
    calc.display[0]='0'; calc.display[1]=0;
    calc.pending_op=0; calc.acc=0; calc.new_num=1; calc.error=0;
}

static void calc_draw(int wx,int wy,int ww,int wh)
{
    (void)wh;
    /* Display */
    gui_fill_rect(wx+8,wy+8,ww-16,26,0x050510);
    gui_draw_rect(wx+8,wy+8,ww-16,26,COL_ACCENT);
    int tw=gui_str_width(calc.display);
    gui_draw_str(wx+ww-16-tw,wy+13,calc.display,
                 calc.error?COL_RED:COL_GREEN,0x050510);

    static const char *lbl[20]={
        "C","+/-","%","÷",
        "7","8","9","×",
        "4","5","6","−",
        "1","2","3","+",
        "0",".", "=","⌫"};
    int bw=(ww-16)/4, bh=40, gx=wx+8, gy=wy+42;
    for(int r=0;r<5;r++){
        for(int c=0;c<4;c++){
            int bx=gx+c*bw, by=gy+r*bh;
            int idx=r*4+c;
            u32 face = (c==3||idx==18) ? COL_ACCENT :
                        r==0           ? COL_BTN_HOT : COL_BTN_NORM;
            gui_fill_rect(bx+1,by+1,bw-2,bh-2,face);
            gui_draw_rect(bx,by,bw,bh,COL_DGRAY);
            int tl=gui_str_width(lbl[idx]);
            gui_draw_str(bx+(bw-tl)/2,by+(bh-16)/2,lbl[idx],COL_TEXT,face);
        }
    }
}

static void calc_push_char(char c){
    int len=gui_strlen(calc.display);
    if(calc.new_num){calc.display[0]=c;calc.display[1]=0;calc.new_num=0;return;}
    if(len>=15) return;
    if(c=='.'){ int i=0; while(calc.display[i])if(calc.display[i++]=='.')return; }
    calc.display[len]=c; calc.display[len+1]=0;
}

static long long calc_parse(void){
    long long v=0; int neg=0; const char *s=calc.display;
    if(*s=='-'){neg=1;s++;}
    while(*s>='0'&&*s<='9') v=v*10+(*s++-'0');
    return neg?-v:v;
}

static void calc_apply_op(void){
    long long cur=calc_parse();
    switch(calc.pending_op){
        case '+': calc.acc+=cur; break;
        case '-': calc.acc-=cur; break;
        case '*': calc.acc*=cur; break;
        case '/':
            if(!cur){calc.error=1;gui_strcpy(calc.display,"Err");return;}
            calc.acc/=cur; break;
        default: calc.acc=cur; break;
    }
    gui_ltoa(calc.acc,calc.display);
    calc.new_num=1;
}

static void calc_key(int k){
    char c=(char)k;
    if(calc.error&&c!='c'&&c!='C') return;
    if(c>='0'&&c<='9'){calc_push_char(c);return;}
    if(c=='.'){calc_push_char('.');return;}
    if(c=='+'||c=='-'||c=='*'||c=='/'){calc_apply_op();calc.pending_op=c;return;}
    if(c=='\r'||c=='='){calc_apply_op();calc.pending_op=0;return;}
    if(c=='\b'||k==FTK_KEY_BKSP||k==FTK_KEY_DEL){
        int len=gui_strlen(calc.display);
        if(len>1) calc.display[len-1]=0;
        else {calc.display[0]='0';calc.display[1]=0;calc.new_num=1;}
        return;
    }
    if(c=='c'||c=='C'){calc_init();return;}
    if(c=='%'){
        long long cur=calc_parse();
        gui_ltoa(calc.acc*cur/100,calc.display);
        calc.new_num=1;return;
    }
}

/* ══════════════════════════════════════════════════════════
 * Calendar
 * ══════════════════════════════════════════════════════════ */
static int days_in_month(int y,int m){
    static const int d[13]={0,31,28,31,30,31,30,31,31,30,31,30,31};
    if(m==2){int lp=(y%4==0&&y%100!=0)||(y%400==0);return lp?29:28;}
    return d[m];
}
static int day_of_week(int y,int m,int d){   /* 0=Mon … 6=Sun */
    if(m<3){m+=12;y--;}
    int k=y%100,j=y/100;
    int h=(d+(13*(m+1))/5+k+k/4+j/4-2*j)%7;
    return (h+5)%7;
}
static void cal_init(void){
    gui_gettime(&cal.now);
    cal.year=cal.now.year; cal.month=cal.now.month;
}
static const char *mnames[13]={"","Jan","Feb","Mar","Apr","May","Jun",
                                "Jul","Aug","Sep","Oct","Nov","Dec"};
static const char *dnames[7]={"Mo","Tu","We","Th","Fr","Sa","Su"};

static void cal_draw(int wx,int wy,int ww,int wh)
{
    int y=cal.year, m=cal.month;
    char hdr[32]; char *p=hdr;
    const char *mn=mnames[m]; while(*mn)*p++=*mn++;
    *p++=' '; gui_ltoa(y,p); while(*p)p++;
    gui_fill_rect(wx,wy,ww,22,COL_WIN_TITLE);
    gui_draw_str(wx+24,wy+3,hdr,COL_TEXT,COL_WIN_TITLE);
    gui_draw_str(wx+6,wy+3,"<",COL_YELLOW,COL_WIN_TITLE);
    gui_draw_str(wx+ww-14,wy+3,">",COL_YELLOW,COL_WIN_TITLE);

    int cy=wy+24, cw=ww/7;
    for(int i=0;i<7;i++){
        gui_fill_rect(wx+i*cw,cy,cw,16,COL_DGRAY);
        gui_draw_str_transp(wx+i*cw+(cw-16)/2,cy,dnames[i],COL_LGRAY);
    }
    cy+=16;

    int first=day_of_week(y,m,1), dim=days_in_month(y,m);
    int col=first, row=0, ch2=26;
    for(int d=1;d<=dim;d++){
        int bx=wx+col*cw, by=cy+row*ch2;
        int today=(y==cal.now.year&&m==cal.now.month&&d==cal.now.day);
        u32 bg=today?COL_ACCENT:(row%2?0x1A1A30:COL_WIN_BODY);
        gui_fill_rect(bx+1,by,cw-2,ch2-1,bg);
        char ds[4]; gui_itoa(d,ds,10);
        int tw=gui_str_width(ds);
        gui_draw_str(bx+(cw-tw)/2,by+5,ds,today?COL_WHITE:COL_TEXT,bg);
        if(++col==7){col=0;row++;}
    }
    gui_draw_str(wx+4,wy+wh-16,"← → months  T=today",COL_TEXT_DIM,COL_WIN_BODY);
}

static void cal_key(int k){
    if(k==FTK_KEY_LEFT||k=='['){ if(--cal.month<1){cal.month=12;cal.year--;} }
    if(k==FTK_KEY_RIGHT||k==']'){ if(++cal.month>12){cal.month=1;cal.year++;} }
    if(k=='t'||k=='T'){cal.year=cal.now.year;cal.month=cal.now.month;}
}

/* ══════════════════════════════════════════════════════════
 * Terminal — real pipe to /bin/fsh
 * ══════════════════════════════════════════════════════════ */

/* Append a chunk of raw output to the line buffer, handling \n and \r */
static void term_append_output(const char *s, int n)
{
    for(int i=0;i<n;i++){
        char c=s[i];
        if(c=='\n'||c=='\r'){
            /* Commit cur_line into lines[] */
            if(term.nlines < TERM_ROWS-1)
                term.nlines++;
            else {
                /* Scroll: shift lines up */
                for(int r=0;r<TERM_ROWS-1;r++)
                    gui_memcpy(term.lines[r],term.lines[r+1],TERM_COLS+2);
            }
            gui_memcpy(term.lines[term.nlines-1], term.cur_line, term.cur_len+1);
            term.cur_line[0]=0; term.cur_len=0;
            continue;
        }
        if(c=='\b'){
            if(term.cur_len>0) term.cur_line[--term.cur_len]=0;
            continue;
        }
        /* Strip most ANSI escape sequences (ESC [ … m) */
        if(c==0x1B){ while(i<n-1&&s[i+1]!='m')i++; i++; continue; }
        if(c>=0x20&&c<0x7F&&term.cur_len<TERM_COLS){
            term.cur_line[term.cur_len++]=c;
            term.cur_line[term.cur_len]=0;
        }
    }
}

/* Drain child stdout non-blocking */
static void term_poll(void)
{
    if(term.from_child<0) return;
    /* Read up to 256 bytes per frame to stay responsive */
    for(int iter=0;iter<8;iter++){
        if(!sys_poll(term.from_child)) break;
        char buf[64];
        long n=sys_read(term.from_child,(long)buf,sizeof(buf));
        if(n<=0) break;
        term_append_output(buf,(int)n);
    }
}

static void term_init(void)
{
    gui_memset(&term,0,sizeof(term));
    term.child_pid=-1;
    term.to_child=-1;
    term.from_child=-1;

    /* pipe[0]=read, pipe[1]=write */
    int stdin_pipe[2], stdout_pipe[2];

    /* Create stdin pipe (WM writes to [1], child reads from [0]) */
    if(sc3(SYS_PIPE,(long)stdin_pipe,0,0)<0){
        term_append_output("pipe(stdin) failed\n",19);
        return;
    }
    /* Create stdout pipe (child writes to [1], WM reads from [0]) */
    if(sc3(SYS_PIPE,(long)stdout_pipe,0,0)<0){
        term_append_output("pipe(stdout) failed\n",20);
        sys_close(stdin_pipe[0]); sys_close(stdin_pipe[1]);
        return;
    }

    /* Temporarily remap OUR stdin/stdout to the pipe ends so that
     * the child inherits them via task.c's fd_table copy-on-spawn. */
    int saved_stdin  = -1;  /* not needed: we'll restore */
    int saved_stdout = -1;
    (void)saved_stdin; (void)saved_stdout;

    /* dup2(stdin_pipe[0],  0) — child reads from here */
    sys_dup2(stdin_pipe[0],  0);
    /* dup2(stdout_pipe[1], 1) — child writes to here */
    sys_dup2(stdout_pipe[1], 1);
    sys_dup2(stdout_pipe[1], 2);

    /* Spawn the shell */
    long pid = sys_spawn("/bin/fsh", 0);

    /* Restore our own stdin/stdout to console (fd type=0 means console) */
    /* We can't easily re-open console; instead we just leave fd 0/1/2
     * as pipes — we only use gui_fb directly, never sys_read/write for UI. */

    /* Close our copies of the pipe ends the child uses */
    sys_close(stdin_pipe[0]);  /* child's stdin read-end */
    sys_close(stdout_pipe[1]); /* child's stdout write-end */

    if(pid < 0){
        term_append_output("spawn /bin/fsh failed\n",22);
        sys_close(stdin_pipe[1]);
        sys_close(stdout_pipe[0]);
        return;
    }

    term.child_pid  = (int)pid;
    term.to_child   = (int)stdin_pipe[1];   /* WM writes here → child stdin  */
    term.from_child = (int)stdout_pipe[0];  /* WM reads here  ← child stdout */

    term_append_output("[fsh started — type commands]\n",30);
}

static void term_draw(int wx,int wy,int ww,int wh)
{
    /* Output area */
    int line_h=14;
    int visible_rows=(wh-26)/line_h;
    if(visible_rows>TERM_ROWS) visible_rows=TERM_ROWS;
    int start=term.nlines - visible_rows;
    if(start<0) start=0;

    for(int r=0;r<visible_rows;r++){
        int ridx=start+r;
        if(ridx>=TERM_ROWS) break;
        int ty=wy+2+r*line_h;
        /* Clear line background */
        gui_fill_rect(wx+2,ty,ww-4,line_h,COL_WIN_BODY);
        gui_draw_str(wx+4,ty,term.lines[ridx],COL_GREEN,COL_WIN_BODY);
    }
    /* Show partial current line */
    {
        int ty=wy+2+(visible_rows-1)*line_h;
        gui_fill_rect(wx+2,ty,ww-4,line_h,COL_WIN_BODY);
        gui_draw_str(wx+4,ty,term.cur_line,COL_LGRAY,COL_WIN_BODY);
    }

    /* Input bar */
    int iy=wy+wh-26;
    gui_fill_rect(wx,iy,ww,26,0x060618);
    gui_draw_hline(wx,iy,ww,COL_ACCENT);

    /* prompt */
    gui_draw_str_transp(wx+4,iy+5,"$ ",COL_ACCENT);

    /* input text — only show last (TERM_COLS-4) chars if long */
    int show_from=0;
    if(term.input_len > TERM_COLS-4) show_from = term.input_len-(TERM_COLS-4);
    gui_draw_str(wx+20,iy+5,term.input+show_from,COL_TEXT,0x060618);

    /* cursor */
    int cur_screen = term.cursor - show_from;
    if(cur_screen>=0){
        gui_draw_vline(wx+20+cur_screen*8,iy+5,14,COL_CURSOR);
    }
}

static void term_submit_line(void)
{
    if(term.to_child<0) return;
    /* Send line + newline to child stdin */
    if(term.input_len>0)
        sys_write(term.to_child,(long)term.input,term.input_len);
    sys_write(term.to_child,(long)"\n",1);
    /* Echo locally */
    char echo[TERM_COLS+4]; char *p=echo;
    *p++='$'; *p++=' ';
    gui_memcpy(p,term.input,term.input_len); p+=term.input_len; *p=0;
    term_append_output(echo,gui_strlen(echo));
    term_append_output("\n",1);
    /* Reset input */
    gui_memset(term.input,0,sizeof(term.input));
    term.input_len=0; term.cursor=0;
}

static void term_key(int k, int mod)
{
    if(k=='\r'||k==FTK_KEY_ENTER){ term_submit_line(); return; }

    if(k==FTK_KEY_LEFT){
        if(term.cursor>0) term.cursor--;
        return;
    }
    if(k==FTK_KEY_RIGHT){
        if(term.cursor<term.input_len) term.cursor++;
        return;
    }
    if(k==FTK_KEY_HOME){ term.cursor=0; return; }
    if(k==FTK_KEY_END)  { term.cursor=term.input_len; return; }

    if(k==FTK_KEY_BKSP||k=='\b'){
        if(term.cursor>0){
            for(int i=term.cursor-1;i<term.input_len-1;i++)
                term.input[i]=term.input[i+1];
            term.input[--term.input_len]=0;
            term.cursor--;
        }
        return;
    }
    if(k==FTK_KEY_DEL){
        if(term.cursor<term.input_len){
            for(int i=term.cursor;i<term.input_len-1;i++)
                term.input[i]=term.input[i+1];
            term.input[--term.input_len]=0;
        }
        return;
    }

    /* Ctrl+C → send to child */
    if(k==3||(k=='c'&&(mod&FTK_MOD_CTRL))){
        if(term.to_child>=0) sys_write(term.to_child,(long)"\x03",1);
        gui_memset(term.input,0,sizeof(term.input));
        term.input_len=0; term.cursor=0;
        return;
    }

    /* Printable */
    if(k>=0x20&&k<0x7F&&term.input_len<TERM_COLS-1){
        /* Insert at cursor */
        for(int i=term.input_len;i>term.cursor;i--)
            term.input[i]=term.input[i-1];
        term.input[term.cursor++]=(char)k;
        term.input[++term.input_len]=0;
    }
}

/* ══════════════════════════════════════════════════════════
 * Hit test helpers
 * ══════════════════════════════════════════════════════════ */
static int in_taskbar_logo(int px,int py){
    int H=(int)gui_fb_h; return px>=0&&px<58&&py>=H-24&&py<H;
}
static int in_menu_item(int px,int py,int *item){
    int H=(int)gui_fb_h;
    int my=H-24-MENU_N*28-4;
    if(px<0||px>144) return 0;
    for(int i=0;i<MENU_N;i++){
        int iy=my+4+i*28;
        if(py>=iy&&py<iy+24){*item=i;return 1;}
    }
    return 0;
}
static int win_hit_close(Win *w,int px,int py){
    int bx=w->x+w->w-18, by=w->y+2;
    return px>=bx&&px<bx+16&&py>=by&&py<by+16;
}
static int win_hit_body(Win *w,int px,int py){
    return px>=w->x&&px<w->x+w->w&&py>=w->y&&py<w->y+w->h;
}
static int win_at(int px,int py){
    for(int i=0;i<MAX_WINS;i++)
        if(wins[i].active&&win_hit_body(&wins[i],px,py)) return i;
    return -1;
}

/* ══════════════════════════════════════════════════════════
 * Software cursor
 * ══════════════════════════════════════════════════════════ */
static int mouse_x=400, mouse_y=300;
static void draw_cursor(void){
    int x=mouse_x, y=mouse_y;
    for(int i=0;i<12;i++){
        gui_put_pixel(x,y+i,COL_WHITE);
        if(i<7) gui_put_pixel(x+i,y+i,COL_WHITE);
    }
    for(int i=6;i<12;i++) gui_put_pixel(x+i-4,y+i,COL_WHITE);
}

/* ══════════════════════════════════════════════════════════
 * Main event / render loop
 * ══════════════════════════════════════════════════════════ */
void _start(void)
{
    if(gui_init()!=0){
        wm_putstr("wm: gui_init failed\n");
        sc1(SYS_EXIT,-1); for(;;);
    }
    wm_putstr("wm: started\n");

    /* Open default windows */
    win_open(APP_CALC);
    win_open(APP_CAL);

    u64 last_draw=0;

    for(;;){
        /* ── 1. Drain child terminal output ── */
        term_poll();

        /* ── 2. Process key events ── */
        ftk_key_event_t ev;
        int got=0;
        for(int ep=0;ep<32;ep++){
            if(!gui_poll_key(&ev)) break;
            got=1;
            if(ev.type!=FTK_KEY_PRESS) continue;

            int k=ev.keycode, mod=ev.modifiers;

            /* Global shortcuts */
            if(k==FTK_KEY_F1){ win_open(APP_CALC); continue; }
            if(k==FTK_KEY_F2){ win_open(APP_CAL);  continue; }
            if(k==FTK_KEY_F3){ win_open(APP_TERM);  continue; }

            /* Alt+Arrows → move software mouse */
            if(mod&FTK_MOD_ALT){
                int step=8;
                if(k==FTK_KEY_UP)   { mouse_y-=step; if(mouse_y<0)mouse_y=0; }
                if(k==FTK_KEY_DOWN) { mouse_y+=step; if(mouse_y>=(int)gui_fb_h)mouse_y=(int)gui_fb_h-1; }
                if(k==FTK_KEY_LEFT) { mouse_x-=step; if(mouse_x<0)mouse_x=0; }
                if(k==FTK_KEY_RIGHT){ mouse_x+=step; if(mouse_x>=(int)gui_fb_w)mouse_x=(int)gui_fb_w-1; }
                continue;
            }

            /* Enter without Alt = click at cursor */
            if(k==FTK_KEY_ENTER && !(mod&FTK_MOD_CTRL)){
                int px=mouse_x, py=mouse_y;
                if(in_taskbar_logo(px,py)){menu_open=!menu_open;continue;}
                if(menu_open){
                    int it=-1;
                    if(in_menu_item(px,py,&it)){ win_open(menu_app[it]); menu_open=0; }
                    else menu_open=0;
                    continue;
                }
                int wi=win_at(px,py);
                if(wi>=0){
                    if(win_hit_close(&wins[wi],px,py)){ win_close(wi); continue; }
                    if(wi!=focused_win){ win_focus(wi); win_raise(wi); }
                }
                continue;
            }

            /* Arrows without Alt → move focused window */
            if(!(mod&FTK_MOD_ALT)&&!(mod&FTK_MOD_CTRL)
               &&focused_win>=0&&wins[focused_win].active
               &&wins[focused_win].app!=APP_TERM  /* terminal needs arrows for line-edit */
               &&wins[focused_win].app!=APP_CAL){
                int step=8;
                if(k==FTK_KEY_UP)   { wins[focused_win].y-=step; }
                if(k==FTK_KEY_DOWN) { wins[focused_win].y+=step; }
                if(k==FTK_KEY_LEFT) { wins[focused_win].x-=step; }
                if(k==FTK_KEY_RIGHT){ wins[focused_win].x+=step; }
            }

            /* Ctrl+Tab → cycle focus */
            if(k==FTK_KEY_TAB&&(mod&FTK_MOD_CTRL)){
                int n=(focused_win+1)%MAX_WINS;
                while(!wins[n].active&&n!=focused_win) n=(n+1)%MAX_WINS;
                win_focus(n); continue;
            }
            /* Ctrl+W → close */
            if((k=='w'||k=='W')&&(mod&FTK_MOD_CTRL)){
                win_close(focused_win); continue;
            }
            /* Ctrl+C in calc → copy display */
            if((k=='c'||k=='C')&&(mod&FTK_MOD_CTRL)){
                if(focused_win>=0&&wins[focused_win].app==APP_CALC)
                    clip_copy(calc.display,gui_strlen(calc.display));
                continue;
            }
            /* Ctrl+V in terminal → paste clipboard */
            if((k=='v'||k=='V')&&(mod&FTK_MOD_CTRL)){
                if(focused_win>=0&&wins[focused_win].app==APP_TERM){
                    int n=clip_paste(term.input+term.input_len,
                                     TERM_COLS-1-term.input_len);
                    term.input_len+=n;
                    term.cursor=term.input_len;
                }
                continue;
            }

            /* Route to focused app */
            if(focused_win>=0&&wins[focused_win].active){
                switch(wins[focused_win].app){
                    case APP_CALC: calc_key(k);      break;
                    case APP_CAL:  cal_key(k);       break;
                    case APP_TERM: term_key(k,mod);  break;
                    default: break;
                }
            }
        }

        /* ── 3. Redraw at ≈30 Hz ── */
        u64 now=gui_ticks();
        if(got || now-last_draw>=3){
            win_draw_all();
            draw_cursor();
            last_draw=now;
        } else {
            sys_yield();
        }
    }
}
