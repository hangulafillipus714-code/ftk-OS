#define SYS_PS    13
#define SYS_WRITE  1
#define SYS_EXIT   0

#define FD_STDOUT 1

#define PS_STATE_RUNNING 0
#define PS_STATE_READY   1
#define PS_STATE_BLOCKED 2
#define PS_STATE_ZOMBIE  3

typedef struct {
    int  pid;
    int  state;
    char name[32];
} ps_info_t;

static long syscall(long nr, long a0, long a1, long a2) {
    long ret;
    __asm__ volatile("syscall"
        : "=a"(ret)
        : "a"(nr), "D"(a0), "S"(a1), "d"(a2)
        : "rcx", "r11", "memory");
    return ret;
}

static void putstr(const char *s) {
    long len = 0;
    while (s[len]) len++;
    if (len > 0)
        syscall(SYS_WRITE, FD_STDOUT, (long)s, len);
}

static void putdec(long v) {
    char tmp[16];
    int ti = 15;
    tmp[15] = '\0';
    if (v == 0) { tmp[14] = '0'; putstr(tmp + 14); return; }
    if (v < 0) { putstr("-"); v = -v; }
    while (v > 0 && ti > 0) {
        tmp[--ti] = '0' + (v % 10);
        v /= 10;
    }
    putstr(tmp + ti);
}

static const char *state_name(int s) {
    switch (s) {
        case PS_STATE_RUNNING: return "RUN";
        case PS_STATE_READY:   return "RDY";
        case PS_STATE_BLOCKED: return "BLK";
        case PS_STATE_ZOMBIE:  return "ZMB";
        default:               return "???";
    }
}

void _start(void) {
    ps_info_t info[16];
    long n = syscall(SYS_PS, -1, (long)info, 16);
    if (n <= 0) return;

    putstr(" PID  STATE NAME\n");
    putstr("----  ----- ----\n");
    for (long i = 0; i < n; i++) {
        int pid = info[i].pid;
        if (pid < 10)   putstr(" ");
        if (pid < 100)  putstr(" ");
        if (pid < 1000) putstr(" ");
        putdec(pid);
        putstr("  ");
        putstr(state_name(info[i].state));
        putstr("  ");
        putstr(info[i].name);
        putstr("\n");
    }

    syscall(SYS_EXIT, 0, 0, 0);
}
