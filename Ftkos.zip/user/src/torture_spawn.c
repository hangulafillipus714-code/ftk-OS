/*
 * torture_spawn.c — User-space stress test: rapid spawn() + exit() loop
 *
 * Forks child processes that immediately exit, in a tight loop. Verifies
 * the kernel scheduler does not leak memory or deadlock under heavy
 * process creation churn.
 */

#define SYS_WRITE    1
#define SYS_EXIT      0
#define SYS_SPAWN    12
#define SYS_WAITPID  14
#define SYS_GETPID    3

#define FD_STDOUT 1

#define ITERATIONS   200
#define CHILD_NAME   "torture_child"

#define NULL ((void*)0)

static long syscall(long nr, long a0, long a1, long a2) {
    long ret;
    __asm__ volatile("syscall"
        : "=a"(ret)
        : "a"(nr), "D"(a0), "S"(a1), "d"(a2)
        : "rcx", "r11", "memory");
    return ret;
}

static void putstr(const char *s) {
    long len = 0;
    while (s[len]) len++;
    if (len > 0)
        syscall(SYS_WRITE, FD_STDOUT, (long)s, len);
}

static void putdec(long v) {
    char buf[24];
    int i = 23;
    buf[i--] = '\0';
    if (v == 0) buf[i--] = '0';
    while (v > 0 && i >= 0) {
        buf[i--] = '0' + (v % 10);
        v /= 10;
    }
    putstr(&buf[i + 1]);
}

void _start(void) {
    long argc;
    char **argv;
    __asm__("mov %%rdi, %0\n\tmov %%rsi, %1" : "=r"(argc), "=r"(argv));
    (void)argv;

    putstr("[torture_spawn] starting spawn/exit loop\r\n");

    long ok = 0;
    long fail = 0;
    long self = syscall(SYS_GETPID, 0, 0, 0);
    putstr("[torture_spawn] parent pid=");
    putdec(self);
    putstr("\r\n");

    for (long i = 0; i < ITERATIONS; i++) {
        char *child_argv[] = { CHILD_NAME, NULL };
        long pid = syscall(SYS_SPAWN, (long)"torture_child", (long)child_argv, 0);
        if (pid < 0) {
            fail++;
            putstr("[torture_spawn] spawn #");
            putdec(i);
            putstr(" FAILED\r\n");
            continue;
        }

        long reaped = syscall(SYS_WAITPID, (long)pid, 0, 0);
        if (reaped < 0) {
            fail++;
            putstr("[torture_spawn] waitpid #");
            putdec(i);
            putstr(" FAILED\r\n");
            continue;
        }
        ok++;
    }

    putstr("[torture_spawn] done: ok=");
    putdec(ok);
    putstr(" fail=");
    putdec(fail);
    putstr("\r\n");

    syscall(SYS_EXIT, (fail > 0) ? 1 : 0, 0, 0);
}
