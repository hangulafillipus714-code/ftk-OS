/*
 * torture_vfs.c — User-space stress test: VFS error handling
 *
 * Verifies that the kernel returns clean error codes instead of
 * panicking when:
 *   - Opening non-existent files
 *   - Using invalid file descriptors
 *   - Closing a never-opened fd
 *   - Writing to a read-only fd (stdin)
 *   - Reading from a write-only fd (stdout)
 *   - Passing null pointers in user space
 *
 * The test does not crash the kernel — it succeeds only if every
 * syscall returns the expected errno-style negative value.
 */

#define SYS_OPEN     10
#define SYS_READ      2
#define SYS_WRITE     1
#define SYS_CLOSE    11
#define SYS_EXIT      0
#define SYS_DUP2     17

#define FD_STDIN   0
#define FD_STDOUT  1
#define FD_STDERR  2

#define ESYS_BADF  -4
#define ESYS_NOENT -7

static long syscall(long nr, long a0, long a1, long a2) {
    long ret;
    __asm__ volatile("syscall"
        : "=a"(ret)
        : "a"(nr), "D"(a0), "S"(a1), "d"(a2)
        : "rcx", "r11", "memory");
    return ret;
}

static void putstr(const char *s) {
    long len = 0;
    while (s[len]) len++;
    if (len > 0)
        syscall(SYS_WRITE, FD_STDOUT, (long)s, len);
}

static void putdec(long v) {
    char buf[24];
    int i = 23;
    buf[i--] = '\0';
    if (v == 0) buf[i--] = '0';
    while (v > 0 && i >= 0) {
        buf[i--] = '0' + (v % 10);
        v /= 10;
    }
    putstr(&buf[i + 1]);
}

static int expect_fail(const char *label, long ret, long expected) {
    if (ret == expected) {
        putstr("[PASS] ");
        putstr(label);
        putstr(" (ret=");
        putdec(ret);
        putstr(")\r\n");
        return 0;
    }
    putstr("[FAIL] ");
    putstr(label);
    putstr(" expected=");
    putdec(expected);
    putstr(" actual=");
    putdec(ret);
    putstr("\r\n");
    return 1;
}

void _start(void) {
    long argc;
    char **argv;
    __asm__("mov %%rdi, %0\n\tmov %%rsi, %1" : "=r"(argc), "=r"(argv));
    (void)argv;

    long failures = 0;

    putstr("=== VFS Torture Test ===\r\n");

    /* 1. Open a non-existent file (expect ESYS_NOENT or other neg errno) */
    long r = syscall(SYS_OPEN, (long)"/no/such/file", 0, 0);
    failures += expect_fail("open non-existent", r, ESYS_NOENT);

    /* 2. Open another non-existent file */
    r = syscall(SYS_OPEN, (long)"/also/missing", 0, 0);
    failures += expect_fail("open missing 2", r, ESYS_NOENT);

    /* 3. Use a wildly invalid fd number */
    r = syscall(SYS_READ, 999, 0, 0);
    failures += expect_fail("read bad fd 999", r, ESYS_BADF);

    /* 4. Use a different invalid fd */
    r = syscall(SYS_WRITE, 888, 0, 0);
    failures += expect_fail("write bad fd 888", r, ESYS_BADF);

    /* 5. Close a never-opened fd */
    r = syscall(SYS_CLOSE, 50, 0, 0);
    failures += expect_fail("close bad fd 50", r, ESYS_BADF);

    /* 6. dup2 with an invalid old fd */
    r = syscall(SYS_DUP2, 777, 4, 0);
    failures += expect_fail("dup2 bad oldfd", r, ESYS_BADF);

    /* 7. Open the same non-existent file several times in a row */
    int i;
    for (i = 0; i < 10; i++) {
        r = syscall(SYS_OPEN, (long)"/broken/path", 0, 0);
        if (r != ESYS_NOENT) {
            putstr("[FAIL] repeated open #");
            putdec(i);
            putstr(" returned ");
            putdec(r);
            putstr("\r\n");
            failures++;
        }
    }
    if (failures == 0 || failures < 7) {
        putstr("[PASS] repeated open non-existent (10x)\r\n");
    }

    /* 8. Pass a clearly-bogus user pointer to read */
    r = syscall(SYS_READ, FD_STDIN, 0xDEADBEEF, 16);
    /* Either -EFAULT (preferred) or some other non-positive errno */
    if (r < 0) {
        putstr("[PASS] read bad pointer (ret=");
        putdec(r);
        putstr(")\r\n");
    } else {
        putstr("[FAIL] read bad pointer returned ");
        putdec(r);
        putstr("\r\n");
        failures++;
    }

    /* 9. Pass a NULL user buffer to write */
    r = syscall(SYS_WRITE, FD_STDOUT, 0, 16);
    if (r < 0) {
        putstr("[PASS] write null buf (ret=");
        putdec(r);
        putstr(")\r\n");
    } else {
        putstr("[FAIL] write null buf returned ");
        putdec(r);
        putstr("\r\n");
        failures++;
    }

    /* Report */
    putstr("=== VFS Torture Summary: failures=");
    putdec(failures);
    putstr(" ===\r\n");

    syscall(SYS_EXIT, (failures > 0) ? 1 : 0, 0, 0);
}
