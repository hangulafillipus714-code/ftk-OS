/*
 * user/src/init.c — FTK OS PID 1 init process
 *
 * Boot sequence:
 *   1. Try to exec /bin/wm   (GUI window manager)
 *   2. Fall back to /bin/fsh (text shell)
 */
#define SYS_EXIT   0
#define SYS_WRITE  1
#define SYS_EXEC   7
#define FD_STDOUT  1

static long syscall(long nr,long a0,long a1,long a2)
{
    long ret;
    __asm__ volatile("syscall":"=a"(ret):"a"(nr),"D"(a0),"S"(a1),"d"(a2):"rcx","r11","memory");
    return ret;
}
static void putstr(const char *s){
    long len=0; while(s[len]) len++;
    syscall(SYS_WRITE,FD_STDOUT,(long)s,len);
}

void _start(void)
{
    putstr("INI\n");
    long rc = syscall(SYS_EXEC,(long)"/bin/wm",0,0);
    putstr("init: wm failed, falling back to fsh\n");
    rc = syscall(SYS_EXEC,(long)"/bin/fsh",0,0);
    putstr("init: fsh also failed\n");
    syscall(SYS_EXIT,(long)rc,0,0);
    for(;;);
}
