/* user/src/fsh.c — FTK OS User Shell (PATH-based) */

#define SYS_EXIT     0
#define SYS_WRITE    1
#define SYS_READ     2
#define SYS_GETPID   3
#define SYS_BRK      6
#define SYS_EXEC     7
#define SYS_READFILE 8
#define SYS_LISTDIR  9
#define SYS_OPEN     10
#define SYS_CLOSE    11
#define SYS_SPAWN    12
#define SYS_PS       13
#define SYS_WAITPID  14
#define SYS_GETDENTS 15
#define SYS_PIPE     16
#define SYS_DUP2     17
#define SYS_DEBUG    18
#define SYS_KILL     19

#define FD_STDIN   0
#define FD_STDOUT  1
#define FD_STDERR  2

#define LINE_MAX   256
#define ARGV_MAX   32
#define HISTORY_SIZE 32

typedef long s64;
typedef unsigned long long u64;

static char history[HISTORY_SIZE][LINE_MAX];
static int history_count = 0;
static int history_index = -1;

static int strcmp(const char *a, const char *b) {
    while (*a && *b && *a == *b) { a++; b++; }
    return (unsigned char)*a - (unsigned char)*b;
}

static char *strcpy(char *d, const char *s) {
    char *r = d;
    while ((*d++ = *s++));
    return r;
}

static int strln(const char *s) {
    int n = 0;
    while (s[n]) n++;
    return n;
}

static void history_save(const char *line) {
    if (line[0] == '\0') return;
    if (history_count > 0 && strcmp(line, history[history_count - 1]) == 0) return;
    if (history_count >= HISTORY_SIZE) {
        for (int i = 0; i < HISTORY_SIZE - 1; i++)
            strcpy(history[i], history[i + 1]);
        history_count = HISTORY_SIZE - 1;
    }
    strcpy(history[history_count], line);
    history[history_count][LINE_MAX - 1] = '\0';
    history_count++;
    history_index = -1;
}

static inline long syscall(long nr, long a0, long a1, long a2)
{
    long ret;
    __asm__ volatile("syscall"
        : "=a"(ret)
        : "a"(nr), "D"(a0), "S"(a1), "d"(a2)
        : "rcx", "r11", "memory");
    return ret;
}

static void putstr(const char *s)
{
    long len = 0;
    while (s[len]) len++;
    if (len > 0)
        syscall(SYS_WRITE, FD_STDOUT, (long)s, len);
}

static void putchar(char c)
{
    syscall(SYS_WRITE, FD_STDOUT, (long)&c, 1);
}

static int prev_input_len = 0;

static void redraw_input(const char *buf, int len, int cur)
{
    putstr("\rftk> ");
    if (len > 0)
        syscall(SYS_WRITE, FD_STDOUT, (long)buf, len);
    for (int i = len; i < prev_input_len; i++)
        putchar(' ');
    for (int i = len; i < prev_input_len; i++)
        putchar('\b');
    prev_input_len = len;
    for (int i = len; i > cur; i--)
        putchar('\b');
}

static void memmove_self(char *dst, const char *src, int n)
{
    if (dst <= src)
        { for (int i = 0; i < n; i++) dst[i] = src[i]; }
    else
        { for (int i = n - 1; i >= 0; i--) dst[i] = src[i]; }
}

static void history_load(int idx, char *buf, int *len, int *cur) {
    strcpy(buf, history[idx]);
    *len = strln(buf);
    *cur = *len;
    redraw_input(buf, *len, *cur);
}

static void shell_readline(char *buf, int maxlen)
{
    int len = 0, cur = 0;
    buf[0] = '\0';

    for (;;) {
        char c;
        long r = syscall(SYS_READ, FD_STDIN, (long)&c, 1);
        if (r != 1) continue;

        if (c == '\r' || c == '\n') {
            putstr("\r\n");
            buf[len] = '\0';
    history_save(buf);
            return;
        }

        if (c == '\b' || c == 0x7F) {
            if (cur == 0) continue;
            cur--; len--;
            memmove_self(&buf[cur], &buf[cur + 1], len - cur);
            buf[len] = '\0';
            redraw_input(buf, len, cur);
            continue;
        }

        if (c == '\x1b') {
            char seq[2];
            if (syscall(SYS_READ, FD_STDIN, (long)&seq[0], 1) != 1) continue;
            if (syscall(SYS_READ, FD_STDIN, (long)&seq[1], 1) != 1) continue;
            if (seq[0] == '[') {
                if (seq[1] == 'A') {
                    if (history_count == 0) continue;
                    if (history_index < 0)
                        history_index = history_count - 1;
                    else if (history_index > 0)
                        history_index--;
                    else
                        continue;
                    history_load(history_index, buf, &len, &cur);
                    continue;
                }
                if (seq[1] == 'B') {
                    if (history_index < 0) continue;
                    history_index++;
                    if (history_index >= history_count) {
                        history_index = -1;
                        len = 0; cur = 0; buf[0] = '\0';
                        redraw_input(buf, len, cur);
                    } else {
                        history_load(history_index, buf, &len, &cur);
                    }
                    continue;
                }
                if (seq[1] == 'D' && cur > 0) {
                    cur--;
                    { char bs = '\b'; syscall(SYS_WRITE, FD_STDOUT, (long)&bs, 1); }
                }
                if (seq[1] == 'C' && cur < len) {
                    char c = buf[cur];
                    cur++;
                    syscall(SYS_WRITE, FD_STDOUT, (long)&c, 1);
                }
            }
            continue;
        }

        if (c >= 0x20 && c < 0x7F && len < maxlen - 1) {
            history_index = -1;
            memmove_self(&buf[cur + 1], &buf[cur], len - cur);
            buf[cur++] = c;
            len++;
            buf[len] = '\0';
            redraw_input(buf, len, cur);
        }
    }
}

static void trim_line(char *line)
{
    int w = 0;
    for (int r = 0; line[r]; r++) {
        char c = line[r];
        if (c == ' ' || c == '\t' || (c >= 0x20 && c < 0x7F))
            line[w++] = c;
    }
    line[w] = '\0';
}

static int tokenize(char *line, char **argv, int max)
{
    trim_line(line);
    int argc = 0;
    while (*line) {
        while (*line == ' ' || *line == '\t') line++;
        if (!*line) break;
        argv[argc++] = line;
        if (argc >= max) break;
        while (*line && *line != ' ' && *line != '\t') line++;
        if (*line) *line++ = '\0';
    }
    return argc;
}

/* ── Built-in commands (shell-internal) ────────────────── */

typedef void (*cmd_handler_t)(int argc, char **argv);

static void cmd_help(int argc, char **argv)
{
    (void)argc; (void)argv;
    putstr("Commands:\n"
           "  help   - this help\n"
           "  clear  - clear screen\n"
           "  exit   - exit shell\n"
           "  exec   - <file> replace shell with program\n"
           "  spawn  - <file> [args...] run program\n"
           "  kill   - <pid> send kill signal to process\n\n"
           "Other commands are searched in /bin/\n");
}

static void cmd_clear(int argc, char **argv)
{
    (void)argc; (void)argv;
    for (int i = 0; i < 40; i++) putstr("\r\n");
}

static void cmd_exit(int argc, char **argv)
{
    (void)argc; (void)argv;
    putstr("Goodbye!\n");
    syscall(SYS_EXIT, 0, 0, 0);
}

static void cmd_exec(int argc, char **argv)
{
    if (argc < 2) {
        putstr("usage: exec <file>\n");
        return;
    }
    long ret = syscall(SYS_EXEC, (long)argv[1], 0, 0);
    if (ret < 0) {
        putstr("exec: failed to load ");
        putstr(argv[1]);
        putstr("\n");
    }
}

static void putdec(long v)
{
    char tmp[16];
    int ti = 15;
    tmp[15] = '\0';
    if (v == 0) { tmp[14] = '0'; putstr(tmp + 14); return; }
    if (v < 0) { putchar('-'); v = -v; }
    while (v > 0 && ti > 0) {
        tmp[--ti] = '0' + (v % 10);
        v /= 10;
    }
    putstr(tmp + ti);
}

static void cmd_spawn(int argc, char **argv)
{
    if (argc < 2) {
        putstr("usage: spawn <file> [args...]\n");
        return;
    }

    long child_argv[ARGV_MAX + 1];
    int nac = argc - 1;
    for (int i = 0; i < nac; i++)
        child_argv[i] = (long)argv[i + 1];
    child_argv[nac] = 0;

    long pid = syscall(SYS_SPAWN, (long)argv[1], (long)child_argv, 0);
    if (pid < 0) {
        putstr("spawn: failed\n");
        return;
    }

    putstr("[");
    putstr(argv[1]);
    putstr(" PID ");
    putdec(pid);
    putstr("]\n");

    int status;
    long ret = syscall(SYS_WAITPID, pid, (long)&status, 0);
    if (ret == pid) {
        putstr("[exit ");
        putdec(status);
        putstr("]\n");
    }
}

static int parse_pid(const char *s)
{
    int n = 0;
    while (*s >= '0' && *s <= '9') { n = n * 10 + (*s - '0'); s++; }
    return n;
}

static void cmd_kill(int argc, char **argv)
{
    if (argc < 2) { putstr("usage: kill <pid>\n"); return; }
    int pid = parse_pid(argv[1]);
    if (pid <= 0) { putstr("kill: invalid pid\n"); return; }
    long ret = syscall(SYS_KILL, pid, 0, 0);
    if (ret < 0) {
        putstr("kill: process ");
        putstr(argv[1]);
        putstr(" not found\n");
    }
}

/* ── Command lookup: built-in first, then PATH ──────── */

static cmd_handler_t lookup(const char *cmd)
{
    if (strcmp(cmd, "help")  == 0) return cmd_help;
    if (strcmp(cmd, "clear") == 0) return cmd_clear;
    if (strcmp(cmd, "exit")  == 0) return cmd_exit;
    if (strcmp(cmd, "exec")  == 0) return cmd_exec;
    if (strcmp(cmd, "spawn") == 0) return cmd_spawn;
    if (strcmp(cmd, "kill")  == 0) return cmd_kill;
    return 0;
}

/* Try to find and spawn a command from PATH directories.
 * Returns the PID on success, < 0 on failure. */
static long try_spawn_path(const char *cmd, long *child_argv)
{
    /* Search path: /bin/ */
    char full_path[256];
    int cmd_len = 0;
    while (cmd[cmd_len]) cmd_len++;

    /* Try /bin/<cmd> */
    strcpy(full_path, "/bin/");
    strcpy(full_path + 5, cmd);

    long pid = syscall(SYS_SPAWN, (long)full_path, (long)child_argv, 0);
    if (pid >= 0) return pid;

    return -1;
}

/* Resolve a command name to a full path (prepends /bin/ if no slash). */
static const char *resolve_cmd_path(const char *cmd, char *out, int out_size) {
    const char *p = cmd;
    while (*p) { if (*p == '/') { strcpy(out, cmd); return out; } p++; }
    int len = 0;
    while (cmd[len]) len++;
    if (5 + len + 1 > out_size) return cmd; /* fallback */
    strcpy(out, "/bin/");
    strcpy(out + 5, cmd);
    return out;
}

/* ── Pipe helper ──────────────────────────────────────── */

static long spawn_with_redirects(const char *path, long *child_argv,
                                 int in_fd, int out_fd)
{
    int saved_stdin = -1, saved_stdout = -1;
    if (in_fd >= 0) {
        saved_stdin = syscall(SYS_DUP2, 0, 10, 0);
        syscall(SYS_DUP2, in_fd, 0, 0);
    }
    if (out_fd >= 0) {
        saved_stdout = syscall(SYS_DUP2, 1, 11, 0);
        syscall(SYS_DUP2, out_fd, 1, 0);
    }

    long pid = syscall(SYS_SPAWN, (long)path, (long)child_argv, 0);

    if (in_fd >= 0 && saved_stdin >= 0) {
        syscall(SYS_DUP2, saved_stdin, 0, 0);
        syscall(SYS_CLOSE, saved_stdin, 0, 0);
    }
    if (out_fd >= 0 && saved_stdout >= 0) {
        syscall(SYS_DUP2, saved_stdout, 1, 0);
        syscall(SYS_CLOSE, saved_stdout, 0, 0);
    }
    return pid;
}

/* ── Entry point ──────────────────────────────────────── */

static int has_pipe(const char *line) {
    while (*line) {
        if (*line == '|') return 1;
        line++;
    }
    return 0;
}

void _start(void)
{
    putstr("INI\n");
    for (;;) {
        char line_buf[LINE_MAX] = {0};
        putstr("ftk> ");
        shell_readline(line_buf, LINE_MAX);

        if (line_buf[0] == '\0')
            continue;

        /* Handle pipes */
        if (has_pipe(line_buf)) {
            char *left = line_buf;
            char *right = 0;
            char *p = line_buf;
            while (*p) {
                if (*p == '|') {
                    *p = '\0';
                    right = p + 1;
                    break;
                }
                p++;
            }
            if (!right || !*right) {
                putstr("syntax error: incomplete pipe\n");
                continue;
            }
            char *left_argv[ARGV_MAX];
            int left_argc = tokenize(left, left_argv, ARGV_MAX);
            char *right_argv[ARGV_MAX];
            int right_argc = tokenize(right, right_argv, ARGV_MAX);
            if (left_argc == 0 || right_argc == 0) {
                putstr("syntax error\n");
                continue;
            }
            long left_args[ARGV_MAX + 1], right_args[ARGV_MAX + 1];
            for (int i = 0; i < left_argc; i++)
                left_args[i] = (long)left_argv[i];
            left_args[left_argc] = 0;
            for (int i = 0; i < right_argc; i++)
                right_args[i] = (long)right_argv[i];
            right_args[right_argc] = 0;

            int pipefd[2];
            if (syscall(SYS_PIPE, (long)pipefd, 0, 0) != 0) {
                putstr("pipe: failed\n");
                continue;
            }
            char left_path[256], right_path[256];
            resolve_cmd_path(left_argv[0], left_path, 256);
            resolve_cmd_path(right_argv[0], right_path, 256);
            long pid1 = spawn_with_redirects(left_path, left_args, -1, pipefd[1]);
            if (pid1 < 0) {
                putstr("Unknown command: ");
                putstr(left_argv[0]);
                putstr("\n");
                syscall(SYS_CLOSE, pipefd[0], 0, 0);
                syscall(SYS_CLOSE, pipefd[1], 0, 0);
                continue;
            }
            /* Close write end in parent so right child doesn't inherit it */
            syscall(SYS_CLOSE, pipefd[1], 0, 0);
            long pid2 = spawn_with_redirects(right_path, right_args, pipefd[0], -1);
            if (pid2 < 0) {
                putstr("Unknown command: ");
                putstr(right_argv[0]);
                putstr("\n");
                syscall(SYS_CLOSE, pipefd[0], 0, 0);
                syscall(SYS_WAITPID, pid1, 0, 0);
                continue;
            }
            syscall(SYS_CLOSE, pipefd[0], 0, 0);
            int status;
            syscall(SYS_WAITPID, pid1, (long)&status, 0);
            syscall(SYS_WAITPID, pid2, (long)&status, 0);
            continue;
        }

        char *argv[ARGV_MAX];
        int argc = tokenize(line_buf, argv, ARGV_MAX);
        if (argc == 0) continue;

        /* Check built-in commands first */
        cmd_handler_t handler = lookup(argv[0]);
        if (handler) {
            handler(argc, argv);
            continue;
        }

        /* Try PATH-based external command */
        long child_argv[ARGV_MAX + 1];
        for (int i = 0; i < argc; i++)
            child_argv[i] = (long)argv[i];
        child_argv[argc] = 0;

        long pid = try_spawn_path(argv[0], child_argv);
        if (pid < 0) {
            putstr("Unknown command: ");
            putstr(argv[0]);
            putstr("\n");
        } else {
            int status;
            syscall(SYS_WAITPID, pid, (long)&status, 0);
        }
    }
}
