#define SYS_EXIT     0
#define SYS_WRITE    1
#define SYS_OPEN     10
#define SYS_CLOSE    11
#define SYS_GETDENTS 15

#define FD_STDOUT 1

typedef struct {
    char name[256];
    unsigned int inode;
    unsigned int size;
    unsigned char attributes;
} ftk_dirent_t;

static long syscall(long nr, long a0, long a1, long a2) {
    long ret;
    __asm__ volatile("syscall"
        : "=a"(ret)
        : "a"(nr), "D"(a0), "S"(a1), "d"(a2)
        : "rcx", "r11", "memory");
    return ret;
}

static void putstr(const char *s) {
    long len = 0;
    while (s[len]) len++;
    if (len > 0)
        syscall(SYS_WRITE, FD_STDOUT, (long)s, len);
}

void _start(void) {
    long argc;
    char **argv;
    __asm__("mov %%rdi, %0\n\tmov %%rsi, %1" : "=r"(argc), "=r"(argv));

    const char *path = "/";
    if (argc > 1) path = argv[1];

    int fd = syscall(SYS_OPEN, (long)path, 0, 0);
    if (fd < 0) {
        putstr("ls: ");
        putstr(path);
        putstr(": failed\n");
        syscall(SYS_EXIT, 1, 0, 0);
    }

    ftk_dirent_t entry;
    long n;
    while ((n = syscall(SYS_GETDENTS, fd, (long)&entry, 1)) > 0) {
        putstr(entry.name);
        if (entry.attributes & 0x10)
            putstr("/");
        putstr("\n");
    }

    syscall(SYS_CLOSE, fd, 0, 0);
    syscall(SYS_EXIT, 0, 0, 0);
}
