/*
 * user/lib/gui.h — FTK OS user-space GUI library
 *
 * Provides:
 *   - Framebuffer access (mmap'd linear buffer)
 *   - 32-bit ARGB drawing primitives (rect, line, text, circle)
 *   - Window / widget abstraction (desktop compositor is single-process)
 *   - Event loop (keyboard + timer)
 *   - Font rendering (8×16 bitmap, same as kernel)
 *
 * Design constraints:
 *   - No dynamic linking: compiled as a static archive (libgui.a)
 *   - No FPU/SSE (kernel ABI forbids it in user space without xsave)
 *   - All coordinates are integer pixels
 *   - Colour format: 0x00RRGGBB (high byte ignored)
 */
#ifndef FTK_GUI_H
#define FTK_GUI_H

/* ── Syscall numbers (mirror of kernel ABI) ──────────────── */
#define SYS_EXIT        0
#define SYS_WRITE       1
#define SYS_READ        2
#define SYS_GETPID      3
#define SYS_SLEEP       4
#define SYS_YIELD       5
#define SYS_BRK         6
#define SYS_SPAWN       12
#define SYS_WAITPID     14
#define SYS_FB_INFO     20
#define SYS_FB_MAP      21
#define SYS_FB_FLUSH    22
#define SYS_GETTICKS    23
#define SYS_GETKEY      24
#define SYS_MMAP        25
#define SYS_GETTIME     28

/* ── Key event constants ─────────────────────────────────── */
#define FTK_KEY_PRESS   1
#define FTK_KEY_RELEASE 0
#define FTK_KEY_UP      0x100
#define FTK_KEY_DOWN    0x101
#define FTK_KEY_LEFT    0x102
#define FTK_KEY_RIGHT   0x103
#define FTK_KEY_F1      0x111
#define FTK_KEY_F2      0x112
#define FTK_KEY_F3      0x113
#define FTK_KEY_F4      0x114
#define FTK_KEY_F5      0x115
#define FTK_KEY_F10     0x11A
#define FTK_KEY_HOME    0x120
#define FTK_KEY_END     0x121
#define FTK_KEY_PGUP    0x122
#define FTK_KEY_PGDN    0x123
#define FTK_KEY_DEL     0x124
#define FTK_KEY_ESC     0x1B
#define FTK_KEY_TAB     0x09
#define FTK_KEY_ENTER   0x0D
#define FTK_KEY_BKSP    0x08
#define FTK_MOD_SHIFT   (1<<0)
#define FTK_MOD_CTRL    (1<<1)
#define FTK_MOD_ALT     (1<<2)

/* ── Basic types ─────────────────────────────────────────── */
typedef unsigned int       u32;
typedef unsigned long long u64;
typedef long               ssize_t;
typedef unsigned long      size_t;

#define NULL ((void*)0)

/* ── Structures ──────────────────────────────────────────── */
typedef struct {
    unsigned int  width;
    unsigned int  height;
    unsigned int  pitch;
    unsigned int  bpp;
    unsigned long phys_base;
} ftk_fb_info_t;

typedef struct {
    int type;
    int keycode;
    int modifiers;
} ftk_key_event_t;

typedef struct {
    int year, month, day;
    int hour, minute, second;
} ftk_time_t;

typedef struct {
    int x, y, w, h;
} ftk_rect_t;

/* ── Colours ─────────────────────────────────────────────── */
#define RGB(r,g,b)   (((u32)(r)<<16)|((u32)(g)<<8)|(u32)(b))
#define COL_BLACK    0x000000u
#define COL_WHITE    0xFFFFFFu
#define COL_RED      0xFF3333u
#define COL_GREEN    0x33FF66u
#define COL_BLUE     0x3366FFu
#define COL_CYAN     0x00CCFFu
#define COL_YELLOW   0xFFEE00u
#define COL_ORANGE   0xFF8800u
#define COL_GRAY     0x808080u
#define COL_LGRAY    0xC8C8C8u
#define COL_DGRAY    0x404040u
#define COL_DARKBLUE 0x003366u

/* Desktop / widget palette */
#define COL_DESKTOP   0x1A1A2E  /* deep navy */
#define COL_TASKBAR   0x16213E
#define COL_WIN_TITLE 0x0F3460
#define COL_WIN_BODY  0x1F2041
#define COL_WIN_BORD  0x533483
#define COL_BTN_NORM  0x4A4E69
#define COL_BTN_HOT   0x9A8C98
#define COL_BTN_PRESS 0xC9ADA7
#define COL_TEXT      0xF2E9E4
#define COL_TEXT_DIM  0x9A8C98
#define COL_ACCENT    0x7B2D8B
#define COL_CURSOR    0xFF6B35

/* ── Syscall wrapper ─────────────────────────────────────── */
static inline long _sc(long nr,long a,long b,long c){
    long r;
    __asm__ volatile("syscall":"=a"(r):"a"(nr),"D"(a),"S"(b),"d"(c):"rcx","r11","memory");
    return r;
}

/* ── Framebuffer globals ─────────────────────────────────── */
extern u32 *gui_fb;
extern unsigned int gui_fb_w;
extern unsigned int gui_fb_h;
extern unsigned int gui_fb_pitch4; /* pitch / 4 (u32 stride) */

/* ── Init / teardown ─────────────────────────────────────── */
int  gui_init(void);
void gui_exit(void);

/* ── Ticks & time ────────────────────────────────────────── */
u64  gui_ticks(void);
void gui_sleep_ticks(u64 t);
int  gui_gettime(ftk_time_t *t);

/* ── Key events ──────────────────────────────────────────── */
int  gui_poll_key(ftk_key_event_t *ev);  /* non-blocking, returns 1 if got event */

/* ── Drawing primitives ──────────────────────────────────── */
void gui_clear(u32 col);
void gui_fill_rect(int x,int y,int w,int h,u32 col);
void gui_draw_rect(int x,int y,int w,int h,u32 col);
void gui_draw_hline(int x,int y,int w,u32 col);
void gui_draw_vline(int x,int y,int h,u32 col);
void gui_draw_line(int x0,int y0,int x1,int y1,u32 col);
void gui_draw_circle(int cx,int cy,int r,u32 col);
void gui_fill_circle(int cx,int cy,int r,u32 col);
void gui_put_pixel(int x,int y,u32 col);

/* ── Text rendering (8×16 bitmapped font) ────────────────── */
void gui_draw_char(int x,int y,char c,u32 fg,u32 bg);
void gui_draw_str(int x,int y,const char *s,u32 fg,u32 bg);
void gui_draw_str_transp(int x,int y,const char *s,u32 fg); /* no bg */
int  gui_str_width(const char *s);   /* pixels */

/* ── Widget helpers ──────────────────────────────────────── */
/* Raised 3-D button */
void gui_draw_button(int x,int y,int w,int h,const char *label,int pressed);
/* Flat card panel */
void gui_draw_panel(int x,int y,int w,int h,u32 bg,u32 border);
/* Window chrome (title bar + body) */
void gui_draw_window(int x,int y,int w,int h,const char *title,int focused);
/* Vertical scroll bar */
void gui_draw_scrollbar(int x,int y,int h,int pos,int max);
/* Progress bar */
void gui_draw_progress(int x,int y,int w,int h,int pct,u32 fg,u32 bg);
/* Text input field */
void gui_draw_input(int x,int y,int w,const char *text,int cur,int focused);
/* Desktop taskbar (bottom strip) */
void gui_draw_taskbar(const char *app_name);

/* ── String helpers (no libc) ────────────────────────────── */
int  gui_strlen(const char *s);
void gui_strcpy(char *d,const char *s);
int  gui_strcmp(const char *a,const char *b);
void gui_itoa(long v,char *buf,int base);
void gui_ltoa(long long v,char *buf);
void gui_memset(void *p,int c,size_t n);
void gui_memcpy(void *d,const void *s,size_t n);
int  gui_isdigit(int c);
int  gui_atoi(const char *s);

#endif /* FTK_GUI_H */
