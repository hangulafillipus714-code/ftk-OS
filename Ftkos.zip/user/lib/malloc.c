#include "libc.h"

#define HEAP_START 0x40000000UL
#define CHUNK_SIZE 16

typedef struct mhdr {
    unsigned long size;
    int used;
    struct mhdr *next;
} mhdr_t;

static mhdr_t *heap_root = 0;
static unsigned long heap_brk = HEAP_START;

static void *morecore(unsigned long size) {
    unsigned long req = (size + 4095) & ~4095;
    unsigned long old = __syscall(SYS_BRK, 0, 0, 0);
    if (old == 0) {
        __syscall(SYS_BRK, HEAP_START, 0, 0);
        old = HEAP_START;
        heap_brk = HEAP_START;
    }
    unsigned long new_brk = heap_brk + req;
    unsigned long ret = __syscall(SYS_BRK, new_brk, 0, 0);
    if (ret != (long)new_brk) return 0;
    heap_brk = new_brk;
    return (void*)old;
}

void *malloc(unsigned long size) {
    if (size == 0) return 0;
    size = (size + CHUNK_SIZE - 1) & ~(CHUNK_SIZE - 1);
    if (size < CHUNK_SIZE) size = CHUNK_SIZE;

    if (!heap_root) {
        mhdr_t *h = morecore(4096);
        if (!h) return 0;
        h->size = 4096 - sizeof(mhdr_t);
        h->used = 0;
        h->next = 0;
        heap_root = h;
    }

    mhdr_t *best = 0;
    mhdr_t *h = heap_root;
    while (h) {
        if (!h->used && h->size >= size) {
            if (!best || h->size < best->size)
                best = h;
        }
        h = h->next;
    }

    if (!best) {
        unsigned long needed = size + sizeof(mhdr_t) + 4096;
        mhdr_t *h = morecore(needed);
        if (!h) return 0;
        h->size = needed - sizeof(mhdr_t);
        h->used = 0;
        h->next = heap_root;
        heap_root = h;
        best = h;
    }

    if (best->size >= size + sizeof(mhdr_t) + CHUNK_SIZE) {
        mhdr_t *new_h = (mhdr_t*)((char*)best + sizeof(mhdr_t) + size);
        new_h->size = best->size - size - sizeof(mhdr_t);
        new_h->used = 0;
        new_h->next = best->next;
        best->next = new_h;
        best->size = size;
    }

    best->used = 1;
    return (void*)((char*)best + sizeof(mhdr_t));
}

void free(void *ptr) {
    if (!ptr) return;
    mhdr_t *h = (mhdr_t*)((char*)ptr - sizeof(mhdr_t));
    h->used = 0;
    /* Coalesce with next */
    if (h->next && !h->next->used) {
        h->size += sizeof(mhdr_t) + h->next->size;
        h->next = h->next->next;
    }
}

void exit(int status) {
    __syscall(SYS_EXIT, status, 0, 0);
    for (;;) {}
}
