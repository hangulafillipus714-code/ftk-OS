#include "libc.h"

int putchar(int c) {
    char ch = (char)c;
    __syscall(SYS_WRITE, FD_STDOUT, (long)&ch, 1);
    return c;
}

int puts(const char *s) {
    unsigned long len = 0;
    while (s[len]) len++;
    if (len > 0)
        __syscall(SYS_WRITE, FD_STDOUT, (long)s, len);
    __syscall(SYS_WRITE, FD_STDOUT, (long)"\n", 1);
    return (int)len + 1;
}

static void print_dec(unsigned long val, int *count) {
    char buf[20];
    int i = 19;
    buf[i] = '\0';
    if (val == 0) { buf[--i] = '0'; }
    while (val > 0 && i > 0) {
        buf[--i] = '0' + (val % 10);
        val /= 10;
    }
    __syscall(SYS_WRITE, FD_STDOUT, (long)(buf + i), 19 - i);
    *count += 19 - i;
}

static void print_hex(unsigned long val, int *count) {
    char buf[18];
    int i = 17;
    buf[i] = '\0';
    if (val == 0) { buf[--i] = '0'; }
    while (val > 0 && i > 0) {
        int d = val % 16;
        buf[--i] = d < 10 ? '0' + d : 'a' + d - 10;
        val /= 16;
    }
    buf[--i] = 'x';
    buf[--i] = '0';
    __syscall(SYS_WRITE, FD_STDOUT, (long)(buf + i), 17 - i);
    *count += 17 - i;
}

static void print_str(const char *s, int *count) {
    if (!s) s = "(null)";
    unsigned long len = 0;
    while (s[len]) len++;
    if (len > 0)
        __syscall(SYS_WRITE, FD_STDOUT, (long)s, len);
    *count += (int)len;
}

int printf(const char *fmt, ...) {
    int count = 0;
    const char *p = fmt;
    __builtin_va_list args;
    __builtin_va_start(args, fmt);

    while (*p) {
        if (*p != '%') {
            char c = *p;
            __syscall(SYS_WRITE, FD_STDOUT, (long)&c, 1);
            count++;
            p++;
            continue;
        }
        p++;
        if (*p == '\0') break;

        int lflag = 0;
        if (*p == 'l') { lflag = 1; p++; }

        if (*p == 'd' || *p == 'i') {
            long val = lflag ? __builtin_va_arg(args, long) : (long)__builtin_va_arg(args, int);
            if (val < 0) {
                __syscall(SYS_WRITE, FD_STDOUT, (long)"-", 1);
                count++;
                val = -val;
            }
            print_dec((unsigned long)val, &count);
        } else if (*p == 'u') {
            unsigned long val = lflag ? __builtin_va_arg(args, unsigned long) : (unsigned long)__builtin_va_arg(args, unsigned int);
            print_dec(val, &count);
        } else if (*p == 'x' || *p == 'p') {
            unsigned long val = (unsigned long)__builtin_va_arg(args, void*);
            print_hex(val, &count);
        } else if (*p == 's') {
            print_str(__builtin_va_arg(args, const char*), &count);
        } else if (*p == 'c') {
            char c = (char)__builtin_va_arg(args, int);
            __syscall(SYS_WRITE, FD_STDOUT, (long)&c, 1);
            count++;
        } else if (*p == '%') {
            __syscall(SYS_WRITE, FD_STDOUT, (long)"%", 1);
            count++;
        }
        p++;
    }

    __builtin_va_end(args);
    return count;
}
