/*
 * user/lib/gui.c — FTK OS GUI library implementation
 *
 * Everything compiles freestanding (no libc, no SSE).
 * Font data is the same 8×16 bitmap table used by the kernel.
 */
#include "gui.h"

/* ── Font data (8×16, CP437 compatible) ──────────────────── */
/* Embedded mini-font: printable ASCII 32-126 only to keep size down. */
/* Each char: 16 bytes, one per row, MSB = leftmost pixel.            */
static const unsigned char gui_font[128][16] = {
    /* 0x00-0x1F: control chars — blank */
    [0 ... 31] = {0},
    /* Space */ [32]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    /* ! */  [33]={0,0,24,24,24,24,24,24,0,24,24,0,0,0,0,0},
    /* " */  [34]={0,0,108,108,108,0,0,0,0,0,0,0,0,0,0,0},
    /* # */  [35]={0,0,108,108,254,108,108,254,108,108,0,0,0,0,0,0},
    /* $ */  [36]={0,24,62,96,96,60,6,6,124,24,0,0,0,0,0,0},
    /* % */  [37]={0,0,98,102,12,24,48,102,70,0,0,0,0,0,0,0},
    /* & */  [38]={0,0,56,108,108,56,118,220,204,118,0,0,0,0,0,0},
    /* ' */  [39]={0,0,24,24,24,0,0,0,0,0,0,0,0,0,0,0},
    /* ( */  [40]={0,0,12,24,48,48,48,48,24,12,0,0,0,0,0,0},
    /* ) */  [41]={0,0,48,24,12,12,12,12,24,48,0,0,0,0,0,0},
    /* * */  [42]={0,0,0,102,60,255,60,102,0,0,0,0,0,0,0,0},
    /* + */  [43]={0,0,0,24,24,126,24,24,0,0,0,0,0,0,0,0},
    /* , */  [44]={0,0,0,0,0,0,0,0,24,24,48,0,0,0,0,0},
    /* - */  [45]={0,0,0,0,0,126,0,0,0,0,0,0,0,0,0,0},
    /* . */  [46]={0,0,0,0,0,0,0,0,24,24,0,0,0,0,0,0},
    /* / */  [47]={0,0,6,6,12,24,48,96,96,0,0,0,0,0,0,0},
    /* 0 */  [48]={0,0,60,102,110,118,102,102,60,0,0,0,0,0,0,0},
    /* 1 */  [49]={0,0,24,56,24,24,24,24,126,0,0,0,0,0,0,0},
    /* 2 */  [50]={0,0,60,102,6,12,48,96,126,0,0,0,0,0,0,0},
    /* 3 */  [51]={0,0,60,102,6,28,6,102,60,0,0,0,0,0,0,0},
    /* 4 */  [52]={0,0,14,30,54,102,127,6,6,0,0,0,0,0,0,0},
    /* 5 */  [53]={0,0,126,96,124,6,6,102,60,0,0,0,0,0,0,0},
    /* 6 */  [54]={0,0,28,48,96,124,102,102,60,0,0,0,0,0,0,0},
    /* 7 */  [55]={0,0,126,6,6,12,24,24,24,0,0,0,0,0,0,0},
    /* 8 */  [56]={0,0,60,102,102,60,102,102,60,0,0,0,0,0,0,0},
    /* 9 */  [57]={0,0,60,102,102,62,6,12,56,0,0,0,0,0,0,0},
    /* : */  [58]={0,0,0,24,24,0,0,24,24,0,0,0,0,0,0,0},
    /* ; */  [59]={0,0,0,24,24,0,0,24,24,48,0,0,0,0,0,0},
    /* < */  [60]={0,0,14,28,56,112,56,28,14,0,0,0,0,0,0,0},
    /* = */  [61]={0,0,0,0,126,0,126,0,0,0,0,0,0,0,0,0},
    /* > */  [62]={0,0,112,56,28,14,28,56,112,0,0,0,0,0,0,0},
    /* ? */  [63]={0,0,60,102,6,12,24,0,24,0,0,0,0,0,0,0},
    /* @ */  [64]={0,0,60,102,110,106,110,96,60,0,0,0,0,0,0,0},
    /* A */  [65]={0,0,24,60,102,102,126,102,102,0,0,0,0,0,0,0},
    /* B */  [66]={0,0,124,102,102,124,102,102,124,0,0,0,0,0,0,0},
    /* C */  [67]={0,0,60,102,96,96,96,102,60,0,0,0,0,0,0,0},
    /* D */  [68]={0,0,120,108,102,102,102,108,120,0,0,0,0,0,0,0},
    /* E */  [69]={0,0,126,96,96,120,96,96,126,0,0,0,0,0,0,0},
    /* F */  [70]={0,0,126,96,96,120,96,96,96,0,0,0,0,0,0,0},
    /* G */  [71]={0,0,60,102,96,110,102,102,60,0,0,0,0,0,0,0},
    /* H */  [72]={0,0,102,102,102,126,102,102,102,0,0,0,0,0,0,0},
    /* I */  [73]={0,0,126,24,24,24,24,24,126,0,0,0,0,0,0,0},
    /* J */  [74]={0,0,62,12,12,12,12,108,56,0,0,0,0,0,0,0},
    /* K */  [75]={0,0,102,108,120,112,120,108,102,0,0,0,0,0,0,0},
    /* L */  [76]={0,0,96,96,96,96,96,96,126,0,0,0,0,0,0,0},
    /* M */  [77]={0,0,99,119,127,107,99,99,99,0,0,0,0,0,0,0},
    /* N */  [78]={0,0,102,118,126,126,110,102,102,0,0,0,0,0,0,0},
    /* O */  [79]={0,0,60,102,102,102,102,102,60,0,0,0,0,0,0,0},
    /* P */  [80]={0,0,124,102,102,124,96,96,96,0,0,0,0,0,0,0},
    /* Q */  [81]={0,0,60,102,102,102,102,108,54,0,0,0,0,0,0,0},
    /* R */  [82]={0,0,124,102,102,124,108,102,102,0,0,0,0,0,0,0},
    /* S */  [83]={0,0,60,102,96,60,6,102,60,0,0,0,0,0,0,0},
    /* T */  [84]={0,0,126,24,24,24,24,24,24,0,0,0,0,0,0,0},
    /* U */  [85]={0,0,102,102,102,102,102,102,60,0,0,0,0,0,0,0},
    /* V */  [86]={0,0,102,102,102,102,102,60,24,0,0,0,0,0,0,0},
    /* W */  [87]={0,0,99,99,99,107,127,119,99,0,0,0,0,0,0,0},
    /* X */  [88]={0,0,102,102,60,24,60,102,102,0,0,0,0,0,0,0},
    /* Y */  [89]={0,0,102,102,102,60,24,24,24,0,0,0,0,0,0,0},
    /* Z */  [90]={0,0,126,6,12,24,48,96,126,0,0,0,0,0,0,0},
    /* [ */  [91]={0,0,62,48,48,48,48,48,62,0,0,0,0,0,0,0},
    /* \ */  [92]={0,0,96,96,48,24,12,6,6,0,0,0,0,0,0,0},
    /* ] */  [93]={0,0,124,12,12,12,12,12,124,0,0,0,0,0,0,0},
    /* ^ */  [94]={0,0,24,60,102,0,0,0,0,0,0,0,0,0,0,0},
    /* _ */  [95]={0,0,0,0,0,0,0,0,0,126,0,0,0,0,0,0},
    /* ` */  [96]={0,0,24,24,12,0,0,0,0,0,0,0,0,0,0,0},
    /* a */  [97]={0,0,0,0,60,6,62,102,62,0,0,0,0,0,0,0},
    /* b */  [98]={0,0,96,96,124,102,102,102,124,0,0,0,0,0,0,0},
    /* c */  [99]={0,0,0,0,60,102,96,102,60,0,0,0,0,0,0,0},
    /* d */  [100]={0,0,6,6,62,102,102,102,62,0,0,0,0,0,0,0},
    /* e */  [101]={0,0,0,0,60,102,126,96,60,0,0,0,0,0,0,0},
    /* f */  [102]={0,0,28,48,126,48,48,48,48,0,0,0,0,0,0,0},
    /* g */  [103]={0,0,0,0,62,102,102,62,6,60,0,0,0,0,0,0},
    /* h */  [104]={0,0,96,96,124,102,102,102,102,0,0,0,0,0,0,0},
    /* i */  [105]={0,0,24,0,56,24,24,24,60,0,0,0,0,0,0,0},
    /* j */  [106]={0,0,12,0,28,12,12,12,108,56,0,0,0,0,0,0},
    /* k */  [107]={0,0,96,96,102,108,120,108,102,0,0,0,0,0,0,0},
    /* l */  [108]={0,0,56,24,24,24,24,24,60,0,0,0,0,0,0,0},
    /* m */  [109]={0,0,0,0,102,127,127,107,99,0,0,0,0,0,0,0},
    /* n */  [110]={0,0,0,0,124,102,102,102,102,0,0,0,0,0,0,0},
    /* o */  [111]={0,0,0,0,60,102,102,102,60,0,0,0,0,0,0,0},
    /* p */  [112]={0,0,0,0,124,102,102,124,96,96,0,0,0,0,0,0},
    /* q */  [113]={0,0,0,0,62,102,102,62,6,6,0,0,0,0,0,0},
    /* r */  [114]={0,0,0,0,110,120,96,96,96,0,0,0,0,0,0,0},
    /* s */  [115]={0,0,0,0,60,96,60,6,124,0,0,0,0,0,0,0},
    /* t */  [116]={0,0,24,24,126,24,24,24,14,0,0,0,0,0,0,0},
    /* u */  [117]={0,0,0,0,102,102,102,102,62,0,0,0,0,0,0,0},
    /* v */  [118]={0,0,0,0,102,102,102,60,24,0,0,0,0,0,0,0},
    /* w */  [119]={0,0,0,0,99,107,127,119,99,0,0,0,0,0,0,0},
    /* x */  [120]={0,0,0,0,102,60,24,60,102,0,0,0,0,0,0,0},
    /* y */  [121]={0,0,0,0,102,102,62,6,60,0,0,0,0,0,0,0},
    /* z */  [122]={0,0,0,0,126,12,24,48,126,0,0,0,0,0,0,0},
    /* { */  [123]={0,0,14,24,24,112,24,24,14,0,0,0,0,0,0,0},
    /* | */  [124]={0,0,24,24,24,0,24,24,24,0,0,0,0,0,0,0},
    /* } */  [125]={0,0,112,24,24,14,24,24,112,0,0,0,0,0,0,0},
    /* ~ */  [126]={0,0,118,220,0,0,0,0,0,0,0,0,0,0,0,0},
};

/* ── Framebuffer globals ─────────────────────────────────── */
u32 *gui_fb       = 0;
unsigned int gui_fb_w     = 0;
unsigned int gui_fb_h     = 0;
unsigned int gui_fb_pitch4= 0;

/* ── String helpers ──────────────────────────────────────── */
int gui_strlen(const char *s){ int n=0; while(s[n]) n++; return n; }
void gui_strcpy(char *d,const char *s){ while((*d++=*s++)); }
int  gui_strcmp(const char *a,const char *b){
    while(*a&&*b&&*a==*b){a++;b++;}return (unsigned char)*a-(unsigned char)*b;
}
void gui_memset(void *p,int c,size_t n){
    unsigned char *q=p; while(n--)*q++=(unsigned char)c;
}
void gui_memcpy(void *d,const void *s,size_t n){
    unsigned char *dd=d; const unsigned char *ss=s; while(n--)*dd++=*ss++;
}
int gui_isdigit(int c){ return c>='0'&&c<='9'; }
int gui_atoi(const char *s){
    int r=0,neg=0;
    if(*s=='-'){neg=1;s++;}
    while(gui_isdigit(*s)) r=r*10+(*s++-'0');
    return neg?-r:r;
}
void gui_itoa(long v,char *buf,int base){
    char tmp[32]; int i=0; long u=v<0?-v:v;
    if(u==0){buf[0]='0';buf[1]=0;return;}
    while(u){tmp[i++]="0123456789ABCDEF"[u%base];u/=base;}
    if(v<0)tmp[i++]='-';
    int j=0; while(i--)buf[j++]=tmp[i]; buf[j]=0;
}
void gui_ltoa(long long v,char *buf){
    char tmp[32]; int i=0; long long u=v<0?-v:v;
    if(u==0){buf[0]='0';buf[1]=0;return;}
    while(u){tmp[i++]='0'+u%10;u/=10;}
    if(v<0)tmp[i++]='-';
    int j=0; while(i--)buf[j++]=tmp[i]; buf[j]=0;
}

/* ── GUI init / exit ─────────────────────────────────────── */
int gui_init(void)
{
    ftk_fb_info_t info;
    if (_sc(SYS_FB_INFO,(long)&info,0,0) != 0) return -1;
    long uva = _sc(SYS_FB_MAP,0,0,0);
    if (uva < 0) return -2;
    gui_fb       = (u32 *)(unsigned long)uva;
    gui_fb_w     = info.width;
    gui_fb_h     = info.height;
    gui_fb_pitch4= info.pitch / 4;
    return 0;
}
void gui_exit(void){ _sc(SYS_EXIT,0,0,0); }

/* ── Ticks / time ────────────────────────────────────────── */
u64 gui_ticks(void){ return (u64)_sc(SYS_GETTICKS,0,0,0); }
void gui_sleep_ticks(u64 t){ _sc(SYS_SLEEP,(long)t,0,0); }
int  gui_gettime(ftk_time_t *t){ return (int)_sc(SYS_GETTIME,(long)t,0,0); }

/* ── Key events ──────────────────────────────────────────── */
int gui_poll_key(ftk_key_event_t *ev)
{
    long r; long nr=SYS_GETKEY;
    __asm__ volatile("syscall":"=a"(r):"a"(nr),"D"((long)ev),"S"(0),"d"(0):"rcx","r11","memory");
    return (int)r;
}

/* ── Drawing primitives ──────────────────────────────────── */
void gui_put_pixel(int x,int y,u32 col){
    if((unsigned)x>=gui_fb_w||(unsigned)y>=gui_fb_h) return;
    gui_fb[(unsigned)y*gui_fb_pitch4+(unsigned)x]=col;
}
void gui_clear(u32 col){
    unsigned int tot=gui_fb_pitch4*gui_fb_h;
    for(unsigned int i=0;i<tot;i++) gui_fb[i]=col;
}
void gui_fill_rect(int x,int y,int w,int h,u32 col){
    if(x<0){w+=x;x=0;} if(y<0){h+=y;y=0;}
    if(w<=0||h<=0) return;
    int x2=x+w, y2=y+h;
    if(x2>(int)gui_fb_w) x2=gui_fb_w;
    if(y2>(int)gui_fb_h) y2=gui_fb_h;
    for(int row=y;row<y2;row++){
        u32 *p=gui_fb+row*gui_fb_pitch4+x;
        for(int px=x;px<x2;px++) *p++=col;
    }
}
void gui_draw_hline(int x,int y,int w,u32 col){
    gui_fill_rect(x,y,w,1,col);
}
void gui_draw_vline(int x,int y,int h,u32 col){
    gui_fill_rect(x,y,1,h,col);
}
void gui_draw_rect(int x,int y,int w,int h,u32 col){
    gui_draw_hline(x,y,w,col);
    gui_draw_hline(x,y+h-1,w,col);
    gui_draw_vline(x,y,h,col);
    gui_draw_vline(x+w-1,y,h,col);
}
void gui_draw_line(int x0,int y0,int x1,int y1,u32 col){
    int dx=x1-x0; if(dx<0)dx=-dx;
    int dy=y1-y0; if(dy<0)dy=-dy;
    int sx=x0<x1?1:-1, sy=y0<y1?1:-1;
    int err=dx-dy;
    for(;;){
        gui_put_pixel(x0,y0,col);
        if(x0==x1&&y0==y1) break;
        int e2=err*2;
        if(e2>-dy){err-=dy;x0+=sx;}
        if(e2< dx){err+=dx;y0+=sy;}
    }
}
void gui_draw_circle(int cx,int cy,int r,u32 col){
    int x=0,y=r,d=3-2*r;
    while(y>=x){
        gui_put_pixel(cx+x,cy+y,col); gui_put_pixel(cx-x,cy+y,col);
        gui_put_pixel(cx+x,cy-y,col); gui_put_pixel(cx-x,cy-y,col);
        gui_put_pixel(cx+y,cy+x,col); gui_put_pixel(cx-y,cy+x,col);
        gui_put_pixel(cx+y,cy-x,col); gui_put_pixel(cx-y,cy-x,col);
        if(d<0) d+=4*x+6; else { d+=4*(x-y)+10; y--; }
        x++;
    }
}
void gui_fill_circle(int cx,int cy,int r,u32 col){
    for(int y=-r;y<=r;y++)
        for(int x=-r;x<=r;x++)
            if(x*x+y*y<=r*r)
                gui_put_pixel(cx+x,cy+y,col);
}

/* ── Text rendering ──────────────────────────────────────── */
void gui_draw_char(int x,int y,char c,u32 fg,u32 bg){
    unsigned char idx=(unsigned char)c;
    if(idx>127) idx=0;
    for(int row=0;row<16;row++){
        unsigned char bits=gui_font[idx][row];
        for(int col=0;col<8;col++){
            u32 pix=(bits&(0x80>>col))?fg:bg;
            gui_put_pixel(x+col,y+row,pix);
        }
    }
}
void gui_draw_str(int x,int y,const char *s,u32 fg,u32 bg){
    while(*s){ gui_draw_char(x,y,*s,fg,bg); x+=8; s++; }
}
void gui_draw_str_transp(int x,int y,const char *s,u32 fg){
    while(*s){
        unsigned char idx=(unsigned char)*s; if(idx>127)idx=0;
        for(int row=0;row<16;row++){
            unsigned char bits=gui_font[idx][row];
            for(int col=0;col<8;col++)
                if(bits&(0x80>>col)) gui_put_pixel(x+col,y+row,fg);
        }
        x+=8; s++;
    }
}
int gui_str_width(const char *s){ return gui_strlen(s)*8; }

/* ── Widget helpers ──────────────────────────────────────── */

void gui_draw_panel(int x,int y,int w,int h,u32 bg,u32 border){
    gui_fill_rect(x,y,w,h,bg);
    gui_draw_rect(x,y,w,h,border);
}

void gui_draw_button(int x,int y,int w,int h,const char *label,int pressed){
    u32 top,bot,face;
    if(pressed){ top=0x222222;bot=0xAAAAAA;face=COL_BTN_PRESS; }
    else       { top=0xAAAAAA;bot=0x222222;face=COL_BTN_NORM;  }
    gui_fill_rect(x,y,w,h,face);
    gui_draw_hline(x,y,w,top);
    gui_draw_vline(x,y,h,top);
    gui_draw_hline(x,y+h-1,w,bot);
    gui_draw_vline(x+w-1,y,h,bot);
    int tw=gui_str_width(label);
    int tx=x+(w-tw)/2, ty=y+(h-16)/2;
    gui_draw_str(tx,ty,label,COL_TEXT,face);
}

void gui_draw_window(int x,int y,int w,int h,const char *title,int focused){
    /* Shadow */
    gui_fill_rect(x+4,y+4,w,h,0x000000);
    /* Title bar */
    u32 tb=focused?COL_WIN_TITLE:COL_DGRAY;
    gui_fill_rect(x,y,w,20,tb);
    /* Title text */
    gui_draw_str_transp(x+6,y+2,title,COL_TEXT);
    /* Close button */
    gui_fill_rect(x+w-18,y+2,16,16,0xBB2222);
    gui_draw_str(x+w-14,y+2,"X",COL_WHITE,0xBB2222);
    /* Body */
    gui_fill_rect(x,y+20,w,h-20,COL_WIN_BODY);
    /* Border */
    gui_draw_rect(x,y,w,h,COL_WIN_BORD);
}

void gui_draw_scrollbar(int x,int y,int h,int pos,int max){
    gui_fill_rect(x,y,10,h,COL_DGRAY);
    if(max>0){
        int th=h*10/(max>10?max:10); if(th<8)th=8;
        int ty=y+(h-th)*pos/(max>1?max:1);
        gui_fill_rect(x+1,ty,8,th,COL_BTN_HOT);
    }
}

void gui_draw_progress(int x,int y,int w,int h,int pct,u32 fg,u32 bg){
    gui_fill_rect(x,y,w,h,bg);
    int fw=w*pct/100; if(fw>0) gui_fill_rect(x,y,fw,h,fg);
    gui_draw_rect(x,y,w,h,COL_GRAY);
}

void gui_draw_input(int x,int y,int w,const char *text,int cur,int focused){
    u32 border=focused?COL_ACCENT:COL_GRAY;
    gui_fill_rect(x,y,w,18,0x0A0A1E);
    gui_draw_rect(x,y,w,18,border);
    gui_draw_str(x+3,y+1,text,COL_TEXT,0x0A0A1E);
    if(focused){
        int cx=x+3+cur*8;
        gui_draw_vline(cx,y+2,14,COL_CURSOR);
    }
}

void gui_draw_taskbar(const char *app_name){
    int W=(int)gui_fb_w, H=(int)gui_fb_h;
    gui_fill_rect(0,H-24,W,24,COL_TASKBAR);
    gui_draw_hline(0,H-24,W,COL_WIN_BORD);
    /* FTK logo button */
    gui_fill_rect(0,H-24,56,24,COL_WIN_TITLE);
    gui_draw_str(6,H-20,"FTK OS",COL_TEXT,COL_WIN_TITLE);
    /* Active app label */
    if(app_name && app_name[0])
        gui_draw_str(70,H-20,app_name,COL_TEXT,COL_TASKBAR);
    /* Clock placeholder on right */
    ftk_time_t t;
    if(_sc(SYS_GETTIME,(long)&t,0,0)==0){
        char buf[16];
        char *p=buf;
        /* HH:MM */
        *p++='0'+t.hour/10; *p++='0'+t.hour%10; *p++=':';
        *p++='0'+t.minute/10; *p++='0'+t.minute%10; *p=0;
        gui_draw_str(W-50,H-20,buf,COL_LGRAY,COL_TASKBAR);
    }
}
