#ifndef FTK_LIBC_H
#define FTK_LIBC_H

#define NULL ((void*)0)
#define FD_STDIN   0
#define FD_STDOUT  1
#define FD_STDERR  2

typedef long ssize_t;
typedef unsigned long size_t;

/* Syscall wrapper */
static inline long __syscall(long nr, long a0, long a1, long a2) {
    long ret;
    __asm__ volatile("syscall"
        : "=a"(ret)
        : "a"(nr), "D"(a0), "S"(a1), "d"(a2)
        : "rcx", "r11", "memory");
    return ret;
}

#define SYS_EXIT     0
#define SYS_WRITE    1
#define SYS_READ     2
#define SYS_GETPID   3
#define SYS_BRK      6
#define SYS_EXEC     7
#define SYS_READFILE 8
#define SYS_LISTDIR  9
#define SYS_OPEN     10
#define SYS_CLOSE    11
#define SYS_SPAWN    12
#define SYS_PS       13
#define SYS_WAITPID  14
#define SYS_GETDENTS 15
#define SYS_PIPE     16
#define SYS_DUP2     17

/* stdio */
int printf(const char *fmt, ...);
int putchar(int c);
int puts(const char *s);

/* stdlib */
void *malloc(unsigned long size);
void free(void *ptr);
void exit(int status);

/* string */
int strcmp(const char *a, const char *b);
int strncmp(const char *a, const char *b, unsigned long n);
unsigned long strlen(const char *s);
char *strcpy(char *dst, const char *src);
char *strncpy(char *dst, const char *src, unsigned long n);
void *memcpy(void *dst, const void *src, unsigned long n);
void *memset(void *dst, int c, unsigned long n);

#endif
